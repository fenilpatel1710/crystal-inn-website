﻿CREATE TABLE [dbo].[tblHotel] (
    [HotelID]                 INT              IDENTITY (1, 1) NOT NULL,
    [HotelCode]               AS               ('H'+CONVERT([varchar](9),[HotelID])),
    [HotelUniqueID]           UNIQUEIDENTIFIER CONSTRAINT [DF_tblHotel_HotelUniqueID] DEFAULT (newsequentialid()) NULL,
    [BusinessLLCName]         VARCHAR (40)     NOT NULL,
    [Email]                   VARCHAR (50)     NOT NULL,
    [MobileNumber]            VARCHAR (20)     NOT NULL,
    [Address1]                VARCHAR (MAX)    NULL,
    [Address2]                VARCHAR (MAX)    NULL,
    [StateID]                 INT              NULL,
    [City]                    VARCHAR (20)     NULL,
    [ZipCode]                 VARCHAR (15)     NULL,
    [Website]                 VARCHAR (90)     NULL,
    [Description]             VARCHAR (MAX)    NULL,
    [IsHotelVerified]         BIT              CONSTRAINT [DF_tblHotel_IsHotelVerified] DEFAULT ((0)) NOT NULL,
    [IsHotelActive]           BIT              CONSTRAINT [DF_tblHotel_IsHotelActive] DEFAULT ((0)) NOT NULL,
    [IsOwnerDashboardVisible] BIT              CONSTRAINT [DF_tblHotel_IsOwnerDashboardVisible] DEFAULT ((0)) NOT NULL,
    [IsHotelBlocked]          BIT              CONSTRAINT [DF_tblHotel_IsHotelBlocked] DEFAULT ((0)) NOT NULL,
    [IsHotelDeleted]          BIT              CONSTRAINT [DF_tblHotel_IsHotelDeleted] DEFAULT ((0)) NOT NULL,
    [CreatedBy]               INT              NULL,
    [CreatedDate]             DATETIME         NULL,
    [UpdatedBy]               INT              NULL,
    [UpdatedDate]             DATETIME         NULL,
    [DeletedBy]               INT              NULL,
    [DeletedDate]             DATETIME         NULL,
    CONSTRAINT [PK_tblHotel] PRIMARY KEY CLUSTERED ([HotelID] ASC),
    CONSTRAINT [FK_tblHotel_tblState] FOREIGN KEY ([StateID]) REFERENCES [dbo].[tblState] ([StateID])
);















GO
