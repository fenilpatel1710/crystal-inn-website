﻿CREATE TABLE [dbo].[tblHotelUser] (
    [HotelUserID]        INT      IDENTITY (1, 1) NOT NULL,
    [HotelID]            INT      NOT NULL,
    [UserID]             INT      NOT NULL,
    [IsHotelUserActive]  BIT      CONSTRAINT [DF_tblHotelUser_IsHotelUserActive] DEFAULT ((0)) NOT NULL,
    [IsHotelUserBlocked] BIT      CONSTRAINT [DF_tblHotelUser_IsHotelUserBlocked] DEFAULT ((0)) NOT NULL,
    [IsHotelUserDeleted] BIT      CONSTRAINT [DF_tblHotelUser_IsHotelUserDeleted] DEFAULT ((0)) NOT NULL,
    [CreatedBy]          INT      NULL,
    [CreatedDate]        DATETIME NULL,
    [UpdatedBy]          INT      NULL,
    [UpdatedDate]        DATETIME NULL,
    [DeletedBy]          INT      NULL,
    [DeletedDate]        DATETIME NULL,
    CONSTRAINT [PK_tblHotelUser] PRIMARY KEY CLUSTERED ([HotelUserID] ASC),
    CONSTRAINT [FK_tblHotelUser_tblHotel] FOREIGN KEY ([HotelID]) REFERENCES [dbo].[tblHotel] ([HotelID]),
    CONSTRAINT [FK_tblHotelUser_tblUser] FOREIGN KEY ([UserID]) REFERENCES [dbo].[tblUser] ([UserID])
);

