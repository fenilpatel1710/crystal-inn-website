﻿CREATE TABLE [dbo].[tblHotelAdditionalRate] (
    [HotelAdditionalRateID]  INT          IDENTITY (1, 1) NOT NULL,
    [HotelID]                INT          NOT NULL,
    [AdditionalRateName]     VARCHAR (50) NULL,
    [AdditionalRate]         DECIMAL (18) NULL,
    [IsDiscountedRate]       BIT          CONSTRAINT [DF_tblHotelAdditionalRate_IsDiscountedRate] DEFAULT ((0)) NOT NULL,
    [IsAdditionalRateActive] BIT          CONSTRAINT [DF_tblHotelAdditionalRate_IsAdditionalRateActive] DEFAULT ((0)) NOT NULL,
    [CreatedBy]              INT          NULL,
    [CreatedDate]            DATETIME     NULL,
    [UpdatedBy]              INT          NULL,
    [UpdatedDate]            DATETIME     NULL,
    [DeletedBy]              INT          NULL,
    [DeletedDate]            DATETIME     NULL,
    CONSTRAINT [PK_tblHotelAdditionalRate] PRIMARY KEY CLUSTERED ([HotelAdditionalRateID] ASC),
    CONSTRAINT [FK_tblHotelAdditionalRate_tblHotel] FOREIGN KEY ([HotelID]) REFERENCES [dbo].[tblHotel] ([HotelID])
);

