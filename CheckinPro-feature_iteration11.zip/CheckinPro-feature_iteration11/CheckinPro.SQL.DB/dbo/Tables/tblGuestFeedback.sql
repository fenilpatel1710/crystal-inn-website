﻿CREATE TABLE [dbo].[tblGuestFeedback] (
    [GuestFeedbackID] INT           IDENTITY (1, 1) NOT NULL,
    [GuestID]         INT           NOT NULL,
    [HotelID]         INT           NOT NULL,
    [Rating]          INT           NULL,
    [Feedback]        VARCHAR (MAX) NULL,
    [FeedbackDate]    DATETIME      NULL,
    [CreatedBy]       INT           NULL,
    [CreatedDate]     DATETIME      NULL,
    [UpdatedBy]       INT           NULL,
    [UpdatedDate]     DATETIME      NULL,
    [DeletedBy]       INT           NULL,
    [DeletedDate]     DATETIME      NULL,
    CONSTRAINT [PK_tblGuestFeedback] PRIMARY KEY CLUSTERED ([GuestFeedbackID] ASC),
    CONSTRAINT [FK_tblGuestFeedback_tblGuest] FOREIGN KEY ([GuestID]) REFERENCES [dbo].[tblGuest] ([GuestID]),
    CONSTRAINT [FK_tblGuestFeedback_tblHotel] FOREIGN KEY ([HotelID]) REFERENCES [dbo].[tblHotel] ([HotelID])
);

