﻿CREATE TABLE [dbo].[tblHotelRoomBookingTaxRate] (
    [HotelRoomBookingTaxRateID]    INT             IDENTITY (1, 1) NOT NULL,
    [HotelRoomBookingID]           INT             NOT NULL,
    [HotelRoomBookingRateDetailID] INT             NOT NULL,
    [HotelTaxRateID]               INT             NULL,
    [BookingTaxRateName]           VARCHAR (50)    NULL,
    [BookingTaxRatePercentage]     DECIMAL (4)     NULL,
    [BookingTaxRate]               DECIMAL (18, 2) NULL,
    [IsBookingTaxRateActive]       BIT             CONSTRAINT [DF_tblHotelRoomBookingTaxRate_IsBookingTaxRateActive] DEFAULT ((1)) NOT NULL,
    [CreatedBy]                    INT             NULL,
    [CreatedDate]                  DATETIME        NULL,
    [UpdatedBy]                    INT             NULL,
    [UpdatedDate]                  DATETIME        NULL,
    [DeletedBy]                    INT             NULL,
    [DeletedDate]                  DATETIME        NULL,
    CONSTRAINT [PK_tblHotelRoomBookingTaxRate] PRIMARY KEY CLUSTERED ([HotelRoomBookingTaxRateID] ASC),
    CONSTRAINT [FK_tblHotelRoomBookingTaxRate_tblHotelRoomBooking] FOREIGN KEY ([HotelRoomBookingID]) REFERENCES [dbo].[tblHotelRoomBooking] ([HotelRoomBookingID]),
    CONSTRAINT [FK_tblHotelRoomBookingTaxRate_tblHotelRoomBookingRateDetail] FOREIGN KEY ([HotelRoomBookingRateDetailID]) REFERENCES [dbo].[tblHotelRoomBookingRateDetail] ([HotelRoomBookingRateDetailID]),
    CONSTRAINT [FK_tblHotelRoomBookingTaxRate_tblHotelTaxRate] FOREIGN KEY ([HotelTaxRateID]) REFERENCES [dbo].[tblHotelTaxRate] ([HotelTaxRateID])
);

