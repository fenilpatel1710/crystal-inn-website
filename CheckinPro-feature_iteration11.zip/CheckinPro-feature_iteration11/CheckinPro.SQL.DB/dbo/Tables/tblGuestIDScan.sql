﻿CREATE TABLE [dbo].[tblGuestIDScan] (
    [ScanID]             INT              IDENTITY (1, 1) NOT NULL,
    [HotelUniqueID]      UNIQUEIDENTIFIER NULL,
    [Document_Number]    VARCHAR (50)     NULL,
    [Document_Scan_Date] DATETIME         NULL,
    [Scanner_JSON_File]  NVARCHAR (MAX)   NULL,
    [Scanner_XML_File]   XML              NULL,
    [CreatedDate]        DATETIME         NULL,
    CONSTRAINT [PK_tblHotelGuestIDScan] PRIMARY KEY CLUSTERED ([ScanID] ASC)
);

