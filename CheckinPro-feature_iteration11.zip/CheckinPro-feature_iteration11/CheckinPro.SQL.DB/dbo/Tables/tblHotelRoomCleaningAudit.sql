﻿CREATE TABLE [dbo].[tblHotelRoomCleaningAudit] (
    [HotelRoomCleaningAuditID] INT           IDENTITY (1, 1) NOT NULL,
    [HotelRoomBookingID]       INT           NULL,
    [HotelRoomID]              INT           NULL,
    [CheckOutComment]          VARCHAR (300) NULL,
    [IsRoomClean]              BIT           CONSTRAINT [DF_tblHotelRoomCleaningAudit_IsRoomClean] DEFAULT ((0)) NOT NULL,
    [ActionDateTime]           DATETIME      NULL,
    [ActionBy]                 VARCHAR (50)  NULL,
    [ActionComment]            VARCHAR (300) NULL,
    CONSTRAINT [PK_tblHotelRoomCleaningAudit] PRIMARY KEY CLUSTERED ([HotelRoomCleaningAuditID] ASC),
    CONSTRAINT [FK_tblHotelRoomCleaningAudit_tblHotelRoom] FOREIGN KEY ([HotelRoomID]) REFERENCES [dbo].[tblHotelRoom] ([HotelRoomID]),
    CONSTRAINT [FK_tblHotelRoomCleaningAudit_tblHotelRoomBooking] FOREIGN KEY ([HotelRoomBookingID]) REFERENCES [dbo].[tblHotelRoomBooking] ([HotelRoomBookingID])
);

