﻿CREATE TABLE [dbo].[tblGuestReward] (
    [GuestRewardID]    INT          IDENTITY (1, 1) NOT NULL,
    [GuestID]          INT          NULL,
    [HotelID]          INT          NULL,
    [TotalRewardPoint] DECIMAL (18) NULL,
    [CreatedBy]        INT          NULL,
    [CreatedDate]      DATETIME     NULL,
    [UpdatedBy]        INT          NULL,
    [UpdatedDate]      DATETIME     NULL,
    [DeletedBy]        INT          NULL,
    [DeletedDate]      DATETIME     NULL,
    CONSTRAINT [PK_tblGuestReward] PRIMARY KEY CLUSTERED ([GuestRewardID] ASC)
);

