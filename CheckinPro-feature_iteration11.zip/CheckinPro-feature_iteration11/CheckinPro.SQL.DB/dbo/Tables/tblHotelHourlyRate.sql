﻿CREATE TABLE [dbo].[tblHotelHourlyRate] (
    [HotelHourlyRateID]       INT             IDENTITY (1, 1) NOT NULL,
    [HotelID]                 INT             NOT NULL,
    [Hour]                    INT             NULL,
    [HourlyRate]              DECIMAL (18, 2) NULL,
    [IsHotelHourlyRateActive] BIT             CONSTRAINT [DF_tblHotelHourlyRate_IsHotelHourlyRateActive] DEFAULT ((0)) NOT NULL,
    [CreatedBy]               INT             NULL,
    [CreatedDate]             DATETIME        NULL,
    [UpdatedBy]               INT             NULL,
    [UpdatedDate]             DATETIME        NULL,
    [DeletedBy]               INT             NULL,
    [DeletedDate]             DATETIME        NULL,
    CONSTRAINT [PK_tblHotelHourlyRate] PRIMARY KEY CLUSTERED ([HotelHourlyRateID] ASC),
    CONSTRAINT [FK_tblHotelHourlyRate_tblHotel] FOREIGN KEY ([HotelID]) REFERENCES [dbo].[tblHotel] ([HotelID])
);

