﻿CREATE TABLE [dbo].[tblHotelRoom] (
    [HotelRoomID]        INT           IDENTITY (1, 1) NOT NULL,
    [HotelID]            INT           NOT NULL,
    [HotelRoomTypeID]    INT           NOT NULL,
    [RoomNumber]         VARCHAR (20)  NULL,
    [Floor]              INT           NULL,
    [MaxOccupancy]       INT           NULL,
    [RoomStatus]         VARCHAR (20)  NULL,
    [Description]        VARCHAR (MAX) NULL,
    [IsHotelRoomActive]  BIT           CONSTRAINT [DF_tblHotelRoom_IsHotelRoomActive] DEFAULT ((0)) NOT NULL,
    [IsHotelRoomDeleted] BIT           CONSTRAINT [DF_tblHotelRoom_IsHotelRoomDeleted] DEFAULT ((0)) NOT NULL,
    [CreatedBy]          INT           NULL,
    [CreatedDate]        DATETIME      NULL,
    [UpdatedBy]          INT           NULL,
    [UpdatedDate]        DATETIME      NULL,
    [DeletedBy]          INT           NULL,
    [DeletedDate]        DATETIME      NULL,
    CONSTRAINT [PK_tblHotelRoom] PRIMARY KEY CLUSTERED ([HotelRoomID] ASC),
    CONSTRAINT [FK_tblHotelRoom_tblHotel] FOREIGN KEY ([HotelID]) REFERENCES [dbo].[tblHotel] ([HotelID]),
    CONSTRAINT [FK_tblHotelRoom_tblHotelRoomType] FOREIGN KEY ([HotelRoomTypeID]) REFERENCES [dbo].[tblHotelRoomType] ([HotelRoomTypeID])
);

