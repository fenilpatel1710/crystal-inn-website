﻿CREATE TABLE [dbo].[tblGuestIDScanAudit] (
    [ScanAuditID]    INT           IDENTITY (1, 1) NOT NULL,
    [ScanID]         INT           NULL,
    [ActionDateTime] DATETIME      NULL,
    [ActionComment]  VARCHAR (300) NULL,
    CONSTRAINT [PK_tblGuestIDScanAudit] PRIMARY KEY CLUSTERED ([ScanAuditID] ASC)
);

