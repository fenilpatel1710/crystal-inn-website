﻿CREATE TABLE [dbo].[tblGuestRewardHistory] (
    [GuestRewardHistoryID]    INT          IDENTITY (1, 1) NOT NULL,
    [HotelRoomBookingGuestID] INT          NULL,
    [EarnedRewardPoint]       DECIMAL (18) NULL,
    [CreatedBy]               INT          NULL,
    [CreatedDate]             DATETIME     NULL,
    [UpdatedBy]               INT          NULL,
    [UpdatedDate]             DATETIME     NULL,
    [DeletedBy]               INT          NULL,
    [DeletedDate]             DATETIME     NULL,
    CONSTRAINT [PK_tblGuestRewardHistory] PRIMARY KEY CLUSTERED ([GuestRewardHistoryID] ASC)
);

