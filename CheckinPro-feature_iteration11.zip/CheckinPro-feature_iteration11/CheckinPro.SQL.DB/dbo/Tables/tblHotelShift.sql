﻿CREATE TABLE [dbo].[tblHotelShift] (
    [HotelShiftID]      INT             IDENTITY (1, 1) NOT NULL,
    [HotelID]           INT             NOT NULL,
    [ShiftNo]           INT             NULL,
    [StartDate]         DATETIME        NULL,
    [EndDate]           DATETIME        NULL,
    [StartingCash]      DECIMAL (18, 2) NULL,
    [TotalCashReceived] DECIMAL (18, 2) NULL,
    [DropCash]          DECIMAL (18, 2) NULL,
    [EndingCash]        DECIMAL (18, 2) NULL,
    [EndingCashDrawer]  DECIMAL (18, 2) NULL,
    [IsShiftActive]     BIT             CONSTRAINT [DF_tblHotelShift_IsShiftActive] DEFAULT ((0)) NOT NULL,
    [CreatedBy]         INT             NULL,
    [CreatedDate]       DATETIME        NULL,
    [UpdatedBy]         INT             NULL,
    [UpdatedDate]       DATETIME        NULL,
    [DeletedBy]         INT             NULL,
    [DeletedDate]       DATETIME        NULL,
    CONSTRAINT [PK_tblHotelShift] PRIMARY KEY CLUSTERED ([HotelShiftID] ASC),
    CONSTRAINT [FK_tblHotelShift_tblHotel] FOREIGN KEY ([HotelID]) REFERENCES [dbo].[tblHotel] ([HotelID])
);

