﻿CREATE TABLE [dbo].[tblHotelDailyRate] (
    [HotelDailyRateID]       INT             IDENTITY (1, 1) NOT NULL,
    [HotelID]                INT             NOT NULL,
    [DailyRateDate]          DATE            NULL,
    [DailyBestAvailableRate] DECIMAL (18, 2) NULL,
    [IsDailyRateActive]      BIT             CONSTRAINT [DF_tblHotelDailyRate_IsDailyRateActive] DEFAULT ((0)) NOT NULL,
    [CreatedBy]              INT             NULL,
    [CreatedDate]            DATETIME        NULL,
    [UpdatedBy]              INT             NULL,
    [UpdatedDate]            DATETIME        NULL,
    [DeletedBy]              INT             NULL,
    [DeletedDate]            DATETIME        NULL,
    CONSTRAINT [PK_tblHotelDailyRate] PRIMARY KEY CLUSTERED ([HotelDailyRateID] ASC),
    CONSTRAINT [FK_tblHotelDailyRate_tblHotel] FOREIGN KEY ([HotelID]) REFERENCES [dbo].[tblHotel] ([HotelID])
);

