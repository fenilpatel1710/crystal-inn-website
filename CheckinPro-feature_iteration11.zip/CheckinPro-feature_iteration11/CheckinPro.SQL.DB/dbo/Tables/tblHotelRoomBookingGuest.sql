﻿CREATE TABLE [dbo].[tblHotelRoomBookingGuest] (
    [HotelRoomBookingGuestID] INT      IDENTITY (1, 1) NOT NULL,
    [HotelRoomBookingID]      INT      NULL,
    [GuestID]                 INT      NULL,
    [IsPrimaryGuest]          BIT      CONSTRAINT [DF_tblHotelRoomBookingGuest_IsPrimaryGuest] DEFAULT ((0)) NOT NULL,
    [CreatedBy]               INT      NULL,
    [CreatedDate]             DATETIME NULL,
    [UpdatedBy]               INT      NULL,
    [UpdatedDate]             DATETIME NULL,
    [DeletedBy]               INT      NULL,
    [DeletedDate]             DATETIME NULL,
    CONSTRAINT [PK_tblHotelRoomBookingGuest] PRIMARY KEY CLUSTERED ([HotelRoomBookingGuestID] ASC),
    CONSTRAINT [FK_tblHotelRoomBookingGuest_tblGuest] FOREIGN KEY ([GuestID]) REFERENCES [dbo].[tblGuest] ([GuestID]),
    CONSTRAINT [FK_tblHotelRoomBookingGuest_tblHotelRoomBooking] FOREIGN KEY ([HotelRoomBookingID]) REFERENCES [dbo].[tblHotelRoomBooking] ([HotelRoomBookingID])
);

