﻿CREATE TABLE [dbo].[tblHotelTaxRate] (
    [HotelTaxRateID]  INT          IDENTITY (1, 1) NOT NULL,
    [HotelID]         INT          NOT NULL,
    [TaxName]         VARCHAR (50) NULL,
    [TaxRate]         DECIMAL (4)  NULL,
    [IsTaxRateActive] BIT          CONSTRAINT [DF_tblHotelTaxRate_IsTaxRateActive] DEFAULT ((0)) NOT NULL,
    [CreatedBy]       INT          NULL,
    [CreatedDate]     DATETIME     NULL,
    [UpdatedBy]       INT          NULL,
    [UpdatedDate]     DATETIME     NULL,
    [DeletedBy]       INT          NULL,
    [DeletedDate]     DATETIME     NULL,
    CONSTRAINT [PK_tblHotelTaxRate] PRIMARY KEY CLUSTERED ([HotelTaxRateID] ASC),
    CONSTRAINT [FK_tblHotelTaxRate_tblHotel] FOREIGN KEY ([HotelID]) REFERENCES [dbo].[tblHotel] ([HotelID])
);

