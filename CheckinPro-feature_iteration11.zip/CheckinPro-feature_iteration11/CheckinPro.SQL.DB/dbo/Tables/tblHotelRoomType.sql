﻿CREATE TABLE [dbo].[tblHotelRoomType] (
    [HotelRoomTypeID]       INT             IDENTITY (1, 1) NOT NULL,
    [HotelID]               INT             NOT NULL,
    [RoomTypeName]          VARCHAR (90)    NULL,
    [Description]           VARCHAR (MAX)   NULL,
    [RoomTypeIcon]          VARCHAR (50)    NULL,
    [AdjustmentRate]        DECIMAL (18, 2) NULL,
    [IsHotelRoomTypeActive] BIT             CONSTRAINT [DF_tblHotelRoomType_IsRoomTypeActive] DEFAULT ((0)) NOT NULL,
    [CreatedBy]             INT             NULL,
    [CreatedDate]           DATETIME        NULL,
    [UpdatedBy]             INT             NULL,
    [UpdatedDate]           DATETIME        NULL,
    [DeletedBy]             INT             NULL,
    [DeletedDate]           DATETIME        NULL,
    CONSTRAINT [PK_tblHotelRoomType] PRIMARY KEY CLUSTERED ([HotelRoomTypeID] ASC),
    CONSTRAINT [FK_tblHotelRoomType_tblHotel] FOREIGN KEY ([HotelID]) REFERENCES [dbo].[tblHotel] ([HotelID])
);

