﻿CREATE TABLE [dbo].[tblHotelConfiguration] (
    [HotelMasterConfigurationID] INT             IDENTITY (1, 1) NOT NULL,
    [HotelID]                    INT             NOT NULL,
    [BestAvailableRate]          DECIMAL (18, 2) NULL,
    [CashDrawerAmount]           DECIMAL (18, 2) NULL,
    [CreatedBy]                  INT             NULL,
    [CreatedDate]                DATETIME        NULL,
    [UpdatedBy]                  INT             NULL,
    [UpdatedDate]                DATETIME        NULL,
    [DeletedBy]                  INT             NULL,
    [DeletedDate]                DATETIME        NULL,
    CONSTRAINT [PK_tblHotelMasterConfiguration] PRIMARY KEY CLUSTERED ([HotelMasterConfigurationID] ASC),
    CONSTRAINT [FK_tblHotelConfiguration_tblHotel] FOREIGN KEY ([HotelID]) REFERENCES [dbo].[tblHotel] ([HotelID])
);

