﻿CREATE TABLE [dbo].[tblHotelRoomBookingAudit] (
    [HotelRoomBookingAuditID] INT           IDENTITY (1, 1) NOT NULL,
    [HotelRoomBookingID]      INT           NULL,
    [ActionName]              VARCHAR (100) NULL,
    [ActionDateTime]          DATETIME      NULL,
    [ActionBy]                VARCHAR (50)  NULL,
    [ActionComment]           VARCHAR (500) NULL,
    CONSTRAINT [PK_tblHotelRoomBookingAudit] PRIMARY KEY CLUSTERED ([HotelRoomBookingAuditID] ASC),
    CONSTRAINT [FK_tblHotelRoomBookingAudit_tblHotelRoomBooking] FOREIGN KEY ([HotelRoomBookingID]) REFERENCES [dbo].[tblHotelRoomBooking] ([HotelRoomBookingID])
);

