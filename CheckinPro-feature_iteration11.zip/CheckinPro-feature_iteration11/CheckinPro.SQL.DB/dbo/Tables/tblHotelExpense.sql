﻿CREATE TABLE [dbo].[tblHotelExpense] (
    [HotelExpenseID]     INT             IDENTITY (1, 1) NOT NULL,
    [HotelID]            INT             NOT NULL,
    [ExpenseDate]        DATE            NULL,
    [ExpenseType]        VARCHAR (200)   NULL,
    [ExpenseAmount]      DECIMAL (18, 2) NULL,
    [ExpenseDescription] VARCHAR (MAX)   NULL,
    [Attachment]         VARBINARY (MAX) NULL,
    [CreatedBy]          INT             NULL,
    [CreatedDate]        DATETIME        NULL,
    [UpdatedBy]          INT             NULL,
    [UpdatedDate]        DATETIME        NULL,
    CONSTRAINT [PK_tblHotelExpense] PRIMARY KEY CLUSTERED ([HotelExpenseID] ASC),
    CONSTRAINT [FK_tblHotelExpense_tblHotel] FOREIGN KEY ([HotelID]) REFERENCES [dbo].[tblHotel] ([HotelID])
);

