﻿CREATE TABLE [dbo].[tblEmailTemplate] (
    [EmailTemplateID]       INT           IDENTITY (1, 1) NOT NULL,
    [EmailTemplateName]     VARCHAR (50)  NULL,
    [EmailTemplateSubject]  VARCHAR (100)  NULL,
    [EmailTemplateDesign]   VARCHAR (MAX) NULL,
    [IsEmailTemplateActive] BIT           NULL,
    [CreatedBy]             INT           NULL,
    [CreatedDate]           DATETIME      NULL,
    [UpdatedBy]             INT           NULL,
    [UpdatedDate]           DATETIME      NULL,
    [DeletedBy]             INT           NULL,
    [DeletedDate]           DATETIME      NULL,
    CONSTRAINT [PK_tblEmailTemplate] PRIMARY KEY CLUSTERED ([EmailTemplateID] ASC)
);
 