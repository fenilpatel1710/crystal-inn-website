﻿CREATE TABLE [dbo].[tblHotelRoomBookingMiscDetail] (
    [HotelRoomBookingMiscellaneousID] INT             IDENTITY (1, 1) NOT NULL,
    [HotelRoomBookingID]              INT             NULL,
    [MiscellaneousDate]               DATETIME        NULL,
    [MiscellaneousAmount]             DECIMAL (18, 2) NULL,
    [CreatedBy]                       INT             NULL,
    [CreatedDate]                     DATETIME        NULL,
    [UpdatedBy]                       INT             NULL,
    [UpdatedDate]                     DATETIME        NULL,
    CONSTRAINT [PK_tblHotelRoomBookingMiscellaneous] PRIMARY KEY CLUSTERED ([HotelRoomBookingMiscellaneousID] ASC),
    CONSTRAINT [FK_tblHotelRoomBookingMiscellaneous_tblHotelRoomBookingMiscellaneous] FOREIGN KEY ([HotelRoomBookingID]) REFERENCES [dbo].[tblHotelRoomBooking] ([HotelRoomBookingID])
);

