﻿CREATE PROC [dbo].[sp_GetHotelMetricsByDateRange]
 
    @HotelID INT,
    @StartDate DATE
 
 AS
 BEGIN

-- Derived Dates for CY and LY
DECLARE 
    @StartDate_FirstOfMonth DATE = DATEFROMPARTS(YEAR(@StartDate), MONTH(@StartDate), 1),
    @StartDate_FirstOfYear DATE = DATEFROMPARTS(YEAR(@StartDate), 1, 1),
    @StartDate_LY DATE = DATEADD(YEAR, -1, @StartDate)
DECLARE 
    @StartDate_FirstOfMonth_LY DATE = DATEFROMPARTS(YEAR(@StartDate_LY), MONTH(@StartDate_LY), 1),
    @StartDate_FirstOfYear_LY DATE = DATEFROMPARTS(YEAR(@StartDate_LY), 1, 1);
 
 
-- Final Query: CY + LY Vertical Output
SELECT
    'DTY_CY' AS MetricType,
    @StartDate AS [Date],
    COUNT(*) AS RoomSold,
    ISNULL(SUM(BRD.RoomChargeAmount),0) AS Revenue,
    CAST(ISNULL(SUM(BRD.RoomChargeAmount) * 1.0 / NULLIF(COUNT(*), 0),0) AS DECIMAL(10,2)) AS ADR,
    CAST(COUNT(*) * 1.0 / NULLIF((SELECT COUNT(*) FROM tblHotelRoom WHERE HotelID = @HotelID), 0) * 100 AS DECIMAL(8,2)) AS Occupancy,
    CAST(ISNULL(SUM(BRD.RoomChargeAmount) * 1.0 / NULLIF((SELECT COUNT(*) FROM tblHotelRoom WHERE HotelID = @HotelID), 0), 0) AS DECIMAL(10,2)) AS RevPAR
FROM tblHotelRoomBooking B
LEFT JOIN tblHotelRoomBookingRateDetail BRD ON B.HotelRoomBookingID = BRD.HotelRoomBookingID
INNER JOIN tblHotelRoomType T ON B.HotelRoomTypeID = T.HotelRoomTypeID
WHERE B.BookingStatus NOT IN ('Booked', 'Cancelled')
    AND T.HotelID = @HotelID
    AND CAST(BRD.CheckInDate AS DATE) = @StartDate
 
UNION ALL
 
SELECT
    'DTY_LY', 
	@StartDate_LY, 
	COUNT(*), 
	ISNULL(SUM(BRD.RoomChargeAmount), 0),
    CAST(ISNULL(SUM(BRD.RoomChargeAmount) * 1.0 / NULLIF(COUNT(*), 0), 0) AS DECIMAL(10,2)),
    CAST(COUNT(*) * 1.0 / NULLIF((SELECT COUNT(*) FROM tblHotelRoom WHERE HotelID = @HotelID), 0) * 100 AS DECIMAL(8,2)),
    CAST(ISNULL(SUM(BRD.RoomChargeAmount) * 1.0 / NULLIF((SELECT COUNT(*) FROM tblHotelRoom WHERE HotelID = @HotelID), 0), 0) AS DECIMAL(10,2))
FROM tblHotelRoomBooking B
LEFT JOIN tblHotelRoomBookingRateDetail BRD ON B.HotelRoomBookingID = BRD.HotelRoomBookingID
INNER JOIN tblHotelRoomType T ON B.HotelRoomTypeID = T.HotelRoomTypeID
WHERE B.BookingStatus NOT IN ('Booked', 'Cancelled')
    AND T.HotelID = @HotelID
    AND CAST(BRD.CheckInDate AS DATE) = @StartDate_LY
 
UNION ALL
 
SELECT
    'MTD_CY', 
	@StartDate, 
	COUNT(*), 
	ISNULL(SUM(BRD.RoomChargeAmount), 0),
    CAST(ISNULL(SUM(BRD.RoomChargeAmount) * 1.0 / NULLIF(COUNT(*), 0), 0) AS DECIMAL(10,2)),
    CAST(COUNT(*) * 1.0 / NULLIF((SELECT COUNT(*) FROM tblHotelRoom WHERE HotelID = @HotelID), 0) * 100 AS DECIMAL(8,2)),
    CAST(ISNULL(SUM(BRD.RoomChargeAmount) * 1.0 / NULLIF((SELECT COUNT(*) FROM tblHotelRoom WHERE HotelID = @HotelID), 0), 0) AS DECIMAL(10,2))
FROM tblHotelRoomBooking B
LEFT JOIN tblHotelRoomBookingRateDetail BRD ON B.HotelRoomBookingID = BRD.HotelRoomBookingID
INNER JOIN tblHotelRoomType T ON B.HotelRoomTypeID = T.HotelRoomTypeID
WHERE B.BookingStatus NOT IN ('Booked', 'Cancelled')
    AND T.HotelID = @HotelID
    AND CAST(BRD.CheckInDate AS DATE) BETWEEN @StartDate_FirstOfMonth AND @StartDate
 
UNION ALL
 
SELECT
    'MTD_LY', 
	@StartDate_LY, 
	COUNT(*), 
	ISNULL(SUM(BRD.RoomChargeAmount), 0),
    CAST(ISNULL(SUM(BRD.RoomChargeAmount) * 1.0 / NULLIF(COUNT(*), 0), 0) AS DECIMAL(10,2)),
    CAST(COUNT(*) * 1.0 / NULLIF((SELECT COUNT(*) FROM tblHotelRoom WHERE HotelID = @HotelID), 0) * 100 AS DECIMAL(8,2)),
    CAST(ISNULL(SUM(BRD.RoomChargeAmount) * 1.0 / NULLIF((SELECT COUNT(*) FROM tblHotelRoom WHERE HotelID = @HotelID), 0), 0) AS DECIMAL(10,2))
FROM tblHotelRoomBooking B
LEFT JOIN tblHotelRoomBookingRateDetail BRD ON B.HotelRoomBookingID = BRD.HotelRoomBookingID
INNER JOIN tblHotelRoomType T ON B.HotelRoomTypeID = T.HotelRoomTypeID
WHERE B.BookingStatus NOT IN ('Booked', 'Cancelled')
    AND T.HotelID = @HotelID
    AND CAST(BRD.CheckInDate AS DATE) BETWEEN @StartDate_FirstOfMonth_LY AND @StartDate_LY
 
UNION ALL
 
SELECT
    'YTD_CY', 
	@StartDate, 
	COUNT(*), 
	ISNULL(SUM(BRD.RoomChargeAmount), 0),
    CAST(ISNULL(SUM(BRD.RoomChargeAmount) * 1.0 / NULLIF(COUNT(*), 0), 0) AS DECIMAL(10,2)),
    CAST(COUNT(*) * 1.0 / NULLIF((SELECT COUNT(*) FROM tblHotelRoom WHERE HotelID = @HotelID), 0) * 100 AS DECIMAL(8,2)),
    CAST(ISNULL(SUM(BRD.RoomChargeAmount) * 1.0 / NULLIF((SELECT COUNT(*) FROM tblHotelRoom WHERE HotelID = @HotelID), 0), 0) AS DECIMAL(10,2))
FROM tblHotelRoomBooking B
LEFT JOIN tblHotelRoomBookingRateDetail BRD ON B.HotelRoomBookingID = BRD.HotelRoomBookingID
INNER JOIN tblHotelRoomType T ON B.HotelRoomTypeID = T.HotelRoomTypeID
WHERE B.BookingStatus NOT IN ('Booked', 'Cancelled')
    AND T.HotelID = @HotelID
    AND CAST(BRD.CheckInDate AS DATE) BETWEEN @StartDate_FirstOfYear AND @StartDate
 
UNION ALL
 
SELECT
    'YTD_LY', 
	@StartDate_LY, 
	COUNT(*), 
	ISNULL(SUM(BRD.RoomChargeAmount), 0),
    CAST(ISNULL(SUM(BRD.RoomChargeAmount) * 1.0 / NULLIF(COUNT(*), 0), 0) AS DECIMAL(10,2)),
    CAST(COUNT(*) * 1.0 / NULLIF((SELECT COUNT(*) FROM tblHotelRoom WHERE HotelID = @HotelID), 0) * 100 AS DECIMAL(8,2)),
    CAST(ISNULL(SUM(BRD.RoomChargeAmount) * 1.0 / NULLIF((SELECT COUNT(*) FROM tblHotelRoom WHERE HotelID = @HotelID), 0), 0) AS DECIMAL(10,2))
FROM tblHotelRoomBooking B
LEFT JOIN tblHotelRoomBookingRateDetail BRD ON B.HotelRoomBookingID = BRD.HotelRoomBookingID
INNER JOIN tblHotelRoomType T ON B.HotelRoomTypeID = T.HotelRoomTypeID
WHERE B.BookingStatus NOT IN ('Booked', 'Cancelled')
    AND T.HotelID = @HotelID
    AND CAST(BRD.CheckInDate AS DATE) BETWEEN @StartDate_FirstOfYear_LY AND @StartDate_LY;

END;