﻿


CREATE PROCEDURE [dbo].[sp_FindHotelRoomBooking]
    @HotelID INT,
	@BookingCode VARCHAR(12) = NULL,
    @BookingStatus VARCHAR(50) = NULL,
    @HotelRoomTypeID INT = NULL,
    @RoomNumber VARCHAR(50) = NULL,
    @GuestCode VARCHAR(20) = NULL,
    @FirstName VARCHAR(20) = NULL,
    @LastName VARCHAR(20) = NULL,
    @StartDate DATETIME = NULL,
    @EndDate DATETIME = NULL
AS
BEGIN
    SET NOCOUNT ON;

WITH PaymentSummary AS (
    SELECT
        HotelRoomBookingID,
        SUM(COALESCE(Amount, 0)) AS TotalPaid
    FROM tblPayment
    WHERE PaymentStatus = 'Completed'
    GROUP BY HotelRoomBookingID
)

SELECT 
    B.HotelRoomBookingID,
    B.HotelRoomTypeID,
    B.HotelRoomID,
    B.BookingCode,
    CONCAT(G.FirstName, ' ', G.LastName) AS [GuestName],
    RT.RoomTypeName AS [RoomType],
    R.RoomNumber,
    B.ScheduledCheckInDate,
    B.ScheduledCheckOutDate,
	SUM(COALESCE(RD.RoomChargeAmount, 0)) AS [RoomChargeAmount],
    SUM(COALESCE(RD.FinalAmount, 0)) AS [Amount],
    COALESCE(P.TotalPaid, 0) AS [TotalPaid],
    SUM(COALESCE(RD.FinalAmount, 0)) - COALESCE(P.TotalPaid, 0) AS [Balance],
    B.IsHourlyBooking,
    B.BookingStatus
FROM tblHotelRoomBooking B WITH (NOLOCK)
INNER JOIN tblHotelRoomBookingRateDetail RD WITH (NOLOCK) ON RD.HotelRoomBookingID = B.HotelRoomBookingID
INNER JOIN tblHotelRoomType RT WITH (NOLOCK) ON RT.HotelRoomTypeID = B.HotelRoomTypeID
LEFT JOIN tblHotelRoom R WITH (NOLOCK) ON R.HotelRoomID = B.HotelRoomID
INNER JOIN tblHotelRoomBookingGuest BG WITH (NOLOCK) ON BG.HotelRoomBookingID = B.HotelRoomBookingID AND BG.IsPrimaryGuest = 1
INNER JOIN tblGuest G WITH (NOLOCK) ON G.GuestID = BG.GuestID
LEFT JOIN PaymentSummary P WITH (NOLOCK) ON P.HotelRoomBookingID = B.HotelRoomBookingID
WHERE RT.HotelID = @HotelID
	AND (@BookingCode IS NULL OR B.BookingCode = @BookingCode)
    AND (@HotelRoomTypeID IS NULL OR B.HotelRoomTypeID = @HotelRoomTypeID)
    AND (@BookingStatus IS NULL OR B.BookingStatus = @BookingStatus)
    AND (@RoomNumber IS NULL OR R.RoomNumber = @RoomNumber)
    AND (@GuestCode IS NULL OR G.GuestCode = @GuestCode)
    AND (@FirstName IS NULL OR G.FirstName = @FirstName)
    AND (@LastName IS NULL OR G.LastName = @LastName)
    AND (
        (@StartDate IS NULL AND @EndDate IS NULL)
        OR (B.ScheduledCheckInDate >= @StartDate AND B.ScheduledCheckInDate <= @EndDate)
        OR (B.ScheduledCheckOutDate >= @StartDate AND B.ScheduledCheckOutDate <= @EndDate)
        OR (B.ScheduledCheckInDate <= @StartDate AND B.ScheduledCheckOutDate >= @EndDate)
    )
GROUP BY 
    B.HotelRoomBookingID,
    B.HotelRoomTypeID,
    B.HotelRoomID,
    B.BookingCode,
    G.FirstName,
    G.LastName,
    RT.RoomTypeName,
    R.RoomNumber,
    B.ScheduledCheckInDate,
    B.ScheduledCheckOutDate,
    B.IsHourlyBooking,
    B.BookingStatus,
    P.TotalPaid

ORDER BY B.HotelRoomBookingID DESC

END;