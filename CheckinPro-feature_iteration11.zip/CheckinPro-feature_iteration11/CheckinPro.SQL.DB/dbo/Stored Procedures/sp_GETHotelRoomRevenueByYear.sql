﻿CREATE PROCEDURE [dbo].[sp_GETHotelRoomRevenueByYear]
    @HotelID INT,
    @Year INT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @CurrentYear INT = YEAR(GETDATE());
    DECLARE @CurrentMonth INT = MONTH(GETDATE());
    -- Month list
    WITH Months AS (
        SELECT 'January' AS MonthName, 1 AS MonthNum UNION ALL
        SELECT 'February', 2 UNION ALL
        SELECT 'March', 3 UNION ALL
        SELECT 'April', 4 UNION ALL
        SELECT 'May', 5 UNION ALL
        SELECT 'June', 6 UNION ALL
        SELECT 'July', 7 UNION ALL
        SELECT 'August', 8 UNION ALL
        SELECT 'September', 9 UNION ALL
        SELECT 'October', 10 UNION ALL
        SELECT 'November', 11 UNION ALL
        SELECT 'December', 12
    ),
    FilteredBookings AS (
        SELECT 
            hrb.HotelRoomBookingID,
            --p.PaymentCompletedOn,
            --p.Amount
			hrbrd.CheckInDate,
			hrbrd.RoomChargeAmount
        FROM tblHotelRoomBooking hrb
        INNER JOIN tblHotelRoomType hrt
            ON hrb.HotelRoomTypeID = hrt.HotelRoomTypeID
        INNER JOIN tblHotelRoomBookingRateDetail hrbrd
            ON hrb.HotelRoomBookingID = hrbrd.HotelRoomBookingID
        INNER JOIN tblPayment p
            ON hrb.HotelRoomBookingID = p.HotelRoomBookingID
           AND p.PaymentStatus = 'Completed'
        WHERE 
            hrt.HotelID = @HotelID
            AND hrb.BookingStatus NOT IN ('Booked', 'Cancelled')
            AND YEAR(p.PaymentCompletedOn) = @Year
    )
    SELECT 
        m.MonthName,
        ISNULL(SUM(CASE 
            WHEN MONTH(fb.CheckInDate) = m.MonthNum THEN fb.RoomChargeAmount 
            ELSE 0 
        END), 0) AS TotalRevenue
    FROM Months m
    LEFT JOIN FilteredBookings fb
        ON MONTH(fb.CheckInDate) = m.MonthNum
    WHERE 
        m.MonthNum <= CASE 
            WHEN @Year = @CurrentYear THEN @CurrentMonth 
            ELSE 12 
        END
    GROUP BY m.MonthName, m.MonthNum
    ORDER BY m.MonthNum;
END