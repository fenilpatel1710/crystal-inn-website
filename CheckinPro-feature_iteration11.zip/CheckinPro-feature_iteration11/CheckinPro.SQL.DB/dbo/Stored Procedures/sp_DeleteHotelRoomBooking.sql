﻿
CREATE PROCEDURE sp_DeleteHotelRoomBooking
@HotelRoomBookingID VARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @sql NVARCHAR(MAX);
    SET @sql = ' delete from tblPayment where HotelRoomBookingID in (' + @HotelRoomBookingID +');
                 delete from tblHotelRoomBookingGuest where HotelRoomBookingID in (' + @HotelRoomBookingID +');
                 delete from tblHotelRoomCleaningAudit where HotelRoomBookingID in (' + @HotelRoomBookingID +');
                 delete from tblHotelRoomBookingAudit where HotelRoomBookingID in (' + @HotelRoomBookingID +');
                 delete from tblHotelRoomBookingMiscDetail where HotelRoomBookingID in (' + @HotelRoomBookingID +');
                 delete from tblHotelRoomBookingTaxRate where HotelRoomBookingID in (' + @HotelRoomBookingID +');
                 delete from tblHotelRoomBookingRateDetail where HotelRoomBookingID in (' + @HotelRoomBookingID +');
                 delete from tblHotelRoomBooking where HotelRoomBookingID in (' + @HotelRoomBookingID +');
                ';

    EXEC (@sql);
END;