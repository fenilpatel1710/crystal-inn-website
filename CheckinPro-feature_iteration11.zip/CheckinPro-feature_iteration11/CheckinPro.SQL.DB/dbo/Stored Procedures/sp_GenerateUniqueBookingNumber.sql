﻿CREATE PROCEDURE [dbo].[sp_GenerateUniqueBookingNumber]
@BookingNumber NVARCHAR(6) OUTPUT
AS
BEGIN
	-- Declare variables
	DECLARE @letters NCHAR(26)
	SET @letters = N'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
	DECLARE @digits NCHAR(10)
	SET @digits = N'0123456789'
	DECLARE @result NVARCHAR(6)
	DECLARE @isUnique BIT = 0
 
	WHILE @isUnique = 0
		BEGIN
		-- Generate a random 6-character string
		SET @result =
			SUBSTRING(@letters, CAST((RAND() * LEN(@letters)) AS INT) + 1, 1) +
			SUBSTRING(@letters, CAST((RAND() * LEN(@letters)) AS INT) + 1, 1) +
			SUBSTRING(@digits, CAST((RAND() * LEN(@digits)) AS INT) + 1, 1) +
			SUBSTRING(@digits, CAST((RAND() * LEN(@digits)) AS INT) + 1, 1) +
			SUBSTRING(@digits, CAST((RAND() * LEN(@digits)) AS INT) + 1, 1) +
			SUBSTRING(@digits, CAST((RAND() * LEN(@digits)) AS INT) + 1, 1)
 
		-- Check if the generated value already exists
		IF NOT EXISTS (SELECT 1 FROM tblHotelRoomBooking WHERE CONVERT(nvarchar,BookingCode) = @result)
			BEGIN
				SET @isUnique = 1 
			END
	END
	-- Return the unique value
	 SET @BookingNumber = @result
END