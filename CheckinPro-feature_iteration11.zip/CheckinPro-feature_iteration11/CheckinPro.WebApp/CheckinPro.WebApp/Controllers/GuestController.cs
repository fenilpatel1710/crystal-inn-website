﻿using Ardalis.Result;
using Ardalis.Result.AspNetCore;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CheckinPro.WebApp.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [TranslateResultToActionResult]
    [ApiController]
    public class GuestController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IGuestService _guestService;


        public GuestController(ILogger<UserController> logger, IGuestService guestService)
        {
            _logger = logger;
            _guestService = guestService;
        }

        /// <summary>
        /// Retrieves a list of Guests.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetGuestModel"/> representing the guest data.</returns>   
        [HttpGet("GetGuests")]
        public async Task<Result<List<GetGuestModel>>> GetGuestByHotelID(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetGuestByHotelID method initiated.");

                var serviceResult = await _guestService.GetGuestByHotelIDAsync(hotelID);

                _logger.LogInformation("Controller: GetGuestByHotelID method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetGuestByHotelID method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching guests.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific guest by its ID.
        /// </summary>
        /// <param name="guestID">The ID of the guest to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetAmenityModel"/> for the specified guest.</returns>
        [HttpGet("GetGuestById/{guestID}")]
        public async Task<Result<List<GetGuestModel>>> GetGuestById(int guestID)
        {
            try
            {
                _logger.LogInformation("Controller: GetGuestById method initiated.");

                var serviceResult = await _guestService.GetGuestByIdAsyn(guestID);

                _logger.LogInformation("Controller: GetGuestById method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetGuestById method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching guest.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific Guest by its ID.
        /// </summary>
        /// <param name="guestId">The ID of the Guest to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetGuestModel"/> for the specified Guest Id.</returns>
        [HttpGet("GetGuestByCodeOrIdentityNumberOrMobile")]
        public async Task<Result<GetGuestModel>> GetGuestByCodeOrIdentityNumberOrMobile([FromQuery] string? guestCode, [FromQuery] string? identityNumber, [FromQuery] string? mobileNumber)
        {
            try
            {
                _logger.LogInformation("Controller: GetGuestByCodeOrIdentityNumberOrMobile method initiated.");

                var guestModel = await _guestService.GetGuestByCodeOrIdentityNumberOrMobileAsync(guestCode, identityNumber, mobileNumber);

                _logger.LogInformation("Controller: GetGuestByCodeOrIdentityNumberOrMobile method execution completed.");
                return Result.Success(guestModel);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetGuestByCodeOrIdentityNumberOrMobile method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching guests.");
            }
        }


        /// <summary>
        /// Retrieves details of a specific Guest by its mobileNumber.
        /// </summary>
        /// <param name="mobileNumber">The mobileNumber of the Guest to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetGuestModel"/> for the specified Guest mobileNumber.</returns>
        [HttpGet("GetGuestByMobile")]
        public async Task<Result<GetGuestModel>> GetGuestByMobile([FromQuery] string mobileNumber)
        {
            try
            {
                _logger.LogInformation("Controller: GetGuestByMobile method initiated.");

                var guestModel = await _guestService.GetGuestByMobileAsync(mobileNumber);

                _logger.LogInformation("Controller: GetGuestByMobile method execution completed.");
                return Result.Success(guestModel);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetGuestByMobile method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching guests.");
            }
        }

        [HttpGet("GetGuestByName")]
        public async Task<Result<List<GetGuestModel>>> GetGuestByName([FromQuery] string? firstName = null, [FromQuery] string? lastName = null)
        {
            try
            {
                _logger.LogInformation("Controller: GetGuestByName method initiated.");

                var guestModel = await _guestService.GetGuestByNameAsync(firstName, lastName);

                _logger.LogInformation("Controller: GetGuestByName method execution completed.");
                return Result.Success(guestModel);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetGuestByName method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching guests.");
            }
        }

        [HttpGet("GetGuestRewardPoint")]
        public async Task<Result<GuestRewardModel>> GetGuestRewardPoint(int hotelID, int guestID)
        {
            try
            {
                _logger.LogInformation("Controller: GetGuestRewardPoint method initiated.");

                var guestModel = await _guestService.GetGuestRewardPointAsync(hotelID, guestID);

                _logger.LogInformation("Controller: GetGuestRewardPoint method execution completed.");
                return Result.Success(guestModel);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetGuestRewardPoint method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching data.");
            }
        }
    }
}
