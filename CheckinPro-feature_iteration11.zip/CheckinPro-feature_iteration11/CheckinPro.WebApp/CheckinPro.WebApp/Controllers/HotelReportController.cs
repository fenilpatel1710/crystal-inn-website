﻿using Ardalis.Result.AspNetCore;
using Ardalis.Result;
using CheckinPro.Services.IServices;
using CheckinPro.WebApp.Providers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using CheckinPro.WebApi.Models;
using CheckinPro.Services;

namespace CheckinPro.WebApp.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [TranslateResultToActionResult]
    [ApiController]
    public class HotelReportController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IHotelReportService _hotelReportService;
        private readonly ISessionUserService _sessionUserService;

        public HotelReportController(ILogger<HotelReportController> logger, IHotelReportService hotelReportService, ISessionUserService sessionUserService)
        {
            _logger = logger;
            _hotelReportService = hotelReportService;
            _sessionUserService = sessionUserService;
        }


        [HttpGet("PrintBookingReceipt/{hotelRoomBookingID}")]
        public async Task<Result<byte[]>> PrintBookingReceipt(int hotelRoomBookingID)
        {
            try
            {
                _logger.LogInformation($"Controller: PrintBookingReceipt method initiated.");

                var serviceResult = await _hotelReportService.PrintBookingReceiptAsync(hotelRoomBookingID);

                _logger.LogInformation($"Controller: PrintBookingReceipt method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: PrintBookingReceipt method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Print Booking Receipt.");
            }
        }

        [HttpGet("DownloadBookingInvoice/{hotelRoomBookingID}")]
        public async Task<Result<byte[]>> DownloadBookingInvoice(int hotelRoomBookingID)
        {
            try
            {
                _logger.LogInformation($"Controller: DownloadBookingInvoice method initiated.");

                var serviceResult = await _hotelReportService.DownloadBookingInvoiceAsync(hotelRoomBookingID);

                _logger.LogInformation($"Controller: DownloadBookingInvoice method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DownloadBookingInvoice method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Download Booking Invoice.");
            }
        }

        [HttpGet("DownloadDailyAuditReport")]
        public async Task<Result<byte[]>> DownloadDailyAuditReport([FromQuery] int hotelId, [FromQuery] DateOnly fromDate, [FromQuery] DateOnly toDate)
        {
            try
            {
                _logger.LogInformation($"Controller: DownloadDailyAuditReport method initiated.");

                var serviceResult = await _hotelReportService.DownloadDailyAuditReportAsync(hotelId, fromDate, toDate);

                _logger.LogInformation($"Controller: DownloadDailyAuditReport method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DownloadDailyAuditReport method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Download Daily Audit Report.");
            }
        }

        [HttpGet("DownloadRoomTaxCollectedReport")]
        public async Task<Result<byte[]>> DownloadRoomTaxCollectedReport([FromQuery] int hotelId, [FromQuery] DateOnly fromDate, [FromQuery] DateOnly toDate)
        {
            try
            {
                _logger.LogInformation($"Controller: DownloadRoomTaxCollectedReport method initiated.");

                var serviceResult = await _hotelReportService.DownloadRoomTaxCollectedReportAsync(hotelId, fromDate, toDate);

                _logger.LogInformation($"Controller: DownloadRoomTaxCollectedReport method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DownloadRoomTaxCollectedReport method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Download RoomTax Collected Report.");
            }
        }

        [HttpGet("DownloadSummaryIncomeReport")]
        public async Task<Result<byte[]>> DownloadSummaryIncomeReport([FromQuery] int hotelId, [FromQuery] DateOnly fromDate, [FromQuery] DateOnly toDate)
        {
            try
            {
                _logger.LogInformation($"Controller: DownloadSummaryIncomeReport method initiated.");

                var serviceResult = await _hotelReportService.DownloadSummaryIncomeReportAsync(hotelId, fromDate, toDate);

                _logger.LogInformation($"Controller: DownloadSummaryIncomeReport method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DownloadSummaryIncomeReport method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Download Summary Income Report.");
            }
        }

        [HttpGet("DownloadRoomRevenueReport")]
        public async Task<Result<byte[]>> DownloadRoomRevenueReport([FromQuery] int hotelId, [FromQuery] DateOnly fromDate, [FromQuery] DateOnly toDate)
        {
            try
            {
                _logger.LogInformation($"Controller: DownloadRoomRevenueReport method initiated.");

                var serviceResult = await _hotelReportService.DownloadRoomRevenueReportAsync(hotelId, fromDate, toDate);

                _logger.LogInformation($"Controller: DownloadRoomRevenueReport method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DownloadRoomRevenueReport method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Download Room Revenue Report.");
            }
        }

        [HttpGet("DownloadIncomeBreakdownReport")]
        public async Task<Result<byte[]>> DownloadIncomeBreakdownReport([FromQuery] int hotelId, [FromQuery] DateOnly fromDate, [FromQuery] DateOnly toDate)
        {
            try
            {
                _logger.LogInformation($"Controller: DownloadIncomeBreakdownReport method initiated.");

                var serviceResult = await _hotelReportService.DownloadIncomeBreakdownReportAsync(hotelId, fromDate, toDate);

                _logger.LogInformation($"Controller: DownloadIncomeBreakdownReport method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DownloadIncomeBreakdownReport method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Download Download Income Breakdown Report.");
            }
        }

        [HttpGet("DownloadShiftReport")]
        public async Task<Result<byte[]>> DownloadShiftReport([FromQuery] int hotelId, [FromQuery] HotelShiftModel hotelShiftData, [FromQuery] DateOnly fromDate, [FromQuery] DateOnly toDate)
        {
            try
            {
                _logger.LogInformation($"Controller: DownloadShiftReport method initiated.");

                var serviceResult = await _hotelReportService.DownloadShiftReportAsync(hotelId, hotelShiftData, fromDate, toDate);

                _logger.LogInformation($"Controller: DownloadShiftReport method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DownloadShiftReport method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Download Download Shift Report.");
            }
        }

    }
}
