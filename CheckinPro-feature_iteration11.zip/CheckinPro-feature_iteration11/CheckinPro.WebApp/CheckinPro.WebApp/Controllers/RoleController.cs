﻿using Ardalis.Result;
using Ardalis.Result.AspNetCore;
using CheckinPro.Common.Models;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using CheckinPro.WebApp.Providers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CheckinPro.WebApp.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [TranslateResultToActionResult]
    [ApiController]
    public class RoleController : Controller
    {
        private readonly ILogger _logger;
        private readonly IRoleService _roleService;
        private readonly ISessionUserService _sessionUserService;

        public RoleController(ILogger<RoleController> logger, IRoleService roleService, ISessionUserService sessionUserService)
        {
            _logger = logger;
            _roleService = roleService;
            _sessionUserService = sessionUserService;
        }


        [HttpGet("GetRoles")]
        public async Task<Result<List<RoleModel>>> GetRoles()
        {
            try
            {
                _logger.LogInformation("Controller: GetRoles method initiated.");

                var roleModels = await _roleService.GetRolesAsync();

                _logger.LogInformation("Controller: GetRoles method execution completed.");
                return Result.Success(roleModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetRoles method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while getting the role.");
            }
        }

        [HttpGet("GetRoleById/{roleId}")]
        public async Task<Result<RoleModel>> GetRoleById(int roleId)
        {
            try
            {
                _logger.LogInformation("Controller: GetRoleById method initiated.");

                var roleModel = await _roleService.GetRoleByIdAsync(roleId);

                _logger.LogInformation("Controller: GetRoleById method execution completed.");
                return Result.Success(roleModel);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetRoleById method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while updating the role.");
            }
        }

        [HttpPut("UpdateRole/{roleId}")]
        public async Task<Result> UpdateRole(int roleId, [FromBody] RoleModel roleRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: UpdateRole method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _roleService.UpdateRoleAsync(roleId, roleRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: UpdateRole method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: UpdateRole method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while updating the role.");
            }
        }
    }
}
