﻿using Ardalis.Result;
using Ardalis.Result.AspNetCore;
using CheckinPro.Common.Models;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using CheckinPro.WebApp.Providers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CheckinPro.WebApp.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [TranslateResultToActionResult]
    [ApiController]

    public class HotelRoomBookingController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly ISessionUserService _sessionUserService;
        private readonly IHotelRoomBookingService _hotelRoomBookingService;

        public HotelRoomBookingController(ILogger<HotelRoomBookingController> logger, ISessionUserService sessionUserService, IHotelRoomBookingService hotelRoomBookingService)
        {
            _logger = logger;
            _sessionUserService = sessionUserService;
            _hotelRoomBookingService = hotelRoomBookingService;
        }


        #region HotelRoomBooking

        [HttpGet("GetHotelDailyRateByDate")]
        public async Task<Result<HotelDailyRateModel>> GetHotelDailyRateByDate([FromQuery] int hotelID, [FromQuery] DateOnly checkInDate)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelDailyRateByDate method initiated.");

                var serviceResult = await _hotelRoomBookingService.GetHotelDailyRateByDateAsync(hotelID, checkInDate);

                _logger.LogInformation("Controller: GetHotelDailyRateByDate method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelDailyRateByDate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel rate.");
            }
        }

        /// <summary>
        /// Get hotel rooms by dates
        /// </summary>
        /// <param name="dates">Check in and check out dates</param>
        /// <returns>containing the <see cref="GetHotelRoomModel"/> for the specified dates</returns>
        [HttpGet("GetHotelRoomsByDates")]
        public async Task<Result<List<HotelRoomModel>>> GetHotelRoomsByDates([FromQuery] int hotelID, [FromQuery] DateTime checkInDate, [FromQuery] DateTime checkOutDate)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelRoomsByDates method initiated.");

                var serviceResult = await _hotelRoomBookingService.GetHotelRoomByDatesAsync(hotelID, checkInDate, checkOutDate);

                _logger.LogInformation("Controller: GetHotelRoomsByDates method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelRoomsByDates method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel rooms.");
            }
        }


        [HttpGet("GetAvailableRoomByDates")]
        public async Task<Result<List<HotelRoomModel>>> GetAvailableRoomByDates([FromQuery] int hotelID, int hotelRoomTypeID, [FromQuery] DateTime checkInDate, [FromQuery] DateTime checkOutDate)
        {
            try
            {
                _logger.LogInformation("Controller: GetAvailableRoomByDates method initiated.");

                var serviceResult = await _hotelRoomBookingService.GetAvailableRoomByDatesAsync(hotelID, hotelRoomTypeID, checkInDate, checkOutDate);

                _logger.LogInformation("Controller: GetAvailableRoomByDates method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetAvailableRoomByDates method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel rooms.");
            }
        }



        /// <summary>
        /// Retrieves a list of booked hotel rooms having check-out today.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelRoomBookingModel"/> representing all booked hotel rooms data having check-out today.</returns>
        [HttpGet("GetTodaysCheckOutRoomsByHotelID/{hotelID}")]
        public async Task<Result<List<GetHotelRoomBookingModel>>> GetTodaysCheckOutRoomsByHotelID(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetTodaysCheckOutRoomsByHotelID method initiated.");

                var serviceResult = await _hotelRoomBookingService.GetTodaysCheckOutRoomsByHotelIDAsync(hotelID);

                _logger.LogInformation("Controller: GetTodaysCheckOutRoomsByHotelID method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetTodaysCheckOutRoomsByHotelID method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching check-out hotel rooms.");
            }
        }

        [HttpGet("GetTodaysBookingsByHotelID/{hotelID}")]
        public async Task<Result<List<GetHotelRoomBookingModel>>> GetTodaysBookingsByHotelID(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetTodaysBookingsByHotelID method initiated.");

                var serviceResult = await _hotelRoomBookingService.GetTodaysBookingsByHotelIDAsync(hotelID);

                _logger.LogInformation("Controller: GetTodaysBookingsByHotelID method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetTodaysBookingsByHotelID method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching check-out hotel rooms.");
            }
        }


        /// <summary> 
        /// Adds a new hotel room booking record based on the provided hotelRoomBookingRequestModel.
        /// </summary>
        /// <param name="hotelRoomBookingRequestModel">The <see cref="HotelRoomBookingModel"/> containing data for the new hotel room booking.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel room booking creation operation.</returns>
        [HttpGet("GetMobileNumbers")]
        public async Task<Result<List<string>>> GetMobileNumbers(string searchTerm = null)
        {
            try
            {
                _logger.LogInformation("Controller: GetMobileNumbers method initiated.");
                var serviceResult = await _hotelRoomBookingService.GetMobileNumbersAsync(searchTerm);
                _logger.LogInformation("Controller: GetMobileNumbers method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetMobileNumbers method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching mobile numbers.");
            }
        }


        /// <summary>
        /// Retrieves a list of booked hotel rooms.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelRoomBookingModel"/> representing all booked hotel rooms data.</returns>
        [HttpGet("GetBookedHotelRoomsByHotelID/{hotelID}")]
        public async Task<Result<List<GetHotelRoomBookingModel>>> GetBookedHotelRoomsByHotelID(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetBookedHotelRoomsByHotelID method initiated.");

                var serviceResult = await _hotelRoomBookingService.GetBookedHotelRoomsAsync(hotelID);

                _logger.LogInformation("Controller: GetBookedHotelRoomsByHotelID method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetBookedHotelRoomsByHotelID method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel rooms.");
            }
        }

        [HttpGet("GetAvailableRoomTypes")]
        public async Task<Result<List<HotelRoomTypeModel>>> GetAvailableRoomTypes(int hotelID, DateTime checkInDate, DateTime checkOutDate)
        {
            try
            {
                _logger.LogInformation("Controller: GetAvailableRoomTypes method initiated for HotelID: {HotelID}", hotelID);
                var serviceResult = await _hotelRoomBookingService.GetAvailableRoomTypesAsync(hotelID, checkInDate, checkOutDate);
                _logger.LogInformation("Controller: GetAvailableRoomTypes method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetAvailableRoomTypes method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching available room types.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific room booking details by its room booking ID.
        /// </summary>
        /// <param name="hotelRoomBookingID">The ID of the hotel room booking to be retrieved.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetHotelRoomBookingModel"/> for the specified hotel room booking Id.</returns>
        [HttpGet("GetRoomBookingDetailsByID/{hotelRoomBookingID}")]
        public async Task<Result<HotelRoomBookingModel>> GetRoomBookingDetailsByID(int hotelRoomBookingID)
        {
            try
            {
                _logger.LogInformation("Controller: GetRoomBookingDetailsByID method initiated.");

                var serviceResult = await _hotelRoomBookingService.GetRoomBookingDetailsByIDAsync(hotelRoomBookingID);

                _logger.LogInformation("Controller: GetRoomBookingDetailsByID method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetRoomBookingDetailsByID method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel room rate by Id.");
            }
        }

        /// <summary> 
        /// Adds a new hotel room booking record based on the provided hotelRoomBookingRequestModel.
        /// </summary>
        /// <param name="hotelRoomBookingRequestModel">The <see cref="HotelRoomBookingModel"/> containing data for the new hotel room booking.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel room booking creation operation.</returns>
        [HttpPost("AddHotelRoomBooking")]
        public async Task<Result<int>> AddHotelRoomBooking([FromBody] HotelRoomBookingModel hotelRoomBookingRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: AddHotelRoomBooking method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserName = _sessionUserService.GetUserName();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.AddHotelRoomBookingAsync(hotelRoomBookingRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: AddHotelRoomBooking method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddHotelRoomBooking method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking details.");
            }
        }


        [HttpPut("UpdateHotelRoomBooking")]
        public async Task<Result> UpdateHotelRoomBooking([FromBody] HotelRoomBookingModel hotelRoomBookingRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: UpdateHotelRoomBooking method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.UpdateHotelRoomBookingAsync(hotelRoomBookingRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: UpdateHotelRoomBooking method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: UpdateHotelRoomBooking method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking details.");
            }
        }

        [HttpPut("UpdateHotelRoomBookingTotalAmount")]
        public async Task<Result> UpdateHotelRoomBookingTotalAmount([FromBody] HotelRoomBookingRateDetailModel hotelRoomBookingRateDetailRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: UpdateHotelRoomBookingTotalAmount method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserName = _sessionUserService.GetUserName();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.UpdateHotelRoomBookingTotalAmountAsync(hotelRoomBookingRateDetailRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: UpdateHotelRoomBookingTotalAmount method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: UpdateHotelRoomBookingTotalAmount method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while updating the hotel room booking TotalAmount.");
            }
        }

        [HttpPut("RoomCheckIn/{hotelRoomBookingID}/{hotelRoomID}")]
        public async Task<Result> RoomCheckIn(int hotelRoomBookingID, int hotelRoomID)
        {
            try
            {
                _logger.LogInformation("Controller: RoomCheckIn method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserName = _sessionUserService.GetUserName();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.RoomCheckInAsync(hotelRoomBookingID, hotelRoomID, auditInfoModel);

                _logger.LogInformation("Controller: RoomCheckIn method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: RoomCheckIn method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Room CheckIn.");
            }
        }

        [HttpPut("RoomChange")]
        public async Task<Result> RoomChange([FromBody] RoomChangeModel roomChangeRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: RoomChange method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserName = _sessionUserService.GetUserName();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.RoomChangeAsync(roomChangeRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: RoomChange method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: RoomChange method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Changing Room.");
            }
        }

        [HttpPut("RoomCheckOut")]
        public async Task<Result> RoomCheckOut(UpdateHotelRoomCleaningAuditModel hotelRoomCleaningAuditRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: RoomCheckOut method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserName = _sessionUserService.GetUserName();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.RoomCheckOutAsync(hotelRoomCleaningAuditRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: RoomCheckOut method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: RoomCheckOut method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Room CheckOut.");
            }
        }

        [HttpPut("RoomCheckOutDateChange")]
        public async Task<Result> RoomCheckOutDateChange(HotelRoomBookingRateDetailModel hotelRoomBookingRateDetailRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: RoomCheckOutDateChange method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserName = _sessionUserService.GetUserName();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.RoomCheckOutDateChangeAsync(hotelRoomBookingRateDetailRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: RoomCheckOutDateChange method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: RoomCheckOutDateChange method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Room CheckOut.");
            }
        }

        [HttpPut("RoomExtend")]
        public async Task<Result> RoomExtend([FromBody] HotelRoomBookingModel hotelRoomBookingRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: RoomExtend method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserName = _sessionUserService.GetUserName();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.RoomExtendAsync(hotelRoomBookingRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: RoomExtend method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: RoomExtend method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Room Extend");
            }
        }

        [HttpPut("RoomCancel/{hotelRoomBookingID}")]
        public async Task<Result> RoomCancel(int hotelRoomBookingID, [FromQuery] string? cancellationReason)
        {
            try
            {
                _logger.LogInformation("Controller: RoomCancel method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserName = _sessionUserService.GetUserName();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.RoomCancelAsync(hotelRoomBookingID, cancellationReason, auditInfoModel);

                _logger.LogInformation("Controller: RoomCancel method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: RoomCancel method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Room Cancel");
            }
        }

        [HttpPut("RoomRefund")]
        public async Task<Result> RoomRefund([FromBody] AddPaymentModel bookingPaymentRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: RoomRefund method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserName = _sessionUserService.GetUserName();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.RoomRefundAsync(bookingPaymentRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: RoomRefund method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: RoomRefund method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while RoomRefund");
            }
        }

        [HttpPut("RoomCleaning")]
        public async Task<Result> RoomCleaning([FromBody] UpdateHotelRoomCleaningAuditModel hotelRoomCleaningAuditRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: RoomCleaning method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.RoomCleaningAsync(hotelRoomCleaningAuditRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: RoomCleaning method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: RoomCleaning method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Room Cleaning");
            }
        }

        [HttpGet("GetPendingRoomCleaningList/{hotelID}")]
        public async Task<Result<List<HotelRoomCleaningAuditModel>>> GetPendingRoomCleaningList(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetPendingRoomCleaningList method initiated.");

                var serviceResult = await _hotelRoomBookingService.GetPendingRoomCleaningListAsync(hotelID);

                _logger.LogInformation("Controller: GetPendingRoomCleaningList method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetPendingRoomCleaningList method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Room Cancel");
            }
        }



        [HttpPut("UpdateHotelRoomBookingStatus")]
        public async Task<Result> UpdateHotelRoomBookingStatus([FromBody] HotelRoomBookingModel hotelRoomBookingRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: UpdateHotelRoomBookingStatus method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.UpdateHotelRoomBookingStatusAsync(hotelRoomBookingRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: UpdateHotelRoomBookingStatus method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: UpdateHotelRoomBookingStatus method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking details.");
            }
        }

        [HttpPut("AddEditMiscAmount")]
        public async Task<Result> AddEditMiscAmount(AddEditMiscAmountModel addEditMiscAmountRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: AddEditMiscAmount method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserName = _sessionUserService.GetUserName();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.AddEditMiscAmountAsync(addEditMiscAmountRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: AddEditMiscAmount method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddEditMiscAmount method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while AddEditMiscAmount");
            }
        }

        [HttpPost("AddEditBookingPayment")]
        public async Task<Result> AddEditBookingPayment(AddPaymentModel bookingPaymentRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: AddEditBookingPayment method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserName = _sessionUserService.GetUserName();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.AddUpdateBookingPaymentAsync(bookingPaymentRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: AddEditBookingPayment method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddEditBookingPayment method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while AddEditBookingPayment");
            }
        }


        /// <summary>
        /// Retrieves a list of booked hotel rooms based on the provided hotel room booking ID and check-out date.
        /// </summary>
        /// <param name="hotelRoomBookingID">The ID of the hotel room booking to exclude from the search.</param>
        /// <param name="checkOutDate">The check-out date to filter bookings.</param>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="BookedRoomDetailsModel"/> representing booked hotel room details.</returns>
        [HttpGet("GetBookedRoomsByCheckOutDate")]
        public async Task<Result<List<GetBookedRoomDetailsModel>>> GetBookedRoomsByCheckOutDate([FromQuery] int hotelRoomBookingID, [FromQuery] DateTime checkOutDate)
        {
            try
            {
                _logger.LogInformation("Controller: GetBookedRoomsByCheckOutDate method initiated.");

                var serviceResult = await _hotelRoomBookingService.GetBookedRoomsByCheckOutDate(hotelRoomBookingID, checkOutDate);

                _logger.LogInformation("Controller: GetBookedRoomsByChecKOutDate method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetBookedRoomsByChecKOutDate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching booked room details.");
                #endregion
            }
        }


        [HttpGet("SearchHotelRoomBooking")]
        public async Task<Result<List<GetHotelRoomBookingSearchListModel>>> SearchHotelRoomBooking([FromQuery] FindHotelRoomBookingModel findHotelRoomBookingRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: SearchHotelRoomBooking method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.SearchHotelRoomBookingAsync(findHotelRoomBookingRequestModel);

                _logger.LogInformation("Controller: SearchHotelRoomBooking method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: SearchHotelRoomBooking method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking details.");
            }
        }

        [HttpPost("AddUpdateGuest")]
        public async Task<Result> AddUpdateGuest([FromQuery] int hotelRoomBookingID, [FromBody] AddGuestModel guestRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: AddUpdateGuest method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserName = _sessionUserService.GetUserName();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.AddUpdateGuestAsync(hotelRoomBookingID, guestRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: AddUpdateGuest method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddUpdateGuest method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while AddUpdateGuest");
            }
        }

        [HttpPut("UpdateGuestRequest")]
        public async Task<Result> UpdateGuestRequest([FromBody] UpdateGuestRequestModel hotelRoomBookingRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: UpdateGuestRequest method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserName = _sessionUserService.GetUserName();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.UpdateGuestRequestAsync(hotelRoomBookingRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: UpdateGuestRequest method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: UpdateGuestRequest method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking details.");
            }
        }

        [HttpPut("UpdateBookingReportFlag")]
        public async Task<Result> UpdateBookingReportFlag([FromQuery] int hotelRoomBookingID, [FromQuery] bool isIncludedInReport)
        {
            try
            {
                _logger.LogInformation("Controller: UpdateBookingReportFlag method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserName = _sessionUserService.GetUserName();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomBookingService.UpdateBookingReportFlagAsync(hotelRoomBookingID, isIncludedInReport, auditInfoModel);

                _logger.LogInformation("Controller: UpdateBookingReportFlag method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: UpdateBookingReportFlag method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Updating Booking Report Flag.");
            }
        }

        [HttpGet("GetRoomBookingMiscAmount/{hotelRoomBookingID}")]
        public async Task<Result<List<AddEditMiscAmountModel>>> GetRoomBookingMiscAmount(int hotelRoomBookingID)
        {
            try
            {
                _logger.LogInformation("Controller: GetRoomBookingMiscAmount method initiated.");

                var serviceResult = await _hotelRoomBookingService.GetRoomBookingMiscAmountAsync(hotelRoomBookingID);

                _logger.LogInformation("Controller: GetRoomBookingMiscAmount method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetRoomBookingMiscAmount method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching Misc Amount list.");
            }
        }

        [HttpDelete("DeleteMiscAmount/{hotelRoomBookingMiscellaneousID}")]
        public async Task<Result> DeleteMiscAmount(int hotelRoomBookingMiscellaneousID)
        {
            try
            {
                _logger.LogInformation("Controller: DeleteMiscAmount method initiated.");

                var serviceResult = await _hotelRoomBookingService.DeleteMiscAmountAsync(hotelRoomBookingMiscellaneousID);

                _logger.LogInformation("Controller: DeleteMiscAmount method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DeleteMiscAmount method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while deleting Misc Amount.");
            }
        }

    }
}
