﻿using Ardalis.Result;
using Ardalis.Result.AspNetCore;
using CheckinPro.Common.Models;
using CheckinPro.Services;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using CheckinPro.WebApp.Providers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Xml.Serialization;

namespace CheckinPro.WebApp.Controllers
{
    [Route("api/[controller]")]
    [TranslateResultToActionResult]
    [ApiController]
    public class ScannerController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IScannerService _scannerService;

        public ScannerController(ILogger<ScannerController> logger, IScannerService scannerService)
        {
            _logger = logger;
            _scannerService = scannerService;
        }


        private static List<string> scannedData = new List<string>();

        //[HttpGet]
        //public IActionResult Get()
        //{
        //    return Ok(scannedData);
        //}

        //[HttpPost("AddGuestScanDetailsss")]
        //[Consumes("application/json", "application/xml")]
        //public IActionResult AddGuestScanDetailsss([FromBody] object scanned_XML_JSON_Data)
        //{
        //    string scanDetail = scanned_XML_JSON_Data.ToString();
        //    scannedData.Add(scanDetail);
        //    return Ok(new { message = "Data received successfully.", data = scanned_XML_JSON_Data.ToString() });
        //}



        //[HttpPost("AddGuestScanDetail_JSON")]
        //[Consumes("application/json")]
        //public async Task<Result> AddGuestScanDetail([FromBody] object Root)
        //{
        //    try
        //    {
        //        _logger.LogInformation("Controller: AddGuestScanDetail method initiated.");
        //        var contentType = Request.ContentType.ToLower();
        //        GuestIDScan guestIDScan = new GuestIDScan();
        //        if (contentType.Contains("application/json"))
        //        {
        //            // If the content is JSON, process it as you already do
        //            guestIDScan.Scanner_JSON_File = Root.ToString();
        //        }
        //        var serviceResult = await _scannerService.AddGuestScanDetailAsync(guestIDScan);

        //        _logger.LogInformation("Controller: AddGuestScanDetail method execution completed.");
        //        return Result.Success(serviceResult);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError($"Controller: AddGuestScanDetail method encountered an exception. Stacktrace: {ex}");
        //        return Result.Error("An error occurred while adding the hotel room booking details.");
        //    }
        //}


        //[HttpPost("AddGuestScanDetail_XML")]
        //[Consumes("application/xml")] // This ensures only XML will be accepted.
        //public async Task<Result> AddGuestScanDetail_XML([FromBody] ScanIDXMLDocumentModel Root)
        //{
        //    try
        //    {
        //        _logger.LogInformation("Controller: AddGuestScanDetail_XML method initiated.");

        //        // Create an instance of GuestIDScan (assuming you need to store scan details here)
        //        GuestIDScan guestIDScan = new GuestIDScan();

        //        // Since you already have [FromBody] ScanIDXMLDocumentModel Root, 
        //        // ASP.NET Core should handle deserialization automatically into the model
        //        if (Root != null)
        //        {
        //            // Convert the XML model into a string if needed for storage (assuming it's for XML file content)
        //            var xmlSerializer = new XmlSerializer(typeof(ScanIDXMLDocumentModel));
        //            XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
        //            namespaces.Add("", "");
        //            using (var stringWriter = new StringWriter())
        //            {
        //                xmlSerializer.Serialize(stringWriter, Root, namespaces);
        //                guestIDScan.Scanner_XML_File = stringWriter.ToString(); // This stores XML as a string
        //            }
        //        }
        //        else
        //        {
        //            return Result.Error("No data found in the request.");
        //        }

        //        // Now call your service with the deserialized guest scan data
        //        var serviceResult = await _scannerService.AddGuestScanDetailAsync(guestIDScan);

        //        _logger.LogInformation("Controller: AddGuestScanDetail_XML method execution completed.");
        //        return Result.Success(serviceResult);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError($"Controller: AddGuestScanDetail_XML method encountered an exception. Stacktrace: {ex}");
        //        return Result.Error("An error occurred while adding the hotel room booking details.");
        //    }
        //}

        [HttpGet("GetGuestScanDetail")]
        public async Task<Result<List<AddGuestModel>>> GetGuestScanDetail(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetGuestScanDetail method initiated.");
                var serviceResult = await _scannerService.GetGuestScanDetailAsync(hotelID);

                _logger.LogInformation("Controller: GetGuestScanDetail method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetGuestScanDetail method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking details.");
            }
        }


        [HttpPost]
        [Route("/GuestScanDetail/{hotelId}")]
        [Consumes("application/json")]
        public async Task<Result> AddGuestScanDetail([FromRoute] Guid hotelId, [FromBody] object Root)
        {
            try
            {
                _logger.LogInformation("Controller: AddGuestScanDetail method initiated.");

                var contentType = Request.ContentType.ToLower();
                GuestIDScan guestIDScan = new GuestIDScan
                {
                    HotelUniqueID = hotelId
                };

                if (contentType.Contains("application/json"))
                {
                    // Assuming Root is raw JSON string or can be ToString'd cleanly
                    guestIDScan.Scanner_JSON_File = Root.ToString();
                }

                var serviceResult = await _scannerService.AddGuestScanDetailAsync(guestIDScan);

                _logger.LogInformation("Controller: AddGuestScanDetail method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddGuestScanDetail method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking details.");
            }
        }

    }
}
