﻿using Ardalis.Result;
using Ardalis.Result.AspNetCore;
using CheckinPro.Common.Models;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using CheckinPro.WebApp.Providers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CheckinPro.WebApp.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [TranslateResultToActionResult]
    [ApiController]
    public class DashboardController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IDashboardService _dashboardService;
        private readonly ISessionUserService _sessionUserService;
        public DashboardController(ILogger<DashboardController> logger, IDashboardService dashboardService, ISessionUserService sessionUserService)
        {
            _logger = logger;
            _dashboardService = dashboardService;
            _sessionUserService = sessionUserService;
        }


        /// <summary>
        /// Retrieves a Dashboard data.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetDashboardModel"/> representing the dashboard data.</returns>   
        [HttpGet("GetDashboard/{hotelID}")]
        public async Task<Result<GetDashboardModel>> GetDashboard(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetDashboard method initiated.");
                var serviceResult = await _dashboardService.GetHotelRoomStatusCountsAsync(hotelID);


                _logger.LogInformation("Controller: GetDashboard method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetDashboard method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching dashboard data.");
            }
        }

        [HttpGet("GetHotelShiftDetailByDate")]
        public async Task<Result<List<HotelShiftModel>>> GetHotelShiftDetailByDate([FromQuery] int hotelId, [FromQuery] DateOnly fromDate, [FromQuery] DateOnly toDate)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelShiftDetailByDate method initiated.");
                var serviceResult = await _dashboardService.GetHotelShiftDetailByDateAsync(hotelId, fromDate, toDate);

                _logger.LogInformation("Controller: GetHotelShiftDetailByDate method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelShiftDetailByDate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching dashboard data.");
            }
        }

        [HttpGet("GetHotelShiftDetail/{hotelID}")]
        public async Task<Result<HotelShiftModel>> GetHotelShiftDetail(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelShiftDetail method initiated.");
                var serviceResult = await _dashboardService.GetHotelShiftDetailAsync(hotelID);


                _logger.LogInformation("Controller: GetHotelShiftDetail method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelShiftDetail method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching dashboard data.");
            }
        }

        [HttpPost("StartHotelShift")]
        public async Task<Result> StartHotelShift(HotelShiftModel hotelShiftRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: StartHotelShift method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _dashboardService.StartHotelShiftAsync(hotelShiftRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: StartHotelShift method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: StartHotelShift method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while starting hotel shift.");
            }
        }

        [HttpPut("EndHotelShift")]
        public async Task<Result> EndHotelShift(HotelShiftModel hotelShiftRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: EndHotelShift method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _dashboardService.EndHotelShiftAsync(hotelShiftRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: EndHotelShift method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: EndHotelShift method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while ending hotel shift.");
            }
        }

        [HttpGet("GetHotelMetricsByDateRange")]
        public async Task<Result<List<GetHotelOwnerDashboardModel>>> GetHotelMetricsByDateRange([FromQuery] int hotelId, [FromQuery] DateTime? selectedDate, [FromQuery] string metrix)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelMetricsByDateRange method initiated.");
                var serviceResult = await _dashboardService.GetHotelMetricsByDateRangeAsync(hotelId, selectedDate, metrix);


                _logger.LogInformation("Controller: GetHotelMetricsByDateRange method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelMetricsByDateRange method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel owner dashboard details.");
            }
        }

        [HttpGet("GetHotelRoomRevenueByYear")]
        public async Task<Result<List<GetHotelRoomRevenueModel>>> GetHotelRoomRevenueByYear([FromQuery] int hotelId, [FromQuery] int year)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelRoomRevenueByYear method initiated.");
                var serviceResult = await _dashboardService.GetHotelRoomRevenueByYearAsync(hotelId, year);

                _logger.LogInformation("Controller: GetHotelRoomRevenueByYear method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelRoomRevenueByYear method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel room revenue details.");
            }
        }
    }
}
