﻿using Ardalis.Result;
using Ardalis.Result.AspNetCore;
using CheckinPro.Common.Models;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using CheckinPro.WebApp.Providers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CheckinPro.WebApp.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [TranslateResultToActionResult]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IUserService _userService;
        private readonly PasswordService _passwordService;
        private readonly ISessionUserService _sessionUserService;


        public UserController(ILogger<UserController> logger, IUserService userService, PasswordService passwordService, ISessionUserService sessionUserService)
        {
            _logger = logger;
            _userService = userService;
            _passwordService = passwordService;
            _sessionUserService = sessionUserService;
        }

        /// <summary>
        /// Retrieves list of all users.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetUserModel"/> representing the user data.</returns>        
        [HttpGet("GetUsers/{hotelID}")]
        public async Task<Result<List<GetUserModel>>> GetUsers(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetUsersList method initiated.");

                var usersList = await _userService.GetUsersAsync(hotelID);

                _logger.LogInformation("Controller: GetUsersList method execution completed.");
                return Result.Success(usersList);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetUsersList method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching users.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific user by its ID.
        /// </summary>
        /// <param name="userID">The ID of the user to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetUserModel"/> for the specified user Id.</returns>       
        [HttpGet("GetUserById")]
        public async Task<Result<GetUserModel>> GetUserById()
        {
            try
            {
                _logger.LogInformation("Controller: GetUserById method initiated.");

                var userModel = await _userService.GetUserByIdAsync(_sessionUserService.GetUserId());

                _logger.LogInformation("Controller: GetUserById method execution completed.");
                return Result.Success(userModel);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetUserById method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching users.");
            }
        }

        /// <summary>
        /// Adds a new user record based on the provided addUserRequestModel.
        /// </summary>
        /// <param name="addUserRequestModel">The <see cref="AddUserModel"/> containing data for the new user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the user creation operation.</returns>      
        [HttpPost("AddUser")]
        public async Task<Result> AddUser([FromBody] AddUserModel addUserRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: AddUser method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var randomPassword = _passwordService.RandomPasswordGenerator();
                addUserRequestModel.Password = _passwordService.HashPassword(randomPassword);

                var serviceResult = await _userService.AddUserAsync(addUserRequestModel, randomPassword, auditInfoModel);

                _logger.LogInformation("Controller: AddUser method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddUser method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the user.");
            }
        }

        /// <summary>
        /// Updates an existing user record based on the provided userID and updateUserRequestModel.
        /// </summary>
        /// <param name="userID">The ID of the user to be updated.</param>
        /// <param name="updateUserRequestModel">The <see cref="UpdateUserModel"/> containing updated data for the user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the user update operation.</returns>
        [HttpPut("UpdateUser")]
        public async Task<Result> UpdateUser([FromBody] UpdateUserModel updateUserRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: UpdateUser method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _userService.UpdateUserAsync(_sessionUserService.GetUserId(), updateUserRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: UpdateUser method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: UpdateUser method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while updating the user.");
            }
        }

        /// <summary>
        /// Deletes an user based on the provided userID.
        /// </summary>
        /// <param name="userID">The ID of the user to be deleted.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing deleted data for the user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the delete operation.</returns>
        [HttpDelete("DeleteUser/{userID}")]
        public async Task<Result> DeleteUser(int userID)
        {
            try
            {
                _logger.LogInformation("Controller: DeleteUser method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _userService.DeleteUserAsync(userID, auditInfoModel);

                _logger.LogInformation("Controller: DeleteUser method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DeleteUser method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while deleting the user.");
            }
        }

        /// <summary>
        /// Blocks an user based on the provided userID.
        /// </summary>
        /// <param name="userID">The ID of the user to be blocked.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the block operation.</returns>

        [HttpPut("BlockUser/{userID}")]
        public async Task<Result> BlockUser(int userID)
        {
            try
            {
                _logger.LogInformation("Controller: BlockUser method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _userService.BlockUserAsync(userID, auditInfoModel);

                _logger.LogInformation("Controller: BlockUser method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: BlockUser method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while blocking the user.");
            }
        }

        /// <summary>
        /// Activates the user based on the provided userID.
        /// </summary>
        /// <param name="userID">The ID of the user to be activated.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the profile activation operation.</returns>
        [HttpPut("ActivateUser/{userID}")]
        public async Task<Result> ActivateUser(int userID)
        {
            try
            {
                _logger.LogInformation("Controller: ActivateUser method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _userService.ActivateUserAsync(userID, auditInfoModel);

                _logger.LogInformation("Controller: ActivateUser method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: ActivateUser method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while activating the user.");
            }
        }
    }
}
