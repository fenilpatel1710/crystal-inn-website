﻿using Ardalis.Result;
using Ardalis.Result.AspNetCore;
using CheckinPro.Common.Models;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using CheckinPro.WebApp.Providers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CheckinPro.WebApp.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [TranslateResultToActionResult]
    [ApiController]
    public class RoomStatusController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IRoomStatusService _RoomStatusService;
        private readonly ISessionUserService _sessionUserService;

        public RoomStatusController(ILogger<RoomStatusController> logger, IRoomStatusService RoomStatusService, ISessionUserService sessionUserService)
        {
            _logger = logger;
            _RoomStatusService = RoomStatusService;
            _sessionUserService = sessionUserService;
        }

        /// <summary>
        /// Retrieves a list of Amenities.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetRoomStatusModel"/> representing the room cleaning status data.</returns>   
        [HttpGet("GetRoomStatuses")]
        public async Task<Result<List<GetRoomStatusModel>>> GetRoomStatuses()
        {
            try
            {
                _logger.LogInformation("Controller: GetRoomStatuses method initiated.");

                var serviceResult = await _RoomStatusService.GetRoomStatusesAsync();

                _logger.LogInformation("Controller: GetCleaningStatuses method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetRoomStatuses method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching room cleaning statuses.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific room cleaning status by its ID.
        /// </summary>
        /// <param name=" RoomStatusID">The ID of the room cleaning status to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetRoomStatusModel"/> for the specified  room cleaning status.</returns>
        [HttpGet("GetRoomStatusById/{RoomStatusID}")]
        public async Task<Result<GetRoomStatusModel>> GetRoomStatusById(int RoomStatusID)
        {
            try
            {
                _logger.LogInformation("Controller: GetRoomStatusById method initiated.");

                var serviceResult = await _RoomStatusService.GetRoomStatusByIdAsync(RoomStatusID);

                _logger.LogInformation("Controller: GetRoomStatusById method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetRoomStatusById method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching  room cleaning status.");
            }
        }

        /// <summary>
        /// Adds a new room cleaning status record based on the provided RoomStatusRequestModel.
        /// </summary>
        /// <param name="RoomStatusRequestModel">The <see cref="AddEditRoomStatusModel"/> containing data for the new Room Feature.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the Room cleaning status addition operation.</returns>
        [HttpPost("AddRoomStatus")]
        public async Task<Result> AddRoomStatus([FromBody] AddEditRoomStatusModel RoomStatusRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: AddRoomStatus method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _RoomStatusService.AddRoomStatusAsync(RoomStatusRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: AddRoomStatus method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddRoomStatus method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the Room Cleaning Status.");
            }
        }

        /// <summary>
        /// Updates an existing room feautre record based on the provided RoomStatusID and RoomStatusRequestModel.
        /// </summary>
        /// <param name="RoomStatusID">The ID of the room feautre to be updated.</param>
        /// <param name="RoomStatusRequestModel">The <see cref="UpdateRoomStatusModel"/> containing updated data for the room feautre.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the room feautre update operation.</returns>
        [HttpPut("UpdateRoomStatus/{RoomStatusID}")]
        public async Task<Result> UpdateRoomStatus(int RoomStatusID, [FromBody] UpdateRoomStatusModel RoomStatusRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: UpdateRoomStatus method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _RoomStatusService.UpdateRoomStatusAsync(RoomStatusID, RoomStatusRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: UpdateRoomStatus method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: UpdateRoomStatus method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while updating the room feautre.");
            }
        }

        /// <summary>
        /// Deletes a room feautre based on the provided RoomStatusID.
        /// </summary>
        /// <param name="RoomStatusID">The ID of the room feautre to be deleted.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing deleted data for the room feautre.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the soft delete operation.</returns>
        [HttpPut("DeleteRoomStatus/{RoomStatusID}")]
        public async Task<Result> DeleteRoomStatus(int RoomStatusID)
        {
            try
            {
                _logger.LogInformation("Controller: DeleteRoomStatus method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _RoomStatusService.DeleteRoomStatusAsync(RoomStatusID, auditInfoModel);

                _logger.LogInformation("Controller: DeleteRoomStatus method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DeleteRoomStatus method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while deleting the room cleaning status.");
            }
        }

    }
}
