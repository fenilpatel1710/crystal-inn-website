﻿using Ardalis.Result;
using Ardalis.Result.AspNetCore;
using CheckinPro.Common.Models;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using CheckinPro.WebApp.Providers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CheckinPro.WebApp.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [TranslateResultToActionResult]
    [ApiController]
    public class StateController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IStateService _stateService;
        private readonly ISessionUserService _sessionUserService;

        public StateController(ILogger<StateController> logger, IStateService stateService, ISessionUserService sessionUserService)
        {
            _logger = logger;
            _stateService = stateService;
            _sessionUserService = sessionUserService;
        }

        [HttpGet("GetStatesByCountryId/{countryId}")]
        public async Task<Result<List<StateModel>>> GetStatesByCountryId(int countryId)
        {
            try
            {
                _logger.LogInformation("Controller: GetStatesByCountryId method initiated.");

                var stateModels = await _stateService.GetStatesByCountryIdAsync(countryId);

                _logger.LogInformation("Controller: GetStatesByCountryId method execution completed.");
                return Result.Success(stateModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetStatesByCountryId method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while getting the state list.");
            }
        }

        [HttpGet("GetActiveStatesByCountryId/{countryId}")]
        public async Task<Result<List<StateModel>>> GetActiveStatesByCountryId(int countryId)
        {
            try
            {
                _logger.LogInformation("Controller: GetActiveStatesByCountryId method initiated.");

                var stateModels = await _stateService.GetActiveStatesByCountryIdAsync(countryId);

                _logger.LogInformation("Controller: GetActiveStatesByCountryId method execution completed.");
                return Result.Success(stateModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetActiveStatesByCountryId method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while getting the state list.");
            }
        }

        [HttpGet("GetStatesByStateId/{stateId}")]
        public async Task<Result<StateModel>> GetStatesByStateId(int stateId)
        {
            try
            {
                _logger.LogInformation("Controller: GetStatesByStateId method initiated.");

                var stateModels = await _stateService.GetStatesByStateIdAsync(stateId);

                _logger.LogInformation("Controller: GetStatesByStateId method execution completed.");
                return Result.Success(stateModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetStatesByStateId method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while getting the state list.");
            }
        }

        [HttpPost("AddState")]
        public async Task<Result> CreateState([FromBody] StateModel stateRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: CreateState method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var stateResult = await _stateService.AddStateAsync(stateRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: CreateState method execution completed.");
                return Result.Success(stateResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: CreateState method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the state.");
            }
        }

        [HttpPut("UpdateState/{stateId}")]
        public async Task<Result> UpdateState(int stateId, [FromBody] StateModel stateRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: UpdateCountry method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _stateService.UpdateStateAsync(stateId, stateRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: UpdateState method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: UpdateState method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while updating the state.");
            }
        }

        [HttpPut("DeleteState/{stateId}")]
        public async Task<Result> DeleteState(int stateId, [FromBody] StateModel stateRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: DeleteState method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _stateService.DeleteStateAsync(stateId, stateRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: DeleteState method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DeleteState method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while deleting the state.");
            }
        }
    }
}
