﻿using Ardalis.Result;
using Ardalis.Result.AspNetCore;
using CheckinPro.Common.Models;
using CheckinPro.Services;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using CheckinPro.WebApi.Models.HotelRoomModels;
using CheckinPro.WebApp.Models;
using CheckinPro.WebApp.Providers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CheckinPro.WebApp.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [TranslateResultToActionResult]
    [ApiController]
    public class HotelController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IHotelService _hotelService;
        private readonly PasswordService _passwordService;
        private readonly IHotelRoomService _hotelRoomService;
        private readonly ISessionUserService _sessionUserService;
        private readonly IHotelConfigurationService _hotelConfigurationService;

        public HotelController(ILogger<HotelController> logger, IHotelService hotelService, PasswordService passwordService, IHotelRoomService hotelRoomService, ISessionUserService sessionUserService, IHotelConfigurationService hotelConfigurationService)
        {
            _logger = logger;
            _hotelService = hotelService;
            _passwordService = passwordService;
            _hotelRoomService = hotelRoomService;
            _sessionUserService = sessionUserService;
            _hotelConfigurationService = hotelConfigurationService;
        }


        /// <summary>
        /// Checks if hotel-related records exist for a given hotel ID.
        /// </summary>
        /// <param name="hotelId">The ID of the hotel to check.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="HotelRecordsCheckResult"/> with presence status.</returns>
        [HttpGet("GetHotelProfileCompletionStatus/{hotelId}")]
        public async Task<Result<HotelProfileStatusModel>> GetHotelProfileCompletionStatus(int hotelId)
        {
            try
            {
                _logger.LogInformation($"Controller: GetHotelProfileCompletionStatus method initiated for HotelID {hotelId}.");

                var serviceResult = await _hotelService.GetHotelProfileCompletionStatusAsync(hotelId);

                _logger.LogInformation($"Controller: GetHotelProfileCompletionStatus method execution completed for HotelID {hotelId}.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelProfileCompletionStatus method encountered an exception for HotelID {hotelId}. Stacktrace: {ex}");
                return Result.Error("An error occurred while checking hotel records.");
            }
        }

        /// <summary>
        /// Retrieves a list of Hotels.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelModel"/> representing the hotel data.</returns>
        [HttpGet("GetHotels")]
        public async Task<Result<List<GetHotelModel>>> GetHotels()
        {
            try
            {
                _logger.LogInformation("Controller: GetHotels method initiated.");

                var serviceResult = await _hotelService.GetHotelsAsync();

                _logger.LogInformation("Controller: GetHotels method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotels method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific hotel by its ID.
        /// </summary>
        /// <param name="hotelID">The ID of the hotel to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetHotelModel"/> for the specified hotel.</returns>
        [HttpGet("GetHotelById/{hotelID}")]
        public async Task<Result<GetHotelModel>> GetHotelById(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelById method initiated.");

                var serviceResult = await _hotelService.GetHotelByIdAsync(hotelID);

                _logger.LogInformation("Controller: GetHotelById method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelById method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel.");
            }
        }


        /// <summary>
        /// Adds a new hotel record based on the provided hotelRequestModel.
        /// </summary>
        /// <param name="hotelRequestModel">The <see cref="AddHotelModel"/> containing data for the new hotel.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel creation operation.</returns>
        [HttpPost("AddHotel")]
        public async Task<Result> AddHotel([FromBody] AddHotelModel hotelRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: AddHotel method initiated.");

                var randomPassword = _passwordService.RandomPasswordGenerator();
                hotelRequestModel.Userinfo.Password = _passwordService.HashPassword(randomPassword);

                AuditInfoModel auditInfoModel = new AuditInfoModel();

                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelService.AddHotelAsync(hotelRequestModel, randomPassword, auditInfoModel);

                _logger.LogInformation("Controller: AddHotel method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddHotel method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding owner and hotel info.");
            }
        }

        [HttpPut("ActiveInactiveOwnerDashboard/{hotelID}")]
        public async Task<Result> ActiveInactiveOwnerDashboard(int hotelID, bool isActive)
        {
            try
            {
                _logger.LogInformation("Controller: ActiveInactiveOwnerDashboard method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelService.ActiveInactiveOwnerDashboardAsync(hotelID, isActive, auditInfoModel);

                _logger.LogInformation("Controller: ActiveInactiveOwnerDashboard method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: ActiveInactiveOwnerDashboard method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while ActiveInactiveOwnerDashboard.");
            }
        }

        [HttpPut("ActiveInactiveHotel/{hotelID}")]
        public async Task<Result> ActiveInactiveHotel(int hotelID, bool isActive)
        {
            try
            {
                _logger.LogInformation("Controller: ActiveInactiveHotel method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelService.ActiveInactiveHotelAsync(hotelID, isActive, auditInfoModel);

                _logger.LogInformation("Controller: ActiveInactiveHotel method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: ActiveInactiveHotel method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while ActiveInactiveHotel.");
            }
        }

        #region HotelConfiguration

        /// <summary>
        /// Retrieves a list of hotel tax rate.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="HotelTaxRateModel"/> representing all hotel tax rate data.</returns>
        [HttpGet("GetHotelTaxRate/{hotelID}")]
        public async Task<Result<List<HotelTaxRateModel>>> GetHotelTaxRate(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelTaxRate method initiated.");

                var serviceResult = await _hotelConfigurationService.GetHotelTaxRateAsync(hotelID);

                _logger.LogInformation("Controller: GetHotelTaxRate method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelTaxRate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching data.");
            }
        }

        /// <summary> 
        /// Adds a new hotel tax rate record based on the provided hotelTaxRateRequestModel.
        /// </summary>
        /// <param name="hotelTaxRateRequestModel">The <see cref="HotelTaxRateModel"/> containing data for the new hotel tax rate.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel tax rate creation operation.</returns>
        [HttpPost("AddEditHotelTaxRate")]
        public async Task<Result> AddEditHotelTaxRate([FromBody] HotelTaxRateModel hotelTaxRateRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: AddEditHotelTaxRate method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();

                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelConfigurationService.AddEditHotelTaxRateAsync(hotelTaxRateRequestModel, auditInfoModel);
                _logger.LogInformation("Controller: AddEditHotelTaxRate method execution completed.");
                return Result.Success(serviceResult);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddEditHotelTaxRate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while AddEditHotelTaxRate info.");
            }
        }

        [HttpGet("GetHotelConfiguration/{hotelID}")]
        public async Task<Result<HotelConfigurationModel>> GetHotelConfiguration(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelConfiguration method initiated.");

                var serviceResult = await _hotelConfigurationService.GetHotelMasterConfigurationAsync(hotelID);

                _logger.LogInformation("Controller: GetHotelConfiguration method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelConfiguration method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching data.");
            }
        }

        [HttpPost("AddEditHotelConfiguration")]
        public async Task<Result> AddEditHotelConfiguration(HotelConfigurationModel hotelMasterConfigurationRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: AddEditHotelConfiguration method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();

                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelConfigurationService.AddEditHotelMasterConfigurationAsync(hotelMasterConfigurationRequestModel, auditInfoModel);
                _logger.LogInformation("Controller: AddEditHotelConfiguration method execution completed.");
                return Result.Success(serviceResult);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddEditHotelConfiguration method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while AddEditHotelConfiguration info.");
            }
        }

        [HttpGet("GetHotelDailyRate/{hotelID}")]
        public async Task<Result<List<HotelDailyRateModel>>> GetHotelDailyRate(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelDailyRate method initiated.");

                var serviceResult = await _hotelConfigurationService.GetHotelDailyRateAsync(hotelID);

                _logger.LogInformation("Controller: GetHotelDailyRate method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelDailyRate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching data.");
            }
        }

        [HttpPost("AddEditHotelDailyRate")]
        public async Task<Result> AddEditHotelDailyRate(HotelDailyRateModel hotelDailyRateRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: AddEditHotelDailyRate method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();

                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelConfigurationService.AddEditHotelDailyRateAsync(hotelDailyRateRequestModel, auditInfoModel);
                _logger.LogInformation("Controller: AddEditHotelDailyRate method execution completed.");
                return Result.Success(serviceResult);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddEditHotelDailyRate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while AddEditHotelDailyRate info.");
            }
        }

        [HttpDelete("DeleteHotelDailyRate/{hotelDailyRateID}")]
        public async Task<Result> DeleteHotelDailyRate(int hotelDailyRateID)
        {
            try
            {
                _logger.LogInformation("Controller: DeleteHotelDailyRate method initiated.");

                var serviceResult = await _hotelConfigurationService.DeleteHotelDailyRateAsync(hotelDailyRateID);

                _logger.LogInformation("Controller: DeleteHotelDailyRate method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DeleteHotelDailyRate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while deleting hotel daily rate.");
            }
        }

        [HttpGet("GetHotelHourlyRate/{hotelID}")]
        public async Task<Result<List<HotelHourlyRateModel>>> GetHotelHourlyRate(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelHourlyRate method initiated.");

                var serviceResult = await _hotelConfigurationService.GetHotelHourlyRateAsync(hotelID);

                _logger.LogInformation("Controller: GetHotelHourlyRate method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelHourlyRate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching data.");
            }
        }

        [HttpPost("AddEditHotelHourlyRate")]
        public async Task<Result> AddEditHotelHourlyRate(HotelHourlyRateModel hotelHourlyRateRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: AddEditHotelHourlyRate method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();

                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelConfigurationService.AddEditHotelHourlyRateAsync(hotelHourlyRateRequestModel, auditInfoModel);
                _logger.LogInformation("Controller: AddEditHotelHourlyRate method execution completed.");
                return Result.Success(serviceResult);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddEditHotelHourlyRate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while AddEditHotelHourlyRate info.");
            }
        }


        [HttpGet("GetHotelRoomType/{hotelID}")]
        public async Task<Result<List<HotelRoomTypeModel>>> GetHotelRoomType(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelRoomType method initiated.");

                var serviceResult = await _hotelConfigurationService.GetHotelRoomTypeAsync(hotelID);

                _logger.LogInformation("Controller: GetHotelRoomType method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelRoomType method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching data.");
            }
        }


        [HttpGet("GetHotelRoomTypeById/{hotelRoomTypeID}")]
        public async Task<Result<HotelRoomTypeModel>> GetHotelRoomTypeById(int hotelRoomTypeID)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelRoomTypeById method initiated.");

                var serviceResult = await _hotelConfigurationService.GetHotelRoomTypeByIdAsync(hotelRoomTypeID);

                _logger.LogInformation("Controller: GetHotelRoomTypeById method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelRoomTypeById method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching data.");
            }
        }

        [HttpPost("AddEditHotelRoomType")]
        public async Task<Result> AddEditHotelRoomType(HotelRoomTypeModel hotelRoomTypeRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: AddEditHotelRoomType method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();

                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelConfigurationService.AddEditHotelRoomTypeAsync(hotelRoomTypeRequestModel, auditInfoModel);
                _logger.LogInformation("Controller: AddEditHotelRoomType method execution completed.");
                return Result.Success(serviceResult);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddEditHotelRoomType method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while AddEditHotelRoomType info.");
            }
        }



        [HttpGet("GetHotelAdditionalRate/{hotelID}")]
        public async Task<Result<List<HotelAdditionalRateModel>>> GetHotelAdditionalRate(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelAdditionalRate method initiated.");

                var serviceResult = await _hotelConfigurationService.GetHotelAdditionalRateAsync(hotelID);

                _logger.LogInformation("Controller: GetHotelAdditionalRate method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelAdditionalRate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching data.");
            }
        }

        [HttpPost("AddEditHotelAdditionalRate")]
        public async Task<Result> AddEditHotelAdditionalRate(HotelAdditionalRateModel hotelAdditionalRateRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: AddEditHotelAdditionalRate method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();

                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelConfigurationService.AddEditHotelAdditionalRateAsync(hotelAdditionalRateRequestModel, auditInfoModel);
                _logger.LogInformation("Controller: AddEditHotelAdditionalRate method execution completed.");
                return Result.Success(serviceResult);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddEditHotelAdditionalRate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while AddEditHotelAdditionalRate info.");
            }
        }


        #endregion

        #region HotelRoom

        /// <summary>
        /// Retrieves a list of hotel rooms.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelRoomModel"/> representing all hotel rooms data.</returns>
        [HttpGet("HotelRoom/GetHotelRooms/{hotelID}")]
        public async Task<Result<List<HotelRoomModel>>> GetHotelRooms(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelRooms method initiated.");

                var serviceResult = await _hotelRoomService.GetHotelRoomAsync(hotelID);

                _logger.LogInformation("Controller: GetHotelRooms method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelRooms method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel rooms.");
            }
        }

        /// <summary>
        /// Retrieves a list of hotel rooms with booking details, including TimeLeftToCheckOut.
        /// </summary>
        /// <param name="hotelID">The ID of the hotel.</param>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="HotelRoomModel"/>.</returns>
        [HttpGet("HotelRoom/GetHotelRoomAllDetails/{hotelID}")]
        public async Task<Result<List<HotelRoomDetailModel>>> GetHotelRoomAllDetails(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelRoomAllDetails method initiated.");

                var serviceResult = await _hotelRoomService.GetHotelRoomAllDetailsAsync(hotelID);

                _logger.LogInformation("Controller: GetHotelRoomAllDetails method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelRoomAllDetails method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel room details.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific hotel room by its ID.
        /// </summary>
        /// <param name="hotelRoomID">The ID of the hotel room to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetHotelRoomModel"/> for the specified hotel room Id.</returns>
        [HttpGet("HotelRoom/GetHotelRoomById/{hotelRoomID}")]
        public async Task<Result<HotelRoomModel>> GetHotelRoomById(int hotelRoomID)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelRoomById method initiated.");

                var serviceResult = await _hotelRoomService.GetHotelRoomByIdAsync(hotelRoomID);

                _logger.LogInformation("Controller: GetHotelRoomById method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelRoomById method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel room by Id.");
            }
        }

        /// <summary> 
        /// Adds a new hotel room record based on the provided hotelRoomRequestModel.
        /// </summary>
        /// <param name="hotelRoomRequestModel">The <see cref="AddEditHotelRoomModel"/> containing data for the new hotel room.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel room creation operation.</returns>
        [HttpPost("HotelRoom/AddEditHotelRoom")]
        public async Task<Result> AddEditHotelRoom([FromBody] AddEditHotelRoomModel hotelRoomRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: AddEditHotelRoom method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomService.AddEditHotelRoomAsync(hotelRoomRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: AddEditHotelRoom method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddEditHotelRoom method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room.");
            }
        }

        /// <summary>
        /// Updates an existing hotel room record based on the provided hotelRoomID and hotelRoomRequestModel.
        /// </summary>
        /// <param name="hotelRoomID">The ID of the hotel room to be updated.</param>
        /// <param name="RoomStatus">The RoomStatus of the hotel room to be updated.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel room update operation.</returns>
        [HttpPut("HotelRoom/UpdateHotelRoom/{hotelRoomID}")]
        public async Task<Result> UpdateHotelRoomStatus(int hotelRoomID, string RoomStatus)
        {
            try
            {
                _logger.LogInformation("Controller: UpdateHotelRoomStatus method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomService.UpdateHotelRoomStatusAsync(hotelRoomID, RoomStatus, auditInfoModel);

                _logger.LogInformation("Controller: UpdateHotelRoomStatus method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: UpdateHotelRoomStatus method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while updating the hotel room.");
            }
        }

        /// <summary>
        /// Deletes a hotel room based on the provided hotelRoomID.
        /// </summary>
        /// <param name="hotelRoomID">The ID of the hotel room to be deleted.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the delete operation.</returns>
        [HttpPut("HotelRoom/DeleteHotelRoom/{hotelRoomID}")]
        public async Task<Result> DeleteHotelRoom(int hotelRoomID)
        {
            try
            {
                _logger.LogInformation("Controller: DeleteHotelRoom method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelRoomService.DeleteHotelRoomAsync(hotelRoomID, auditInfoModel);

                _logger.LogInformation("Controller: DeleteHotelRoom method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DeleteHotelRoom method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while deleting the hotel room.");
            }
        }
        #endregion

        #region HotelExpense  

        [HttpGet("GetHotelExpense/{hotelID}")]
        public async Task<Result<List<HotelExpenseModel>>> GetHotelExpense(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelExpense method initiated.");

                var serviceResult = await _hotelService.GetHotelExpenseAsync(hotelID);

                _logger.LogInformation("Controller: GetHotelExpense method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelExpense method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel expense.");
            }
        }

        [HttpPost("AddHotelExpense")]
        public async Task<Result> AddHotelExpense([FromBody] HotelExpenseModel hotelExpenseRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: AddHotelExpense method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();

                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelService.AddHotelExpenseAsync(hotelExpenseRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: AddHotelExpense method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddHotelExpense method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding hotel expense.");
            }
        }

        [HttpPut("UpdateHotelExpense")]
        public async Task<Result> UpdateHotelExpense([FromBody] HotelExpenseModel hotelExpenseRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: UpdateHotelExpense method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelService.UpdateHotelExpenseAsync(hotelExpenseRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: UpdateHotelExpense method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: UpdateHotelExpense method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while updating Hotel Expense.");
            }
        }

        [HttpDelete("DeleteHotelExpense/{hotelExpenseID}")]
        public async Task<Result> DeleteHotelExpense(int hotelExpenseID)
        {
            try
            {
                _logger.LogInformation("Controller: DeleteHotelExpense method initiated.");

                var serviceResult = await _hotelService.DeleteHotelExpenseAsync(hotelExpenseID);

                _logger.LogInformation("Controller: DeleteHotelExpense method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DeleteHotelExpense method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while deleting hotel expense.");
            }
        }

        #endregion


        #region DirectBillingCompany  

        [HttpGet("GetDirectBillingCompany/{hotelID}")]
        public async Task<Result<List<DirectBillingCompanyModel>>> GetDirectBillingCompany(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetDirectBillingCompany method initiated.");

                var serviceResult = await _hotelService.GetDirectBillingCompanyAsync(hotelID);

                _logger.LogInformation("Controller: GetDirectBillingCompany method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetDirectBillingCompany method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching DirectBillingCompany.");
            }
        }

        [HttpPost("AddUpdateDirectBillingCompany")]
        public async Task<Result> AddUpdateDirectBillingCompany([FromBody] DirectBillingCompanyModel directBillingCompanyRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: AddUpdateDirectBillingCompany method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();

                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _hotelService.AddUpdateDirectBillingCompanyAsync(directBillingCompanyRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: AddUpdateDirectBillingCompany method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: AddUpdateDirectBillingCompany method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while AddUpdateDirectBillingCompany.");
            }
        }

        #endregion
    }

}