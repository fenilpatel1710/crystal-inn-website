﻿using Ardalis.Result;
using Ardalis.Result.AspNetCore;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using CheckinPro.WebApp.Providers;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace CheckinPro.WebApp.Controllers
{
    [Route("api/[controller]")]
    [TranslateResultToActionResult]
    [ApiController]
    public class UserAccountController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly PasswordService _passwordService;
        private readonly ISessionUserService _sessionUserService;
        private readonly IUserAccountService _userAccountService;
        public UserAccountController(ILogger<UserAccountController> logger, IUserAccountService userAccountService, PasswordService passwordService, ISessionUserService sessionUserService)
        {
            _logger = logger;
            _userAccountService = userAccountService;
            _passwordService = passwordService;
            _sessionUserService = sessionUserService;
        }

        /// <summary>
        /// Retrieves details of a specific user by its emailID.
        /// </summary>
        /// <param name="emailID">The emailID of the user to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="SignInUserResponseModel"/> for the specified emailID.</returns>       
        [Authorize]
        [HttpGet("GetSignInUserDetail")]
        public async Task<Result<SignInUserResponseModel>> GetSignInUserDetail()
        {
            try
            {
                _logger.LogInformation("Controller: GetSignInUserDetail method initiated.");

                var serviceResponse = await _userAccountService.GetSignInUserDetailAsync(_sessionUserService.GetUserEmail());
                if (serviceResponse.IsSuccess)
                {
                    _logger.LogInformation("Controller: GetSignInUserDetail method execution completed.");
                    return Result.Success(serviceResponse);
                }
                else
                {
                    return Result.NoContent();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetSignInUserDetail method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while GetSignInUserDetail.");
            }
        }

        /// <summary>
        /// Authenticates a user based on the provided sign-in credentials.
        /// </summary>
        /// <param name="signInRequestModel">The <see cref="SignInRequestModel"/> containing the user's email and password for authentication.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the user Signin operation.</returns>
        [HttpPost("SignIn")]
        public async Task<Result<Boolean>> SignIn([FromBody] SignInRequestModel signInRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: SignIn method initiated.");

                var serviceResponse = await _userAccountService.GetPasswordToVerify(signInRequestModel.EmailID);
                if (serviceResponse.Value != string.Empty)
                {
                    if (_passwordService.VerifyHashedPassword(serviceResponse.Value, signInRequestModel.Password))
                    {

                        var serviceResult = await _userAccountService.GetSignInUserDetailAsync(signInRequestModel.EmailID);
                        if (serviceResult.IsSuccess)
                        {
                            var claims = new List<Claim>
                            {
                                new(ClaimTypes.Sid, serviceResult.Value.UserID.ToString()),
                                new(ClaimTypes.GivenName, serviceResult.Value.UserName),
                                new(ClaimTypes.Role, serviceResult.Value.RoleName),
                                new(ClaimTypes.Email, serviceResult.Value.EmailID),
                                new("IsProfileActive", serviceResult.Value.IsProfileActive.ToString())
                            };

                            var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                            var authProperties = new AuthenticationProperties();

                            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), authProperties);

                            _logger.LogInformation("Controller: SignIn method execution completed.");
                            return Result.Success(serviceResult.Value.IsPasswordChanged);
                        }
                        else
                        {
                            _logger.LogInformation("Controller: Invalid email or password.");
                            return Result.NoContent();
                        }
                    }
                    else
                    {
                        _logger.LogInformation("Controller: Invalid email or password.");
                        return Result.Unauthorized("Invalid email or password");
                    }
                }
                else
                {
                    return Result.NoContent();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: SignIn method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while user signin.");
            }
        }

        /// <summary>
        /// Initiates a password change for the user identified by the specified email address.
        /// </summary>
        /// <param name="changePasswordModel">The model containing the user's email address, current password, and new password.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the change password operation.</returns>
        [Authorize]
        [HttpPost("ChangePassword")]
        public async Task<Result> ChangePassword([FromBody] ChangePasswordModel changePasswordModel)
        {
            try
            {
                _logger.LogInformation("Controller: ChangePassword method initiated.");

                var serviceResponse = await _userAccountService.GetPasswordToVerify(changePasswordModel.EmailID);
                if (serviceResponse.Value != string.Empty)
                {
                    if (_passwordService.VerifyHashedPassword(serviceResponse.Value, changePasswordModel.OldPassword))
                    {

                        changePasswordModel.NewPassword = _passwordService.HashPassword(changePasswordModel.NewPassword);
                        var serviceResult = await _userAccountService.ChangePasswordAsync(changePasswordModel);

                        _logger.LogInformation("Controller: ChangePassword method execution completed.");
                        return Result.Success(serviceResult);
                    }
                    else
                    {
                        _logger.LogInformation("Controller: Invalid email or password.");
                        return Result.Invalid();
                    }
                }
                else
                {
                    return Result.NoContent();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: ChangePassword method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while change password.");
            }
        }

        /// <summary>
        /// Initiates a password reset process for the user identified by the provided EmailID.
        /// </summary>
        /// <param name="forgotPasswordModel">The model containing the user's email address and new password.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the forgot password operation.</returns>

        [HttpPost("ForgotPassword/{EmailID}")]
        public async Task<Result> ForgotPassword(string EmailID)
        {
            try
            {
                _logger.LogInformation("Controller: ForgotPassword method initiated.");

                var serviceResult = await _userAccountService.ForgotPasswordAsync(EmailID);

                _logger.LogInformation("Controller: ForgotPassword method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: ForgotPassword method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while forgot password.");
            }
        }

        /// <summary>
        /// Verifies whether the provided input OTP matches the stored OTP.
        /// </summary>
        /// <param name="ValidateOTPModel">The <see cref="ValidateOTPModel"/> containing the user's email and OTP for verification.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the OTP verification operation.</returns>

        [HttpPost("ValidateOTP")]
        public async Task<Result> ValidateOTP([FromBody] ValidateOTPModel validateOTPModel)
        {
            try
            {
                _logger.LogInformation("Controller: ValidateOTP method initiated.");

                var serviceResult = await _userAccountService.ValidateOTPAsync(validateOTPModel);

                _logger.LogInformation("Controller: ValidateOTP method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: ValidateOTP method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while validating password.");
            }
        }

        /// <summary>
        /// For password reset.
        /// </summary>
        /// <param name="resetPasswordModel">The <see cref="ResetPasswordModel"/> containing the user's email and new password for reset.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the password reset operation.</returns>

        [HttpPost("ResetPassword")]
        public async Task<Result> ResetPassword([FromBody] ResetPasswordModel resetPasswordModel)
        {
            try
            {
                _logger.LogInformation("Controller: ResetPassword method initiated.");


                resetPasswordModel.NewPassword = _passwordService.HashPassword(resetPasswordModel.NewPassword);
                var serviceResult = await _userAccountService.ResetPasswordAsync(resetPasswordModel);

                _logger.LogInformation("Controller: ResetPassword method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: ResetPassword method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while password reset  .");
            }
        }

        [Authorize]
        [HttpPost]
        [Route("SignOut")]
        public async Task<IActionResult> SignOutAsync()
        {
            await HttpContext.SignOutAsync();
            HttpContext.Response.Cookies.Delete("AppCookies", new CookieOptions()
            {
                Expires = DateTime.Now.AddDays(-1),
                Secure = true
            });
            return Ok("success");
        }
    }
}
