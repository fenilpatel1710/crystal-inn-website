﻿using Ardalis.Result;
using Ardalis.Result.AspNetCore;
using CheckinPro.Common.Models;
using CheckinPro.Services.IServices;
using Microsoft.AspNetCore.Mvc;

namespace CheckinPro.WebApp.Controllers
{
    [Route("api/[controller]")]
    [TranslateResultToActionResult]
    [ApiController]
    public class DropdownController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IDropdownService _dropdownService;
        public DropdownController(ILogger<DropdownController> logger, IDropdownService dropdownService)
        {
            _logger = logger;
            _dropdownService = dropdownService;
        }

        [HttpGet("GetRolesForDropdown")]
        public async Task<Result<List<SelectionItemModel>>> GetRolesForDropdown()
        {
            try
            {
                _logger.LogInformation("Controller: GetRolesForDropdown method initiated.");

                var roleModels = await _dropdownService.GetRolesForDropdownAsync();

                _logger.LogInformation("Controller: GetRolesForDropdown method execution completed.");
                return Result.Success(roleModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetRolesForDropdown method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while getting the active roles.");
            }
        }

        [HttpGet("GetCountriesForDropdown")]
        public async Task<Result<List<SelectionItemModel>>> GetCountriesForDropdown()
        {
            try
            {
                _logger.LogInformation("Controller: GetCountriesForDropdown method initiated.");

                var countryModels = await _dropdownService.GetCountriesForDropdownAsync();

                _logger.LogInformation("Controller: GetCountriesForDropdown method execution completed.");
                return Result.Success(countryModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetCountriesForDropdown method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while getting the active countries.");
            }
        }

        [HttpGet("GetStatesForDropdown/{countryID}")]
        public async Task<Result<List<SelectionItemModel>>> GetStatesForDropdown(int countryID)
        {
            try
            {
                _logger.LogInformation("Controller: GetStatesForDropdown method initiated.");

                var roomTypeModels = await _dropdownService.GetStatesForDropdownAsync(countryID);

                _logger.LogInformation("Controller: GetStatesForDropdown method execution completed.");
                return Result.Success(roomTypeModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetStatesForDropdown method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while getting the active state.");
            }
        }

        [HttpGet("GetHotelRoomTypesForDropdown/{hotelID}")]
        public async Task<Result<List<SelectionItemModel>>> GetHotelRoomTypeForDropdown(int hotelID)
        {
            try
            {
                _logger.LogInformation("Controller: GetHotelRoomTypesForDropdown method initiated.");

                var roleModels = await _dropdownService.GetHotelRoomTypesForDropdownAsync(hotelID);

                _logger.LogInformation("Controller: GetHotelRoomTypesForDropdown method execution completed.");
                return Result.Success(roleModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetHotelRoomTypesForDropdown method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while getting the active room feature.");
            }
        }

        [HttpGet("GetRoomStatusesForDropdown")]
        public async Task<Result<List<SelectionItemModel>>> GetRoomStatusesForDropdown()
        {
            try
            {
                _logger.LogInformation("Controller: GetRoomStatusesForDropdown method initiated.");

                var roleModels = await _dropdownService.GetRoomStatusesForDropdownAsync();

                _logger.LogInformation("Controller: GetRoomStatusesForDropdown method execution completed.");
                return Result.Success(roleModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetRoomStatusesForDropdown method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while getting the active room  status.");
            }
        }
    }
}
