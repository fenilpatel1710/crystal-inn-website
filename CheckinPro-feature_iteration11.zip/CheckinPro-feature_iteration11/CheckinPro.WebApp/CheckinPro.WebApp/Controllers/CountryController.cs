﻿using Ardalis.Result;
using Ardalis.Result.AspNetCore;
using CheckinPro.Common.Models;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using CheckinPro.WebApp.Providers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CheckinPro.WebApp.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [TranslateResultToActionResult]
    [ApiController]
    public class CountryController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly ICountryService _countryService;
        private readonly ISessionUserService _sessionUserService;

        public CountryController(ILogger<CountryController> logger, ICountryService countryService, ISessionUserService sessionUserService)
        {
            _logger = logger;
            _countryService = countryService;
            _sessionUserService = sessionUserService;
        }

        [HttpGet("GetCountries")]
        public async Task<Result<List<CountryModel>>> GetCountries()
        {
            try
            {
                _logger.LogInformation("Controller: GetCountries method initiated.");

                var countryModels = await _countryService.GetCountriesAsync();

                _logger.LogInformation("Controller: GetCountries method execution completed.");
                return Result.Success(countryModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetCountries method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while getting the country.");
            }
        }

        [HttpGet("GetCountryById/{countryId}")]
        public async Task<Result<CountryModel>> GetCountryById(int countryId)
        {
            try
            {
                _logger.LogInformation("Controller: GetCountryById method initiated.");

                var countryModel = await _countryService.GetCountryByIdAsync(countryId);

                _logger.LogInformation("Controller: GetCountryById method execution completed.");
                return Result.Success(countryModel);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: GetCountryById method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while updating the country.");
            }
        }

        [HttpPost("AddCountry")]
        public async Task<Result> CreateCountry([FromBody] CountryModel countryRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: CreateCountry method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _countryService.AddCountryAsync(countryRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: CreateCountry method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: CreateCountry method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the country.");
            }
        }

        [HttpPut("UpdateCountry/{countryId}")]
        public async Task<Result> UpdateCountry(int countryId, [FromBody] CountryModel countryRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: UpdateCountry method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _countryService.UpdateCountryAsync(countryId, countryRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: UpdateCountry method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: UpdateCountry method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while updating the country.");
            }
        }

        [HttpPut("DeleteCountry/{countryId}")]
        public async Task<Result> DeleteCountry(int countryId, CountryModel countryRequestModel)
        {
            try
            {
                _logger.LogInformation("Controller: DeleteCountry method initiated.");

                AuditInfoModel auditInfoModel = new AuditInfoModel();
                auditInfoModel.AuditUserID = _sessionUserService.GetUserId();
                auditInfoModel.AuditUserRole = _sessionUserService.GetUserRole();

                var serviceResult = await _countryService.DeleteCountryAsync(countryId, countryRequestModel, auditInfoModel);

                _logger.LogInformation("Controller: DeleteCountry method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DeleteCountry method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while deleting the country.");
            }
        }
    }
}
