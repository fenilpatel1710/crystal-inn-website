using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Report.Templates;
using CheckinPro.Repositories;
using CheckinPro.Repositories.IRepository;
using CheckinPro.Services;
using CheckinPro.Services.IServices;
using CheckinPro.WebApp.Components;
using CheckinPro.WebApp.Providers;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.Filters;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Add WebApp services
builder.Services.AddRazorComponents()
    .AddInteractiveWebAssemblyComponents();

// Add Cookie Authentication services
builder.Services.AddAuthentication(
            CookieAuthenticationDefaults.AuthenticationScheme
        )
        .AddCookie(options =>
        {
            options.Cookie = new CookieBuilder
            {
                Name = "AppCookies",
                SameSite = SameSiteMode.None,
            };
            options.Events = new CookieAuthenticationEvents
            {
                OnRedirectToLogin = context =>
                {
                    context.Response.Clear();
                    context.Response.StatusCode = 401;

                    return Task.CompletedTask;
                }
            };
            options.ExpireTimeSpan = TimeSpan.FromMinutes(30);
        });



// Add WebApi services
builder.Services.AddControllers()
    .AddXmlSerializerFormatters();

//// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();

// Add Swagger services.
builder.Services.AddSwaggerGen(option =>
{
    option.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        Description = "JWT Authorization header using the Bearer scheme. Enter 'Bearer' [space] and then your token in the text input below. Example: 'Bearer 12345abcdef'",
    });

    option.OperationFilter<SecurityRequirementsOperationFilter>();
});

// Add Cors services.
builder.Services.AddCors(options =>
{
    options.AddPolicy("CorsSpecs",
    builder =>
    {
        builder
            .AllowAnyHeader()
            .AllowAnyMethod()
            .SetIsOriginAllowed(options => true)
        .AllowCredentials();
    });
});

// Add configuration files
builder.Configuration
    .SetBasePath(Directory.GetCurrentDirectory())
    .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: true, reloadOnChange: true);

// Add DbContext ConnectionString 
var SQLDBConnectionString = builder.Configuration.GetValue<string>("ConnectionStrings:DBConnectionString");

builder.Services.AddDbContext<CheckinProContext>(options =>
                       options.UseSqlServer(SQLDBConnectionString));

// Register SMTP settings
builder.Services.Configure<SmtpSettings>(builder.Configuration.GetSection("SMTPConfiguration"));

// Register Memory Cache
builder.Services.AddMemoryCache();

// Register all the custom dependency injection Repositories
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<ICountryRepository, CountryRepository>();
builder.Services.AddScoped<IStateRepository, StateRepository>();
builder.Services.AddScoped<IRoomStatusRepository, RoomStatusRepository>();
builder.Services.AddScoped<IUserAccountRepository, UserAccountRepository>();
builder.Services.AddScoped<IEmailRepository, EmailRepository>();
builder.Services.AddScoped<IRoleRepository, RoleRepository>();
builder.Services.AddScoped<IHotelRepository, HotelRepository>();
builder.Services.AddScoped<IHotelRoomRepository, HotelRoomRepository>();
builder.Services.AddScoped<IDropdownRepository, DropdownRepository>();
builder.Services.AddScoped<IHotelRoomBookingRepository, HotelRoomBookingRepository>();
builder.Services.AddScoped<IGuestRepository, GuestRepository>();
builder.Services.AddScoped<IHotelConfigurationRepository, HotelConfigurationRepository>();
builder.Services.AddScoped<IDashboardRepository, DashboardRepository>();
builder.Services.AddScoped<IHtmlGenerator, HtmlGenerator>();
builder.Services.AddScoped<IHotelReportRepository, HotelReportRepository>();
builder.Services.AddScoped<IScannerRepository, ScannerRepository>();



// Register all the custom dependency injection Services
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<ICountryService, CountryService>();
builder.Services.AddScoped<IStateService, StateService>();
builder.Services.AddScoped<IRoomStatusService, RoomStatusService>();
builder.Services.AddScoped<IUserAccountService, UserAccountService>();
builder.Services.AddScoped<IRoleService, RoleService>();
builder.Services.AddScoped<IHotelService, HotelService>();
builder.Services.AddScoped<IHotelRoomService, HotelRoomService>();
builder.Services.AddScoped<IDropdownService, DropdownService>();
builder.Services.AddScoped<PasswordService>();
builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
builder.Services.AddScoped<ISessionUserService, SessionUserService>();
builder.Services.AddScoped<IHotelRoomBookingService, HotelRoomBookingService>();
builder.Services.AddScoped<IGuestService, GuestService>();
builder.Services.AddScoped<IHotelConfigurationService, HotelConfigurationService>();
builder.Services.AddScoped<IDashboardService, DashboardService>();
builder.Services.AddScoped<IHotelReportService, HotelReportService>();
builder.Services.AddScoped<IScannerService, ScannerService>();



var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment() || app.Environment.IsStaging())
{
    app.UseWebAssemblyDebugging();
    // Add Swagger builder services
    app.UseSwagger();
    app.UseSwaggerUI();
}
else
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();
app.UseCors("CorsSpecs");
app.UseAuthentication();
app.UseAuthorization();

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveWebAssemblyRenderMode()
    .AddAdditionalAssemblies(typeof(CheckinPro.WebApp.Client._Imports).Assembly);


app.MapControllers();

app.Run();
