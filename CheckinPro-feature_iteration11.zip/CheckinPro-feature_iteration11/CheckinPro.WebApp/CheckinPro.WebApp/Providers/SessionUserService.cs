﻿using System.Security.Claims;

namespace CheckinPro.WebApp.Providers
{
    public interface ISessionUserService
    {
        int GetUserId();
        string GetUserName();
        string GetUserEmail();
        string GetUserRole();
        bool IsProfileActive();
    }
    public class SessionUserService : ISessionUserService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private ClaimsPrincipal CurrentUser => _httpContextAccessor.HttpContext?.User;

        public SessionUserService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }
        public int GetUserId()
        {
            var userIdClaim = CurrentUser?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Sid);
            return userIdClaim != null ? Convert.ToInt32(userIdClaim.Value) : 0; // Return default if not found
        }

        public string GetUserName()
        {
            var userNameClaim = CurrentUser?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.GivenName);
            return userNameClaim?.Value;
        }

        public string GetUserEmail()
        {
            var emailClaim = CurrentUser?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email);
            return emailClaim?.Value;
        }

        public string GetUserRole()
        {
            var roleClaim = CurrentUser?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role);
            return roleClaim?.Value;
        }

        public bool IsProfileActive()
        {
            var isProfileActiveClaim = CurrentUser?.Claims.FirstOrDefault(c => c.Type == "IsProfileActive");
            return isProfileActiveClaim != null && Convert.ToBoolean(isProfileActiveClaim.Value);
        }
    }
}
