﻿using CheckinPro.WebApi.Models;
using Microsoft.AspNetCore.Identity;

namespace CheckinPro.WebApp.Providers
{
    public class PasswordService
    {
        private readonly IPasswordHasher<GetUserModel> _passwordHasher = new PasswordHasher<GetUserModel>();
        private static readonly Random _random = new Random();
        GetUserModel getUserModel = new GetUserModel();

        public string RandomPasswordGenerator()
        {
            int passwordLength = 8;
            // Define the characters that can be used in the password
            char[] characters = Enumerable.Range(48, 74)  // ASCII values 48 to 122
                .Select(i => (char)i)
                .Where(c => char.IsLetterOrDigit(c)) // Only letters and digits
                .ToArray();

            // Generate the password using random characters
            var randomPassword = new string(Enumerable.Repeat(characters, passwordLength)
                .Select(s => s[_random.Next(s.Length)]).ToArray());

            return randomPassword;
        }

        public string HashPassword(string password)
        {
            //Used to generate hashed password for new users
            var hashedPassword = _passwordHasher.HashPassword(getUserModel, password);

            return hashedPassword;
        }

        public bool VerifyHashedPassword(string dbPassword, string password)
        {
            //get storedHashedPassword from User table using user username/email
            var result = _passwordHasher.VerifyHashedPassword(getUserModel, dbPassword, password);
            return result == PasswordVerificationResult.Success;

        }
    }
}
