using Blazored.LocalStorage;
using CheckinPro.WebApp.Client.IServices;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Radzen;
using Refit;

var builder = WebAssemblyHostBuilder.CreateDefault(args);

builder.Services.AddRadzenComponents();
builder.Services.AddScoped<ThemeService>();

builder.Services.AddAuthorizationCore();

builder.Services.AddScoped<AuthenticationStateProvider, CustomAuthStateProvider>();

builder.Services.AddBlazoredLocalStorage();

builder.Services.AddTransient<RefitRequestHandler>();

// Add services to the container.
//var baseURL = builder.Configuration.GetValue<string>("BaseAddress");
var baseURL = builder.HostEnvironment.BaseAddress + "api";
if (baseURL != null)
{
    builder.Services.AddRefitClient<IUserAccountWebAppService>().ConfigureHttpClient(c =>
    {
        c.BaseAddress = new Uri(baseURL);
    });

    builder.Services.AddRefitClient<IRoleWebAppService>().ConfigureHttpClient(c =>
    {
        c.BaseAddress = new Uri(baseURL);

    }).AddHttpMessageHandler<RefitRequestHandler>();

    builder.Services.AddRefitClient<ICountryWebAppService>().ConfigureHttpClient(c =>
    {
        c.BaseAddress = new Uri(baseURL);
    }).AddHttpMessageHandler<RefitRequestHandler>();

    builder.Services.AddRefitClient<IStateWebAppService>().ConfigureHttpClient(c =>
    {
        c.BaseAddress = new Uri(baseURL);
    }).AddHttpMessageHandler<RefitRequestHandler>();

    builder.Services.AddRefitClient<IRoomStatusWebAppService>().ConfigureHttpClient(c =>
    {
        c.BaseAddress = new Uri(baseURL);
    }).AddHttpMessageHandler<RefitRequestHandler>();


    builder.Services.AddRefitClient<IUserWebAppService>().ConfigureHttpClient(c =>
    {
        c.BaseAddress = new Uri(baseURL);
    }).AddHttpMessageHandler<RefitRequestHandler>();

    builder.Services.AddRefitClient<IDropdownWebAppService>().ConfigureHttpClient(c =>
    {
        c.BaseAddress = new Uri(baseURL);
    }).AddHttpMessageHandler<RefitRequestHandler>();
    builder.Services.AddRefitClient<IDashboardWebAppService>().ConfigureHttpClient(c =>
    {
        c.BaseAddress = new Uri(baseURL);
    }).AddHttpMessageHandler<RefitRequestHandler>();

    builder.Services.AddRefitClient<IHotelWebAppService>().ConfigureHttpClient(c =>
    {
        c.BaseAddress = new Uri(baseURL);
    }).AddHttpMessageHandler<RefitRequestHandler>();

    builder.Services.AddRefitClient<IGuestWebAppService>().ConfigureHttpClient(c =>
    {
        c.BaseAddress = new Uri(baseURL);
    }).AddHttpMessageHandler<RefitRequestHandler>();

    builder.Services.AddRefitClient<IGuestWebAppService>().ConfigureHttpClient(c =>
    {
        c.BaseAddress = new Uri(baseURL);
    }).AddHttpMessageHandler<RefitRequestHandler>();

    builder.Services.AddRefitClient<IHotelRoomBookingWebAppService>().ConfigureHttpClient(c =>
    {
        c.BaseAddress = new Uri(baseURL);
    }).AddHttpMessageHandler<RefitRequestHandler>();

    builder.Services.AddRefitClient<IHotelReportWebAppService>().ConfigureHttpClient(c =>
    {
        c.BaseAddress = new Uri(baseURL);
    }).AddHttpMessageHandler<RefitRequestHandler>();
}

await builder.Build().RunAsync();
