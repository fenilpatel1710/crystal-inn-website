﻿using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components.Authorization;
using System.Security.Claims;
public class CustomAuthStateProvider : AuthenticationStateProvider
{
    private ClaimsPrincipal claimsPrincipal = new(new ClaimsIdentity());
    public override async Task<AuthenticationState> GetAuthenticationStateAsync()
    {
        return await Task.FromResult(new AuthenticationState(claimsPrincipal));
    }

    public void SetAuthInfo(SignInResponseWebAppModel signInResponseWebAppModel)
    {
        var identity = new ClaimsIdentity([
            new Claim(ClaimTypes.Sid, signInResponseWebAppModel.UserID.ToString()),
            new Claim("HotelID", signInResponseWebAppModel.HotelID.ToString()),
            new Claim(ClaimTypes.GivenName, signInResponseWebAppModel.UserName),
            new Claim(ClaimTypes.Role, signInResponseWebAppModel.RoleName),
            new Claim(ClaimTypes.Email, signInResponseWebAppModel.EmailID),
            new Claim("IsProfileActive", signInResponseWebAppModel.IsProfileActive.ToString()),
            new Claim("IsShiftActive", signInResponseWebAppModel.IsShiftActive.ToString()),
            new Claim("IsOwnerDashboardVisible", signInResponseWebAppModel.IsOwnerDashboardVisible.ToString())
            ], "AuthCookie");

        claimsPrincipal = new ClaimsPrincipal(identity);
        NotifyAuthenticationStateChanged(GetAuthenticationStateAsync());
    }

    public void ClearAuthInfo()
    {
        claimsPrincipal = new ClaimsPrincipal(new ClaimsIdentity());
        NotifyAuthenticationStateChanged(GetAuthenticationStateAsync());
    }
}