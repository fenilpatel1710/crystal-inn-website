﻿using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using System.Security.Claims;

namespace CheckinPro.WebApp.Client.Providers
{
    public class CustomComponentBase : ComponentBase
    {
        [Inject]
        protected AuthenticationStateProvider _authStateProvider { get; set; }

        [Inject] private NavigationManager _navigationManager { get; set; }

        private NotificationAlert _notificationAlertComponent = new();



        public async Task<SignInResponseWebAppModel> GetCurrentUser()
        {
            var user = (await (_authStateProvider as CustomAuthStateProvider)
            .GetAuthenticationStateAsync()).User;

            var userInfo = new SignInResponseWebAppModel
            {
                IsAuthenticated = user.Identity.IsAuthenticated
            };

            if (user.Identity.IsAuthenticated)
            {
                var sidClaim = user.FindFirst(x => x.Type == ClaimTypes.Sid);
                userInfo.UserID = sidClaim != null ? Convert.ToInt16(sidClaim.Value) : 0;

                var hotelID = user.FindFirst(x => x.Type == "HotelID");
                userInfo.HotelID = hotelID != null ? Convert.ToInt16(hotelID.Value) : 0;

                var givenNameClaim = user.FindFirst(x => x.Type == ClaimTypes.GivenName);
                userInfo.UserName = givenNameClaim?.Value ?? string.Empty;

                var roleClaim = user.FindFirst(x => x.Type == ClaimTypes.Role);
                userInfo.RoleName = roleClaim?.Value ?? string.Empty;

                var emailClaim = user.FindFirst(x => x.Type == ClaimTypes.Email);
                userInfo.EmailID = emailClaim?.Value ?? string.Empty;

                var profileActiveClaim = user.FindFirst(x => x.Type == "IsProfileActive");
                userInfo.IsProfileActive = bool.TryParse(profileActiveClaim?.Value, out bool result) ? result : false;

                var shiftActiveClaim = user.FindFirst(x => x.Type == "IsShiftActive");
                userInfo.IsShiftActive = bool.TryParse(shiftActiveClaim?.Value, out bool results) ? results : false;

                var ownerDashboardVisibleClaim = user.FindFirst(x => x.Type == "IsOwnerDashboardVisible");
                userInfo.IsOwnerDashboardVisible = bool.TryParse(ownerDashboardVisibleClaim?.Value, out bool resultss) ? resultss : false;
            }
            return userInfo;
        }
    }
}
