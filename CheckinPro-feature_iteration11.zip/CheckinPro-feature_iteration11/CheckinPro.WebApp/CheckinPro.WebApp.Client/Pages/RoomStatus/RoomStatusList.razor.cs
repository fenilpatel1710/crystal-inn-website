﻿using CheckinPro.Common.Models;
using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Pages.Hotel.HotelRoom;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.RoomStatus
{
    public partial class RoomStatusList : ComponentBase
    {

        #region Inject Services
        [Inject] private IRoomStatusWebAppService _roomStatusWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter
        private bool IsLoading { get; set; } = true;
        bool IsBusy { get; set; } = false;

        private string pagingSummaryFormat = "Displaying page {0} of {1} (total {2} records)";

        private IEnumerable<int> pageSizeOptions = new int[] { 10, 20, 30 };

        private int selectedIndex = 0;

        private string? roomStatusName;

        private string? roomStatusIconName;

        private List<GetRoomStatusWebAppModel> serviceResponseData { get; set; } = new();
        private List<GetRoomStatusWebAppModel> activeRoomStatuses => serviceResponseData.Where(a => !a.IsDeleted).ToList();
        private List<GetRoomStatusWebAppModel> deletedRoomStatuses => serviceResponseData.Where(a => a.IsDeleted).ToList();

        #endregion


        #region Page Method Starts
        protected override async Task OnAfterRenderAsync(bool firstRender)
        {
            if (firstRender)
            {
                await GetRoomStatuses();
            }
        }

        private async Task CreateEditRoomStatusDialog(GetRoomStatusWebAppModel? roomStatusModel)
        {
            // Determine dialog title based on whether we're creating or editing
            var dialogName = roomStatusModel == null ? "Add Room Status" : "Edit Room Status";

            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true };

            var roomStatusRequestModel = new GetRoomStatusWebAppModel();
            if (roomStatusModel != null)
            {
                roomStatusRequestModel.RoomStatusID = roomStatusModel.RoomStatusID;
                roomStatusRequestModel.RoomStatusName = roomStatusModel.RoomStatusName;
                roomStatusRequestModel.RoomStatusIcon = roomStatusModel.RoomStatusIcon;
                roomStatusRequestModel.Description = roomStatusModel.Description;
                roomStatusRequestModel.IsActive = roomStatusModel.IsActive;
            }

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<RoomStatusForm>(dialogName, new Dictionary<string, object>
            {
                { "roomStatusRequestModel", roomStatusRequestModel },
                { "IsBusy", IsBusy },
                { "OnSubmit", EventCallback.Factory.Create<GetRoomStatusWebAppModel>(this, HandleFormOnRoomStatusSubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }

        private async Task HandleFormOnRoomStatusSubmit(GetRoomStatusWebAppModel roomStatusRequestModel)
        {
            _dialogService.Close();

            if (roomStatusRequestModel.RoomStatusID == 0)
            {
                await CreateRoomStatus(roomStatusRequestModel);
            }
            else
            {
                await EditRoomStatus(roomStatusRequestModel);
            }
        }

        private void HandleOnCancel()
        {
            _dialogService.Close();
        }
        private void OnCreateNewClick()
        {
            _navigationManager.NavigateTo("/roomstatus/add");
        }

        private void NavigateToEditPage(int roomStatusID)
        {
            // Use navigation manager to redirect to the Edit amenity page
            _navigationManager.NavigateTo($"/roomstatus/edit/{roomStatusID}");
        }

        private async Task ConfirmDelete(int roomStatusID, string RoomStatusName)
        {
            var result = await _dialogService.Confirm($"Are you sure you want to delete the Room Status <strong>'{RoomStatusName}'</strong>?", "Confirm Delete",
                new ConfirmOptions() { OkButtonText = "Yes", CancelButtonText = "No", ShowClose = true });


            if (result.HasValue && result.Value)
            {
                await DeleteRoomStatus(roomStatusID, RoomStatusName);
            }
            // Refresh the data grid or perform any necessary actions
            await GetRoomStatuses();
        }

        #endregion

        #region API service calls
        private async Task GetRoomStatuses()
        {
            IsLoading = true;
            var serviceResponse = await _roomStatusWebAppService.GetRoomStatuses();
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseData = serviceResponse.Content;
            }
            else
            {
                serviceResponseData = new List<GetRoomStatusWebAppModel>();
            }
            IsLoading = false;
            StateHasChanged();
        }

        private async Task CreateRoomStatus(GetRoomStatusWebAppModel roomStatusRequestModel)
        {
            IsLoading = true;
            IsBusy = true;

            var addRoomStatusRequestModel = new AddRoomStatusWebAppModel()
            {
                RoomStatusName = roomStatusRequestModel.RoomStatusName,
                RoomStatusIcon = roomStatusRequestModel.RoomStatusIcon,
                Description = roomStatusRequestModel.Description,
                IsActive = roomStatusRequestModel.IsActive,

            };
            var serviceResponse = await _roomStatusWebAppService.AddRoomStatus(addRoomStatusRequestModel);


            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"'{roomStatusRequestModel.RoomStatusName}' added successfully!");

                await GetRoomStatuses();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error saving '{roomStatusRequestModel.RoomStatusName}'.");
            }
            IsLoading = false;
            IsBusy = false;
            StateHasChanged();
        }

        private async Task EditRoomStatus(GetRoomStatusWebAppModel roomStatusRequestModel)
        {
            IsLoading = true;
            IsBusy = true;

            var editRoomStatusRequestModel = new UpdateRoomStatusWebAppModel()
            {
                RoomStatusName = roomStatusRequestModel.RoomStatusName,
                RoomStatusIcon = roomStatusRequestModel.RoomStatusIcon,
                Description = roomStatusRequestModel.Description,
                IsActive = roomStatusRequestModel.IsActive,
            };

            var serviceResponse = await _roomStatusWebAppService.UpdateRoomStatus(roomStatusRequestModel.RoomStatusID, editRoomStatusRequestModel);


            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Room Status updated successfully!");
                await GetRoomStatuses();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error updating room Status.");
            }
            IsLoading = false;
            IsBusy = false;
            StateHasChanged();
        }
        private async Task DeleteRoomStatus(int roomStatusID, string RoomStatusName)
        {
            IsLoading = true;
            AuditInfoModel auditInfoModel = new AuditInfoModel();
            auditInfoModel.AuditUserID = 1;
            var serviceResponseData = await _roomStatusWebAppService.DeleteRoomStatus(roomStatusID, auditInfoModel);

            if (serviceResponseData.IsSuccessStatusCode)
            {
                //show a success notification
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"'{RoomStatusName}' deleted successfully!");
            }
            else
            {
                //show an error notification
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error deleting '{RoomStatusName}'.");
            }
            IsLoading = false;
            StateHasChanged();
        }
        #endregion
    }
}
