﻿using Blazored.LocalStorage;
using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Providers;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;
using System.Globalization;

namespace CheckinPro.WebApp.Client.Pages.Dashboard
{
    public partial class OwnerDashboard : CustomComponentBase
    {
        #region Inject Services
        [Inject] private IDashboardWebAppService _dashboardWebAppService { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private ILocalStorageService _localStorageService { get; set; }


        private NotificationAlert _notificationAlertComponent = new NotificationAlert();
        #endregion

        #region Parameter
        public int hotelID { get; set; }
        private bool isLoading { get; set; } = true;
        public List<GetHotelOwnerDashboardWebAppModel> serviceResponseHotelOwnerDashboardData { get; set; } = new();

        private List<GetHotelOwnerDashboardWebAppModel> filteredDashboardData = new();
        public List<GetHotelRoomRevenueWebAppModel> serviceResponseHotelRoomRevenueSelectedYearData { get; set; } = new();
        public List<GetHotelRoomRevenueWebAppModel> serviceResponseHotelRoomRevenueLastYearData { get; set; } = new();
        public DateTime selectedDate { get; set; } = DateTime.Now;

        private List<int> years = new();

        private int selectedYear;

        private string selectedPeriodType = "DTD";

        private List<string> periodTypes = new() { "DTD", "MTD", "YTD" };

        bool showDataLabels = false;

        #endregion

        #region Page Method Starts
        protected override async Task OnInitializedAsync()
        {
            var data = await GetCurrentUser();
            hotelID = Convert.ToInt32(data.HotelID);


            int startYear = 2020;
            int currentYear = DateTime.Now.Year;

            years = Enumerable.Range(startYear, currentYear - startYear + 1).ToList();
            selectedYear = currentYear;
            //await GetHotelRoomRevenueByYear();
            //await GetHotelMetricsByDateRange();
            isLoading = false;
            StateHasChanged();
        }

        private async void OnClickSearch()
        {
            await GetHotelMetricsByDateRange();
            StateHasChanged();
        }

        private List<string> GetMetricTypesByPeriod(string periodType)
        {
            return periodType switch
            {
                "DTD" => new() { "DTY_CY", "DTY_LY" },
                "MTD" => new() { "MTD_CY", "MTD_LY" },
                "YTD" => new() { "YTD_CY", "YTD_LY" },
                //"ALL" => new() { "DTY_CY", "DTY_LY", "MTD_CY", "MTD_LY", "YTD_CY", "YTD_LY" },
                _ => new()
            };
        }

        private async Task OnSelectedPeriodTypeChange()
        {
            var selectedMetricTypes = GetMetricTypesByPeriod(selectedPeriodType);

            filteredDashboardData = serviceResponseHotelOwnerDashboardData
                .Where(x => selectedMetricTypes.Contains(x.Metrictype))
                .ToList();

            StateHasChanged();
        }

        private BadgeStyle GetBadgeStyle(GetHotelOwnerDashboardWebAppModel item)
        {
            var parts = item.Metrictype.Split('_');
            if (parts.Length != 2)
                return BadgeStyle.Primary;

            var baseType = parts[0]; // e.g. MTD, YTD, DTY
            var currentType = parts[1]; // e.g. CY or LY

            string oppositeType = currentType == "CY" ? "LY" : "CY";

            var oppositeItem = serviceResponseHotelOwnerDashboardData
                .FirstOrDefault(i => i.Metrictype == $"{baseType}_{oppositeType}");

            if (oppositeItem != null)
            {
                if (item.TotalRevenue > oppositeItem.TotalRevenue)
                    return BadgeStyle.Success;
                else if (item.TotalRevenue < oppositeItem.TotalRevenue)
                    return BadgeStyle.Danger;
                else
                    return BadgeStyle.Primary; // same value
            }

            return BadgeStyle.Primary; // fallback if no pair found
        }

        private string GetClass(GetHotelOwnerDashboardWebAppModel item)
        {
            var parts = item.Metrictype.Split('_');
            if (parts.Length != 2)
                return "rz-color-primary";

            var baseType = parts[0]; // e.g. MTD, YTD, DTY
            var currentType = parts[1]; // e.g. CY or LY

            string oppositeType = currentType == "CY" ? "LY" : "CY";

            var oppositeItem = serviceResponseHotelOwnerDashboardData
                .FirstOrDefault(i => i.Metrictype == $"{baseType}_{oppositeType}");

            if (oppositeItem != null)
            {
                if (item.TotalRevenue > oppositeItem.TotalRevenue)
                    return "rz-color-success-dark";
                else if (item.TotalRevenue < oppositeItem.TotalRevenue)
                    return "rz-color-danger-dark";
                else
                    return "rz-color-primary";
            }
            return "rz-color-primary"; // fallback if no pair found
        }

        private async Task OnYearChange(int year)
        {
            selectedYear = year;
            await GetHotelRoomRevenueByYear();
            StateHasChanged();
        }

        string FormatAsUSD(object value)
        {
            return ((double)value).ToString("C0", CultureInfo.CreateSpecificCulture("en-US"));
        }
        #endregion


        #region API service calls
        private async Task GetHotelMetricsByDateRange()
        {
            isLoading = true;
            var serviceResponse = await _dashboardWebAppService.GetHotelMetricsByDateRange(hotelID, selectedDate, selectedPeriodType);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseHotelOwnerDashboardData = serviceResponse.Content;
                OnSelectedPeriodTypeChange();
            }
            else
            {
                serviceResponseHotelOwnerDashboardData = new List<GetHotelOwnerDashboardWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task GetHotelRoomRevenueByYear()
        {
            isLoading = true;
            var serviceResponse = await _dashboardWebAppService.GetHotelRoomRevenueByYear(hotelID, selectedYear);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseHotelRoomRevenueSelectedYearData = serviceResponse.Content;
            }
            else
            {
                serviceResponseHotelRoomRevenueSelectedYearData = new List<GetHotelRoomRevenueWebAppModel>();
            }
            var serviceResponseLastYearData = await _dashboardWebAppService.GetHotelRoomRevenueByYear(hotelID, selectedYear - 1);
            if (serviceResponseLastYearData.IsSuccessStatusCode)
            {
                serviceResponseHotelRoomRevenueLastYearData = serviceResponseLastYearData.Content;
            }
            else
            {
                serviceResponseHotelRoomRevenueLastYearData = new List<GetHotelRoomRevenueWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();

        }
        #endregion
    }
}
