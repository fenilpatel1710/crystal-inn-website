﻿using Blazored.LocalStorage;
using CheckinPro.Common.Models.Constants;
using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Pages.Hotel.HotelShift;
using CheckinPro.WebApp.Client.Providers;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;
using static CheckinPro.Common.Models.Constants.CommonConstants;

namespace CheckinPro.WebApp.Client.Pages.Dashboard
{
    public partial class Dashboard : CustomComponentBase
    {
        #region Inject Services
        [Inject] private IHotelWebAppService _hotelWebAppService { get; set; }
        [Inject] private IDashboardWebAppService _dashboardWebAppService { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private ILocalStorageService _localStorageService { get; set; }


        private NotificationAlert _notificationAlertComponent = new NotificationAlert();
        #endregion

        #region Parameter
        public int hotelID { get; set; }
        public bool IsShiftActive { get; set; }
        public string Role { get; set; }
        private bool isLoading { get; set; } = true;
        public bool IsHotelProfileComplete { get; set; }

        int selectedIndex = 0;
        private GetDashboardWebAppModel serviceResponseData { get; set; } = new();
        private HotelProfileStatusWebAppModel hotelProfileServiceResponseData { get; set; } = new();
        public HotelShiftWebAppModel serviceResponseHotelShiftData { get; set; } = new();
        #endregion

        #region Page Method Starts

        protected override async Task OnInitializedAsync()
        {
            var data = await GetCurrentUser();
            hotelID = Convert.ToInt32(data.HotelID);
            IsShiftActive = data.IsShiftActive;
            Role = data.RoleName;
            if (Role == CommonConstants.ApplicationUserRole.HotelStaff)
            {
                _navigationManager.NavigateTo($"/room-cleaning/list/{hotelID}");
            }
            if (!IsHotelProfileComplete)
            {
                await GetHotelProfileStatuses();
                await GetHotelShiftDetail();
            }

            isLoading = false;
        }

        private async Task OnStartShiftDialog()
        {
            var dialogName = "New Shift";
            var hotelShiftRequestModel = new HotelShiftWebAppModel();

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<StartShiftForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelShiftRequestModel", hotelShiftRequestModel },
                { "OnSubmit", EventCallback.Factory.Create<HotelShiftWebAppModel>(this, HandleFormOnSubmitStartShift) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            });
        }

        private async Task HandleFormOnSubmitStartShift(HotelShiftWebAppModel hotelShiftModel)
        {
            hotelShiftModel.HotelID = hotelID;
            _dialogService.Close();
            await StartHotelShift(hotelShiftModel);

        }

        private async Task OnEndShiftDialog()
        {
            var dialogName = "End Shift";
            await GetHotelShiftDetail();
            var hotelShiftRequestModel = new HotelShiftWebAppModel
            {
                HotelShiftID = serviceResponseHotelShiftData.HotelShiftID,
                HotelID = serviceResponseHotelShiftData.HotelID,
                ShiftNo = serviceResponseHotelShiftData.ShiftNo,
                StartingCash = serviceResponseHotelShiftData.StartingCash,
                TotalCashReceived = serviceResponseHotelShiftData.TotalCashReceived,
                IsShiftActive = serviceResponseHotelShiftData.IsShiftActive,
            };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<EndShiftForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelShiftRequestModel", hotelShiftRequestModel },
                { "OnSubmit", EventCallback.Factory.Create<HotelShiftWebAppModel>(this, HandleFormOnSubmitEndShift) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            });
        }

        private async Task HandleFormOnSubmitEndShift(HotelShiftWebAppModel hotelShiftModel)
        {
            _dialogService.Close();
            await EndHotelShift(hotelShiftModel);
        }
        private void HandleOnCancel()
        {
            _dialogService.Close();
        }

        private async Task OnClickNavigateTo(string redirecTo)
        {
            switch (redirecTo)
            {
                case "newbooking":
                    _navigationManager.NavigateTo($"/room-booking/{hotelID}");
                    break;
                case "searchreservations":
                    _navigationManager.NavigateTo($"/booking-summary/{hotelID}/5");
                    break;
                case "inhouse":
                    _navigationManager.NavigateTo($"/booking-summary/{hotelID}/1");
                    break;
                case "dirtyrooms":
                    _navigationManager.NavigateTo($"/room-cleaning/list/{hotelID}");
                    break;
                case "pendingcheckout":
                    _navigationManager.NavigateTo($"/booking-summary/{hotelID}/2");
                    break;
                case "checkedout":
                    _navigationManager.NavigateTo($"/booking-summary/{hotelID}/4");
                    break;
                case "arrivals":
                    _navigationManager.NavigateTo($"/booking-summary/{hotelID}/0");
                    break;
                case "cancel":
                    _navigationManager.NavigateTo($"/booking-summary/{hotelID}/3");
                    break;
                case "totalrooms":
                    _navigationManager.NavigateTo($"/hotel/room/list/{hotelID}");
                    break;
                case "outofservice":
                    _navigationManager.NavigateTo($"/hotel/room/list/{hotelID}?roomStatus={RoomStatusMessages.OutOfService}");
                    break;
                case "sold":
                    _navigationManager.NavigateTo($"/hotel/room/list/{hotelID}?roomStatus={RoomStatusMessages.Booked}");
                    break;
                case "available":
                    _navigationManager.NavigateTo($"/hotel/room/list/{hotelID}?roomStatus={RoomStatusMessages.ReadyToCheckIn}");
                    break;
                default:
                    break;
            }
        }
        #endregion

        #region API service calls

        private async Task GetHotelProfileStatuses()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelProfileCompletionStatus(hotelID);

            if (serviceResponse.IsSuccessStatusCode)
            {
                hotelProfileServiceResponseData = serviceResponse.Content;
                IsHotelProfileComplete = (hotelProfileServiceResponseData.IsHotelTaxRatePresent
                    && hotelProfileServiceResponseData.IsHotelConfigurationPresent
                    //&& hotelProfileServiceResponseData.IsHotelDailyPresent
                    && hotelProfileServiceResponseData.IsHotelHourlyPresent
                    && hotelProfileServiceResponseData.IsHotelRoomTypePresent
                    && hotelProfileServiceResponseData.IsHotelAdditionalRatePresent
                    && hotelProfileServiceResponseData.IsHotelRoomPresent
                    && hotelProfileServiceResponseData.IsHotelStaffPresent);
                if (IsHotelProfileComplete)
                {
                    await GetDashboard();
                }
            }
            else
            {
                hotelProfileServiceResponseData = new HotelProfileStatusWebAppModel();
            }

            isLoading = false;
            StateHasChanged();

        }

        private async Task GetDashboard()
        {
            isLoading = true;
            var serviceResponse = await _dashboardWebAppService.GetDashboard(hotelID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseData = serviceResponse.Content;
            }
            else
            {
                serviceResponseData = new GetDashboardWebAppModel();
            }
            isLoading = false;
            StateHasChanged();

        }

        private async Task GetHotelShiftDetail()
        {
            isLoading = true;
            var serviceResponse = await _dashboardWebAppService.GetHotelShiftDetail(hotelID);
            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {
                serviceResponseHotelShiftData = serviceResponse.Content;
                IsShiftActive = serviceResponseHotelShiftData.IsShiftActive;
                await _localStorageService.SetItemAsync("IsShiftActive", IsShiftActive.ToString());

            }
            else
            {
                IsShiftActive = false;
                await _localStorageService.SetItemAsync("IsShiftActive", IsShiftActive.ToString());
                serviceResponseHotelShiftData = new HotelShiftWebAppModel();
            }
            isLoading = false;
            StateHasChanged();

        }

        private async Task StartHotelShift(HotelShiftWebAppModel hotelShiftRequestModel)
        {
            isLoading = true;
            var serviceResponse = await _dashboardWebAppService.StartHotelShift(hotelShiftRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Shift started successfully!");
                await GetHotelShiftDetail();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while starting shift.");
            }
            _navigationManager.NavigateTo(_navigationManager.Uri, forceLoad: true);

            isLoading = false;
            StateHasChanged();
        }

        private async Task EndHotelShift(HotelShiftWebAppModel hotelShiftRequestModel)
        {
            isLoading = true;
            var serviceResponse = await _dashboardWebAppService.EndHotelShift(hotelShiftRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Shift ended successfully!");
                await GetHotelShiftDetail();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while ending shift.");
            }
            _navigationManager.NavigateTo(_navigationManager.Uri, forceLoad: true);
            isLoading = false;
            StateHasChanged();
        }
        #endregion

    }
}
