﻿using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;


namespace CheckinPro.WebApp.Client.Pages.Dashboard
{
    public partial class HotelProfileStatus : ComponentBase
    {
        #region Inject Services
        [Inject] private NavigationManager _navigationManager { get; set; }
        #endregion

        #region Parameter

        [Parameter] public int hotelID { get; set; } = 0;
        [Parameter] public bool IsHotelProfileComplete { get; set; }
        [Parameter] public HotelProfileStatusWebAppModel serviceResponseData { get; set; } = new();

        #endregion


        #region Page Method Starts
        protected override async Task OnInitializedAsync()
        {
        }

        #endregion

        #region API service calls

        #endregion
    }
}
