﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.User
{
    public partial class ProfileInfo : ComponentBase
    {
        #region Inject Services
        [Inject] private IUserWebAppService _userWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameters

        private bool isLoading { get; set; } = true;
        bool IsBusy { get; set; } = false;
        private GetUserWebAppModel getUserModel { get; set; } = new();

        int? selectedCountryId;

        int? selectedStateId;

        [Parameter]
        public int UserID { get; set; }
        private UserAddEditWebAppModel updateUserRequestModel { get; set; } = new();

        #endregion

        #region OnRender Method Starts

        protected override async Task OnAfterRenderAsync(bool firstRender)
        {
            if (firstRender)
            {
                await GetUserProfileInfo();
            }
        }


        #endregion

        #region API service calls

        // Fetch the user's profile details by UserID
        private async Task GetUserProfileInfo()
        {
            isLoading = true;
            var serviceResponse = await _userWebAppService.GetUserById();

            if (serviceResponse.IsSuccessStatusCode)
            {
                // Successfully fetched user profile
                getUserModel = serviceResponse.Content;

            }
            else
            {
                updateUserRequestModel = new UserAddEditWebAppModel();
            }
            isLoading = false;
            StateHasChanged();
        }

        async void OnUpdateProfileClicked()
        {
            await UpdateProfileInfo();
        }
        private async Task UpdateProfileInfo()
        {
            isLoading = true;
            IsBusy = true;

            // Map the properties to roomTypeRequestModel
            updateUserRequestModel.EmailID = getUserModel.EmailID;
            updateUserRequestModel.MobileNumber = getUserModel.MobileNumber;
            updateUserRequestModel.Address1 = getUserModel.Address1;
            updateUserRequestModel.Address2 = getUserModel.Address2;
            updateUserRequestModel.City = getUserModel.City;
            updateUserRequestModel.StateID = getUserModel.StateID;
            updateUserRequestModel.ZipCode = getUserModel.ZipCode;

            var serviceResponse = await _userWebAppService.UpdateUser(updateUserRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", "User Info updated successfully.");
            }
            else
            {
                // Failed to fetch user profile
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", "Unable to load user profile.");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();
        }

        #endregion
    }
}
