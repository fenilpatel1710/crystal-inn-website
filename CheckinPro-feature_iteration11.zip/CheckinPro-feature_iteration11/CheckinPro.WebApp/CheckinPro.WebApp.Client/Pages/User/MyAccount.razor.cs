using Microsoft.AspNetCore.Components;

namespace CheckinPro.WebApp.Client.Pages.User
{
    public partial class MyAccount : ComponentBase
    {
        #region Inject Services

        #endregion



        #region Parameter

        private bool isLoading { get; set; } = true;

        private int selectedIndex = 0;

        #endregion


        #region Page Method Starts

        #endregion

        #region API service calls

        #endregion
    }
}