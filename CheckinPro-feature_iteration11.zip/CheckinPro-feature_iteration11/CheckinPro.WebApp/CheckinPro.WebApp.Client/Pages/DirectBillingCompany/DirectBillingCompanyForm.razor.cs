﻿using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;

namespace CheckinPro.WebApp.Client.Pages.DirectBillingCompany
{
    public partial class DirectBillingCompanyForm : ComponentBase
    {
        #region Parameter
        [Parameter] public int hotelID { get; set; } = 0;
        [Parameter] public EventCallback<DirectBillingCompanyWebAppModel> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        [Parameter] public DirectBillingCompanyWebAppModel directBillingCompanyRequestModel { get; set; } = new();
        [Parameter] public bool IsBusy { get; set; } = false;

        #endregion

        #region OnRender Method Starts

        private async Task HandleFormOnSubmit()
        {
            IsBusy = true;
            await OnSubmit.InvokeAsync(directBillingCompanyRequestModel);
            IsBusy = false;
        }

        private void HandleOnCancel()
        {
            OnCancel.InvokeAsync();
        }
        #endregion
    }
}
