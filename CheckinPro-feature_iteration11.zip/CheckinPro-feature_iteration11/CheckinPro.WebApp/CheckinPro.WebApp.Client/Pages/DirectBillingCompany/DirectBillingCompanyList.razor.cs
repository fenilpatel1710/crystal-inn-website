﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.DirectBillingCompany
{
    public partial class DirectBillingCompanyList : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelWebAppService _hotelWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter
        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        bool IsBusy { get; set; } = false;
        [Parameter] public int hotelID { get; set; } = 0;
        public int hotelRoomID { get; set; } = 0;
        public string? roomTypeName { get; set; }
        public string? roomNumber { get; set; }
        public string? roomStatus { get; set; }

        private string pagingSummaryFormat = "Displaying page {0} of {1} (total {2} records)";

        private IEnumerable<int> pageSizeOptions = new int[] { 10, 20, 30 };

        private int selectedIndex = 0;
        private List<DirectBillingCompanyWebAppModel> serviceResponseDataList { get; set; } = new();
        #endregion

        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            await GetDirectBillingCompany();
        }

        private async Task CreateEditCompanyDialog(DirectBillingCompanyWebAppModel? directBillingCompany)
        {
            // If editing, use the passed object; if creating, initialize a new one.
            var directBillingCompanyRequestModel = new DirectBillingCompanyWebAppModel();
            if (directBillingCompany != null)
            {
                directBillingCompanyRequestModel.CompanyID = directBillingCompany.CompanyID;
                directBillingCompanyRequestModel.HotelID = directBillingCompany.HotelID;
                directBillingCompanyRequestModel.CompanyName = directBillingCompany.CompanyName;
                directBillingCompanyRequestModel.BillingAddress = directBillingCompany.BillingAddress;
                directBillingCompanyRequestModel.MobileNumber = directBillingCompany.MobileNumber;
                directBillingCompanyRequestModel.Email = directBillingCompany.Email;
                directBillingCompanyRequestModel.ManagerFirstName = directBillingCompany.ManagerFirstName;
                directBillingCompanyRequestModel.ManagerLastName = directBillingCompany.ManagerLastName;
                directBillingCompanyRequestModel.ManagerAddress = directBillingCompany.ManagerAddress;
                directBillingCompanyRequestModel.NameOnCreditCard = directBillingCompany.NameOnCreditCard;
                directBillingCompanyRequestModel.CreditCardNumber = directBillingCompany.CreditCardNumber;
                directBillingCompanyRequestModel.ExpirationDate = directBillingCompany.ExpirationDate;
                directBillingCompanyRequestModel.SecurityCode = directBillingCompany.SecurityCode;
                directBillingCompanyRequestModel.AccountNumber = directBillingCompany.AccountNumber;
                directBillingCompanyRequestModel.RoutingNumber = directBillingCompany.RoutingNumber;
                directBillingCompanyRequestModel.Notes = directBillingCompany.Notes;
            }

            // Determine dialog title based on whether we're creating or editing
            var dialogName = directBillingCompany == null ? "Add New Company" : "Edit Company";

            var dialogOptions = new SideDialogOptions { CloseDialogOnOverlayClick = false, ShowClose = true, Width = "900px", Position = DialogPosition.Right, ShowMask = true };

            var dialogParameters = new Dictionary<string, object>
            {
                { "hotelID", hotelID },
                { "directBillingCompanyRequestModel", directBillingCompanyRequestModel },
                { "IsBusy", IsBusy },
                { "OnSubmit", EventCallback.Factory.Create<DirectBillingCompanyWebAppModel>(this, HandleFormOnSubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            };

            var dialogResult = await _dialogService.OpenSideAsync<DirectBillingCompanyForm>(dialogName, dialogParameters, options: dialogOptions);

        }


        private async Task HandleFormOnSubmit(DirectBillingCompanyWebAppModel directBillingCompanyRequestModel)
        {
            _dialogService.CloseSide();
            // Create new company
            await CreateEditHotelDirectBillingCompany(directBillingCompanyRequestModel);
        }

        private void HandleOnCancel()
        {
            _dialogService.CloseSide();
        }
        #endregion

        #region API service calls
        private async Task GetDirectBillingCompany()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetDirectBillingCompany(hotelID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseDataList = serviceResponse.Content;
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while getting company data '{serviceResponse.Error}'.");
                serviceResponseDataList = new List<DirectBillingCompanyWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task CreateEditHotelDirectBillingCompany(DirectBillingCompanyWebAppModel directBillingCompanyRequestModel)
        {
            isLoading = true;
            IsBusy = true;
            directBillingCompanyRequestModel.HotelID = hotelID;
            var serviceResponse = await _hotelWebAppService.AddUpdateDirectBillingCompany(directBillingCompanyRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Company saved successfully!");

                await GetDirectBillingCompany();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving Company details.");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();
        }
        #endregion
    }
}
