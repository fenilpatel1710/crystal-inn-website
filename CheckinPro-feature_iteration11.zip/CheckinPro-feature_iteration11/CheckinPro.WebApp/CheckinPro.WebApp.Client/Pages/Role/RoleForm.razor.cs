﻿using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;

namespace CheckinPro.WebApp.Client.Pages.Role
{
    public partial class RoleForm: ComponentBase
    {
        #region Parameter
        [Parameter] public EventCallback<RoleWebAppModel> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        [Parameter] public RoleWebAppModel roleRequestModel { get; set; } = new();
        [Parameter] public bool IsBusy { get; set; } = false;

        #endregion

        #region OnRender Method Starts

        private async Task HandleFormOnSubmit()
        {
            IsBusy = true;
            await OnSubmit.InvokeAsync(roleRequestModel);
            IsBusy = false;
        }

        private void HandleOnCancel()
        {
            OnCancel.InvokeAsync();
        }
        #endregion
    }
}
