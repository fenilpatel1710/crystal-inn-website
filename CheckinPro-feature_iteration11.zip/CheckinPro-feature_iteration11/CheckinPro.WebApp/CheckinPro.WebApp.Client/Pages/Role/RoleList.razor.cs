﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Pages.Hotel.HotelRoom;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.Role
{
    public partial class RoleList : ComponentBase
    {
        #region Inject Services
        [Inject] private IRoleWebAppService _roleWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter

        private bool IsLoading { get; set; } = true;
        private bool IsBusy { get; set; } = false;

        private string pagingSummaryFormat = "Displaying page {0} of {1} (total {2} records)";

        private IEnumerable<int> pageSizeOptions = new int[] { 10, 20, 30 };

        private string? roleName;
        private List<RoleWebAppModel> serviceResponseData { get; set; } = new();
        private List<RoleWebAppModel> activeRoles => serviceResponseData.ToList();
        #endregion

        #region Page Method Starts
        protected override async Task OnAfterRenderAsync(bool firstRender)
        {
            if (firstRender)
            {
                await GetRoles();
            }
        }

        private async Task EditSystemRoleDialog(RoleWebAppModel? roleRequestModel)
        {

            // Determine dialog title based on whether we're creating or editing
            var dialogName = roleRequestModel == null ? "Add New Role" : "Edit Role";

            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<RoleForm>(dialogName, new Dictionary<string, object>
            {
                { "roleRequestModel", roleRequestModel },
                { "IsBusy", IsBusy },
                { "OnSubmit", EventCallback.Factory.Create<RoleWebAppModel>(this, HandleFormOnRoleSubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }


        private async Task HandleFormOnRoleSubmit(RoleWebAppModel roleWebAppModel)
        {
            _dialogService.Close();
            await UpdateRole(roleWebAppModel);
        }

        private void HandleOnCancel()
        {
            _dialogService.Close();
        }

        private void NavigateToEditPage(int roleID)
        {
            // Use navigation manager to redirect to the Edit amenity page
            _navigationManager.NavigateTo($"/role/edit/{roleID}");
        }

        #endregion

        #region API service calls
        private async Task GetRoles()
        {
            IsLoading = true;
            var serviceResponse = await _roleWebAppService.GetRoles();
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseData = serviceResponse.Content;
            }
            else
            {
                serviceResponseData = new List<RoleWebAppModel>();
            }
            IsLoading = false;
            StateHasChanged();
        }

        private async Task UpdateRole(RoleWebAppModel roleRequestModel)
        {
            IsLoading = true;
            IsBusy = true;
            var serviceResponse = await _roleWebAppService.UpdateRole(roleRequestModel.RoleID, roleRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"'{roleRequestModel.RoleName}' updated successfully!");
                await GetRoles();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error updating '{roleRequestModel.RoleName}'.");
            }
            IsLoading = false;
            IsBusy = false;
            StateHasChanged();
        }
        #endregion
    }
}
