﻿using CheckinPro.Common.Models.Constants;
using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using Radzen;
using System.Reflection.Metadata;

namespace CheckinPro.WebApp.Client.Pages.Reports
{
    public partial class BookingReport : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelReportWebAppService _hotelReportWebAppService { get; set; }
        [Inject] private IDashboardWebAppService _dashboardWebAppService { get; set; }
        [Inject] private IJSRuntime _jsruntime { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter
        private bool isLoading { get; set; } = true;
        bool IsBusy { get; set; } = false;
        bool IsDailyAuditReport { get; set; } = false;
        bool IsRoomTaxCollectedReport { get; set; } = false;
        bool IsSummaryIncomeReport { get; set; } = false;
        bool IsRoomRevenueReport { get; set; } = false;
        bool IsIncomeBreakdownReport { get; set; } = false;
        bool IsSearchShiftReport { get; set; } = false;
        [Parameter] public int hotelID { get; set; } = 0;
        public DateOnly StartDate { get; set; } = DateOnly.FromDateTime(CommonConstants.GetSystemMinDate());
        public DateOnly EndDate { get; set; } = DateOnly.FromDateTime(CommonConstants.GetSystemMinDate());
        private List<HotelShiftWebAppModel> serviceResponseShiftDataList { get; set; } = new();

        private string pagingSummaryFormat = "Displaying page {0} of {1} (total {2} records)";

        private IEnumerable<int> pageSizeOptions = new int[] { 10, 20, 30 };

        private int selectedIndex = 0;
        #endregion

        #region OnRender Method Starts
        protected override async Task OnInitializedAsync()
        {

        }

        private async Task DownloadPDFReport(byte[] pdf, string fileName)
        {
            var fileStream = new MemoryStream(pdf);

            using var streamRef = new DotNetStreamReference(stream: fileStream);

            await _jsruntime.InvokeVoidAsync("downloadFileFromStream", fileName, streamRef);
        }

        private async Task OnClickDownloadShiftReport()
        {
            IsSearchShiftReport = true;
            await GetHotelShiftDetailByDate();
            IsSearchShiftReport = false;

        }
        #endregion


        #region API service calls   
        private async Task GetHotelShiftDetailByDate()
        {
            isLoading = true;
            var serviceResponse = await _dashboardWebAppService.GetHotelShiftDetailByDate(hotelID, StartDate, EndDate);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseShiftDataList = serviceResponse.Content;
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while getting Room data '{serviceResponse.Error}'.");
                serviceResponseShiftDataList = new List<HotelShiftWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }
        private async Task DownloadDailyAuditReport()
        {
            IsDailyAuditReport = true;
            var serviceResponse = await _hotelReportWebAppService.DownloadDailyAuditReport(hotelID, StartDate, EndDate);
            if (serviceResponse.IsSuccessStatusCode)
            {
                byte[] serviceResponseData = serviceResponse.Content;
                await DownloadPDFReport(serviceResponseData, CommonConstants.ReportFileName.DailyAuditReport);
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"{CommonConstants.ReportFileName.DailyAuditReport} downloaded successfully!");

            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while downloading DailyAuditReport.");
            }
            IsDailyAuditReport = false;
            StateHasChanged();
        }

        private async Task DownloadRoomTaxCollectedReport()
        {
            IsRoomTaxCollectedReport = true;
            var serviceResponse = await _hotelReportWebAppService.DownloadRoomTaxCollectedReport(hotelID, StartDate, EndDate);
            if (serviceResponse.IsSuccessStatusCode)
            {
                byte[] serviceResponseData = serviceResponse.Content;
                await DownloadPDFReport(serviceResponseData, CommonConstants.ReportFileName.RoomTaxCollectedReport);
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"{CommonConstants.ReportFileName.RoomTaxCollectedReport} downloaded successfully!");
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while downloading RoomTaxCollectedReport.");
            }
            IsRoomTaxCollectedReport = false;
            StateHasChanged();
        }

        private async Task DownloadSummaryIncomeReport()
        {
            IsSummaryIncomeReport = true;
            var serviceResponse = await _hotelReportWebAppService.DownloadSummaryIncomeReport(hotelID, StartDate, EndDate);
            if (serviceResponse.IsSuccessStatusCode)
            {
                byte[] serviceResponseData = serviceResponse.Content;
                await DownloadPDFReport(serviceResponseData, CommonConstants.ReportFileName.SummaryIncomeReport);
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"{CommonConstants.ReportFileName.SummaryIncomeReport} downloaded successfully!");
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while downloading SummaryIncomeReport.");
            }
            IsSummaryIncomeReport = false;
            StateHasChanged();
        }

        private async Task DownloadRoomRevenueReport()
        {
            IsRoomRevenueReport = true;
            var serviceResponse = await _hotelReportWebAppService.DownloadRoomRevenueReport(hotelID, StartDate, EndDate);
            if (serviceResponse.IsSuccessStatusCode)
            {
                byte[] serviceResponseData = serviceResponse.Content;
                await DownloadPDFReport(serviceResponseData, CommonConstants.ReportFileName.RoomRevenueReport);
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"{CommonConstants.ReportFileName.RoomRevenueReport} downloaded successfully!");
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while downloading RoomRevenueReport.");
            }
            IsRoomRevenueReport = false;
            StateHasChanged();
        }

        private async Task DownloadIncomeBreakdownReport()
        {
            IsIncomeBreakdownReport = true;
            var serviceResponse = await _hotelReportWebAppService.DownloadIncomeBreakdownReport(hotelID, StartDate, EndDate);
            if (serviceResponse.IsSuccessStatusCode)
            {
                byte[] serviceResponseData = serviceResponse.Content;
                await DownloadPDFReport(serviceResponseData, CommonConstants.ReportFileName.IncomeBreakdownReport);
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"{CommonConstants.ReportFileName.IncomeBreakdownReport} downloaded successfully!");
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while downloading IncomeBreakdownReport.");
            }
            IsIncomeBreakdownReport = false;
            StateHasChanged();
        }

        private async Task DownloadShiftReport(HotelShiftWebAppModel hotelShiftWebAppModel)
        {
            hotelShiftWebAppModel.IsBusyShiftReportDownload = true;
            var serviceResponse = await _hotelReportWebAppService.DownloadShiftReport(hotelID, hotelShiftWebAppModel, StartDate, EndDate);
            if (serviceResponse.IsSuccessStatusCode)
            {
                byte[] serviceResponseData = serviceResponse.Content;
                await DownloadPDFReport(serviceResponseData, CommonConstants.ReportFileName.ShiftReport);
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"{CommonConstants.ReportFileName.ShiftReport} downloaded successfully!");
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while downloading ShiftReport.");
            }
            hotelShiftWebAppModel.IsBusyShiftReportDownload = false;
            StateHasChanged();
        }
        #endregion
    }
}
