﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.Hotel
{
    public partial class AddHotel : ComponentBase
    {

        #region Inject Services
        [Inject] private IHotelWebAppService _hotelWebAppService { get; set; }

        [Inject] private NavigationManager _navigationManager { get; set; }

        private NotificationAlert _notificationAlertComponent = new NotificationAlert();
        #endregion

        #region Parameter

        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        [Parameter] public bool IsBusy { get; set; } = false;
        private AddHotelWebAppModel hotelRequestModel { get; set; } = new();
        private UserinfoWebAppModel hotelUserinfoRequestModel { get; set; } = new();

        int? selectedCountryId;
        [Parameter] public EventCallback<AddHotelWebAppModel> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        #endregion

        #region OnRender Method Starts
        protected override void OnInitialized()
        {
            hotelRequestModel = new AddHotelWebAppModel
            {
                Userinfo = new UserinfoWebAppModel() // Initialize Userinfo
            };
            isLoading = false;
        }
        async void OnSaveClicked()
        {
            await CreateNewHotel();
        }

        #endregion

        #region API service calls
        private async Task CreateNewHotel()
        {
            isLoading = true;
            IsBusy = true;
            var serviceResponse = await _hotelWebAppService.AddHotel(hotelRequestModel);


            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"'{hotelRequestModel.BusinessLLCName}' added successfully!");
                _navigationManager.NavigateTo("/hotel/list");
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving '{hotelRequestModel.BusinessLLCName}'.");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();
        }
        #endregion

    }
}