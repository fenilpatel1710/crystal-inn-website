﻿using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Newtonsoft.Json.Linq;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelShift
{
    public partial class EndShiftForm : ComponentBase
    {
        #region Parameter
        [Parameter] public EventCallback<HotelShiftWebAppModel> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        [Parameter] public HotelShiftWebAppModel hotelShiftRequestModel { get; set; }
        public bool IsBusy { get; set; } = false;

        #endregion

        #region OnRender Method Starts
        private async Task HandleFormOnSubmit()
        {
            IsBusy = true;
            await OnSubmit.InvokeAsync(hotelShiftRequestModel);
            IsBusy = false;
        }

        private void HandleOnCancel()
        {
            OnCancel.InvokeAsync();
        }

        private void OnChangeDropCash(object args)
        {
            decimal? dropCash = args as decimal?;

            var EndingCash = (hotelShiftRequestModel.StartingCash + hotelShiftRequestModel.TotalCashReceived) - dropCash;
            hotelShiftRequestModel.EndingCash = EndingCash;
            hotelShiftRequestModel.EndingCashDrawer = EndingCash;
        }
        #endregion
    }
}
