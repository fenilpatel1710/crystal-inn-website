﻿using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelStaff
{
    public partial class HotelStaffForm : ComponentBase
    {
        #region Parameter
        [Parameter] public EventCallback<UserAddEditWebAppModel> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        [Parameter] public UserAddEditWebAppModel userRequestModel { get; set; } = new();
        [Parameter] public bool IsBusy { get; set; } = false;

        int? selectedCountryId;
        #endregion


        #region OnRender Method Starts

        private async Task OnCountryChange(int? countryId)
        {
            // Fetch states for the selected country
            if (countryId.HasValue)
            {
                selectedCountryId = countryId.Value;
            }
        }
        private async Task OnStateChange(int? stateId)
        {
            // Fetch states for the selected country
            if (stateId.HasValue)
            {
                userRequestModel.StateID = stateId.Value;
            }
        }
        private async Task HandleFormOnSubmit()
        {
            IsBusy = true;
            await OnSubmit.InvokeAsync(userRequestModel);
            IsBusy = false;
        }

        private void HandleOnCancel()
        {
            OnCancel.InvokeAsync();
        }
        #endregion
    }
}
