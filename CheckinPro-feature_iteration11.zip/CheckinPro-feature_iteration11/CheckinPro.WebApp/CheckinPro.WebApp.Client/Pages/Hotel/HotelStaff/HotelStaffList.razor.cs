﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Pages.User;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelStaff
{
    public partial class HotelStaffList : ComponentBase
    {
        #region Inject Services
        [Inject] private IUserWebAppService _userWebAppService { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion


        #region Parameter
        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        bool IsBusy { get; set; } = false;

        [Parameter] public int hotelID { get; set; }
        public int userID { get; set; } = 0;
        public string? roleName { get; set; }
        public string? fullName { get; set; }
        public string? mobileNumber { get; set; }
        public string? emailID { get; set; }



        private string pagingSummaryFormat = "Displaying page {0} of {1} (total {2} records)";

        private IEnumerable<int> pageSizeOptions = new int[] { 10, 20, 30 };

        private List<GetUserWebAppModel> serviceResponseDataList { get; set; } = new();
        private UserAddEditWebAppModel hotelStaffRequestModel { get; set; } = new();
        #endregion


        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            await GetHotelStaff();
        }

        private async Task CreateHotelStaffDialog()
        {
            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true };
            var dialogName = string.Empty;

            dialogName = "Create New Hotel Staff";


            //await _dialogService.OpenSideAsync<UserAddEditForm>(dialogName, new Dictionary<string, object>
            //{
            //    { "IsBusy", IsBusy },  
            //    { "OnSubmit", EventCallback.Factory.Create<UpdateUserWebAppModel>(this, HandleFormOnSubmit) }, 
            //    { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) }  
            //},
            //new SideDialogOptions
            //{
            //    CloseDialogOnOverlayClick = true,
            //    Position = DialogPosition.Right,
            //    ShowMask = true
            //});

            await _dialogService.OpenAsync<HotelStaffForm>(dialogName, new Dictionary<string, object>
            {
                { "IsBusy", IsBusy },
                { "OnSubmit", EventCallback.Factory.Create<UserAddEditWebAppModel>(this, HandleFormOnSubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }

        private async Task HandleFormOnSubmit(UserAddEditWebAppModel hotelStaffRequestModel)
        {
            await CreateHotelStaff(hotelStaffRequestModel);
            _dialogService.Close();
        }

        private void HandleOnCancel()
        {
            _dialogService.Close();
        }

        private async Task OnStatusChange(bool isActive, GetUserWebAppModel context)
        {

            // Show confirmation dialog before making API call
            var confirmMessage = isActive
                ? $"Are you sure you want to activate the staff <strong>'{context.FullName}'</strong>?"
                : $"Are you sure you want to deactivate the staff <strong>'{context.FullName}'</strong>?";

            var confirmTitle = isActive ? "Confirm Activate" : "Confirm Inactivate";

            // Show the confirmation dialog
            var result = await _dialogService.Confirm(confirmMessage, confirmTitle,
                new ConfirmOptions { OkButtonText = "Yes", CancelButtonText = "No", ShowClose = true });

            if (result.HasValue && result.Value)
            {
                // If confirmed, call the API
                try
                {
                    if (isActive)
                    {
                        // Call the API to activate the  hotel staff
                        await ActiveHotelStaff(context.UserID, context.FullName);
                    }
                    else
                    {
                        // Call the API to deactivate the hotel staff
                        await DeactivateHotelStaff(context.UserID, context.FullName);
                    }
                }
                catch (Exception ex)
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error processing the staff status.");
                }
                finally
                {
                    // Refresh the data grid after making the API call
                    await GetHotelStaff();
                }
            }
            else
            {
                // If the user cancels, do nothing
                return;
            }
        }

        #endregion

        #region API service calls

        private async Task GetHotelStaff()
        {
            isLoading = true;
            var serviceResponse = await _userWebAppService.GetUsers(hotelID);
            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {
                serviceResponseDataList = serviceResponse.Content.OrderBy(item => item.RoleName).ToList();
            }
            else
            {
                serviceResponseDataList = new List<GetUserWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task CreateHotelStaff(UserAddEditWebAppModel hotelStaffRequestModel)
        {
            isLoading = true;
            IsBusy = true;
            hotelStaffRequestModel.HotelID = hotelID;
            var serviceResponse = await _userWebAppService.AddUser(hotelStaffRequestModel);
            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Staff saved successfully!");

                await GetHotelStaff();
            }
            else
            {
                var errorMessage = serviceResponse.Error.Message ?? "An unknown error occurred.";
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", errorMessage);
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();
        }

        private async Task ActiveHotelStaff(int userID, string fullName)
        {
            isLoading = true;
            var serviceResponseData = await _userWebAppService.ActivateUser(userID);

            if (serviceResponseData.IsSuccessStatusCode)
            {
                //show a success notification
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"'{fullName}' activated successfully!");
            }
            else
            {
                //show an error notification
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while activating '{fullName}'.");
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task DeactivateHotelStaff(int userID, string fullName)
        {
            isLoading = true;
            var serviceResponseData = await _userWebAppService.BlockUser(userID);

            if (serviceResponseData.IsSuccessStatusCode)
            {
                //show a success notification
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"'{fullName}' deactivated successfully!");
            }
            else
            {
                //show an error notification
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while deactivating '{fullName}'.");
            }
            isLoading = false;
            StateHasChanged();
        }
        #endregion
    }
}
