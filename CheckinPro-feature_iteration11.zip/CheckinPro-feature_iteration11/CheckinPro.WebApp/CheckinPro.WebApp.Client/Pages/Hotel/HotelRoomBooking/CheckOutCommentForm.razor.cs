﻿using CheckinPro.Common.Models.Constants;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking
{
    public partial class CheckOutCommentForm : ComponentBase
    {

        #region Inject Services
        [Inject] private DialogService _dialogService { get; set; }
        #endregion

        #region Parameter
        [Parameter] public EventCallback<string> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        [Parameter] public string checkOutComment { get; set; } = string.Empty;
        [Parameter] public bool IsRewardPointGiven { get; set; } = true;
        [Parameter] public decimal? EarnedRewardPoint { get; set; }
        [Parameter] public decimal? BookingAmount { get; set; }
        [Parameter] public bool IsBusy { get; set; } = false;
        private bool ShowRewardPointValidation { get; set; }
        public UpdateHotelRoomCleaningAuditWebAppModel requestModel { get; set; } = new();

        #endregion

        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            requestModel.IsRewardPointGiven = IsRewardPointGiven;

            if (requestModel.IsRewardPointGiven)
            {
                requestModel.EarnedRewardPoint = CalculateRewardPoint();
            }
            else
            {
                requestModel.EarnedRewardPoint = null;
            }
        }
        

        private async Task HandleFormOnSubmit()
        {
            
            ShowRewardPointValidation = false;
            if (requestModel.IsRewardPointGiven && (!requestModel.EarnedRewardPoint.HasValue || requestModel.EarnedRewardPoint.Value <= 0))
            {
                ShowRewardPointValidation = true;
                return;
            }
            IsBusy = true;
            try
            {
                _dialogService.Close(requestModel);
            }
            finally
            {
                IsBusy = false;
            }
        }



        private void HandleOnCancel()
        {
            _dialogService.Close(null);
        }

        private async Task OnRewardPointFlagChange(bool IsRewardPointGiven)
        {
            ShowRewardPointValidation = false;
            if (IsRewardPointGiven)
            {
                requestModel.EarnedRewardPoint = CalculateRewardPoint();
            }
            else
            {
                requestModel.EarnedRewardPoint = null;
            }
        }

        private decimal CalculateRewardPoint()
        {
            decimal rewardPoint = Math.Round(BookingAmount * 0.03m ?? 0, 0);
            return rewardPoint;
        }
        #endregion
    }
}