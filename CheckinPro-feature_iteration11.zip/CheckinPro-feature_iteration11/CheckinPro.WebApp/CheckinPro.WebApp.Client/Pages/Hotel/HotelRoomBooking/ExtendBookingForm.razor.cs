﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;
using Refit;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking
{
    public partial class ExtendBookingForm : ComponentBase
    {

        #region Inject Services
        [Inject] private IHotelWebAppService _hotelWebAppService { get; set; }
        [Inject] private IHotelRoomBookingWebAppService _hotelRoomBookingWebAppService { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter
        [Parameter] public int hotelID { get; set; } = 0;
        [Parameter] public HotelRoomBookingWebAppModel hotelRoomBookingRequestModel { get; set; } = new();
        public bool isLoading { get; set; } = true;

        private HotelRoomBookingRateDetailWebAppModel hotelRoomBookingRateDetailRequestModel { get; set; } = new();
        private HotelConfigurationWebAppModel serviceResponseHotelConfigurationData { get; set; } = new();
        private List<HotelRoomTypeWebAppModel> serviceResponseHotelRoomTypeDataList { get; set; } = new();
        private HotelDailyRateWebAppModel serviceResponseHotelDailyRateData { get; set; } = new();
        private List<HotelHourlyRateWebAppModel> serviceResponseHotelHourlyRateDataList { get; set; } = new();
        private List<HotelTaxRateWebAppModel> serviceResponseHotelTaxRateDataList { get; set; } = new();

        private bool isEditingFinalAmount = false;
        private bool isCalculateRoomRate = false;
        private bool IsBusyExtend = false;
        private string BookingDuration = string.Empty;
        #endregion

        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            hotelRoomBookingRateDetailRequestModel.CheckInDate = hotelRoomBookingRequestModel.ScheduledCheckOutDate;
            if (hotelRoomBookingRequestModel.IsHourlyBooking)
            {
                hotelRoomBookingRequestModel.CheckOutTime = null;
                await GetHotelHourlyRate();
            }
            else
            {
                hotelRoomBookingRateDetailRequestModel.CheckOutDate = hotelRoomBookingRateDetailRequestModel.CheckInDate.Value.AddDays(1).Date.AddHours(11);
            }
            isLoading = false;
            StateHasChanged();
        }

        private async void OnSearchClicked()
        {
            isLoading = true;
            await CalculateRoomRate();
            isLoading = false;
            isCalculateRoomRate = true;
            StateHasChanged();
        }

        private DateTime GetCheckOutMinDate()
        {
            return hotelRoomBookingRateDetailRequestModel.CheckInDate.Value.AddDays(1).Date.AddHours(11);
        }

        private void OnCheckOutDateChange(DateTime? value)
        {
            if (value.HasValue && value.Value >= hotelRoomBookingRateDetailRequestModel.CheckInDate)
            {
                // Set the selected checkout date and set the time to 11:30 AM
                hotelRoomBookingRateDetailRequestModel.CheckOutDate = value.Value.Date.AddHours(11);
            }
            else
            {
                // Default to check-in date + 1 day and set time to 11:30 AM
                hotelRoomBookingRateDetailRequestModel.CheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckInDate.Value.AddDays(1).Date.AddHours(11);
            }

            // Optionally, call any other necessary function like OnDateChange
            OnDateChange();
        }
        private void OnCheckOutHoursChange(object args)
        {
            int? checkOutHours = args as int?;

            // Ensure check-out hours value is valid
            if (checkOutHours.HasValue && checkOutHours.Value != 0)
            {
                // Only update the check-out date, NOT the check-in date
                hotelRoomBookingRateDetailRequestModel.CheckOutDate = hotelRoomBookingRateDetailRequestModel.CheckInDate.Value.AddHours((double)checkOutHours);

                // Find the hourly rate based on the selected check-out hours
                var matchedRate = serviceResponseHotelHourlyRateDataList
                                   .FirstOrDefault(rate => rate.Hour == checkOutHours);

                if (matchedRate != null)
                {
                    hotelRoomBookingRateDetailRequestModel.HourlyRate = matchedRate.HourlyRate;
                }
                else
                {
                    hotelRoomBookingRateDetailRequestModel.HourlyRate = null;
                }
            }
            else
            {
                // If no valid value for check-out hours, default to 1 hour
                hotelRoomBookingRateDetailRequestModel.CheckOutDate = hotelRoomBookingRateDetailRequestModel.CheckInDate.Value.AddHours(1);
            }

            // Ensure we don't modify the check-in date here
            OnDateChange();
        }
        private async void OnDateChange()
        {
            isCalculateRoomRate = false;
            if (hotelRoomBookingRateDetailRequestModel.CheckInDate != DateTime.MinValue && hotelRoomBookingRateDetailRequestModel.CheckOutDate != DateTime.MinValue)
            {
                var checkIn = hotelRoomBookingRateDetailRequestModel.CheckInDate.Value;
                var checkOut = hotelRoomBookingRateDetailRequestModel.CheckOutDate.Value;

                if (hotelRoomBookingRequestModel.IsHourlyBooking == false) // Days
                {
                    var duration = checkOut.Date - checkIn.Date;
                    if (duration.TotalDays >= 1)
                    {
                        hotelRoomBookingRateDetailRequestModel.Duration = Convert.ToInt32(Math.Floor(duration.TotalDays));
                        BookingDuration = $"{Math.Floor(duration.TotalDays)} Day(s)";
                        //IsSearchDisabled = false;
                    }
                    else
                    {
                        BookingDuration = "Invalid duration for days booking.";
                        //IsSearchDisabled = true;
                    }
                }
                else if (hotelRoomBookingRequestModel.IsHourlyBooking == true) // Hourly
                {
                    var duration = checkOut - checkIn;
                    if (duration.TotalHours >= 1)
                    {
                        hotelRoomBookingRateDetailRequestModel.Duration = Convert.ToInt32(Math.Floor(duration.TotalHours));
                        BookingDuration = $"{Math.Floor(duration.TotalHours)} Hour(s)";
                        // IsSearchDisabled = false;
                    }
                    else if (duration.TotalMinutes >= 1)
                    {
                        hotelRoomBookingRateDetailRequestModel.Duration = Convert.ToInt32(Math.Floor(duration.TotalMinutes));
                        BookingDuration = $"{Math.Floor(duration.TotalMinutes)} Minute(s)";
                        //IsSearchDisabled = false;
                    }
                    else
                    {
                        BookingDuration = "Invalid duration for hourly booking.";
                        //IsSearchDisabled = true;
                    }
                }
            }
            StateHasChanged();
        }
        private async Task CalculateRoomRate()
        {
            decimal? RoomRate = 0;
            OnDateChange();
            await GetHotelConfiguration();
            await GetAvailableRoomTypes();

            var taxRateForBooking = hotelRoomBookingRequestModel.HotelRoomBookingRateDetails.FirstOrDefault(item => item.IsExtend == false);
            if (taxRateForBooking != null && taxRateForBooking.HotelRoomBookingTaxRates.Any())
            {
                serviceResponseHotelTaxRateDataList = taxRateForBooking.HotelRoomBookingTaxRates.Select(h => new HotelTaxRateWebAppModel
                {
                    HotelTaxRateID = h.HotelTaxRateID ?? 0,
                    TaxName = h.BookingTaxRateName,
                    TaxRate = h.BookingTaxRatePercentage,
                }).ToList();
            }
            var hotelRoomTypeData = serviceResponseHotelRoomTypeDataList.Where(item => item.HotelRoomTypeID == hotelRoomBookingRequestModel.HotelRoomTypeID).FirstOrDefault();
            if (hotelRoomTypeData != null)
            {

                if (hotelRoomTypeData?.AdjustmentRate.HasValue == true)
                {
                    hotelRoomBookingRateDetailRequestModel.AdjustmentRate = hotelRoomTypeData.AdjustmentRate;
                    RoomRate += hotelRoomBookingRateDetailRequestModel.AdjustmentRate;
                }

                if (hotelRoomBookingRequestModel.IsHourlyBooking == false)
                {
                    await GetHotelDailyRate();
                    hotelRoomBookingRateDetailRequestModel.BestAvailableRate = serviceResponseHotelDailyRateData?.DailyBestAvailableRate.HasValue == true && serviceResponseHotelDailyRateData.DailyBestAvailableRate.Value != 0
                   ? serviceResponseHotelDailyRateData.DailyBestAvailableRate.Value : serviceResponseHotelConfigurationData.BestAvailableRate;
                    RoomRate += hotelRoomBookingRateDetailRequestModel.BestAvailableRate;

                }
                else if (hotelRoomBookingRequestModel.IsHourlyBooking == true)
                {
                    await GetHotelHourlyRate();
                    RoomRate += hotelRoomBookingRateDetailRequestModel.HourlyRate;
                    ///hotelRoomBookingRequestModel.HourlyRate += hotelRoomBookingRequestModel.AdjustmentRate;
                }
            }

            if (hotelRoomBookingRateDetailRequestModel.CheckInDate != DateTime.MinValue && hotelRoomBookingRateDetailRequestModel.CheckOutDate != DateTime.MinValue)
            {
                // Calculate the duration
                var checkIn = hotelRoomBookingRateDetailRequestModel.CheckInDate.Value;
                var checkOut = hotelRoomBookingRateDetailRequestModel.CheckOutDate.Value;
                var duration = checkOut - checkIn;
                decimal bookingDuration = (decimal)Math.Floor(duration.TotalDays);
                bookingDuration = bookingDuration < 1 ? 1 : bookingDuration;


                // Check if the booking duration is valid
                if (duration.TotalDays <= 0)
                {
                    hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = 0; // Invalid duration
                    hotelRoomBookingRateDetailRequestModel.TotalAmount = 0; // Reset final amount
                    hotelRoomBookingRateDetailRequestModel.FinalAmount = 0; // Reset final amount
                    return;
                }

                // Calculate total amount based on booking type
                if (hotelRoomBookingRequestModel.IsHourlyBooking == false)
                {
                    // For "days" booking (daily rate)
                    if (duration.TotalDays >= 1)
                    {
                        // Calculate the SubTotalAmount based on the rate per day
                        hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = bookingDuration * RoomRate; // Per day rate
                    }
                    else
                    {
                        hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = 0; // Invalid duration for daily booking
                    }

                    hotelRoomBookingRateDetailRequestModel.TotalAmount = hotelRoomBookingRateDetailRequestModel.RoomChargeAmount;
                    hotelRoomBookingRateDetailRequestModel.FinalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount;

                    if (serviceResponseHotelTaxRateDataList.Any())
                    {
                        //HandleTaxRateChange(serviceResponseHotelTaxRateDataList);
                        OnSelectCalculateTaxRate(serviceResponseHotelTaxRateDataList);
                    }
                }
                else if (hotelRoomBookingRequestModel.IsHourlyBooking == true)
                {

                    hotelRoomBookingRateDetailRequestModel.TotalAmount = RoomRate;
                    CalculateReverseAmount(serviceResponseHotelTaxRateDataList);
                }
            }
            else
            {
                hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = 0;
                hotelRoomBookingRateDetailRequestModel.TotalAmount = 0;
                hotelRoomBookingRateDetailRequestModel.FinalAmount = 0;
            }

            StateHasChanged();
        }

        private void OnSelectCalculateTaxRate(object selectedTaxRateItem)
        {
            decimal totalTaxRates = 0m;
            decimal subTotalAmount = hotelRoomBookingRateDetailRequestModel.RoomChargeAmount ?? 0m;

            var selectedHotelTaxRate = (IEnumerable<HotelTaxRateWebAppModel>)selectedTaxRateItem;

            // Clear the existing tax rates to avoid duplicates
            hotelRoomBookingRequestModel.HotelRoomBookingTaxRates.Clear();

            if (selectedHotelTaxRate.Any())
            {
                foreach (var item in selectedHotelTaxRate)
                {
                    // Add the tax rate to the list
                    totalTaxRates += Convert.ToDecimal(item.TaxRate);
                    var newTaxRate = new HotelRoomBookingTaxRateWebAppModel
                    {
                        HotelTaxRateID = item.HotelTaxRateID,
                        BookingTaxRateName = item.TaxName,
                        BookingTaxRatePercentage = item.TaxRate,
                        BookingTaxRate = (subTotalAmount * (item.TaxRate / 100)),
                    };

                    hotelRoomBookingRequestModel.HotelRoomBookingTaxRates.Add(newTaxRate);
                }

                // Calculate the total tax amount using the selected tax rate(s)
                decimal validTaxRate = totalTaxRates / 100; // Convert total tax rate to decimal

                decimal taxAmount = subTotalAmount * validTaxRate;

                // Calculate final amount (subtotal + tax)
                hotelRoomBookingRateDetailRequestModel.TotalAmount = (decimal?)Math.Round(subTotalAmount + taxAmount, 2);
                hotelRoomBookingRateDetailRequestModel.FinalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount;
            }
            else
            {
                if (hotelRoomBookingRequestModel.IsHourlyBooking)
                {
                    hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = hotelRoomBookingRateDetailRequestModel.HourlyRate;
                    hotelRoomBookingRateDetailRequestModel.TotalAmount = hotelRoomBookingRateDetailRequestModel.RoomChargeAmount;
                    hotelRoomBookingRateDetailRequestModel.FinalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount;
                }
                else
                {
                    hotelRoomBookingRateDetailRequestModel.TotalAmount = hotelRoomBookingRateDetailRequestModel.RoomChargeAmount;
                    hotelRoomBookingRateDetailRequestModel.FinalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount;
                }
            }

            StateHasChanged();
        }

        private void CalculateReverseAmount(IEnumerable<HotelTaxRateWebAppModel> hotelTaxRateWebAppModel)
        {

            // Ensure FinalAmount is valid
            if (!hotelRoomBookingRateDetailRequestModel.TotalAmount.HasValue || hotelRoomBookingRateDetailRequestModel.TotalAmount == 0)
                return;

            decimal totalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount ?? 0m;

            // Get tax rates dynamically
            var taxPercentages = hotelTaxRateWebAppModel.Where(tax => tax.TaxRate.HasValue).Select(tax => tax.TaxRate.Value).ToList();

            // Calculate the total percentage dynamically
            decimal totalTaxRate = taxPercentages.Sum();

            // Calculate the combined percentage factor (1 + total tax rate / 100)
            decimal percentageFactor = 1 + (totalTaxRate / 100);

            // Reverse calculation to find the room charge
            decimal roomCharge = totalAmount / percentageFactor; // Final amount / 1.17 to get room charge

            // Assign values back to the model
            hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = roomCharge;

            OnSelectCalculateTaxRate(hotelTaxRateWebAppModel);

            StateHasChanged();
        }
        private void OnFinalAmountClicked()
        {
            isEditingFinalAmount = true; // Show numeric input to edit the final amount
        }

        private void OnSaveFinalAmountClick()
        {
            isEditingFinalAmount = false;
            // Ensure FinalAmount is valid
            if (!hotelRoomBookingRateDetailRequestModel.TotalAmount.HasValue || hotelRoomBookingRateDetailRequestModel.TotalAmount == 0)
                return;

            decimal totalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount ?? 0m;

            // Get tax rates dynamically
            var taxPercentages = hotelRoomBookingRequestModel.HotelRoomBookingTaxRates.Where(tax => tax.BookingTaxRatePercentage.HasValue).Select(tax => tax.BookingTaxRatePercentage.Value).ToList();

            // Calculate the total percentage dynamically
            decimal totalTaxRate = taxPercentages.Sum();

            // Calculate the combined percentage factor (1 + total tax rate / 100)
            decimal percentageFactor = 1 + (totalTaxRate / 100);

            // Reverse calculation to find the room charge
            decimal roomCharge = totalAmount / percentageFactor; // Final amount / 1.17 to get room charge

            // Assign values back to the model
            hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = roomCharge;


            var taxRatesList = hotelRoomBookingRequestModel.HotelRoomBookingTaxRates.Select(tax => new HotelTaxRateWebAppModel
            {
                HotelTaxRateID = tax.HotelTaxRateID ?? 0,
                TaxName = tax.BookingTaxRateName,
                TaxRate = tax.BookingTaxRatePercentage
            }).ToList();

            OnSelectCalculateTaxRate(taxRatesList);

            StateHasChanged();
        }

        private async Task OnExtendClicked()
        {
            if (!hotelRoomBookingRateDetailRequestModel.FinalAmount.HasValue)
            {
                return;
            }
            IsBusyExtend = true;
            OnSaveBookingRateDetail(hotelRoomBookingRateDetailRequestModel);
            var response = await RoomExtend();
            IsBusyExtend = false;
            StateHasChanged();
            if (response.IsSuccessStatusCode)
            {
                _dialogService.CloseSide(true);
            }
        }

        private void OnSaveBookingRateDetail(HotelRoomBookingRateDetailWebAppModel hotelRoomBookingRateDetailRequestModel)
        {
            hotelRoomBookingRequestModel.ScheduledCheckOutDate = hotelRoomBookingRateDetailRequestModel.CheckOutDate;
            hotelRoomBookingRequestModel.Duration += hotelRoomBookingRateDetailRequestModel.Duration;
            hotelRoomBookingRequestModel.HotelRoomBookingRateDetails = new List<HotelRoomBookingRateDetailWebAppModel>();
            var newBookingRateDetail = new HotelRoomBookingRateDetailWebAppModel
            {
                CheckInDate = hotelRoomBookingRateDetailRequestModel.CheckInDate,
                CheckOutDate = hotelRoomBookingRateDetailRequestModel.CheckOutDate,
                Duration = hotelRoomBookingRateDetailRequestModel.Duration,
                BestAvailableRate = hotelRoomBookingRateDetailRequestModel.BestAvailableRate,
                AdjustmentRate = hotelRoomBookingRateDetailRequestModel.AdjustmentRate,
                HourlyRate = hotelRoomBookingRateDetailRequestModel.HourlyRate,
                RoomChargeAmount = hotelRoomBookingRateDetailRequestModel.RoomChargeAmount,
                TotalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount,
                IsDiscountedRate = hotelRoomBookingRateDetailRequestModel.IsDiscountedRate,
                AdditionalRateType = hotelRoomBookingRateDetailRequestModel.AdditionalRateType,
                AdditionalRateAmount = hotelRoomBookingRateDetailRequestModel.AdditionalRateAmount,
                DiscountedAmount = hotelRoomBookingRateDetailRequestModel.DiscountedAmount,
                FinalAmount = hotelRoomBookingRateDetailRequestModel.FinalAmount,
                Balance = hotelRoomBookingRateDetailRequestModel.FinalAmount - hotelRoomBookingRequestModel.HotelRoomPayments.Sum(item => item.Amount),
            };

            hotelRoomBookingRequestModel.HotelRoomBookingRateDetails.Add(newBookingRateDetail);
            hotelRoomBookingRequestModel.HotelRoomBookingRateDetails = hotelRoomBookingRequestModel.HotelRoomBookingRateDetails.ToList();
            StateHasChanged();
        }


        #endregion


        #region API service calls

        private async Task GetHotelConfiguration()
        {
            var serviceResponse = await _hotelWebAppService.GetHotelConfiguration(hotelID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseHotelConfigurationData = serviceResponse.Content;
            }
            else
            {
                serviceResponseHotelConfigurationData = new HotelConfigurationWebAppModel(); // Initialize as empty list if null
            }
            StateHasChanged();
        }
        private async Task GetAvailableRoomTypes()
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.GetAvailableRoomTypes(hotelID, hotelRoomBookingRateDetailRequestModel.CheckInDate.Value, hotelRoomBookingRateDetailRequestModel.CheckOutDate.Value);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseHotelRoomTypeDataList = serviceResponse.Content;
            }
            else
            {
                serviceResponseHotelRoomTypeDataList = new List<HotelRoomTypeWebAppModel>();
            }
            StateHasChanged();
        }
        private async Task GetHotelDailyRate()
        {
            DateOnly checkInDate = DateOnly.FromDateTime(hotelRoomBookingRateDetailRequestModel.CheckInDate.Value);

            var serviceResponse = await _hotelRoomBookingWebAppService.GetHotelDailyRateByDate(hotelID, checkInDate);
            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {
                serviceResponseHotelDailyRateData = serviceResponse.Content;
            }
            else
            {
                serviceResponseHotelDailyRateData = new HotelDailyRateWebAppModel(); // Initialize as empty list if null
            }
            StateHasChanged();
        }
        private async Task GetHotelHourlyRate()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelHourlyRate(hotelID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseHotelHourlyRateDataList = serviceResponse.Content;
            }
            else
            {
                serviceResponseHotelHourlyRateDataList = new List<HotelHourlyRateWebAppModel>(); // Initialize as empty list if null
            }
            isLoading = false;
            StateHasChanged();
        }
        private async Task<ApiResponse<bool>> RoomExtend()
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.RoomExtend(hotelRoomBookingRequestModel);
            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Room extend successfully!");

            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while extending room.");
            }
            return serviceResponse;
        }
        #endregion
    }
}
