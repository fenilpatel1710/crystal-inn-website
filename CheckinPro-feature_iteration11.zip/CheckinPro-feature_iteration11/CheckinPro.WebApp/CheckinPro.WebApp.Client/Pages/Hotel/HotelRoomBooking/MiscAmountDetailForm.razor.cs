﻿using CheckinPro.Common.Models;
using CheckinPro.Common.Models.Constants;
using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Providers;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;
using System.ComponentModel;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking
{
    public partial class MiscAmountDetailForm : BookingServiceComponent
    {
        #region Inject Services
        [Inject] private IHotelRoomBookingWebAppService _hotelRoomBookingWebAppService { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter
        [Parameter] public EventCallback OnCancel { get; set; }
        public AddEditMiscAmountWebAppModel hotelRoomBookingMiscRequestModel { get; set; } = new();
        public List<AddEditMiscAmountWebAppModel> serviceResponseMiscData { get; set; } = new();
        [Parameter] public int hotelRoomBookingID { get; set; }
        public bool isEditMiscAmountClick { get; set; } = false;

        #endregion

        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            hotelRoomBookingMiscRequestModel.MiscellaneousDate = DateTime.Now;
            await GetRoomBookingMiscAmount();
        }
        private async Task HandleFormOnSubmit()
        {
            hotelRoomBookingMiscRequestModel.HotelRoomBookingID = hotelRoomBookingID;
            var serviceResponse = await OnSaveMiscellaneousAmountClicked(hotelRoomBookingMiscRequestModel);
            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Miscellaneous Amount saved successfully!");
                await GetRoomBookingMiscAmount();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving Miscellaneous Amount.");
            }
            hotelRoomBookingMiscRequestModel = new AddEditMiscAmountWebAppModel();
            hotelRoomBookingMiscRequestModel.MiscellaneousDate = DateTime.Now;
            isEditMiscAmountClick = false;
            StateHasChanged();
        }
        private async Task OnEditMiscAmountClick(AddEditMiscAmountWebAppModel miscAmountRequestData)
        {
            isEditMiscAmountClick = true;
            hotelRoomBookingMiscRequestModel = new AddEditMiscAmountWebAppModel
            {
                HotelRoomBookingMiscellaneousID = miscAmountRequestData.HotelRoomBookingMiscellaneousID,
                HotelRoomBookingID = miscAmountRequestData.HotelRoomBookingID,
                MiscellaneousDate = miscAmountRequestData.MiscellaneousDate,
                MiscellaneousAmount = miscAmountRequestData.MiscellaneousAmount,
            };
            await Task.CompletedTask;
            StateHasChanged();
        }
        private async Task OnDeleteMiscAmountClick(int hotelRoomBookingMiscellaneousID, decimal? miscellaneousAmount)
        {
            var result = await _dialogService.Confirm($"Are you sure you want to delete Misc Amount <strong>'{miscellaneousAmount}'</strong>?", "Confirm Delete",
            new ConfirmOptions() { OkButtonText = "Yes", CancelButtonText = "No", ShowClose = true });

            if (result.HasValue && result.Value)
            {
                await DeleteMiscAmount(hotelRoomBookingMiscellaneousID);
            }
        }

        #endregion

        #region API service calls
        private async Task GetRoomBookingMiscAmount()
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.GetRoomBookingMiscAmount(hotelRoomBookingID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseMiscData = serviceResponse.Content;
            }
            else
            {
                serviceResponseMiscData = new List<AddEditMiscAmountWebAppModel>();
            }
            StateHasChanged();
        }

        private async Task DeleteMiscAmount(int hotelRoomBookingMiscellaneousID)
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.DeleteMiscAmount(hotelRoomBookingMiscellaneousID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Misc Amount deleted successfully!");

                await GetRoomBookingMiscAmount();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while deleting Misc Amount '{serviceResponse.Error}'.");
            }
            StateHasChanged();
        }

        #endregion
    }
}
