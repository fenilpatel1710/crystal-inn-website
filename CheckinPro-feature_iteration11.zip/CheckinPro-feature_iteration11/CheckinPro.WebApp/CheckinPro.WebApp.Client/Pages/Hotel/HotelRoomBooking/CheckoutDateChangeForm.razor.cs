﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using CheckinPro.WebApp.Models.Guest;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking
{
    public partial class CheckoutDateChangeForm : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelRoomBookingWebAppService _hotelRoomBookingWebAppService { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter
        public bool isLoading { get; set; } = true;
        [Parameter] public int hotelID { get; set; } = 0;

        //[Parameter] public HotelRoomBookingWebAppModel hotelRoomBookingData { get; set; }
        [Parameter] public DateTime? startDate { get; set; }
        [Parameter] public DateTime? endDate { get; set; }
        public DateTime? newEndDate { get; set; }

        private bool isCalculateRoomRate = false;

        private string BookingDuration = string.Empty;

        [Parameter] public List<HotelRoomBookingRateDetailWebAppModel> bookingRateDetailList { get; set; } = new();

        public HotelRoomBookingRateDetailWebAppModel hotelRoomBookingRateDetailRequestModel = new HotelRoomBookingRateDetailWebAppModel();
        private List<HotelTaxRateWebAppModel> serviceResponseHotelTaxRateDataList { get; set; } = new();
        #endregion

        #region OnRender Method Starts
        protected override async Task OnInitializedAsync()
        {
            newEndDate = endDate;
            //if (hotelRoomBookingData != null)
            //{
            //    startDate = hotelRoomBookingData.ScheduledCheckInDate;
            //    endDate = hotelRoomBookingData.ScheduledCheckOutDate;
            //    bookingRateDetailList = hotelRoomBookingData.HotelRoomBookingRateDetails.ToList();
            //    StateHasChanged();
            //}
        }

        private void OnCheckOutDateChange(DateTime? value)
        {
            if (!value.HasValue) return;

            newEndDate = value.Value.Date.AddHours(11);
            hotelRoomBookingRateDetailRequestModel = new();
            isCalculateRoomRate = false;

            foreach (var booking in bookingRateDetailList)
            {
                if (booking.CheckInDate >= newEndDate)
                {
                    booking.IsBookingActive = false;
                }
                else
                {
                    booking.IsBookingActive = true;
                }
                if (newEndDate > booking.CheckInDate && newEndDate <= booking.CheckOutDate)
                {
                    hotelRoomBookingRateDetailRequestModel = new HotelRoomBookingRateDetailWebAppModel
                    {
                        HotelRoomBookingRateDetailID = booking.HotelRoomBookingRateDetailID,
                        CheckInDate = booking.CheckInDate,
                        CheckOutDate = newEndDate,
                        Duration = booking.Duration,
                        BestAvailableRate = booking.BestAvailableRate,
                        AdjustmentRate = booking.AdjustmentRate,
                        HourlyRate = booking.HourlyRate,
                        RoomChargeAmount = booking.RoomChargeAmount,
                        TotalAmount = booking.TotalAmount,
                        IsDiscountedRate = booking.IsDiscountedRate,
                        AdditionalRateType = booking.AdditionalRateType,
                        AdditionalRateAmount = booking.AdditionalRateAmount,
                        DiscountedAmount = booking.DiscountedAmount,
                        MiscellaneousAmount = booking.MiscellaneousAmount,
                        FinalAmount = booking.FinalAmount,
                        Balance = booking.Balance,
                        IsExtend = booking.IsExtend,
                        IsBookingActive = booking.IsBookingActive,
                        CreatedDate = booking.CreatedDate,
                        HotelRoomBookingTaxRates = booking.HotelRoomBookingTaxRates.Select(item => new HotelRoomBookingTaxRateWebAppModel
                        {
                            HotelRoomBookingTaxRateID = item.HotelRoomBookingTaxRateID,
                            HotelTaxRateID = item.HotelTaxRateID,
                            BookingTaxRateName = item.BookingTaxRateName,
                            BookingTaxRatePercentage = item.BookingTaxRatePercentage,
                            BookingTaxRate = item.BookingTaxRate,
                            IsBookingTaxRateActive = item.IsBookingTaxRateActive
                        }).ToList(),
                    };
                    //var rateData = booking;
                    //hotelRoomBookingRateDetailRequestModel = rateData;
                    //hotelRoomBookingRateDetailRequestModel.CheckOutDate = newEndDate;
                }
            }
            StateHasChanged();
        }

        private async Task OnSaveClick()
        {
            await RoomCheckOutDateChange();
            _dialogService.Close(true);
        }

        private async void OnSearchClicked()
        {
            isLoading = true;
            await CalculateRoomRate();
            isCalculateRoomRate = true;
            isLoading = false;
            StateHasChanged();
        }

        private async Task CalculateRoomRate()
        {
            decimal? RoomRate = 0;

            if (hotelRoomBookingRateDetailRequestModel.HotelRoomBookingTaxRates.Any())
            {
                serviceResponseHotelTaxRateDataList = hotelRoomBookingRateDetailRequestModel.HotelRoomBookingTaxRates.Select(h => new HotelTaxRateWebAppModel
                {
                    HotelTaxRateID = h.HotelTaxRateID ?? 0,
                    TaxName = h.BookingTaxRateName,
                    TaxRate = h.BookingTaxRatePercentage,
                }).ToList();
            }

            if (hotelRoomBookingRateDetailRequestModel.CheckInDate != DateTime.MinValue && hotelRoomBookingRateDetailRequestModel.CheckOutDate != DateTime.MinValue)
            {
                var checkIn = hotelRoomBookingRateDetailRequestModel.CheckInDate.Value;
                var checkOut = hotelRoomBookingRateDetailRequestModel.CheckOutDate.Value;
                var duration = checkOut - checkIn;
                decimal bookingDuration = (decimal)Math.Floor(duration.TotalDays);
                bookingDuration = bookingDuration < 1 ? 1 : bookingDuration;

                if (duration.TotalDays <= 0)
                {
                    BookingDuration = "Invalid duration for days booking.";
                    hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = 0; // Invalid duration
                    hotelRoomBookingRateDetailRequestModel.TotalAmount = 0; // Reset final amount
                    hotelRoomBookingRateDetailRequestModel.FinalAmount = 0; // Reset final amount
                    return;
                }

                if (hotelRoomBookingRateDetailRequestModel?.AdjustmentRate.HasValue == true)
                {
                    RoomRate += hotelRoomBookingRateDetailRequestModel.AdjustmentRate;
                }

                RoomRate += hotelRoomBookingRateDetailRequestModel.BestAvailableRate;

                // Calculate total amount based on booking type

                if (duration.TotalDays >= 1)
                {
                    hotelRoomBookingRateDetailRequestModel.Duration = Convert.ToInt32(Math.Floor(duration.TotalDays));
                    BookingDuration = $"{Math.Floor(duration.TotalDays)} Day(s)";
                    hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = bookingDuration * RoomRate; // Per day rate
                }
                else
                {
                    BookingDuration = "Invalid duration for days booking.";
                    hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = 0; // Invalid duration
                    hotelRoomBookingRateDetailRequestModel.TotalAmount = 0; // Reset final amount
                    hotelRoomBookingRateDetailRequestModel.FinalAmount = 0; // Reset final amount
                }

                hotelRoomBookingRateDetailRequestModel.TotalAmount = hotelRoomBookingRateDetailRequestModel.RoomChargeAmount;
                hotelRoomBookingRateDetailRequestModel.FinalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount;

                if (serviceResponseHotelTaxRateDataList.Any())
                {
                    //HandleTaxRateChange(serviceResponseHotelTaxRateDataList);
                    OnSelectCalculateTaxRate(serviceResponseHotelTaxRateDataList);
                }
            }
            else
            {
                hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = 0;
                hotelRoomBookingRateDetailRequestModel.TotalAmount = 0;
                hotelRoomBookingRateDetailRequestModel.FinalAmount = 0;
            }
            StateHasChanged();
        }

        private void OnSelectCalculateTaxRate(object selectedTaxRateItem)
        {
            decimal totalTaxRates = 0m;
            decimal subTotalAmount = hotelRoomBookingRateDetailRequestModel.RoomChargeAmount ?? 0m;

            var selectedHotelTaxRate = (IEnumerable<HotelTaxRateWebAppModel>)selectedTaxRateItem;

            // Clear the existing tax rates to avoid duplicates
            hotelRoomBookingRateDetailRequestModel.HotelRoomBookingTaxRates.Clear();

            if (selectedHotelTaxRate.Any())
            {
                foreach (var item in selectedHotelTaxRate)
                {
                    // Add the tax rate to the list
                    totalTaxRates += Convert.ToDecimal(item.TaxRate);
                    var newTaxRate = new HotelRoomBookingTaxRateWebAppModel
                    {
                        HotelTaxRateID = item.HotelTaxRateID,
                        BookingTaxRateName = item.TaxName,
                        BookingTaxRatePercentage = item.TaxRate,
                        BookingTaxRate = (subTotalAmount * (item.TaxRate / 100)),
                    };

                    hotelRoomBookingRateDetailRequestModel.HotelRoomBookingTaxRates.Add(newTaxRate);
                }

                // Calculate the total tax amount using the selected tax rate(s)
                decimal validTaxRate = totalTaxRates / 100; // Convert total tax rate to decimal

                decimal taxAmount = subTotalAmount * validTaxRate;

                // Calculate final amount (subtotal + tax)
                hotelRoomBookingRateDetailRequestModel.TotalAmount = (decimal?)Math.Round(subTotalAmount + taxAmount, 2);
                hotelRoomBookingRateDetailRequestModel.FinalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount;
            }
            else
            {
                hotelRoomBookingRateDetailRequestModel.TotalAmount = hotelRoomBookingRateDetailRequestModel.RoomChargeAmount;
                hotelRoomBookingRateDetailRequestModel.FinalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount;
            }

            StateHasChanged();
        }

        private void CalculateReverseAmount(IEnumerable<HotelTaxRateWebAppModel> hotelTaxRateWebAppModel)
        {

            // Ensure FinalAmount is valid
            if (!hotelRoomBookingRateDetailRequestModel.TotalAmount.HasValue || hotelRoomBookingRateDetailRequestModel.TotalAmount == 0)
                return;

            decimal totalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount ?? 0m;

            // Get tax rates dynamically
            var taxPercentages = hotelTaxRateWebAppModel.Where(tax => tax.TaxRate.HasValue).Select(tax => tax.TaxRate.Value).ToList();

            // Calculate the total percentage dynamically
            decimal totalTaxRate = taxPercentages.Sum();

            // Calculate the combined percentage factor (1 + total tax rate / 100)
            decimal percentageFactor = 1 + (totalTaxRate / 100);

            // Reverse calculation to find the room charge
            decimal roomCharge = totalAmount / percentageFactor; // Final amount / 1.17 to get room charge

            // Assign values back to the model
            hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = roomCharge;

            OnSelectCalculateTaxRate(hotelTaxRateWebAppModel);

            StateHasChanged();
        }

        #endregion

        #region API Service Calls
        private async Task RoomCheckOutDateChange()
        {
            isLoading = true;
            var serviceResponse = await _hotelRoomBookingWebAppService.RoomCheckOutDateChange(hotelRoomBookingRateDetailRequestModel);
            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"CheckOut date changed successfully.");
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while CheckOut date change");
            }
            isLoading = false;
            StateHasChanged();
        }

        #endregion
    }
}
