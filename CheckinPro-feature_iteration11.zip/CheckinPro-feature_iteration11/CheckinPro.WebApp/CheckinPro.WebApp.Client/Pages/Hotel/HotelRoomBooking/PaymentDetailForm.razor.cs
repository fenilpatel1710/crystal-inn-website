﻿using CheckinPro.Common.Models;
using CheckinPro.Common.Models.Constants;
using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Providers;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;
using System.ComponentModel;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking
{
    public partial class PaymentDetailForm : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelRoomBookingWebAppService _hotelRoomBookingWebAppService { get; set; }
        [Inject] private IGuestWebAppService _guestWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private DialogService _dialogService { get; set; }
        [Inheritance] private CustomComponentBase _customComponentBase { get; set; }


        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter
        [Parameter] public EventCallback<AddEditHotelRoomPaymentWebAppModel> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        [Parameter] public AddEditHotelRoomPaymentWebAppModel hotelRoomPaymentRequestModel { get; set; } = new();
        [Parameter] public decimal finalAmount { get; set; }
        [Parameter] public decimal paidAmount { get; set; }
        [Parameter] public string guestName { get; set; }
        [Parameter] public int hotelID { get; set; }
        [Parameter] public int guestID { get; set; }
        [Parameter] public decimal appliedRewardPoint { get; set; } = 0;

        public GuestRewardWebAppModel guestRewardServiceResponseData { get; set; } = new();
        public List<SelectionItemModel> PaymentMode = CommonConstants.PaymentMode;
        public List<SelectionItemModel> PaymentType = CommonConstants.PaymentType;
        public List<SelectionItemModel> IdentityTypes = CommonConstants.IdentityTypes;
        public List<SelectionItemModel> PaymentGateway = CommonConstants.PaymentGateway;
        //public List<SelectionItemModel> TransactionType = CommonConstants.TransactionType;
        public List<SelectionItemModel> PaymentStatus = CommonConstants.PaymentStatus;
        [Parameter] public bool IsRefund { get; set; } = false;
        private bool IsBusy { get; set; } = false;
        public decimal totalRewardPoint { get; set; } = 0;
        public string usedRewardValidation { get; set; } = string.Empty;


        #endregion

        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {

            finalAmount = Math.Round(finalAmount, 2);
            paidAmount = Math.Round(paidAmount, 2);
            if (hotelRoomPaymentRequestModel.PaymentMode == null && hotelRoomPaymentRequestModel.Amount == null)
            {
                hotelRoomPaymentRequestModel.Amount = Math.Round(finalAmount - paidAmount, 2);
                hotelRoomPaymentRequestModel.PaymentMode = CommonConstants.PaymentModeOption.Cash;
                hotelRoomPaymentRequestModel.PaymentType = "Booking Payment";
                hotelRoomPaymentRequestModel.PaymentStatus = CommonConstants.PaymentStatusMessages.Completed;
                hotelRoomPaymentRequestModel.PaymentCompletedOn = DateTime.Now;
            }
            if (guestID > 0)
            {
                await GuestReward();
            }
            if (IsRefund && hotelRoomPaymentRequestModel.RefundDate == null)
            {
                hotelRoomPaymentRequestModel.RefundDate = DateTime.Now;
            }
        }

        private async Task HandleFormOnSubmit()
        {
            IsBusy = true;
            if (appliedRewardPoint <= finalAmount)
            {
                usedRewardValidation = string.Empty;
                //if (IsRefund)
                //{
                //    await RoomRefund();
                //    OnCancel.InvokeAsync();
                //}
                hotelRoomPaymentRequestModel.IsRefund = IsRefund;

                if (hotelRoomPaymentRequestModel.PaymentMode == null && hotelRoomPaymentRequestModel.Amount == null)
                {
                    decimal? TotalPaid = (paidAmount + hotelRoomPaymentRequestModel.Amount);
                    if (TotalPaid >= finalAmount)
                    {
                        _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", "The entered amount cannot be greater than the final amount.");
                    }
                    await OnSubmit.InvokeAsync(hotelRoomPaymentRequestModel);
                }
                else
                {
                    await OnSubmit.InvokeAsync(hotelRoomPaymentRequestModel);
                }
            }
            else
            {
                usedRewardValidation = "Point can not be greater than Final Amount";
            }
            // decimal? TotalPaid = (paidAmount + hotelRoomPaymentRequestModel.Amount);
            //if (TotalPaid <= finalAmount)
            //{
            //    if (IsRefund)
            //    {
            //        await RoomRefund();
            //    }
            //    await OnSubmit.InvokeAsync(hotelRoomPaymentRequestModel);
            //}
            //else
            //{
            //    _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "Invalid Payment Amount", "The entered amount cannot be greater than the final amount.");
            //}
            IsBusy = false;
        }

        private void HandleOnCancel()
        {
            OnCancel.InvokeAsync();
        }

        private void OnChangeRewardPoint(object args)
        {
            decimal? usedRewardPoint = args as decimal?;
            hotelRoomPaymentRequestModel.Amount = usedRewardPoint;
            hotelRoomPaymentRequestModel.UsedRewardPoint = usedRewardPoint;
            appliedRewardPoint = usedRewardPoint ?? 0;
            StateHasChanged();
        }

        private void OnPaymentModeChange()
        {
            if (hotelRoomPaymentRequestModel.PaymentMode == CommonConstants.PaymentModeOption.RewardPoint)
            {
                if (totalRewardPoint >= finalAmount)
                {
                    hotelRoomPaymentRequestModel.UsedRewardPoint = Math.Round(finalAmount - paidAmount, 0);
                }
                else
                {
                    hotelRoomPaymentRequestModel.UsedRewardPoint = totalRewardPoint;
                }
                appliedRewardPoint = hotelRoomPaymentRequestModel.UsedRewardPoint ?? 0;
                hotelRoomPaymentRequestModel.Amount = appliedRewardPoint;
            }                     
        }

        #endregion

        #region API service calls
        private async Task RoomRefund()
        {

            var serviceResponse = await _hotelRoomBookingWebAppService.RoomRefund(hotelRoomPaymentRequestModel);
            if (serviceResponse.IsSuccessStatusCode)
            {
                hotelRoomPaymentRequestModel.IsRefunded = IsRefund;
            }
            //if (serviceResponse.IsSuccessStatusCode)
            //{
            //    _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Room Refund '{hotelRoomPaymentRequestModel.Amount}' successfully completed!");
            //}
            //else
            //{
            //    _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while Room Refund Process");
            //}
            IsBusy = false;
            StateHasChanged();
        }

        private async Task GuestReward()
        {

            var serviceResponse = await _guestWebAppService.GetGuestRewardPoint(hotelID, guestID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                guestRewardServiceResponseData = serviceResponse.Content;
                totalRewardPoint = guestRewardServiceResponseData.TotalRewardPoint ?? 0;
            }
            else
            {
                guestRewardServiceResponseData = new();
            }
            StateHasChanged();
        }

        #endregion

    }
}
