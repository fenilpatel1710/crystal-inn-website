﻿using CheckinPro.Common.Models.Constants;
using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Pages.Guest;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using Newtonsoft.Json;
using Radzen;
using System.Xml.Serialization;
using static CheckinPro.Common.Models.Constants.CommonConstants;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking
{
    public partial class RoomBooking : BookingServiceComponent
    {
        #region Inject Services
        [Inject] private IDropdownWebAppService _dropDownWebAppService { get; set; }
        [Inject] private IGuestWebAppService _guestWebAppService { get; set; }
        [Inject] private IHotelRoomBookingWebAppService _hotelRoomBookingWebAppService { get; set; }
        [Inject] private IHotelWebAppService _hotelWebAppService { get; set; }
        [Inject] private IHotelReportWebAppService _hotelReportWebAppService { get; set; }
        [Inject] private DialogService _dialogService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private IJSRuntime _jsruntime { get; set; }

        private NotificationAlert _notificationAlertComponent = new();

        #endregion

        #region Parameter
        [Parameter] public int hotelID { get; set; } = 0;
        [Parameter] public int hotelRoomTypeID { get; set; } = 0;
        [Parameter] public int hotelRoomID { get; set; } = 0;
        [Parameter] public string? roomNumber { get; set; }
        [Parameter] public string? guestCode { get; set; }
        [Parameter] public int hotelRoomBookingID { get; set; } = 0;
        [Parameter] public bool IsBookingExtend { get; set; } = false;
        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        bool IsBusy { get; set; } = false;
        bool IsBusyBooked { get; set; } = false;
        bool IsBusyCheckIn { get; set; } = false;
        bool IsQuickBooking { get; set; } = false;
        bool IsSearchDisabled { get; set; } = false;

        private int? checkOutHours = 1;

        IEnumerable<HotelTaxRateWebAppModel> selectedHotelTaxRate;

        private decimal? rateExceptionAmount;
        private bool isEditingFinalAmount = false;

        private bool isGuestPresent = false;
        int? selectedCountryId;
        private List<string> mobileNumbers = new();

        private string BookingDuration = string.Empty;
        private string GuestCode = string.Empty;
        private string IdentityNumber = string.Empty;
        private string MobileNumber = string.Empty;
        private string FirstName = string.Empty;
        private string LastName = string.Empty;
        private bool isGuestLastBookingDetailVisible = false;
        private string guestName { get; set; }
        private int guestID { get; set; }
        public decimal? UsedRewardPoint { get; set; }
        public string? rewardPointErrorMessage { get; set; } = string.Empty;
        public bool isRewardPointVisible { get; set; } = false;

        private HotelRoomBookingWebAppModel hotelRoomBookingRequestModel { get; set; } = new();
        private HotelConfigurationWebAppModel serviceResponseHotelConfigurationData { get; set; } = new();
        private List<HotelTaxRateWebAppModel> serviceResponseHotelTaxRateDataList { get; set; } = new();
        private HotelDailyRateWebAppModel serviceResponseHotelDailyRateData { get; set; } = new();
        private List<HotelHourlyRateWebAppModel> serviceResponseHotelHourlyRateDataList { get; set; } = new();
        private List<HotelAdditionalRateWebAppModel> serviceResponseHotelAdditionalRateList { get; set; } = new();
        private List<HotelRoomWebAppModel> serviceResponseHotelRoomDataList { get; set; } = new();
        private List<HotelRoomTypeWebAppModel> serviceResponseHotelRoomTypeDataList { get; set; } = new();
        private HotelAdditionalRateWebAppModel selectedHotelAdditionalRate { get; set; } = new HotelAdditionalRateWebAppModel();
        private List<GetHotelRoomBookingSearchListWebAppModel> serviceResponseDataList { get; set; } = new();
        public BookingListDataGridFlags bookingListDataGridFlags { get; set; } = new();
        private FindHotelRoomBookingWebAppModel findHotelRoomBookingRequestModel { get; set; } = new();
        public GuestRewardWebAppModel guestRewardServiceResponseData { get; set; } = new();

        #endregion

        #region OnRender Method Starts
        protected override async Task OnInitializedAsync()
        {
            if (hotelRoomTypeID > 0 && hotelRoomID > 0 && !string.IsNullOrEmpty(roomNumber))
            {
                IsQuickBooking = true;
            }
            await OnBookingTypeChange();
            bookingListDataGridFlags.isRoomNumberVisible = true;
            bookingListDataGridFlags.isCheckInButtonVisible = false;
            bookingListDataGridFlags.isCancelButtonVisible = false;
            bookingListDataGridFlags.isCheckOutButtonVisible = false;
            isLoading = false;
            StateHasChanged();
        }

        private async Task Quick_ExtendBooking()
        {
            if (IsQuickBooking)
            {
                hotelRoomBookingRequestModel.HotelRoomID = hotelRoomID;
                hotelRoomBookingRequestModel.HotelRoom.RoomNumber = roomNumber;
            }
            else if (IsBookingExtend)
            {
                hotelRoomTypeID = hotelRoomBookingRequestModel.HotelRoomTypeID;
                hotelRoomID = hotelRoomBookingRequestModel.HotelRoomID.Value;
                roomNumber = hotelRoomBookingRequestModel.HotelRoom.RoomNumber;
                //hotelRoomBookingRequestModel.IsBookingExtend = true;
                //hotelRoomBookingRequestModel.OriginalHotelRoomBookingID = hotelRoomBookingRequestModel.HotelRoomBookingID;
                hotelRoomBookingRequestModel.BookingStatus = null;
                //hotelRoomBookingRequestModel.PaymentStatus = null;
                hotelRoomBookingRequestModel.AdditionalRateType = null;
                hotelRoomBookingRequestModel.AdditionalRateAmount = new();
                hotelRoomBookingRequestModel.HotelRoomPayments = new List<AddEditHotelRoomPaymentWebAppModel>();
            }

            await GetAvailableRoomTypes();
            var hotelRoomTypeData = serviceResponseHotelRoomTypeDataList.Where(item => item.HotelRoomTypeID == hotelRoomTypeID).FirstOrDefault();
            if (hotelRoomTypeData != null)
            {
                await SelectRoomType(hotelRoomTypeData);
            }
            StateHasChanged();
        }

        //private async void QuickBookingCheck()
        //{
        //    if (IsQuickBooking)
        //    {
        //        hotelRoomBookingRequestModel.HotelRoomID = hotelRoomID;
        //        hotelRoomBookingRequestModel.HotelRoom.RoomNumber = roomNumber;
        //        await GetAvailableRoomTypes();
        //        var hotelRoomTypeData = serviceResponseHotelRoomTypeDataList.Where(item => item.HotelRoomTypeID == hotelRoomTypeID).FirstOrDefault();
        //        if (hotelRoomTypeData != null)
        //        {
        //            await SelectRoomType(hotelRoomTypeData);
        //        }
        //    }
        //}

        private async void OnStepsChange(int index)
        {
            switch (index)
            {
                case 0: // Reservation Details
                    //_notificationAlertComponent.ShowNotification(NotificationSeverity.Warning, "", "Please complete the reservation details before proceeding.");
                    break;

                case 1: // Guest Details
                        //_notificationAlertComponent.ShowNotification(NotificationSeverity.Warning, "", "Please complete the guest details before proceeding.");
                    OnSearchClicked();
                    break;

                case 2: // Booking Details
                        //indGuestIdentities();
                    break;

                case 3: // Payment Details
                    //_notificationAlertComponent.ShowNotification(NotificationSeverity.Warning, "", "Please complete the payment details before proceeding.");
                    await GetGuestReward();
                    break;

                default:
                    break;
            }
        }

        private async Task OnBookingTypeChange()
        {
            hotelRoomBookingRequestModel.RoomChargeAmount = new();
            hotelRoomBookingRequestModel.TotalAmount = new();
            hotelRoomBookingRequestModel.AdditionalRateType = null;
            hotelRoomBookingRequestModel.AdditionalRateAmount = new();
            hotelRoomBookingRequestModel.FinalAmount = new();
            hotelRoomBookingRequestModel.BookingStatus = null;
            //hotelRoomBookingRequestModel.PaymentStatus = null;
            hotelRoomBookingRequestModel.HotelRoomID = 0;
            hotelRoomBookingRequestModel.HotelRoomTypeID = 0;
            hotelRoomBookingRequestModel.HotelRoomPayments = new List<AddEditHotelRoomPaymentWebAppModel>();
            serviceResponseHotelRoomDataList = new();
            hotelRoomBookingRequestModel.HotelRoom = new AddEditHotelRoomWebAppModel();
            selectedHotelAdditionalRate = new HotelAdditionalRateWebAppModel();

            if (IsBookingExtend)
            {
                await GetHotelRoomBookingDetail();
            }

            if (hotelRoomBookingRequestModel.IsHourlyBooking == false) // Days
            {
                if (IsBookingExtend)
                {
                    hotelRoomBookingRequestModel.ScheduledCheckInDate = hotelRoomBookingRequestModel.ScheduledCheckOutDate;
                    hotelRoomBookingRequestModel.ScheduledCheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckInDate.Value.AddDays(1).Date.AddHours(11);
                }
                else
                {
                    hotelRoomBookingRequestModel.ScheduledCheckInDate = Convert.ToDateTime(GetCheckInMinDate());
                    hotelRoomBookingRequestModel.ScheduledCheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckInDate.Value.AddDays(1).Date.AddHours(11);
                }

                OnCheckOutDateChange(hotelRoomBookingRequestModel.ScheduledCheckOutDate);
                await GetHotelConfiguration();
                await GetHotelDailyRate();
                await GetHotelAdditionalRate();
            }
            else if (hotelRoomBookingRequestModel.IsHourlyBooking == true) // Hourly
            {
                if (IsBookingExtend)
                {
                    hotelRoomBookingRequestModel.ScheduledCheckInDate = hotelRoomBookingRequestModel.ScheduledCheckOutDate;
                }
                else
                {
                    var now = DateTime.Now;
                    hotelRoomBookingRequestModel.ScheduledCheckInDate = new DateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, 0);
                }
                await GetHotelHourlyRate();
            }

            await GetHotelTaxRate();

            if (IsQuickBooking || IsBookingExtend)
            {
                await Quick_ExtendBooking();
            }
            StateHasChanged();
        }

        private DateTime GetCheckInMinDate()
        {
            var now = DateTime.Now;
            if (hotelRoomBookingRequestModel.IsHourlyBooking)
            {
                return new DateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, 0);
            }

            if (now.Hour < 6)
            {
                return now.AddDays(-1).Date.AddHours(11);
            }

            return now.Date.AddHours(11);
        }

        private DateTime GetCheckOutMinDate()
        {
            return (hotelRoomBookingRequestModel.ScheduledCheckInDate ?? GetCheckInMinDate()).AddDays(1).Date.AddHours(11);
        }


        //private DateTime GetMinCheckInDate()
        //{
        //    DateTime now = DateTime.Now;

        //    // If current time is between 12 AM and 6 AM, allow previous day booking
        //    if (now.Hour < 6)
        //    {
        //        return now.AddDays(-1).Date.AddHours(11); // Allow booking the previous day
        //    }
        //    else
        //    {
        //        return now.Date.AddHours(11); // Allow booking today or future
        //    }
        //}

        //private DateTime GetMinCheckOutDate()
        //{
        //    // For "Days" booking, the check-out date should be at least one day after check-in
        //    if (hotelRoomBookingRequestModel.ScheduledCheckInDate.HasValue)
        //    {
        //        return hotelRoomBookingRequestModel.ScheduledCheckInDate.Value.AddDays(1).Date.AddHours(11);
        //    }

        //    return DateTime.Now.AddDays(1); // Default to tomorrow if check-in is not set
        //}

        private void OnCheckInDateChange(DateTime? value)
        {
            if (value.HasValue)
            {
                // For Days booking, ensure the check-out date is at least one day after the check-in date
                hotelRoomBookingRequestModel.ScheduledCheckInDate = value.Value;

                // For "Days" booking, ensure check-out is at least one day after check-in
                if (hotelRoomBookingRequestModel.IsHourlyBooking == false && hotelRoomBookingRequestModel.ScheduledCheckOutDate < hotelRoomBookingRequestModel.ScheduledCheckInDate.Value.AddDays(1))
                {
                    hotelRoomBookingRequestModel.ScheduledCheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckInDate.Value.AddDays(1);
                }
                else
                {
                    hotelRoomBookingRequestModel.ScheduledCheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckInDate.Value.AddHours(1);
                }
            }
            else
            {
                // Set to current date or previous day depending on time of day
                hotelRoomBookingRequestModel.ScheduledCheckInDate = GetCheckInMinDate();
            }

            OnDateChange();
        }

        private void OnCheckOutDateChange(DateTime? value)
        {
            if (value.HasValue && value.Value >= hotelRoomBookingRequestModel.ScheduledCheckInDate)
            {
                // Set the selected checkout date and set the time to 11:30 AM
                hotelRoomBookingRequestModel.ScheduledCheckOutDate = value.Value.Date.AddHours(11);
            }
            else
            {
                // Default to check-in date + 1 day and set time to 11:30 AM
                hotelRoomBookingRequestModel.ScheduledCheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckInDate.Value.AddDays(1).Date.AddHours(11);
            }

            // Optionally, call any other necessary function like OnDateChange
            OnDateChange();
        }

        private void OnCheckOutHoursChange(object args)
        {
            int? checkOutHours = args as int?;

            // Ensure check-out hours value is valid
            if (checkOutHours.HasValue && checkOutHours.Value != 0)
            {
                // Only update the check-out date, NOT the check-in date
                hotelRoomBookingRequestModel.ScheduledCheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckInDate.Value.AddHours((double)checkOutHours);

                // Find the hourly rate based on the selected check-out hours
                var matchedRate = serviceResponseHotelHourlyRateDataList
                                   .FirstOrDefault(rate => rate.Hour == checkOutHours);

                if (matchedRate != null)
                {
                    hotelRoomBookingRequestModel.HourlyRate = matchedRate.HourlyRate;
                }
                else
                {
                    hotelRoomBookingRequestModel.HourlyRate = null;
                }
            }
            else
            {
                // If no valid value for check-out hours, default to 1 hour
                hotelRoomBookingRequestModel.ScheduledCheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckInDate.Value.AddHours(1);
            }

            // Ensure we don't modify the check-in date here
            OnDateChange();
        }

        private async void OnDateChange()
        {
            if (hotelRoomBookingRequestModel.ScheduledCheckInDate != DateTime.MinValue && hotelRoomBookingRequestModel.ScheduledCheckOutDate != DateTime.MinValue)
            {
                var checkIn = hotelRoomBookingRequestModel.ScheduledCheckInDate.Value;
                var checkOut = hotelRoomBookingRequestModel.ScheduledCheckOutDate.Value;

                if (hotelRoomBookingRequestModel.IsHourlyBooking == false) // Days
                {
                    var duration = checkOut.Date - checkIn.Date;
                    if (duration.TotalDays >= 1)
                    {
                        hotelRoomBookingRequestModel.Duration = Convert.ToInt32(Math.Floor(duration.TotalDays));
                        BookingDuration = $"{Math.Floor(duration.TotalDays)} Day(s)";
                        IsSearchDisabled = false;
                    }
                    else
                    {
                        BookingDuration = "Invalid duration for days booking.";
                        IsSearchDisabled = true;
                    }
                }
                else if (hotelRoomBookingRequestModel.IsHourlyBooking == true) // Hourly
                {
                    var duration = checkOut - checkIn;
                    if (duration.TotalHours >= 1)
                    {
                        hotelRoomBookingRequestModel.Duration = Convert.ToInt32(Math.Floor(duration.TotalHours));
                        BookingDuration = $"{Math.Floor(duration.TotalHours)} Hour(s)";
                        IsSearchDisabled = false;
                    }
                    else if (duration.TotalMinutes >= 1)
                    {
                        hotelRoomBookingRequestModel.Duration = Convert.ToInt32(Math.Floor(duration.TotalMinutes));
                        BookingDuration = $"{Math.Floor(duration.TotalMinutes)} Minute(s)";
                        IsSearchDisabled = false;
                    }
                    else
                    {
                        BookingDuration = "Invalid duration for hourly booking.";
                        IsSearchDisabled = true;
                    }
                }
            }
            StateHasChanged();
        }

        private bool IsCheckInDisabled()
        {
            var currentDate = GetCheckInMinDate();
            if (hotelRoomBookingRequestModel.ScheduledCheckInDate.HasValue && hotelRoomBookingRequestModel.ScheduledCheckInDate.Value.Date == currentDate.Date)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        private async void OnSearchClicked()
        {
            IsBusy = true;
            if (IsQuickBooking || IsBookingExtend)
            {
                await Quick_ExtendBooking();
            }
            else
            {
                if (hotelRoomBookingRequestModel.IsHourlyBooking == false) // Days
                {
                    await GetHotelDailyRate();
                }
                await GetAvailableRoomTypes();

                var hotelRoomTypeData = serviceResponseHotelRoomTypeDataList.Where(item => item.HotelRoomTypeID == hotelRoomBookingRequestModel.HotelRoomTypeID).FirstOrDefault();
                if (hotelRoomTypeData != null)
                {
                    SelectRoomType(hotelRoomTypeData);
                }
            }
            IsBusy = false;
            StateHasChanged();
        }

        private async Task SelectRoomType(HotelRoomTypeWebAppModel hotelRoomType)
        {
            isLoading = true;
            hotelRoomBookingRequestModel.HotelRoomTypeID = hotelRoomType.HotelRoomTypeID;
            hotelRoomBookingRequestModel.HotelRoom.HotelRoomType = new HotelRoomTypeWebAppModel
            {
                HotelRoomTypeID = hotelRoomType.HotelRoomTypeID,
                RoomTypeName = hotelRoomType.RoomTypeName,
                RoomTypeIcon = hotelRoomType.RoomTypeIcon,
                AdjustmentRate = hotelRoomType.AdjustmentRate,
            };
            decimal? RoomRate = 0;

            if (hotelRoomType?.AdjustmentRate.HasValue == true)
            {
                hotelRoomBookingRequestModel.AdjustmentRate = hotelRoomType.AdjustmentRate;
                RoomRate += hotelRoomBookingRequestModel.AdjustmentRate;
            }

            if (hotelRoomBookingRequestModel.IsHourlyBooking == false)
            {
                hotelRoomBookingRequestModel.BestAvailableRate =
                    serviceResponseHotelDailyRateData?.DailyBestAvailableRate.HasValue == true &&
                    serviceResponseHotelDailyRateData.DailyBestAvailableRate.Value != 0
                    ? serviceResponseHotelDailyRateData.DailyBestAvailableRate.Value
                    : serviceResponseHotelConfigurationData.BestAvailableRate;
                RoomRate += hotelRoomBookingRequestModel.BestAvailableRate;

            }
            else if (hotelRoomBookingRequestModel.IsHourlyBooking == true)
            {
                RoomRate += hotelRoomBookingRequestModel.HourlyRate;
                ///hotelRoomBookingRequestModel.HourlyRate += hotelRoomBookingRequestModel.AdjustmentRate;
            }

            CalculateRoomRate(RoomRate);
            isLoading = false;
            StateHasChanged();
        }

        private string GetCardClass(int hotelRoomTypeID)
        {
            // If this card is selected, apply the 'selected' class (green color)
            return hotelRoomBookingRequestModel.HotelRoomTypeID == hotelRoomTypeID ? "rz-border-radius-3 rz-my-1 rz-link rz-ripple rz-background-color-success-light rz-border-0" : "rz-border-radius-3 rz-my-1 rz-link rz-ripple rz-border-0";
        }

        private void CalculateRoomRate(decimal? RateAmount)
        {
            if (hotelRoomBookingRequestModel.ScheduledCheckInDate != DateTime.MinValue && hotelRoomBookingRequestModel.ScheduledCheckOutDate != DateTime.MinValue)
            {
                // Calculate the duration
                var checkIn = hotelRoomBookingRequestModel.ScheduledCheckInDate.Value;
                var checkOut = hotelRoomBookingRequestModel.ScheduledCheckOutDate.Value;
                var duration = checkOut - checkIn;
                decimal bookingDuration = (decimal)Math.Floor(duration.TotalDays);
                bookingDuration = bookingDuration < 1 ? 1 : bookingDuration;


                // Check if the booking duration is valid
                if (duration.TotalDays <= 0)
                {
                    hotelRoomBookingRequestModel.RoomChargeAmount = 0; // Invalid duration
                    hotelRoomBookingRequestModel.TotalAmount = 0; // Reset final amount
                    hotelRoomBookingRequestModel.FinalAmount = 0; // Reset final amount
                    return;
                }

                // Calculate total amount based on booking type
                if (hotelRoomBookingRequestModel.IsHourlyBooking == false)
                {
                    // For "days" booking (daily rate)
                    if (duration.TotalDays >= 1)
                    {
                        // Calculate the SubTotalAmount based on the rate per day
                        hotelRoomBookingRequestModel.RoomChargeAmount = bookingDuration * RateAmount; // Per day rate
                    }
                    else
                    {
                        hotelRoomBookingRequestModel.RoomChargeAmount = 0; // Invalid duration for daily booking
                    }

                    hotelRoomBookingRequestModel.TotalAmount = hotelRoomBookingRequestModel.RoomChargeAmount;
                    hotelRoomBookingRequestModel.FinalAmount = hotelRoomBookingRequestModel.TotalAmount;

                    if (serviceResponseHotelTaxRateDataList.Any())
                    {
                        //HandleTaxRateChange(serviceResponseHotelTaxRateDataList);
                        OnSelectCalculateTaxRate(serviceResponseHotelTaxRateDataList);
                    }
                }
                else if (hotelRoomBookingRequestModel.IsHourlyBooking == true)
                {

                    hotelRoomBookingRequestModel.TotalAmount = RateAmount;
                    CalculateReverseAmount(serviceResponseHotelTaxRateDataList);
                }
            }
            else
            {
                hotelRoomBookingRequestModel.RoomChargeAmount = 0;
                hotelRoomBookingRequestModel.TotalAmount = 0;
                hotelRoomBookingRequestModel.FinalAmount = 0;
            }

            StateHasChanged();
        }

        private void HandleTaxRateChange(object selectedTaxRateItem)
        {
            selectedHotelTaxRate = (IEnumerable<HotelTaxRateWebAppModel>)selectedTaxRateItem;
            if (hotelRoomBookingRequestModel.IsHourlyBooking)
            {
                OnSelectCalculateHourlyTaxRate(selectedHotelTaxRate);
            }
            else
            {
                OnSelectCalculateTaxRate(selectedHotelTaxRate);
            }
        }

        private void OnSelectCalculateTaxRate(object selectedTaxRateItem)
        {
            decimal totalTaxRates = 0m;
            decimal subTotalAmount = hotelRoomBookingRequestModel.RoomChargeAmount ?? 0m;

            selectedHotelTaxRate = (IEnumerable<HotelTaxRateWebAppModel>)selectedTaxRateItem;

            // Clear the existing tax rates to avoid duplicates
            hotelRoomBookingRequestModel.HotelRoomBookingTaxRates.Clear();

            if (selectedHotelTaxRate.Any())
            {
                foreach (var item in selectedHotelTaxRate)
                {
                    // Add the tax rate to the list
                    totalTaxRates += Convert.ToDecimal(item.TaxRate);
                    var newTaxRate = new HotelRoomBookingTaxRateWebAppModel
                    {
                        HotelTaxRateID = item.HotelTaxRateID,
                        BookingTaxRateName = item.TaxName,
                        BookingTaxRatePercentage = item.TaxRate,
                        BookingTaxRate = (subTotalAmount * (item.TaxRate / 100)),
                    };

                    hotelRoomBookingRequestModel.HotelRoomBookingTaxRates.Add(newTaxRate);
                }

                // Calculate the total tax amount using the selected tax rate(s)
                decimal validTaxRate = totalTaxRates / 100; // Convert total tax rate to decimal

                decimal taxAmount = subTotalAmount * validTaxRate;

                // Calculate final amount (subtotal + tax)
                hotelRoomBookingRequestModel.TotalAmount = (decimal?)Math.Round(subTotalAmount + taxAmount, 2);
                hotelRoomBookingRequestModel.FinalAmount = hotelRoomBookingRequestModel.TotalAmount;
            }
            else
            {
                if (hotelRoomBookingRequestModel.IsHourlyBooking)
                {
                    hotelRoomBookingRequestModel.RoomChargeAmount = hotelRoomBookingRequestModel.HourlyRate;
                    hotelRoomBookingRequestModel.TotalAmount = hotelRoomBookingRequestModel.RoomChargeAmount;
                    hotelRoomBookingRequestModel.FinalAmount = hotelRoomBookingRequestModel.TotalAmount;
                }
                else
                {
                    hotelRoomBookingRequestModel.TotalAmount = hotelRoomBookingRequestModel.RoomChargeAmount;
                    hotelRoomBookingRequestModel.FinalAmount = hotelRoomBookingRequestModel.TotalAmount;
                }
            }
            if (selectedHotelAdditionalRate.HotelAdditionalRateID > 0)
            {
                OnAdditionalRateChanges();
            }
            StateHasChanged();
        }

        private void OnSelectCalculateHourlyTaxRate(IEnumerable<HotelTaxRateWebAppModel> selectedTaxRateItem)
        {
            hotelRoomBookingRequestModel.FinalAmount = hotelRoomBookingRequestModel.HourlyRate;
            CalculateReverseAmount(selectedHotelTaxRate);
            StateHasChanged();
        }

        private async Task GuestScanDetailDialog()
        {
            var dialogName = "List of Scanned IDs";
            var dialogOptions = new SideDialogOptions { CloseDialogOnOverlayClick = true, Width = "1000px", Position = DialogPosition.Right, ShowMask = true };

            await _dialogService.OpenSideAsync<ScanGuestDetailForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelID", hotelID },
                { "OnSubmit", EventCallback.Factory.Create<AddEditGuestWebAppModel>(this, HandleFormOnSubmitGuestScan) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancelGuestScan) }
            }, options: dialogOptions);
        }
        private async Task HandleFormOnSubmitGuestScan(AddEditGuestWebAppModel guestRequestModel)
        {
            _dialogService.CloseSide();
            await CreateEditGuestDialog(guestRequestModel);

        }
        private void HandleOnCancelGuestScan()
        {
            _dialogService.CloseSide();
        }

        public async void ScanGuestIdentity_XML(UploadChangeEventArgs args)
        {
            foreach (var file in args.Files)
            {
                try
                {
                    long maxFileSize = 10 * 1024 * 1024; // 10MB max file size

                    // Open the file stream (with size validation)
                    var stream = file.OpenReadStream(maxFileSize);

                    // Create a memory stream to read the XML file content
                    using (var memoryStream = new MemoryStream())
                    {
                        await stream.CopyToAsync(memoryStream);
                        memoryStream.Seek(0, SeekOrigin.Begin);

                        // Deserialize the XML content into your model using XmlSerializer
                        var xmlSerializer = new XmlSerializer(typeof(ScanIDXMLDocumentWebAppModel));
                        var documentData = (ScanIDXMLDocumentWebAppModel)xmlSerializer.Deserialize(memoryStream);

                        // Now you can access the deserialized data
                        var newData = documentData.NewData;

                        // You can now use `newData` to populate your model or perform other logic
                        var guestRequestModel = new AddEditGuestWebAppModel
                        {
                            FirstName = newData.OCREmulateFirstName,
                            LastName = newData.OCREmulateLastName,
                            IdentityType = newData.FrontDocumentType,
                            IdentityNumber = newData.OCRDocumentNumber,
                            FrontSideImage = newData.FrontImage,
                            Address1 = newData.OCRAddress,
                            //StateID = newData.OCRState,
                            City = newData.OCRCity,
                            //ZipCode = newData.OCRZip
                        };

                        // Perform additional logic as needed
                        CheckDuplicateGuest(guestRequestModel);
                    }
                }
                catch (Exception ex)
                {
                    // Handle any errors during the process
                    Console.WriteLine($"Error processing XML file: {ex.Message}");
                }
            }
        }

        async void ScanGuestIdentity_JSON(UploadChangeEventArgs args)
        {

            foreach (var file in args.Files)
            {

                long maxFileSize = 10 * 1024 * 1024; // 10MB max file size

                // Open the file stream (with size validation)
                var stream = file.OpenReadStream(maxFileSize);

                var buffer = new byte[file.Size];
                await file.OpenReadStream().ReadAsync(buffer);

                // Convert byte buffer to string (UTF-8)
                var jsonContent = System.Text.Encoding.UTF8.GetString(buffer);
                // Close the stream after reading
                stream.Close();

                // Try to deserialize the JSON content
                try
                {
                    var options = new System.Text.Json.JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    };
                    var userData = JsonConvert.DeserializeObject<ScanIDXMLDocumentWebAppModel>(jsonContent);
                    var newData = userData.NewData;

                    // Create the guest request model from the deserialized data
                    var guestRequestModel = new AddEditGuestWebAppModel
                    {
                        FirstName = newData.OCREmulateFirstName,
                        LastName = newData.OCREmulateLastName,
                        IdentityType = newData.FrontDocumentType,
                        IdentityNumber = newData.OCRDocumentNumber,
                        FrontSideImage = newData.FrontImage,
                        Address1 = newData.OCRAddress,
                        //StateID = newData.OCRState,
                        City = newData.OCRCity,
                        //ZipCode = newData.OCRZip
                    };

                    CheckDuplicateGuest(guestRequestModel);
                }

                catch (JsonException jsonEx)
                {
                    // Handle any JSON deserialization issues
                    Console.WriteLine($"Error deserializing JSON: {jsonEx.Message}");
                }
            }
        }

        private async Task CreateEditGuestDialog(AddEditGuestWebAppModel? hotelGuest)
        {
            var guestRequestModel = new AddEditGuestWebAppModel();
            if (hotelGuest != null)
            {

                guestRequestModel.GuestID = hotelGuest.GuestID;
                guestRequestModel.FirstName = hotelGuest.FirstName;
                guestRequestModel.LastName = hotelGuest.LastName;
                guestRequestModel.IdentityType = hotelGuest.IdentityType;
                guestRequestModel.IdentityNumber = hotelGuest.IdentityNumber;
                guestRequestModel.FrontSideImage = hotelGuest.FrontSideImage;
                guestRequestModel.Email = hotelGuest.Email;
                guestRequestModel.MobileNumber = hotelGuest.MobileNumber;
                guestRequestModel.Address1 = hotelGuest.Address1;
                guestRequestModel.Address2 = hotelGuest.Address2;
                guestRequestModel.Country = hotelGuest.Country;
                guestRequestModel.State = hotelGuest.State;
                guestRequestModel.City = hotelGuest.City;
                guestRequestModel.ZipCode = hotelGuest.ZipCode;
                guestRequestModel.IsGuestScanned = hotelGuest.IsGuestScanned;
                guestRequestModel.ScanID = hotelGuest.ScanID;
                guestRequestModel.IsPrimaryGuest = hotelGuest.IsPrimaryGuest;
            }

            var dialogName = hotelGuest == null ? "Add New Guest" : "Edit Guest";
            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true, Width = "1000px", };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<GuestForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelID", hotelID },
                { "guestRequestModel", guestRequestModel },
                { "IsDisabled", false },
                { "OnSubmit", EventCallback.Factory.Create<AddEditGuestWebAppModel>(this, HandleFormOnSubmitGuestDetail) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }

        private async Task HandleFormOnSubmitGuestDetail(AddEditGuestWebAppModel guestRequestModel)
        {
            CheckDuplicateGuest(guestRequestModel);
            _dialogService.Close();

            //await CreateEditHotelAdditionalRate(hotelAdditionalRateRequestModel);
        }

        private void CheckDuplicateGuest(AddEditGuestWebAppModel guestRequestModel)
        {
            var duplicateGuest = hotelRoomBookingRequestModel.Guests.FirstOrDefault(existingGuest => existingGuest.IdentityNumber == guestRequestModel.IdentityNumber);
            if (duplicateGuest != null)
            {
                duplicateGuest.FirstName = guestRequestModel.FirstName;
                duplicateGuest.LastName = guestRequestModel.LastName;
                duplicateGuest.IdentityType = guestRequestModel.IdentityType;
                duplicateGuest.IdentityNumber = guestRequestModel.IdentityNumber;
                duplicateGuest.MobileNumber = guestRequestModel.MobileNumber;
                duplicateGuest.Email = guestRequestModel.Email;
                duplicateGuest.Address1 = guestRequestModel.Address1;
                duplicateGuest.Address2 = guestRequestModel.Address2;
                duplicateGuest.Country = guestRequestModel.Country;
                duplicateGuest.State = guestRequestModel.State;
                duplicateGuest.City = guestRequestModel.City;
                duplicateGuest.ZipCode = guestRequestModel.ZipCode;
                guestRequestModel.IsPrimaryGuest = guestRequestModel.IsPrimaryGuest;

                hotelRoomBookingRequestModel.Guests = hotelRoomBookingRequestModel.Guests.ToList();

                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", "Guest details updated successfully.");
            }
            else
            {
                if (hotelRoomBookingRequestModel.Guests.Count == 0)
                {
                    guestID = guestRequestModel.GuestID;
                    guestName = guestRequestModel.FirstName + " " + guestRequestModel.LastName;
                    guestRequestModel.IsPrimaryGuest = true;
                }
                hotelRoomBookingRequestModel.Guests.Add(guestRequestModel);
                hotelRoomBookingRequestModel.Guests = hotelRoomBookingRequestModel.Guests.ToList();

            }
            StateHasChanged();

        }
        private async Task OnViewLastBookingClicked(string? guestCode)
        {
            isLoading = true;
            findHotelRoomBookingRequestModel.HotelId = hotelID;
            findHotelRoomBookingRequestModel.GuestCode = guestCode;
            findHotelRoomBookingRequestModel.BookingStatus = BookingStatusMessages.CheckedOut;
            var serviceResponse = await _hotelRoomBookingWebAppService.SearchHotelRoomBooking(findHotelRoomBookingRequestModel);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseDataList = serviceResponse.Content.OrderByDescending(item => item.ScheduledCheckInDate).ToList();
            }
            else
            {
                serviceResponseDataList = new List<GetHotelRoomBookingSearchListWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }
        private void SetPrimaryGuest(string identityNumber)
        {
            // Find the guest by IdentityNumber
            var guestToSetPrimary = hotelRoomBookingRequestModel.Guests
                .FirstOrDefault(guest => guest.IdentityNumber == identityNumber);

            if (guestToSetPrimary != null)
            {
                // Set the selected guest as primary
                guestToSetPrimary.IsPrimaryGuest = true;
                guestID = guestToSetPrimary.GuestID;
                guestName = guestToSetPrimary.FirstName + " " + guestToSetPrimary.LastName;
                serviceResponseDataList = new List<GetHotelRoomBookingSearchListWebAppModel>();

                // Set all other guests as not primary
                foreach (var guest in hotelRoomBookingRequestModel.Guests.Where(g => g.IdentityNumber != identityNumber))
                {
                    guest.IsPrimaryGuest = false;
                }

                // Optionally, you can trigger a re-render here if you're using a UI framework that needs to be explicitly updated.
                StateHasChanged(); // This is used in Blazor to re-render the UI
            }
        }

        private void RemoveGuest(string identityNumber)
        {
            var removeGuest = hotelRoomBookingRequestModel.Guests.FirstOrDefault(existingGuest => existingGuest.IdentityNumber == identityNumber);
            if (removeGuest != null)
            {
                if (removeGuest.IsPrimaryGuest == true)
                {
                    serviceResponseDataList = new List<GetHotelRoomBookingSearchListWebAppModel>();
                }

                hotelRoomBookingRequestModel.Guests.Remove(removeGuest);
                hotelRoomBookingRequestModel.Guests = hotelRoomBookingRequestModel.Guests.ToList();

                if (hotelRoomBookingRequestModel.Guests.Count == 1)
                {
                    hotelRoomBookingRequestModel.Guests.FirstOrDefault().IsPrimaryGuest = true;
                    var guestData = hotelRoomBookingRequestModel.Guests.FirstOrDefault(item => item.IsPrimaryGuest);

                }
            }
            StateHasChanged();
        }

        private string CheckPaymentStatus()
        {
            // Calculate the remaining amount by subtracting total payments from final amount
            decimal? TotalPaid = hotelRoomBookingRequestModel.HotelRoomPayments.Where(item => item.PaymentStatus == CommonConstants.PaymentStatusMessages.Completed).Sum(o => o.Amount);

            // Default payment status
            string paymentStatus = "Payment Pending";

            // Full Payment Completed
            if (TotalPaid == hotelRoomBookingRequestModel.FinalAmount)
            {
                paymentStatus = "Payment Completed";
            }

            // Partial Payment
            else if (TotalPaid > 0 && TotalPaid < hotelRoomBookingRequestModel.FinalAmount)
            {
                paymentStatus = "Partial Payment";
            }

            return paymentStatus;
        }

        private async Task CreateEditPaymentDetailDialog(AddEditHotelRoomPaymentWebAppModel? hotelRoomPayment, bool IsRefund)
        {
            var hotelRoomPaymentRequestModel = new AddEditHotelRoomPaymentWebAppModel();
            if (hotelRoomPayment != null)
            {
                hotelRoomPaymentRequestModel.PaymentLocalID = hotelRoomPayment.PaymentLocalID;
                hotelRoomPaymentRequestModel.PaymentID = hotelRoomPayment.PaymentID;
                hotelRoomPaymentRequestModel.PaymentMode = hotelRoomPayment.PaymentMode;
                hotelRoomPaymentRequestModel.PaymentType = hotelRoomPayment.PaymentType;
                hotelRoomPaymentRequestModel.PaymentGateway = hotelRoomPayment.PaymentGateway;
                hotelRoomPaymentRequestModel.PaymentCompletedOn = hotelRoomPayment.PaymentCompletedOn;
                hotelRoomPaymentRequestModel.TransactionID = hotelRoomPayment.TransactionID;
                //hotelRoomPaymentRequestModel.TransactionType = hotelRoomPayment.TransactionType;
                hotelRoomPaymentRequestModel.Amount = hotelRoomPayment.Amount;
                hotelRoomPaymentRequestModel.UsedRewardPoint = hotelRoomPayment.UsedRewardPoint;
                hotelRoomPaymentRequestModel.PaymentStatus = hotelRoomPayment.PaymentStatus;
                hotelRoomPaymentRequestModel.IsRefunded = hotelRoomPayment.IsRefunded;
                hotelRoomPaymentRequestModel.RefundAmount = hotelRoomPayment.RefundAmount;
                hotelRoomPaymentRequestModel.RefundNotes = hotelRoomPayment.RefundNotes;
                if (hotelRoomPayment.IsRefunded)
                {
                    IsRefund = hotelRoomPayment.IsRefunded;
                }
            }

            var dialogName = IsRefund ? "Refund" : (hotelRoomPayment == null ? "Add Payment" : "Edit Payment");
            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true, Width = "700px", };
            decimal appliedRewardPoint = 0;
            if (hotelRoomBookingRequestModel.HotelRoomPayments.Count > 0)
            {
                appliedRewardPoint = hotelRoomBookingRequestModel.HotelRoomPayments.Where(payment => payment.PaymentMode == PaymentModeOption.RewardPoint).Sum(item => item.UsedRewardPoint ?? 0);
            }
            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<PaymentDetailForm>(dialogName, new Dictionary<string, object>
            {
                { "finalAmount", hotelRoomBookingRequestModel.FinalAmount  },
                { "paidAmount",  hotelRoomBookingRequestModel.HotelRoomPayments.Where(payment => payment.PaymentStatus == PaymentStatusMessages.Completed).Sum(o => o.Amount) },
                { "appliedRewardPoint",appliedRewardPoint},
                { "guestName", guestName},
                { "hotelID", hotelID},
                { "guestID", guestID},
                { "hotelRoomPaymentRequestModel", hotelRoomPaymentRequestModel },
                { "IsRefund", IsRefund },
                { "OnSubmit", EventCallback.Factory.Create<AddEditHotelRoomPaymentWebAppModel>(this, HandleFormOnSubmitPaymentDetail) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }

        private async Task HandleFormOnSubmitPaymentDetail(AddEditHotelRoomPaymentWebAppModel hotelRoomPayment)
        {
            OnSavePaymentClicked(hotelRoomPayment);
            _dialogService.Close();

            //await CreateEditHotelAdditionalRate(hotelAdditionalRateRequestModel);
        }

        private void OnSavePaymentClicked(AddEditHotelRoomPaymentWebAppModel hotelRoomPayment)
        {
            IsBusyBooked = true;
            isLoading = true;

            var existingPayment = hotelRoomBookingRequestModel.HotelRoomPayments.FirstOrDefault(item => item.PaymentLocalID == hotelRoomPayment.PaymentLocalID);
            if (existingPayment != null)
            {
                existingPayment.PaymentLocalID = hotelRoomPayment.PaymentLocalID;
                existingPayment.Amount = hotelRoomPayment.Amount;
                existingPayment.UsedRewardPoint = hotelRoomPayment.UsedRewardPoint;
                existingPayment.PaymentMode = hotelRoomPayment.PaymentMode;
                existingPayment.PaymentType = hotelRoomPayment.PaymentType;
                existingPayment.PaymentStatus = hotelRoomPayment.PaymentStatus;
                existingPayment.TransactionID = hotelRoomPayment.TransactionID;
                //existingPayment.TransactionType = hotelRoomPayment.TransactionType;
                existingPayment.PaymentGateway = hotelRoomPayment.PaymentGateway;
                existingPayment.PaymentNotes = hotelRoomPayment.PaymentNotes;
                existingPayment.PaymentCompletedOn = hotelRoomPayment.PaymentCompletedOn;
            }
            else
            {
                var newRoomPayment = new AddEditHotelRoomPaymentWebAppModel
                {
                    PaymentLocalID = hotelRoomPayment.PaymentLocalID,
                    Amount = hotelRoomPayment.Amount,
                    UsedRewardPoint = hotelRoomPayment.UsedRewardPoint,
                    PaymentMode = hotelRoomPayment.PaymentMode,
                    PaymentType = hotelRoomPayment.PaymentType,
                    PaymentStatus = hotelRoomPayment.PaymentStatus,
                    TransactionID = hotelRoomPayment.TransactionID,
                    //TransactionType = hotelRoomPayment.TransactionType,
                    PaymentGateway = hotelRoomPayment.PaymentGateway,
                    PaymentNotes = hotelRoomPayment.PaymentNotes,
                    PaymentCompletedOn = hotelRoomPayment.PaymentCompletedOn

                };
                hotelRoomBookingRequestModel.HotelRoomPayments.Add(newRoomPayment);
            }

            hotelRoomBookingRequestModel.HotelRoomPayments = hotelRoomBookingRequestModel.HotelRoomPayments.ToList();
            StateHasChanged();
            if (GetBalance() > 0 && guestRewardServiceResponseData.GuestRewardID > 0 && hotelRoomBookingRequestModel.HotelRoomPayments.Count(item => item.PaymentMode == CommonConstants.PaymentModeOption.RewardPoint) == 0)
            {
                isRewardPointVisible = true;
            }
            else
            {
                isRewardPointVisible = false;
            }
                // _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "Room Payment Added", "The room payment has been successfully added.");
                //hotelRoomBookingRequestModel.PaymentStatus =
                CheckPaymentStatus();
            isLoading = false;
            IsBusyBooked = false;
            StateHasChanged();
        }

        private async Task GuestOldBookingNotesDialog(List<HotelRoomBookingWebAppModel> hotelRoomBooking)
        {
            // If editing, use the passed object; if creating, initialize a new one.
            var hotelRoomBookingModel = hotelRoomBooking ?? new List<HotelRoomBookingWebAppModel>();

            // Determine dialog title based on whether we're creating or editing
            var dialogName = "Guest Old Booking Notes";

            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<GuestNoteTimelineForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelRoomBookingModel", hotelRoomBookingModel },
                { "IsBusy", IsBusyBooked },
                { "OnSubmit", EventCallback.Factory.Create<List<HotelRoomBookingWebAppModel> >(this, HandleFormOnSubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }

        private async Task HandleFormOnSubmit(List<HotelRoomBookingWebAppModel> hotelRoomBookingModel)
        {
            _dialogService.Close();
            //await CreateEditHotelAdditionalRate(hotelAdditionalRateRequestModel);
        }

        private async Task GuestListByNameDialog(List<GetGuestWebAppModel> guestList)
        {
            // Determine dialog title based on whether we're creating or editing
            var dialogName = "Guest List";

            var dialogOptions = new SideDialogOptions { CloseDialogOnOverlayClick = true, Width = "1000px", Position = DialogPosition.Right, ShowMask = true };

            await _dialogService.OpenSideAsync<GuestSearchListForm>(dialogName, new Dictionary<string, object>
            {
                { "guestData", guestList },
                { "OnSubmit", EventCallback.Factory.Create<AddEditGuestWebAppModel>(this, HandleFormSelectedGuestOnSubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, options: dialogOptions);
        }

        private async Task HandleFormSelectedGuestOnSubmit(AddEditGuestWebAppModel guestModel)
        {

            CheckDuplicateGuest(guestModel);
            if (guestModel.HotelRoomBookings.Count > 0)
            {
                var guestNotes = guestModel.HotelRoomBookings.ToList();
                await GuestOldBookingNotesDialog(guestNotes);
            }
            _dialogService.CloseSide();
        }

        private void HandleOnCancel()
        {
            _dialogService.Close();
        }

        private void OnAdditionalRateChanges()
        {
            hotelRoomBookingRequestModel.IsDiscountedRate = selectedHotelAdditionalRate.IsDiscountedRate;
            hotelRoomBookingRequestModel.AdditionalRateType = selectedHotelAdditionalRate.AdditionalRateName;
            hotelRoomBookingRequestModel.AdditionalRateAmount = selectedHotelAdditionalRate.AdditionalRate;

            // Check if the room rate is discounted or involves additional charges
            bool isDiscountedRate = selectedHotelAdditionalRate.IsDiscountedRate; // Discount flag
            decimal? rateAmount = selectedHotelAdditionalRate.AdditionalRate / 100; // Convert rate to decimal percentage (e.g., 5 becomes 0.05)
            decimal? totalAmount = hotelRoomBookingRequestModel.TotalAmount;

            if (isDiscountedRate)
            {
                // Apply discount (rateAmount is now in decimal form, e.g., 0.05 for 5% discount)
                decimal? discountAmount = totalAmount * rateAmount; // Calculate discount as percentage of total amount
                hotelRoomBookingRequestModel.FinalAmount = totalAmount - discountAmount; // Subtract the discount
                rateExceptionAmount = discountAmount;
                //hotelRoomBookingRequestModel.DiscountedAmount = selectedRoomRateTax;
            }
            else
            {
                // Apply extra charges (rateAmount is now in decimal form, e.g., 0.05 for extra 5% charge)
                decimal? extraCharges = totalAmount * rateAmount; // Calculate extra charge as percentage of total amount
                hotelRoomBookingRequestModel.FinalAmount = totalAmount + extraCharges; // Add the extra charge
                rateExceptionAmount = extraCharges;
                //hotelRoomBookingRequestModel.AdditionalRateAmount = selectedRoomRateTax;
            }

            // Ensure the total is not negative
            if (hotelRoomBookingRequestModel.FinalAmount < 0)
            {
                hotelRoomBookingRequestModel.FinalAmount = 0;
            }
            StateHasChanged();
        }

        private void OnFinalAmountClicked()
        {
            isEditingFinalAmount = true; // Show numeric input to edit the final amount
        }

        private void OnSaveFinalAmountClick()
        {
            isEditingFinalAmount = false;
            CalculateReverseAmount(selectedHotelTaxRate);
        }

        private void CalculateReverseAmount(IEnumerable<HotelTaxRateWebAppModel> hotelTaxRateWebAppModel)
        {

            // Ensure FinalAmount is valid
            if (!hotelRoomBookingRequestModel.TotalAmount.HasValue || hotelRoomBookingRequestModel.TotalAmount == 0)
                return;

            decimal totalAmount = hotelRoomBookingRequestModel.TotalAmount ?? 0m;

            // Get tax rates dynamically
            var taxPercentages = hotelTaxRateWebAppModel.Where(tax => tax.TaxRate.HasValue).Select(tax => tax.TaxRate.Value).ToList();

            // Calculate the total percentage dynamically
            decimal totalTaxRate = taxPercentages.Sum();

            // Calculate the combined percentage factor (1 + total tax rate / 100)
            decimal percentageFactor = 1 + (totalTaxRate / 100);

            // Reverse calculation to find the room charge
            decimal roomCharge = totalAmount / percentageFactor; // Final amount / 1.17 to get room charge

            // Assign values back to the model
            hotelRoomBookingRequestModel.RoomChargeAmount = roomCharge;

            OnSelectCalculateTaxRate(hotelTaxRateWebAppModel);

            StateHasChanged();
        }

        //private void CalculateReverseAmount(IEnumerable<HotelTaxRateWebAppModel> hotelTaxRateWebAppModel)
        //{

        //    // Ensure FinalAmount is valid
        //    if (!hotelRoomBookingRequestModel.FinalAmount.HasValue || hotelRoomBookingRequestModel.FinalAmount == 0)
        //        return;

        //    decimal finalAmount = 0;

        //    if (hotelRoomBookingRequestModel.AdditionalRateAmount.HasValue)
        //    {
        //        finalAmount = hotelRoomBookingRequestModel.FinalAmount.Value - hotelRoomBookingRequestModel.AdditionalRateAmount.Value;
        //    }
        //    else
        //    {
        //        finalAmount = hotelRoomBookingRequestModel.FinalAmount.Value;
        //    }

        //    // Get tax rates dynamically
        //    var taxPercentages = hotelTaxRateWebAppModel
        //           .Where(tax => tax.TaxRate.HasValue)
        //           .Select(tax => tax.TaxRate.Value)
        //           .ToList();

        //    // Calculate the total percentage dynamically
        //    decimal totalTaxRate = taxPercentages.Sum(); // Sum of all tax rates (e.g., 6%, 7%, 4%)

        //    // Calculate the combined percentage factor (1 + total tax rate / 100)
        //    decimal percentageFactor = 1 + (totalTaxRate / 100); // Total = 1 + (6 + 7 + 4) / 100 = 1.17


        //    // Reverse calculation to find the room charge
        //    decimal roomCharge = finalAmount / percentageFactor; // Final amount / 1.17 to get room charge

        //    // Assign values back to the model
        //    hotelRoomBookingRequestModel.SubTotalAmount = roomCharge;
        //    // hotelRoomBookingRequestModel.TotalAmount = finalAmount;

        //    OnSelectCalculateTaxRate(hotelTaxRateWebAppModel);
        //    //if (hotelRoomBookingRequestModel.IsHourlyBooking == true)
        //    //{
        //    //    OnSelectCalculateTaxRate(hotelTaxRateWebAppModel);
        //    //}
        //    //else
        //    //{
        //    //    var taxRatesList = hotelRoomBookingRequestModel.HotelRoomBookingTaxRates
        //    //        .Select(tax => new HotelTaxRateWebAppModel
        //    //        {
        //    //            HotelTaxRateID = tax.HotelTaxRateID ?? 0,
        //    //            TaxName = tax.BookingTaxRateName,
        //    //            TaxRate = tax.BookingTaxRatePercentage
        //    //        }).ToList();
        //    //    OnSelectCalculateTaxRate(taxRatesList);
        //    //}
        //    StateHasChanged();
        //}

        private async Task OnSaveClicked()
        {
            if (IsBusyBooked || !hotelRoomBookingRequestModel.FinalAmount.HasValue)
            {
                return;
            }
            IsBusyBooked = true;
            StateHasChanged();
            OnSaveBookingRateDetail(hotelRoomBookingRequestModel);
            var serviceResponse = await OnBookedClick(hotelRoomBookingRequestModel);
            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Room Booked successfully!");
                _navigationManager.NavigateTo($"/booking-summary/{hotelID}/0");
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while room booking.");
            }

            // await CreateHotelRoomBooking();
            IsBusyBooked = false;
            StateHasChanged();
        }

        private async Task OnCheckInClicked()
        {
            if (!hotelRoomBookingRequestModel.FinalAmount.HasValue)
            {
                return;
            }
            IsBusyCheckIn = true;

            OnSaveBookingRateDetail(hotelRoomBookingRequestModel);
            if (IsQuickBooking || IsBookingExtend)
            {
                var serviceResponse = await OnBookedClick(hotelRoomBookingRequestModel);
                if (serviceResponse.IsSuccessStatusCode)
                {
                    int hotelRoomBookingID = serviceResponse.Content;
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Room check in successfully!");
                    await PrintBookingReceipt(hotelRoomBookingID);
                    _navigationManager.NavigateTo($"/booking-detail/{hotelID}/{hotelRoomBookingID}");
                }
                else
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while check in.");
                }
            }
            else
            {
                int hotelRoomID = await OnCheckedInRoomSelectDialog(hotelID, hotelRoomBookingRequestModel);
                if (hotelRoomID is 0)
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Info, "", "Room check in request has been cancelled.");
                }
                else
                {
                    hotelRoomBookingRequestModel.HotelRoomID = hotelRoomID;
                    var serviceResponse = await OnBookedClick(hotelRoomBookingRequestModel);
                    if (serviceResponse.IsSuccessStatusCode)
                    {
                        int hotelRoomBookingID = serviceResponse.Content;
                        _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Room check in successfully!");
                        await PrintBookingReceipt(hotelRoomBookingID);
                        _navigationManager.NavigateTo($"/booking-detail/{hotelID}/{hotelRoomBookingID}");
                    }
                    else
                    {
                        _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while check in.");
                    }
                }
            }
            IsBusyCheckIn = false;
            StateHasChanged();
        }

        private void OnSaveBookingRateDetail(HotelRoomBookingWebAppModel hotelRoomBookingRequestModel)
        {
            IsBusyBooked = true;
            isLoading = true;
            hotelRoomBookingRequestModel.HotelRoomBookingRateDetails = new List<HotelRoomBookingRateDetailWebAppModel>();
            var newBookingRateDetail = new HotelRoomBookingRateDetailWebAppModel
            {
                CheckInDate = hotelRoomBookingRequestModel.ScheduledCheckInDate,
                CheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckOutDate,
                Duration = hotelRoomBookingRequestModel.Duration,
                BestAvailableRate = hotelRoomBookingRequestModel.BestAvailableRate,
                AdjustmentRate = hotelRoomBookingRequestModel.AdjustmentRate,
                HourlyRate = hotelRoomBookingRequestModel.HourlyRate,
                RoomChargeAmount = hotelRoomBookingRequestModel.RoomChargeAmount,
                TotalAmount = hotelRoomBookingRequestModel.TotalAmount,
                IsDiscountedRate = hotelRoomBookingRequestModel.IsDiscountedRate,
                AdditionalRateType = hotelRoomBookingRequestModel.AdditionalRateType,
                AdditionalRateAmount = hotelRoomBookingRequestModel.AdditionalRateAmount,
                DiscountedAmount = hotelRoomBookingRequestModel.DiscountedAmount,
                FinalAmount = hotelRoomBookingRequestModel.FinalAmount,
                Balance = hotelRoomBookingRequestModel.FinalAmount - hotelRoomBookingRequestModel.HotelRoomPayments.Where(payment => payment.PaymentStatus == PaymentStatusMessages.Completed).Sum(item => item.Amount),
            };

            if (hotelRoomBookingRequestModel.HotelRoomBookingTaxRates.Count == 0)
            {
                newBookingRateDetail.TaxStatus = TaxStatus.NonTaxable;
            }
            else if (hotelRoomBookingRequestModel.HotelRoomBookingTaxRates.Count == serviceResponseHotelTaxRateDataList.Count)
            {
                newBookingRateDetail.TaxStatus = TaxStatus.Taxable;
            }
            else
            {
                newBookingRateDetail.TaxStatus = TaxStatus.PartialTaxable;
            }

            hotelRoomBookingRequestModel.HotelRoomBookingRateDetails.Add(newBookingRateDetail);
            hotelRoomBookingRequestModel.HotelRoomBookingRateDetails = hotelRoomBookingRequestModel.HotelRoomBookingRateDetails.ToList();
            isLoading = false;
            IsBusyBooked = false;
            StateHasChanged();
        }

        private async void OnRoomChangeClicked(HotelRoomBookingWebAppModel hotelRoomBooking)
        {

            var selectedRoom = await OnRoomChangeSelectDialog(hotelID, hotelRoomBooking, true);
            if (selectedRoom == null)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Info, "", "Room change request has been cancelled.");
            }
            else
            {
                if (selectedRoom.HotelRoomTypeID != 0 && selectedRoom.HotelRoomID != 0)
                {
                    hotelRoomTypeID = selectedRoom.HotelRoomTypeID;
                    hotelRoomID = selectedRoom.HotelRoomID ?? 0;
                    roomNumber = selectedRoom.RoomNumber;
                    await Quick_ExtendBooking();
                }
                else
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while room change.");
                }
            }
            StateHasChanged();
        }

        private void RemoveRateException()
        {
            // Reset the Additional Rate fields
            hotelRoomBookingRequestModel.IsDiscountedRate = false;
            hotelRoomBookingRequestModel.AdditionalRateType = string.Empty;
            hotelRoomBookingRequestModel.AdditionalRateAmount = 0;

            // Reset the Final Amount to its original value (before any rate exception was applied)
            hotelRoomBookingRequestModel.FinalAmount = hotelRoomBookingRequestModel.TotalAmount;

            // Clear the selected additional rate value
            selectedHotelAdditionalRate = new();
            rateExceptionAmount = 0;

            // Call StateHasChanged to re-render the component
            StateHasChanged();
        }

        private async void PrintBookingReceipt(byte[] byteArray)
        {
            // Convert byte array to string (HTML content)
            string base64Data = Convert.ToBase64String(byteArray);
            // Trigger print via JavaScript
            await _jsruntime.InvokeVoidAsync("printPDF", base64Data);
        }

        private async Task OnUsePointClick()
        {

            if (UsedRewardPoint > hotelRoomBookingRequestModel.FinalAmount.Value || UsedRewardPoint > GetBalance())
            {
                rewardPointErrorMessage = "Please enter reward points less than or equal to the room charge.";
            }
            else if (UsedRewardPoint <= 0 || UsedRewardPoint == null)
            {
                rewardPointErrorMessage = "Reward Point can not be 0 or null.";
            }
            else if (UsedRewardPoint > guestRewardServiceResponseData.TotalRewardPoint)
            {
                rewardPointErrorMessage = "Reward Point cannot be greater than Total Points";
            }
            else
            {
                rewardPointErrorMessage = string.Empty;
                var rewardPointPayment = new AddEditHotelRoomPaymentWebAppModel
                {

                    Amount = UsedRewardPoint,
                    UsedRewardPoint = UsedRewardPoint,
                    PaymentMode = CommonConstants.PaymentModeOption.RewardPoint,
                    PaymentType = "Booking Payment",
                    PaymentStatus = CommonConstants.PaymentStatusMessages.Completed,
                    PaymentNotes = "Use reward point for this booking",
                    PaymentCompletedOn = CommonConstants.GetSystemMinDate()
                };

                OnSavePaymentClicked(rewardPointPayment);

            }
        }

        private async Task RemoveRewardPoint(AddEditHotelRoomPaymentWebAppModel hotelRoomPayment)
        {
            hotelRoomBookingRequestModel.HotelRoomPayments.Remove(hotelRoomPayment);
            hotelRoomBookingRequestModel.HotelRoomPayments = hotelRoomBookingRequestModel.HotelRoomPayments.ToList();
            StateHasChanged();
            if (GetBalance() > 0 && guestRewardServiceResponseData.GuestRewardID > 0 && hotelRoomBookingRequestModel.HotelRoomPayments.Count(item => item.PaymentMode == CommonConstants.PaymentModeOption.RewardPoint) == 0)
            {
                isRewardPointVisible = true;
            }
            else
            {
                isRewardPointVisible = false;
            }
            StateHasChanged();
        }

        private decimal GetBalance()
        {
            return hotelRoomBookingRequestModel.FinalAmount - hotelRoomBookingRequestModel.HotelRoomPayments.Where(payment => payment.PaymentStatus == PaymentStatusMessages.Completed).Sum(o => o.Amount) ?? 0;
        }

        #endregion

        #region API service calls
        private async Task GetAvailableRoomTypes()
        {
            isLoading = true;
            var serviceResponse = await _hotelRoomBookingWebAppService.GetAvailableRoomTypes(hotelID, hotelRoomBookingRequestModel.ScheduledCheckInDate.Value, hotelRoomBookingRequestModel.ScheduledCheckOutDate.Value);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseHotelRoomTypeDataList = serviceResponse.Content;
            }
            else
            {
                serviceResponseHotelRoomTypeDataList = new List<HotelRoomTypeWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task GetHotelTaxRate()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelTaxRate(hotelID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseHotelTaxRateDataList = serviceResponse.Content.Where(item => item.IsTaxRateActive).ToList();
            }
            else
            {
                serviceResponseHotelTaxRateDataList = new List<HotelTaxRateWebAppModel>(); // Initialize as empty list if null
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task GetHotelConfiguration()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelConfiguration(hotelID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseHotelConfigurationData = serviceResponse.Content;
            }
            else
            {
                serviceResponseHotelConfigurationData = new HotelConfigurationWebAppModel(); // Initialize as empty list if null
            }

            isLoading = false;
            StateHasChanged();
        }

        private async Task GetHotelDailyRate()
        {

            isLoading = true;
            DateOnly checkInDate = DateOnly.FromDateTime(hotelRoomBookingRequestModel.ScheduledCheckInDate.Value);

            var serviceResponse = await _hotelRoomBookingWebAppService.GetHotelDailyRateByDate(hotelID, checkInDate);
            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {
                serviceResponseHotelDailyRateData = serviceResponse.Content;
            }
            else
            {
                serviceResponseHotelDailyRateData = new HotelDailyRateWebAppModel(); // Initialize as empty list if null
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task GetHotelHourlyRate()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelHourlyRate(hotelID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseHotelHourlyRateDataList = serviceResponse.Content;
            }
            else
            {
                serviceResponseHotelHourlyRateDataList = new List<HotelHourlyRateWebAppModel>(); // Initialize as empty list if null
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task GetHotelAdditionalRate()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelAdditionalRate(hotelID);
            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {
                serviceResponseHotelAdditionalRateList = serviceResponse.Content.Where(item => item.IsAdditionalRateActive).ToList();
            }
            else
            {
                serviceResponseHotelAdditionalRateList = new List<HotelAdditionalRateWebAppModel>(); // Initialize as empty list if null
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task SearchGuest(string filterBy)
        {

            switch (filterBy)
            {
                case "IdentityNumber":
                    GuestCode = string.Empty;
                    MobileNumber = string.Empty;
                    break;
                case "MobileNumber":
                    GuestCode = string.Empty;
                    IdentityNumber = string.Empty;
                    break;

                default:
                    IdentityNumber = string.Empty;
                    MobileNumber = string.Empty;
                    break;
            }
            isLoading = true;
            var serviceResponse = await _guestWebAppService.GetGuestByCodeOrIdentityNumberOrMobile(GuestCode, IdentityNumber, MobileNumber);

            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {
                var guestData = serviceResponse.Content;

                // Create a new AddEditGuestWebAppModel for the returned guest
                var guest = new AddEditGuestWebAppModel
                {
                    GuestID = guestData.GuestID,
                    GuestCode = guestData.GuestCode,
                    FirstName = guestData.FirstName,
                    LastName = guestData.LastName,
                    IdentityType = guestData.IdentityType,
                    IdentityNumber = guestData.IdentityNumber,
                    FrontSideImage = guestData.FrontSideImage,
                    Email = guestData.Email,
                    MobileNumber = guestData.MobileNumber,
                    Address1 = guestData.Address1,
                    Address2 = guestData.Address2,
                    Country = guestData.Country,
                    State = guestData.State,
                    City = guestData.City,
                    ZipCode = guestData.ZipCode,
                    // Map the HotelRoomBookings list correctly
                    HotelRoomBookings = guestData.HotelRoomBookings.Where(hrb => hrb.HotelRoomBookingID != 0 && hrb.GuestNotes != null && hrb.GuestNoteType != null).Select(hrb => new HotelRoomBookingWebAppModel
                    {
                        HotelRoomBookingID = hrb.HotelRoomBookingID,
                        ScheduledCheckInDate = hrb.ScheduledCheckInDate,
                        GuestNoteType = hrb.GuestNoteType,
                        GuestNotes = hrb.GuestNotes,
                    }).ToList()
                };

                //if (guestData.State != null)
                //{
                //    selectedCountryId = guestData.State?.Country.CountryID;
                //}

                //// Add the guest to the list of guests
                //hotelRoomBookingRequestModel.Guests.Clear();  // Clear any existing guests if needed
                //hotelRoomBookingRequestModel.Guests.Add(guest);  // Add the newly retrieved guest

                CheckDuplicateGuest(guest);

                // Check if the guest has any hotel room bookings
                if (guest.HotelRoomBookings.Count > 0)
                {
                    var guestNotes = guest.HotelRoomBookings.ToList();
                    await GuestOldBookingNotesDialog(guestNotes);
                }

                isGuestPresent = true;
            }
            else
            {
                // Show an error notification if the guest details could not be retrieved
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", "Error getting guest details.");
            }

            isLoading = false;
            StateHasChanged();
        }

        private async Task SearchGuestByName()
        {
            isLoading = true;
            var serviceResponse = await _guestWebAppService.GetGuestByName(FirstName, LastName);

            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {
                var guestData = serviceResponse.Content;
                await GuestListByNameDialog(guestData);
            }
            else
            {
                // Show an error notification if the guest details could not be retrieved
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", "Error getting guest details.");
            }

            isLoading = false;
            StateHasChanged();
        }

        private async Task PrintBookingReceipt(int hotelRoomBookingID)
        {
            IsBusyBooked = true;

            // Downloading the receipt byte array
            var serviceResponse = await _hotelReportWebAppService.PrintBookingReceipt(hotelRoomBookingID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                byte[] serviceResponseData = serviceResponse.Content;

                PrintBookingReceipt(serviceResponseData);

            }
            else
            {
                // Notification of failure
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while printing the booking receipt: '{serviceResponse.Error}'.");
            }

            IsBusyBooked = false;
            StateHasChanged();
        }

        private async Task GetHotelRoomBookingDetail()
        {
            isLoading = true;
            var serviceResponse = await _hotelRoomBookingWebAppService.GetRoomBookingDetailsByID(hotelRoomBookingID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                hotelRoomBookingRequestModel = serviceResponse.Content;
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while getting Booking data'{serviceResponse.Error}'.");
                hotelRoomBookingRequestModel = new HotelRoomBookingWebAppModel();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task GetGuestReward()
        {
            isLoading = true;
            var serviceResponse = await _guestWebAppService.GetGuestRewardPoint(hotelID, guestID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                guestRewardServiceResponseData = serviceResponse.Content;

                if (guestRewardServiceResponseData.GuestRewardID > 0)
                {
                    isRewardPointVisible = true;
                }
            }
            else
            {
                guestRewardServiceResponseData = new();
            }
            isLoading = false;
            StateHasChanged();
        }
        #endregion
    }
}
