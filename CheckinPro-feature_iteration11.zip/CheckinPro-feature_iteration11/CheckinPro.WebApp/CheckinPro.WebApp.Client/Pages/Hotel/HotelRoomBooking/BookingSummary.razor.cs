﻿using Blazored.LocalStorage;
using CheckinPro.Common.Models;
using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;
using static CheckinPro.Common.Models.Constants.CommonConstants;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking
{
    public partial class BookingSummary : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelRoomBookingWebAppService _hotelRoomBookingWebAppService { get; set; }
        [Inject] private IDropdownWebAppService _dropDownWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private DialogService _dialogService { get; set; }
        [Inject] private ILocalStorageService _localStorageService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter
        [Parameter] public int hotelID { get; set; } = 0;
        [Parameter] public int tabPosition { get; set; } = 0;
        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        bool IsBusy { get; set; } = false;
        bool IsShiftActive { get; set; } = false;

        private string pagingSummaryFormat = "Displaying page {0} of {1} (total {2} records)";

        private IEnumerable<int> pageSizeOptions = new int[] { 10, 20, 30 };
        private List<SelectionItemModel> serviceResponseRoomTypeDataList { get; set; } = new();
        private List<GetHotelRoomBookingSearchListWebAppModel> serviceResponseDataList { get; set; } = new();
        private FindHotelRoomBookingWebAppModel findHotelRoomBookingRequestModel { get; set; } = new();
        public BookingListDataGridFlags bookingListDataGridFlags { get; set; } = new();
        #endregion

        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            OnInitializedData();
        }

        protected override async Task OnParametersSetAsync()
        {
            OnInitializedData();
        }

        private async void OnInitializedData()
        {

            OnTabChange(tabPosition);
            var storedValue = await _localStorageService.GetItemAsync<string>("IsShiftActive");
            IsShiftActive = storedValue != null && bool.Parse(storedValue);
            StateHasChanged();
        }

        private async void OnTabChange(int index)
        {
            tabPosition = index;
            //var currentDate = DateOnly.FromDateTime(DateTime.Now);
            var checkInWindowStart = GetSystemMinDate();
            var checkInWindowEnd = GetSystemMaxDate();

            switch (index)
            {
                case 0: // Arrivals
                    findHotelRoomBookingRequestModel.StartDate = checkInWindowStart;
                    findHotelRoomBookingRequestModel.EndDate = checkInWindowEnd;
                    findHotelRoomBookingRequestModel.BookingStatus = BookingStatusMessages.Booked;
                    await SearchRoomBookings();
                    bookingListDataGridFlags.isRoomNumberVisible = false;
                    bookingListDataGridFlags.isCheckInButtonVisible = true;
                    bookingListDataGridFlags.isCheckOutButtonVisible = false;
                    bookingListDataGridFlags.isCancelButtonVisible = true;
                    break;
                case 1: // InHouse Rooms
                    findHotelRoomBookingRequestModel.StartDate = checkInWindowStart;
                    findHotelRoomBookingRequestModel.EndDate = checkInWindowEnd;
                    findHotelRoomBookingRequestModel.BookingStatus = BookingStatusMessages.CheckedIn;
                    await SearchRoomBookings();
                    //InHouseList(currentDate);
                    bookingListDataGridFlags.isRoomNumberVisible = true;
                    bookingListDataGridFlags.isCheckInButtonVisible = false;
                    bookingListDataGridFlags.isCheckOutButtonVisible = true;
                    bookingListDataGridFlags.isCancelButtonVisible = false;
                    break;
                case 2: // Pending Check Out Rooms
                    findHotelRoomBookingRequestModel.StartDate = checkInWindowStart;
                    findHotelRoomBookingRequestModel.EndDate = checkInWindowEnd;
                    findHotelRoomBookingRequestModel.BookingStatus = BookingStatusMessages.CheckedIn;
                    await SearchRoomBookings();
                    PendingCheckOutList(checkInWindowStart, checkInWindowEnd);
                    bookingListDataGridFlags.isRoomNumberVisible = true;
                    bookingListDataGridFlags.isCheckInButtonVisible = false;
                    bookingListDataGridFlags.isCheckOutButtonVisible = true;
                    bookingListDataGridFlags.isCancelButtonVisible = false;
                    break;
                case 3: // Cancellation
                    findHotelRoomBookingRequestModel.StartDate = checkInWindowStart;
                    findHotelRoomBookingRequestModel.EndDate = checkInWindowEnd;
                    findHotelRoomBookingRequestModel.BookingStatus = BookingStatusMessages.Cancelled;
                    await SearchRoomBookings();
                    bookingListDataGridFlags.isRoomNumberVisible = true;
                    bookingListDataGridFlags.isCheckInButtonVisible = false;
                    bookingListDataGridFlags.isCheckOutButtonVisible = false;
                    bookingListDataGridFlags.isCancelButtonVisible = false;
                    break;
                case 4: // CheckedOut Rooms
                    findHotelRoomBookingRequestModel.StartDate = checkInWindowStart;
                    findHotelRoomBookingRequestModel.EndDate = checkInWindowEnd;
                    findHotelRoomBookingRequestModel.BookingStatus = BookingStatusMessages.CheckedOut;
                    await SearchRoomBookings();
                    bookingListDataGridFlags.isRoomNumberVisible = true;
                    bookingListDataGridFlags.isCheckInButtonVisible = false;
                    bookingListDataGridFlags.isCheckOutButtonVisible = false;
                    bookingListDataGridFlags.isCancelButtonVisible = false;
                    break;
                case 5: // Search Reservations     
                    ClearSearchResult();
                    await GetHotelRoomTypes();
                    findHotelRoomBookingRequestModel.StartDate = null;
                    findHotelRoomBookingRequestModel.EndDate = null;
                    bookingListDataGridFlags.isRoomNumberVisible = true;
                    bookingListDataGridFlags.isCheckInButtonVisible = false;
                    bookingListDataGridFlags.isCancelButtonVisible = false;
                    bookingListDataGridFlags.isCheckOutButtonVisible = false;
                    break;
                default:
                    break;
            }
            StateHasChanged();
        }

        private void InHouseList(DateOnly currentDate)
        {
            var filteredBookings = serviceResponseDataList?.Where(s => DateOnly.FromDateTime(s.ScheduledCheckOutDate.Value.Date) != currentDate).ToList();
            serviceResponseDataList = filteredBookings;
        }

        private void PendingCheckOutList(DateTime checkInWindowStart, DateTime checkInWindowEnd)
        {
            var filteredBookings = serviceResponseDataList?.Where(booking => booking.ScheduledCheckOutDate >= checkInWindowStart && booking.ScheduledCheckOutDate <= checkInWindowEnd).ToList();
            //var filteredBookings = serviceResponseDataList?.Where(s => DateOnly.FromDateTime(s.ScheduledCheckOutDate.Value.Date) == currentDate).ToList();
            serviceResponseDataList = filteredBookings;
        }

        private void ClearSearchResult()
        {
            serviceResponseDataList = new();
            findHotelRoomBookingRequestModel = new();
            StateHasChanged();
        }
        #endregion

        #region API service calls
        private async Task GetHotelRoomTypes()
        {
            isLoading = true;
            var serviceResponse = await _dropDownWebAppService.GetHotelRoomTypesForDropdown(hotelID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseRoomTypeDataList = serviceResponse.Content.Select(item => new SelectionItemModel
                {
                    ItemID = item.ItemID,
                    ItemName = item.ItemName,
                    ItemIcon = item.ItemIcon
                }).ToList();
            }
            else
            {
                serviceResponseRoomTypeDataList = new List<SelectionItemModel>();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task SearchRoomBookings()
        {
            isLoading = true;
            findHotelRoomBookingRequestModel.HotelId = hotelID;
            var serviceResponse = await _hotelRoomBookingWebAppService.SearchHotelRoomBooking(findHotelRoomBookingRequestModel);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseDataList = serviceResponse.Content;
            }
            else
            {
                serviceResponseDataList = new List<GetHotelRoomBookingSearchListWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }
        #endregion

    }
}
