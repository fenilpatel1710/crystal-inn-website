﻿using CheckinPro.Common.Models;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking
{
    public partial class CancellationReasonForm : ComponentBase
    {
        #region Inject Services
        [Inject] private DialogService _dialogService { get; set; }
        #endregion

        #region Parameter
        [Parameter] public EventCallback<string> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        [Parameter] public string CancellationReason { get; set; } = string.Empty;
        [Parameter] public bool IsBusy { get; set; } = false;

        #endregion

        #region OnRender Method Starts
        private async Task HandleFormOnSubmit()
        {
            IsBusy = true;
            _dialogService.Close(CancellationReason ?? string.Empty);
            IsBusy = false;
        }

        private void HandleOnCancel()
        {
            _dialogService.Close(null);
        }
        #endregion
    }
}
