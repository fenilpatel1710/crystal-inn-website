﻿using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking
{
    public partial class ViewExtendHistoryForm : ComponentBase
    {
        #region Parameter
        [Parameter] public List<HotelRoomBookingRateDetailWebAppModel> hotelRoomBookingRateDetailRequestModel { get; set; }
        [Parameter] public bool isHourly { get; set; }


        #endregion
    }
}
