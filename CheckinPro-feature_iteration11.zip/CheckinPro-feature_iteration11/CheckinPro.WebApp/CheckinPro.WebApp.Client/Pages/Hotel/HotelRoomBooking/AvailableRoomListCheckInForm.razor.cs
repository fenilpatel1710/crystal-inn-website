﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking
{
    public partial class AvailableRoomListCheckInForm : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelRoomBookingWebAppService _hotelRoomBookingWebAppService { get; set; }
        [Inject] private DialogService _dialogService { get; set; }
        #endregion

        #region Parameter
        [Parameter] public int hotelID { get; set; } = 0;
        [Parameter] public HotelRoomBookingWebAppModel hotelRoomBookingRequestModel { get; set; } = new();
        public bool isLoading { get; set; } = true;
        public int HotelRoomID { get; set; } = 0;
        private List<HotelRoomWebAppModel> serviceResponseHotelRoomDataList { get; set; } = new();

        #endregion

        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            await GetAvailableRoomByDates();

            isLoading = false;
            StateHasChanged();
        }

        private void SelectRoomForCheckIn(HotelRoomWebAppModel hotelRoomWebAppModel)
        {
            HotelRoomID = hotelRoomWebAppModel.HotelRoomID;          
            StateHasChanged();
        }

     
        private async Task HandleFormOnSubmit()
        {
            _dialogService.CloseSide(HotelRoomID);
            //await OnSubmit.InvokeAsync(hotelRoomBookingRequestModel);
        }

        private void HandleOnCancel()
        {
            HotelRoomID = 0;
            _dialogService.CloseSide(HotelRoomID);
        }

        private string GetCardClass(int hotelRoomID)
        {
            // If this card is selected, apply the 'selected' class (green color)
            return HotelRoomID == hotelRoomID ? "rz-border-radius-3 rz-my-1 rz-link rz-ripple rz-background-color-success-light" : "rz-border-radius-3 rz-my-1 rz-link rz-ripple";
        }

        #endregion

        #region API service calls

        private async Task GetAvailableRoomByDates()
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.GetAvailableRoomByDates(hotelID, hotelRoomBookingRequestModel.HotelRoomTypeID, hotelRoomBookingRequestModel.ScheduledCheckInDate, hotelRoomBookingRequestModel.ScheduledCheckOutDate);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseHotelRoomDataList = serviceResponse.Content;
            }
            else
            {
                serviceResponseHotelRoomDataList = new List<HotelRoomWebAppModel>(); // Initialize as empty list if null
            }
        }
        #endregion

    }
}
