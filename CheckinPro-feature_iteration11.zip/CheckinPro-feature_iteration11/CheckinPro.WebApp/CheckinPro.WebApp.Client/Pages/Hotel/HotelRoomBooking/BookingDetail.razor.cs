﻿using Blazored.LocalStorage;
using CheckinPro.Common.Models;
using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Pages.Guest;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using CheckinPro.WebApp.Models.Guest;
using CheckinPro.WebApp.Models.HotelRoomBooking;
using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using Radzen;
using System.Threading.Tasks;
using static CheckinPro.Common.Models.Constants.CommonConstants;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking
{
    public partial class BookingDetail : BookingServiceComponent
    {
        #region Inject Services
        [Inject] private IHotelWebAppService _hotelWebAppService { get; set; }
        [Inject] private IHotelRoomBookingWebAppService _hotelRoomBookingWebAppService { get; set; }
        [Inject] private IHotelReportWebAppService _hotelReportWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private DialogService _dialogService { get; set; }
        [Inject] private IJSRuntime _jsruntime { get; set; }
        [Inject] private ILocalStorageService _localStorageService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter
        [Parameter] public int hotelID { get; set; } = 0;
        [Parameter] public int hotelRoomBookingID { get; set; } = 0;
        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        bool IsBusySave { get; set; } = false;
        bool IsBusyCheckIn { get; set; } = false;
        bool IsBusyCancel { get; set; } = false;
        bool IsBusyCheckOut { get; set; } = false;
        bool IsBusyPrintBookingReceipt { get; set; } = false;
        bool IsBusyDownloadBookingInvoice { get; set; } = false;
        bool IsBusy { get; set; } = false;
        bool IsShiftActive { get; set; } = false;

        private int editingHotelRoomBookingRateDetailID = 0;

        private bool isEditingMiscellaneousAmount = false;

        private bool isExtendBooking = false;
        private HotelRoomBookingRateDetailWebAppModel? initialRateDetail { get; set; } = new();

        private decimal? oldMiscellaneousAmount;

        private decimal? originalFinalAmount;

        private decimal? rateExceptionAmount;
        private HotelRoomBookingWebAppModel hotelRoomBookingServiceResponseData { get; set; } = new();
        private HotelConfigurationWebAppModel serviceResponseHotelConfigurationData { get; set; } = new();
        private HotelDailyRateWebAppModel serviceResponseHotelDailyRateData { get; set; } = new();
        private List<HotelHourlyRateWebAppModel> serviceResponseHotelHourlyRateDataList { get; set; } = new();
        private List<GetBookedRoomDetailsWebAppModel> bookedRoomDetailsServiceResponseDataList { get; set; } = new();

        IEnumerable<HotelTaxRateWebAppModel> selectedHotelTaxRate;

        private string BookingDuration = string.Empty;
        #endregion

        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            var storedValue = await _localStorageService.GetItemAsync<string>("IsShiftActive");
            IsShiftActive = storedValue != null && bool.Parse(storedValue);
            await GetHotelRoomBookingDetail();
        }

        public BadgeStyle GetBadgeStyle(string bookingStatus)
        {
            switch (bookingStatus)
            {
                case BookingStatusMessages.Booked:
                    return BadgeStyle.Info;  // Booking is confirmed and guaranteed.
                case BookingStatusMessages.Cancelled:
                    return BadgeStyle.Danger;  // Booking was cancelled by guest or admin.
                case BookingStatusMessages.CheckedIn:
                    return BadgeStyle.Success;  // Guest has checked into the hotel.
                case BookingStatusMessages.CheckedOut:
                    return BadgeStyle.Base;  // Guest has checked out of the hotel.
                case BookingStatusMessages.NoShow:
                    return BadgeStyle.Primary;  // Guest didn't show up for their booking.
                case BookingStatusMessages.OverDue:
                    return BadgeStyle.Warning;  // Guest has checked out time overdue.
                default:
                    return BadgeStyle.Primary;  // Default style if status is unrecognized.
            }
        }

        private DateTime GetMinCheckInDate()
        {
            DateTime now = DateTime.Now;

            // If current time is between 12 AM and 6 AM, allow previous day booking
            if (now.Hour < 6)
            {
                return now.AddDays(-1).Date.AddHours(11); // Allow booking the previous day
            }
            else
            {
                return now.Date.AddHours(11); // Allow booking today or future
            }
        }

        private DateTime GetMinCheckOutDate()
        {
            // For "Days" booking, the check-out date should be at least one day after check-in
            if (hotelRoomBookingServiceResponseData.ScheduledCheckInDate.HasValue)
            {
                return hotelRoomBookingServiceResponseData.ScheduledCheckInDate.Value.AddDays(1).Date.AddHours(11);
            }

            return DateTime.Now.AddDays(1); // Default to tomorrow if check-in is not set
        }

        private void OnCheckOutDateChange(DateTime? value)
        {
            if (value.HasValue && value.Value >= hotelRoomBookingServiceResponseData.ScheduledCheckInDate)
            {
                // Set the selected checkout date and set the time to 11:30 AM
                hotelRoomBookingServiceResponseData.ScheduledCheckOutDate = value.Value.Date.AddHours(11);
            }
            else
            {
                // Default to check-in date + 1 day and set time to 11:30 AM
                hotelRoomBookingServiceResponseData.ScheduledCheckOutDate = hotelRoomBookingServiceResponseData.ScheduledCheckInDate.Value.AddDays(1).Date.AddHours(11);
            }

            // Optionally, call any other necessary function like OnDateChange
            OnDateChange();
        }

        private async void OnDateChange()
        {
            if (hotelRoomBookingServiceResponseData.ScheduledCheckInDate != DateTime.MinValue && hotelRoomBookingServiceResponseData.ScheduledCheckOutDate != DateTime.MinValue)
            {
                var checkIn = hotelRoomBookingServiceResponseData.ScheduledCheckInDate.Value;
                var checkOut = hotelRoomBookingServiceResponseData.ScheduledCheckOutDate.Value;

                if (hotelRoomBookingServiceResponseData.IsHourlyBooking == false) // Days
                {
                    var duration = checkOut.Date - checkIn.Date;
                    if (duration.TotalDays >= 1)
                    {
                        hotelRoomBookingServiceResponseData.Duration = Convert.ToInt32(Math.Floor(duration.TotalDays));
                        BookingDuration = $"{Math.Floor(duration.TotalDays)} Day(s)";
                    }
                    else
                    {
                        BookingDuration = "Invalid duration for days booking.";
                    }
                }
                else if (hotelRoomBookingServiceResponseData.IsHourlyBooking == true) // Hourly
                {
                    var duration = checkOut - checkIn;
                    if (duration.TotalHours >= 1)
                    {
                        hotelRoomBookingServiceResponseData.Duration = Convert.ToInt32(Math.Floor(duration.TotalHours));
                        BookingDuration = $"{Math.Floor(duration.TotalHours)} Hour(s)";
                    }
                    else if (duration.TotalMinutes >= 1)
                    {
                        hotelRoomBookingServiceResponseData.Duration = Convert.ToInt32(Math.Floor(duration.TotalDays));
                        BookingDuration = $"{Math.Floor(duration.TotalMinutes)} Minute(s)";
                    }
                    else
                    {
                        BookingDuration = "Invalid duration for hourly booking.";
                    }
                }
            }

            StateHasChanged();
        }

        private void OnCheckOutHoursChange(object args)
        {
            int? checkOutHours = args as int?;

            // Ensure check-out hours value is valid
            if (checkOutHours.HasValue && checkOutHours.Value != 0)
            {
                // Only update the check-out date, NOT the check-in date
                hotelRoomBookingServiceResponseData.ScheduledCheckOutDate = hotelRoomBookingServiceResponseData.ScheduledCheckInDate.Value.AddHours((double)checkOutHours);

                // Find the hourly rate based on the selected check-out hours
                //var matchedRate = serviceResponseHotelHourlyRateDataList.FirstOrDefault(rate => rate.Hour == checkOutHours);

                //if (matchedRate != null)
                //{
                //    hotelRoomBoohotelRoomBookingServiceResponseDatakingRequestModel.HourlyRate = matchedRate.HourlyRate;
                //}
                //else
                //{
                //    hotelRoomBookingServiceResponseData.HourlyRate = null;
                //}
            }
            else
            {
                // If no valid value for check-out hours, default to 1 hour
                hotelRoomBookingServiceResponseData.ScheduledCheckOutDate = hotelRoomBookingServiceResponseData.ScheduledCheckInDate.Value.AddHours(1);
            }

            // Ensure we don't modify the check-in date here
            OnDateChange();
        }

        private void OnTotalAmountClicked(int hotelRoomBookingRateDetailID)
        {
            editingHotelRoomBookingRateDetailID = hotelRoomBookingRateDetailID;
            StateHasChanged();
        }

        //private void OnSaveFinalAmountClickss()
        //{
        //    isEditingFinalAmount = false;
        //    // Ensure FinalAmount is valid
        //    if (!hotelRoomBookingServiceResponseData.FinalAmount.HasValue || hotelRoomBookingServiceResponseData.FinalAmount == 0)
        //        return;
        //    List<decimal> taxPercentages;

        //    // Get tax rates dynamically
        //    taxPercentages = hotelRoomBookingServiceResponseData.HotelRoomBookingTaxRates
        //       .Where(tax => tax.BookingTaxRatePercentage.HasValue)
        //       .Select(tax => tax.BookingTaxRatePercentage.Value)
        //       .ToList();

        //    // Calculate the total percentage dynamically
        //    decimal totalTaxRate = taxPercentages.Sum(); // Sum of all tax rates (e.g., 6%, 7%, 4%)

        //    // Calculate the combined percentage factor (1 + total tax rate / 100)
        //    decimal percentageFactor = 1 + (totalTaxRate / 100); // Total = 1 + (6 + 7 + 4) / 100 = 1.17

        //    decimal finalAmount = hotelRoomBookingServiceResponseData.FinalAmount.Value;

        //    // Reverse calculation to find the room charge
        //    decimal roomCharge = finalAmount / percentageFactor; // Final amount / 1.17 to get room charge

        //    // Assign values back to the model
        //    hotelRoomBookingServiceResponseData.SubTotalAmount = roomCharge;
        //    // hotelRoomBookingRequestModel.TotalAmount = finalAmount;

        //    if (hotelRoomBookingServiceResponseData.IsHourlyBooking == true)
        //    {
        //        OnSelectCalculateTaxRate(hotelRoomBookingServiceResponseData.HotelRoomBookingTaxRates);
        //    }
        //    else
        //    {
        //        var taxRatesList = hotelRoomBookingServiceResponseData.HotelRoomBookingTaxRates
        //.Select(tax => new HotelTaxRateWebAppModel // Ensure the correct type
        //{
        //    HotelTaxRateID = tax.HotelTaxRateID ?? 0,
        //    TaxName = tax.BookingTaxRateName,
        //    TaxRate = tax.BookingTaxRatePercentage
        //}).ToList();
        //        OnSelectCalculateTaxRate(taxRatesList);
        //    }


        //    // Now call OnSelectCalculateTaxRate with the correct type

        //    StateHasChanged();
        //}

        //private void OnSaveFinalAmountClick()
        //{
        //    isEditingTotalAmount = false;
        //    // Ensure FinalAmount is valid
        //    if (!hotelRoomBookingServiceResponseData.TotalAmount.HasValue || hotelRoomBookingServiceResponseData.TotalAmount == 0)
        //        return;
        //    //List<decimal> taxPercentages;

        //    // Get tax rates dynamically
        //    // taxPercentages = hotelRoomBookingServiceResponseData.HotelRoomBookingTaxRates.Where(tax => tax.BookingTaxRatePercentage.HasValue).Select(tax => tax.BookingTaxRatePercentage.Value).ToList();

        //    // Calculate the total percentage dynamically
        //    //decimal? totalTaxRates = taxPercentages.Sum() + 100; // Sum of all tax rates (e.g., 6%, 7%, 4%)

        //    //decimal? totalAmount = hotelRoomBookingServiceResponseData.TotalAmount.Value;

        //    // Reverse calculation to find the room charge
        //    //decimal? roomCharge = totalAmount / totalTaxRates * 100; // Final amount / 1.17 to get room charge

        //    // Assign values back to the model
        //    //hotelRoomBookingServiceResponseData.SubTotalAmount = roomCharge;

        //    decimal totalAmount = hotelRoomBookingServiceResponseData.TotalAmount ?? 0m;

        //    // Get tax rates dynamically
        //    var taxPercentages = hotelRoomBookingServiceResponseData.HotelRoomBookingTaxRates.Where(tax => tax.BookingTaxRatePercentage.HasValue).Select(tax => tax.BookingTaxRatePercentage.Value).ToList();

        //    // Calculate the total percentage dynamically
        //    decimal totalTaxRate = taxPercentages.Sum();

        //    // Calculate the combined percentage factor (1 + total tax rate / 100)
        //    decimal percentageFactor = 1 + (totalTaxRate / 100);

        //    // Reverse calculation to find the room charge
        //    decimal roomCharge = totalAmount / percentageFactor; // Final amount / 1.17 to get room charge

        //    // Assign values back to the model
        //    hotelRoomBookingServiceResponseData.SubTotalAmount = roomCharge;


        //    var taxRatesList = hotelRoomBookingServiceResponseData.HotelRoomBookingTaxRates.Select(tax => new HotelTaxRateWebAppModel
        //    {
        //        HotelTaxRateID = tax.HotelTaxRateID ?? 0,
        //        TaxName = tax.BookingTaxRateName,
        //        TaxRate = tax.BookingTaxRatePercentage
        //    }).ToList();

        //    OnSelectCalculateTaxRate(taxRatesList);

        //    StateHasChanged();
        //}

        private void OnSaveTotalAmountClick(HotelRoomBookingRateDetailWebAppModel hotelRoomBookingRateDetailData)
        {
            editingHotelRoomBookingRateDetailID = 0;
            // Ensure TotalAmount is valid
            if (!hotelRoomBookingRateDetailData.TotalAmount.HasValue || hotelRoomBookingRateDetailData.TotalAmount == 0)
                return;

            decimal totalAmount = hotelRoomBookingRateDetailData.TotalAmount ?? 0m;

            // Get tax rates dynamically
            var taxPercentages = hotelRoomBookingRateDetailData.HotelRoomBookingTaxRates.Where(tax => tax.BookingTaxRatePercentage.HasValue).Select(tax => tax.BookingTaxRatePercentage.Value).ToList();

            // Calculate the total percentage dynamically
            decimal totalTaxRate = taxPercentages.Sum();

            // Calculate the combined percentage factor (1 + total tax rate / 100)
            decimal percentageFactor = 1 + (totalTaxRate / 100);

            // Reverse calculation to find the room charge
            decimal roomCharge = totalAmount / percentageFactor; // Final amount / 1.17 to get room charge

            // Assign values back to the model
            hotelRoomBookingRateDetailData.RoomChargeAmount = roomCharge;


            var taxRatesList = hotelRoomBookingRateDetailData.HotelRoomBookingTaxRates.Select(tax => new HotelTaxRateWebAppModel
            {
                HotelTaxRateID = tax.HotelTaxRateID ?? 0,
                TaxName = tax.BookingTaxRateName,
                TaxRate = tax.BookingTaxRatePercentage
            }).ToList();

            OnSelectCalculateTaxRate(taxRatesList, hotelRoomBookingRateDetailData);

            StateHasChanged();
        }

        private void OnBookingExtendClicked()
        {
            //isExtendBooking = true;
            //StateHasChanged();

            _navigationManager.NavigateTo($"/room-booking/{hotelID}/{hotelRoomBookingID}/{true}");

            //var guest = hotelRoomBookingServiceResponseData.Guests.Where(item => item.IsPrimaryGuest).FirstOrDefault();
            //if (guest != null)
            //{
            //    _navigationManager.NavigateTo($"/room-booking/{hotelID}/{hotelRoomBookingServiceResponseData.HotelRoomTypeID}/{hotelRoomBookingServiceResponseData.HotelRoomID}/{hotelRoomBookingServiceResponseData.HotelRoom.RoomNumber}/{guest?.GuestCode}");
            //}
        }

        //private async void CalculateExtendAmount()
        //{
        //    isEditingTotalAmount = false;
        //    decimal? RoomRate = 0;

        //    if (hotelRoomBookingServiceResponseData.HotelRoomType?.AdjustmentRate.HasValue == true)
        //    {
        //        RoomRate += hotelRoomBookingServiceResponseData.AdjustmentRate;
        //    }

        //    if (hotelRoomBookingServiceResponseData.IsHourlyBooking)
        //    {
        //        await GetHotelHourlyRate();
        //        RoomRate += hotelRoomBookingServiceResponseData.HourlyRate;
        //    }
        //    else
        //    {
        //        await GetHotelConfiguration();
        //        await GetHotelDailyRate();
        //        RoomRate += (serviceResponseHotelDailyRateData.DailyBestAvailableRate ?? 0) != 0 ? serviceResponseHotelDailyRateData.DailyBestAvailableRate : serviceResponseHotelConfigurationData.BestAvailableRate;
        //        //hotelRoomBookingServiceResponseData.BestAvailableRate = RoomRate;
        //    }

        //    CalculateRoomRate(RoomRate);

        //    StateHasChanged();
        //}

        //private void CalculateRoomRate(decimal? RateAmount)
        //{
        //    if (hotelRoomBookingServiceResponseData.ScheduledCheckInDate != DateTime.MinValue && hotelRoomBookingServiceResponseData.ScheduledCheckOutDate != DateTime.MinValue)
        //    {
        //        // Calculate the duration
        //        var checkIn = DateTime.Now;
        //        var checkOut = hotelRoomBookingServiceResponseData.ScheduledCheckOutDate.Value;
        //        var duration = checkOut - checkIn;
        //        decimal bookingDuration = (decimal)Math.Floor(duration.TotalDays);
        //        bookingDuration = bookingDuration < 1 ? 1 : bookingDuration;


        //        // Check if the booking duration is valid
        //        if (duration.TotalDays <= 0)
        //        {
        //            hotelRoomBookingServiceResponseData.SubTotalAmount = 0; // Invalid duration
        //            hotelRoomBookingServiceResponseData.TotalAmount = 0; // Reset final amount
        //            hotelRoomBookingServiceResponseData.FinalAmount = 0; // Reset final amount
        //            return;
        //        }

        //        // Calculate total amount based on booking type
        //        if (hotelRoomBookingServiceResponseData.IsHourlyBooking == false)
        //        {
        //            // For "days" booking (daily rate)
        //            if (duration.TotalDays >= 1)
        //            {
        //                // Calculate the SubTotalAmount based on the rate per day
        //                hotelRoomBookingServiceResponseData.SubTotalAmount = bookingDuration * RateAmount; // Per day rate
        //            }
        //            else
        //            {
        //                hotelRoomBookingServiceResponseData.SubTotalAmount = 0; // Invalid duration for daily booking
        //            }

        //            hotelRoomBookingServiceResponseData.TotalAmount = hotelRoomBookingServiceResponseData.SubTotalAmount;
        //            hotelRoomBookingServiceResponseData.FinalAmount = hotelRoomBookingServiceResponseData.TotalAmount;

        //            if (hotelRoomBookingServiceResponseData.HotelRoomBookingTaxRates.Any())
        //            {
        //                OnSelectCalculateTaxRate(hotelRoomBookingServiceResponseData.HotelRoomBookingTaxRates);
        //            }
        //        }
        //        else if (hotelRoomBookingServiceResponseData.IsHourlyBooking == true)
        //        {

        //            hotelRoomBookingServiceResponseData.FinalAmount = RateAmount;
        //            OnSaveFinalAmountClick();
        //        }


        //    }
        //    else
        //    {
        //        hotelRoomBookingServiceResponseData.SubTotalAmount = 0;
        //        hotelRoomBookingServiceResponseData.TotalAmount = 0;
        //        hotelRoomBookingServiceResponseData.FinalAmount = 0;
        //    }

        //    StateHasChanged();
        //}

        //private void AddMiscellaneousAmount()
        //{
        //    isEditingMiscellaneousAmount = true;

        //    oldMiscellaneousAmount = initialRateDetail.MiscellaneousAmount;
        //    originalFinalAmount = initialRateDetail.FinalAmount;
        //}

        private async Task CreateEditMiscAmountDialog()
        {
            var dialogName = "Miscellaneous Amount";
            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true, Width = "700px", };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<MiscAmountDetailForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelRoomBookingID", hotelRoomBookingID},
                //{ "OnSubmit", EventCallback.Factory.Create<AddEditMiscAmountWebAppModel>(this, HandleFormOnSubmitPaymentDetail) }
                }, dialogOptions);
            isLoading = true;
            StateHasChanged();
            await GetHotelRoomBookingDetail();
        }

        private async void OnSaveMiscellaneousAmount()
        {
            isEditingMiscellaneousAmount = false;

            AddEditMiscAmountWebAppModel addEditMiscAmountRequestModel = new AddEditMiscAmountWebAppModel();
            addEditMiscAmountRequestModel.HotelRoomBookingID = hotelRoomBookingID;
            addEditMiscAmountRequestModel.MiscellaneousAmount = initialRateDetail?.MiscellaneousAmount;

            // If oldMiscellaneousAmount is null (which means it's the first time adding the value)
            if (!oldMiscellaneousAmount.HasValue)
            {
                initialRateDetail.FinalAmount += initialRateDetail?.MiscellaneousAmount ?? 0;
                addEditMiscAmountRequestModel.FinalAmount = initialRateDetail?.FinalAmount;
            }
            else
            {
                initialRateDetail.FinalAmount = originalFinalAmount + (initialRateDetail?.MiscellaneousAmount ?? 0) - oldMiscellaneousAmount.Value;
                addEditMiscAmountRequestModel.FinalAmount = initialRateDetail?.FinalAmount;
            }

            var serviceResponse = await OnSaveMiscellaneousAmountClicked(addEditMiscAmountRequestModel);
            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Miscellaneous Amount saved successfully!");
                await GetHotelRoomBookingDetail();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving Miscellaneous Amount.");
            }

            //// If oldMiscellaneousAmount is null (which means it's the first time adding the value)
            //if (!oldMiscellaneousAmount.HasValue)
            //{
            //    // If it's the first time setting the MiscellaneousAmount, simply add it to the FinalAmount
            //    hotelRoomBookingServiceResponseData.FinalAmount += hotelRoomBookingServiceResponseData.MiscellaneousAmount ?? 0;
            //}
            //else
            //{
            //    // If MiscellaneousAmount is not null, adjust FinalAmount based on the change
            //    hotelRoomBookingServiceResponseData.FinalAmount = originalFinalAmount
            //        + (hotelRoomBookingServiceResponseData.MiscellaneousAmount ?? 0)  // Add new MiscellaneousAmount
            //        - oldMiscellaneousAmount.Value;  // Subtract old MiscellaneousAmount
            //}

            // Update the UI
            StateHasChanged();
        }

        private async Task OnSelectCalculateTaxRate(object selectedFeatureItem, HotelRoomBookingRateDetailWebAppModel hotelRoomBookingRateDetailData)
        {
            selectedHotelTaxRate = (IEnumerable<HotelTaxRateWebAppModel>)selectedFeatureItem;
            decimal totalTaxRates = 0m;
            decimal roomChargeAmount = hotelRoomBookingRateDetailData.RoomChargeAmount ?? 0m;
            decimal oldTotalAmount = hotelRoomBookingRateDetailData.TotalAmount ?? 0m;


            // Clear the existing tax rates to avoid duplicates
            hotelRoomBookingRateDetailData.HotelRoomBookingTaxRates.Clear();

            if (hotelRoomBookingServiceResponseData.IsHourlyBooking == true)
            {
                hotelRoomBookingRateDetailData.TotalAmount = hotelRoomBookingServiceResponseData.HourlyRate;
            }

            if (selectedHotelTaxRate.Any())
            {
                foreach (var item in selectedHotelTaxRate)
                {
                    // Add the tax rate to the list
                    totalTaxRates += Convert.ToDecimal(item.TaxRate);
                    var newTaxRate = new HotelRoomBookingTaxRateWebAppModel
                    {
                        HotelTaxRateID = item.HotelTaxRateID,
                        BookingTaxRateName = item.TaxName,
                        BookingTaxRatePercentage = item.TaxRate,
                        BookingTaxRate = (roomChargeAmount * (item.TaxRate / 100)),
                    };

                    hotelRoomBookingRateDetailData.HotelRoomBookingTaxRates.Add(newTaxRate);
                }

                // Calculate the total tax amount using the selected tax rate(s)
                decimal validTaxRate = totalTaxRates / 100; // Convert total tax rate to decimal
                var taxAmount = roomChargeAmount * validTaxRate;

                // Calculate final amount (subtotal + tax)
                hotelRoomBookingRateDetailData.TotalAmount = (decimal?)Math.Round(roomChargeAmount + taxAmount, 2);
                hotelRoomBookingRateDetailData.FinalAmount = hotelRoomBookingRateDetailData.TotalAmount;
                //if (hotelRoomBookingRateDetailData.AdditionalRateAmount > 0)
                //{
                //    OnAdditionalRateChanges();
                //}
                hotelRoomBookingRateDetailData.FinalAmount += (hotelRoomBookingRateDetailData.MiscellaneousAmount ?? 0);
            }
            else
            {
                if (hotelRoomBookingServiceResponseData.IsHourlyBooking)
                {
                    hotelRoomBookingRateDetailData.RoomChargeAmount = hotelRoomBookingRateDetailData.HourlyRate;
                    hotelRoomBookingRateDetailData.TotalAmount = hotelRoomBookingRateDetailData.RoomChargeAmount;
                    hotelRoomBookingRateDetailData.FinalAmount = hotelRoomBookingRateDetailData.TotalAmount + (hotelRoomBookingRateDetailData.MiscellaneousAmount ?? 0);
                }
                else
                {
                    hotelRoomBookingRateDetailData.TotalAmount = hotelRoomBookingRateDetailData.RoomChargeAmount;
                    hotelRoomBookingRateDetailData.FinalAmount = hotelRoomBookingRateDetailData.TotalAmount;
                    //if (hotelRoomBookingRateDetailData.AdditionalRateAmount > 0)
                    //{
                    //    OnAdditionalRateChanges();
                    //}
                    hotelRoomBookingRateDetailData.FinalAmount += (hotelRoomBookingRateDetailData.MiscellaneousAmount ?? 0);
                }
            }
            var serviceResponse = await OnUpdateTotalAmountClick(hotelRoomBookingRateDetailData);
            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"TotalAmount saved successfully!");
                await GetHotelRoomBookingDetail();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving TotalAmount.");
            }
            StateHasChanged();
        }

        private async Task CreateEditGuestDialog(AddEditGuestWebAppModel? hotelGuest)
        {
            var guestRequestModel = new AddEditGuestWebAppModel();
            if (hotelGuest != null)
            {

                guestRequestModel.GuestID = hotelGuest.GuestID;
                guestRequestModel.FirstName = hotelGuest.FirstName;
                guestRequestModel.LastName = hotelGuest.LastName;
                guestRequestModel.IdentityType = hotelGuest.IdentityType;
                guestRequestModel.IdentityNumber = hotelGuest.IdentityNumber;
                guestRequestModel.FrontSideImage = hotelGuest.FrontSideImage;
                guestRequestModel.Email = hotelGuest.Email;
                guestRequestModel.MobileNumber = hotelGuest.MobileNumber;
                guestRequestModel.Address1 = hotelGuest.Address1;
                guestRequestModel.Address2 = hotelGuest.Address2;
                guestRequestModel.Country = hotelGuest.Country;
                guestRequestModel.State = hotelGuest.State;
                guestRequestModel.City = hotelGuest.City;
                guestRequestModel.ZipCode = hotelGuest.ZipCode;
                guestRequestModel.IsPrimaryGuest = hotelGuest.IsPrimaryGuest;
                guestRequestModel.IsGuestScanned = hotelGuest.IsGuestScanned;
            }

            var dialogName = hotelGuest == null ? "Add New Guest" : "Edit Guest";
            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true, Width = "1000px", };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<GuestForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelID", hotelID },
                { "guestRequestModel", guestRequestModel },
                //{ "selectedCountryId", selectedCountryId },
                { "IsDisabled", false },
                { "OnSubmit", EventCallback.Factory.Create<AddEditGuestWebAppModel>(this, HandleFormOnSubmitGuestDetail) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }

        private async Task HandleFormOnSubmitGuestDetail(AddEditGuestWebAppModel guestRequestModel)
        {
            await CheckDuplicateGuest(guestRequestModel);
            _dialogService.Close();
        }

        private async Task CheckDuplicateGuest(AddEditGuestWebAppModel guestRequestModel)
        {

            var serviceResponse = await OnAddUpdateGuestClick(hotelRoomBookingID, guestRequestModel);
            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Guest Detail saved successfully!");
                //_navigationManager.NavigateTo($"/booking-summary/{hotelID}/0");
                await GetHotelRoomBookingDetail();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving Guest detail.");
            }

            //var duplicateGuest = hotelRoomBookingServiceResponseData.Guests.FirstOrDefault(existingGuest => existingGuest.IdentityNumber == guestRequestModel.IdentityNumber);
            //if (duplicateGuest != null)
            //{
            //    _notificationAlertComponent.ShowNotification(NotificationSeverity.Warning, "", "This guest has already been added.");
            //}
            //else
            //{
            //    if (hotelRoomBookingServiceResponseData.Guests.Count == 0)
            //    {
            //        guestRequestModel.IsPrimaryGuest = true;
            //    }
            //    hotelRoomBookingServiceResponseData.Guests.Add(guestRequestModel);
            //    hotelRoomBookingServiceResponseData.Guests = hotelRoomBookingServiceResponseData.Guests.ToList();
            //}
            StateHasChanged();

        }
        private async Task CreateEditPaymentDetailDialog(AddEditHotelRoomPaymentWebAppModel? hotelRoomPayment, bool IsRefund)
        {
            var hotelRoomPaymentRequestModel = new AddEditHotelRoomPaymentWebAppModel();
            if (hotelRoomPayment != null)
            {

                hotelRoomPaymentRequestModel.PaymentID = hotelRoomPayment.PaymentID;
                hotelRoomPaymentRequestModel.HotelRoomBookingID = hotelRoomBookingID;
                hotelRoomPaymentRequestModel.PaymentMode = hotelRoomPayment.PaymentMode;
                hotelRoomPaymentRequestModel.PaymentType = hotelRoomPayment.PaymentType;
                hotelRoomPaymentRequestModel.PaymentGateway = hotelRoomPayment.PaymentGateway;
                hotelRoomPaymentRequestModel.TransactionID = hotelRoomPayment.TransactionID;
                //hotelRoomPaymentRequestModel.TransactionType = hotelRoomPayment.TransactionType;
                hotelRoomPaymentRequestModel.Amount = hotelRoomPayment.Amount;
                hotelRoomPaymentRequestModel.PaymentStatus = hotelRoomPayment.PaymentStatus;
                hotelRoomPaymentRequestModel.PaymentCompletedOn = hotelRoomPayment.PaymentCompletedOn;
                hotelRoomPaymentRequestModel.IsRefunded = hotelRoomPayment.IsRefunded;
                hotelRoomPaymentRequestModel.IsRefund = IsRefund;
                hotelRoomPaymentRequestModel.RefundDate = hotelRoomPayment.RefundDate;
                hotelRoomPaymentRequestModel.RefundAmount = hotelRoomPayment.RefundAmount;
                hotelRoomPaymentRequestModel.RefundNotes = hotelRoomPayment.RefundNotes;
            }



            var dialogName = IsRefund ? "Refund" : (hotelRoomPayment == null ? "Add Payment" : "Edit Payment");
            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true, Width = "700px", };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<PaymentDetailForm>(dialogName, new Dictionary<string, object>
            {
                { "finalAmount", hotelRoomBookingServiceResponseData.HotelRoomBookingRateDetails.Where(item => item.IsBookingActive).Sum(item => item.FinalAmount) },
                { "paidAmount",  hotelRoomBookingServiceResponseData.HotelRoomPayments.Where(payment => payment.PaymentStatus == PaymentStatusMessages.Completed).Sum(o => o.Amount) },
                { "hotelRoomPaymentRequestModel", hotelRoomPaymentRequestModel },
                { "IsRefund", IsRefund },
                { "OnSubmit", EventCallback.Factory.Create<AddEditHotelRoomPaymentWebAppModel>(this, HandleFormOnSubmitPaymentDetail) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }

        private async Task HandleFormOnSubmitPaymentDetail(AddEditHotelRoomPaymentWebAppModel hotelRoomPayment)
        {
            _dialogService.Close();

            OnSavePaymentClicked(hotelRoomPayment);

            //await CreateEditHotelAdditionalRate(hotelAdditionalRateRequestModel);
        }

        private async void OnSavePaymentClicked(AddEditHotelRoomPaymentWebAppModel hotelRoomPayment)
        {
            IsBusy = true;
            isLoading = true;
            if (hotelRoomPayment.IsRefund)
            {
                var serviceResponse = await OnSaveRefundClicked(hotelRoomPayment);
                if (serviceResponse.IsSuccessStatusCode)
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Refund save successfully!");
                    await GetHotelRoomBookingDetail();
                }
                else
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Info, "", "Refund request has been cancelled.");
                }
            }
            else
            {
                var bookingPaymentRequestModel = new AddEditHotelRoomPaymentWebAppModel
                {
                    PaymentID = hotelRoomPayment.PaymentID,
                    HotelRoomBookingID = hotelRoomBookingID,
                    Amount = hotelRoomPayment.Amount,
                    PaymentMode = hotelRoomPayment.PaymentMode,
                    PaymentType = hotelRoomPayment.PaymentType,
                    PaymentStatus = hotelRoomPayment.PaymentStatus,
                    TransactionID = hotelRoomPayment.TransactionID,
                    PaymentGateway = hotelRoomPayment.PaymentGateway,
                    PaymentNotes = hotelRoomPayment.PaymentNotes,
                    PaymentCompletedOn = hotelRoomPayment.PaymentCompletedOn

                };

                var serviceResponse = await OnSaveBookingPaymentClicked(bookingPaymentRequestModel);
                if (serviceResponse.IsSuccessStatusCode)
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Payment save successfully!");
                    await GetHotelRoomBookingDetail();
                }
                else
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Info, "", "Payment request has been cancelled.");
                }
            }
            //string paymentStatus = CheckPaymentStatus();

            //var existingPayment = hotelRoomBookingServiceResponseData.HotelRoomPayments.FirstOrDefault(item => item.PaymentID == hotelRoomPayment.PaymentID);
            //if (existingPayment != null)
            //{
            //    existingPayment.Amount = hotelRoomPayment.Amount;
            //    existingPayment.PaymentMode = hotelRoomPayment.PaymentMode;
            //    existingPayment.PaymentType = hotelRoomPayment.PaymentType;
            //    existingPayment.PaymentStatus = hotelRoomPayment.PaymentStatus;
            //    existingPayment.TransactionID = hotelRoomPayment.TransactionID;
            //    //existingPayment.TransactionType = hotelRoomPayment.TransactionType;
            //    existingPayment.PaymentGateway = hotelRoomPayment.PaymentGateway;
            //    existingPayment.PaymentNotes = hotelRoomPayment.PaymentNotes;
            //}
            //else
            //{
            //    var newRoomPayment = new AddEditHotelRoomPaymentWebAppModel
            //    {
            //        Amount = hotelRoomPayment.Amount,
            //        PaymentMode = hotelRoomPayment.PaymentMode,
            //        PaymentType = hotelRoomPayment.PaymentType,
            //        PaymentStatus = hotelRoomPayment.PaymentStatus,
            //        TransactionID = hotelRoomPayment.TransactionID,
            //        //TransactionType = hotelRoomPayment.TransactionType,
            //        PaymentGateway = hotelRoomPayment.PaymentGateway,
            //        PaymentNotes = hotelRoomPayment.PaymentNotes

            //    };
            //    hotelRoomBookingServiceResponseData.HotelRoomPayments.Add(newRoomPayment);
            //}

            //var newRoomPayment = new AddEditHotelRoomPaymentWebAppModel
            //{
            //    Amount = hotelRoomPayment.Amount,
            //    PaymentMode = hotelRoomPayment.PaymentMode,
            //    PaymentStatus = hotelRoomPayment.PaymentStatus,
            //    TransactionID = hotelRoomPayment.TransactionID,
            //    TransactionType = hotelRoomPayment.TransactionType,
            //    PaymentGateway = hotelRoomPayment.PaymentGateway,
            //    PaymentNotes = hotelRoomPayment.PaymentNotes

            //};
            //hotelRoomBookingServiceResponseData.HotelRoomPayments.Add(newRoomPayment);

            //hotelRoomBookingServiceResponseData.HotelRoomPayments = hotelRoomBookingServiceResponseData.HotelRoomPayments.ToList();
            // _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "Room Payment Added", "Room payment has been successfully added.");
            // hotelRoomBookingServiceResponseData.PaymentStatus = CheckPaymentStatus();
            isLoading = false;
            IsBusy = false;
            StateHasChanged();
        }

        //private string CheckPaymentStatus()
        //{
        //    // Calculate the remaining amount by subtracting total payments from final amount
        //    decimal? remainingAmount = hotelRoomBookingServiceResponseData.FinalAmount - hotelRoomBookingServiceResponseData.HotelRoomPayments.Sum(o => o.Amount);

        //    // Default payment status
        //    string paymentStatus = "No Payment Made";

        //    // Full Payment Completed
        //    if (remainingAmount == 0 && hotelRoomBookingServiceResponseData.HotelRoomPayments.Any())
        //    {
        //        paymentStatus = "Payment Completed";
        //    }
        //    // Payment Done (Overpayment)
        //    else if (remainingAmount < 0)
        //    {
        //        paymentStatus = "Payment Done"; // Or "Overpaid"
        //    }
        //    // Partial Payment
        //    else if (remainingAmount > 0 && hotelRoomBookingServiceResponseData.HotelRoomPayments.Any())
        //    {
        //        paymentStatus = "Partial Payment";
        //    }

        //    return paymentStatus;
        //}

        private async Task DownloadFileFromStream(byte[] pdf)
        {


            var fileStream = new MemoryStream(pdf);
            var fileName = "#BK" + hotelRoomBookingServiceResponseData.HotelRoomBookingID + "_Invoice.pdf";

            using var streamRef = new DotNetStreamReference(stream: fileStream);

            await _jsruntime.InvokeVoidAsync("downloadFileFromStream", fileName, streamRef);
        }

        private void HandleOnCancel()
        {
            _dialogService.Close();
        }

        private async Task OnSaveClicked()
        {
            IsBusySave = true;
            var serviceResponse = await OnUpdateBookingClick(hotelRoomBookingServiceResponseData);
            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Booking detail saved successfully!");
                //_navigationManager.NavigateTo($"/booking-summary/{hotelID}/0");
                await GetHotelRoomBookingDetail();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving Booking detail.");
            }

            IsBusySave = false;
            StateHasChanged();
        }

        private async Task OnSaveGuestRequest()
        {
            IsBusySave = true;
            var updateGuestRequest = new UpdateGuestRequestWebAppModel
            {
                HotelRoomBookingID = hotelRoomBookingServiceResponseData.HotelRoomBookingID,
                GuestSpecialRequests = hotelRoomBookingServiceResponseData.GuestSpecialRequests,
                GuestNoteType = hotelRoomBookingServiceResponseData.GuestNoteType,
                GuestNotes = hotelRoomBookingServiceResponseData.GuestNotes
            };
            var serviceResponse = await OnUpdateGuestRequestClick(updateGuestRequest);
            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Guest Request saved successfully!");
                //_navigationManager.NavigateTo($"/booking-summary/{hotelID}/0");
                await GetHotelRoomBookingDetail();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving Booking detail.");
            }

            IsBusySave = false;
            StateHasChanged();
        }

        private async void OnCheckInClicked(HotelRoomBookingWebAppModel hotelRoomBooking)
        {
            IsBusyCheckIn = true;
            int hotelRoomID = await OnCheckedInRoomSelectDialog(hotelID, hotelRoomBooking);
            if (hotelRoomID is 0)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Info, "", "Room check in request has been cancelled.");
            }
            else
            {
                var serviceResponse = await OnCheckInClick(hotelRoomBooking.HotelRoomBookingID, hotelRoomID);
                if (serviceResponse.IsSuccessStatusCode)
                {
                    //_navigationManager.NavigateTo($"/booking-summary/{hotelID}/1");
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Room check in successfully!");
                    await GetHotelRoomBookingDetail();
                }
                else
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while check in.");
                }
            }
            IsBusyCheckIn = false;
            StateHasChanged();
        }

        private async void OnRoomChangeClicked(HotelRoomBookingWebAppModel hotelRoomBooking)
        {
            IsBusyCheckIn = true;
            var selectedRoom = await OnRoomChangeSelectDialog(hotelID, hotelRoomBooking, true);
            if (selectedRoom == null)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Info, "", "Room change request has been cancelled.");
            }
            else
            {
                var roomChangeRequestModel = new RoomChangeWebAppModel
                {
                    HotelRoomBookingID = hotelRoomBooking.HotelRoomBookingID,
                    HotelRoomTypeID = selectedRoom.HotelRoomTypeID,
                    HotelRoomID = selectedRoom.HotelRoomID,
                    OldHotelRoomID = selectedRoom.OldHotelRoomID,
                };
                var serviceResponse = await OnRoomChangeClick(roomChangeRequestModel);
                if (serviceResponse.IsSuccessStatusCode)
                {
                    //_navigationManager.NavigateTo($"/booking-summary/{hotelID}/1");
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Room change successfully!");
                    await GetHotelRoomBookingDetail();
                }
                else
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while room change.");
                }
            }
            IsBusyCheckIn = false;
            StateHasChanged();
        }

        private async void OnExtendBookingClickeds(HotelRoomBookingWebAppModel hotelRoomBooking)
        {
            var roomExtend = await OnRoomBookingExtendDialog(hotelID, hotelRoomBooking, true);
            if (roomExtend == true)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Room extend successfully!");
                await GetHotelRoomBookingDetail();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Info, "", "Room Extend request has been cancelled.");
            }
            StateHasChanged();
        }

        private async void OnCheckOutClicked(HotelRoomBookingWebAppModel hotelRoomBooking)
        {
            IsBusyCheckOut = true;
            //var RemainAmount = hotelRoomBookingServiceResponseData.HotelRoomBookingRateDetails.Where(item => item.IsBookingActive).Sum(item => item.FinalAmount) - (hotelRoomBookingServiceResponseData.HotelRoomPayments.Where(item => item.PaymentStatus == PaymentStatusMessages.Completed).Sum(o => o.Amount) - hotelRoomBookingServiceResponseData.HotelRoomPayments.Where(payment => payment.IsRefunded).Sum(o => o.RefundAmount));
            //if (RemainAmount == 0)
            var RemainAmount = hotelRoomBookingServiceResponseData.HotelRoomBookingRateDetails.Where(item => item.IsExtend == false).FirstOrDefault().Balance;
            if (RemainAmount == 0)
            {
                var finalAmount = hotelRoomBookingServiceResponseData.HotelRoomBookingRateDetails.Where(item => item.IsBookingActive).Sum(item => item.FinalAmount);
                UpdateHotelRoomCleaningAuditWebAppModel checkOutComment = await OnCheckOutCommentDialog(finalAmount);
                if (checkOutComment is null)
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Info, "", "Room check out request has been cancelled.");
                }
                else
                {
                    var hotelRoomCleaningAuditRequestModel = new UpdateHotelRoomCleaningAuditWebAppModel
                    {
                        HotelRoomBookingID = hotelRoomBooking.HotelRoomBookingID,
                        HotelRoomID = hotelRoomBooking.HotelRoomID,
                        CheckOutComment = checkOutComment.CheckOutComment,
                        IsRewardPointGiven = checkOutComment.IsRewardPointGiven,
                        EarnedRewardPoint = checkOutComment.EarnedRewardPoint,

                    };

                    var serviceResponse = await OnCheckOutClick(hotelRoomCleaningAuditRequestModel);
                    if (serviceResponse.IsSuccessStatusCode)
                    {
                        //_navigationManager.NavigateTo($"/booking-summary/{hotelID}/4");
                        _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Room check out successfully!");
                        await GetHotelRoomBookingDetail();
                    }
                    else
                    {
                        _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while check out.");
                    }
                }
            }
            else if (RemainAmount < 0)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", "Refund is pending for this booking.");
                await _dialogService.Alert("Refund is pending for this booking!", "Checkout Failed", new AlertOptions() { OkButtonText = "Okay!" });
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", "Payment is pending for this booking.");
                await _dialogService.Alert("Payment is pending for this booking!", "Checkout Failed", new AlertOptions() { OkButtonText = "Okay!" });
            }
            IsBusyCheckOut = false;
            StateHasChanged();
        }

        private async void OnCancelledClicked(HotelRoomBookingWebAppModel hotelRoomBooking)
        {
            IsBusyCancel = true;
            var confirmationResult = await ConfirmCancel(hotelRoomBooking.BookingCode);
            if (confirmationResult == true)
            {
                string cancellationReason = await OnCancelledBookingNotesDialog();
                if (cancellationReason is null)
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Info, "", "Room cancellation request was not processed.");
                }
                else
                {
                    var serviceResponse = await OnCancelledClicked(hotelRoomBooking.HotelRoomBookingID, cancellationReason);
                    if (serviceResponse.IsSuccessStatusCode)
                    {
                        //_navigationManager.NavigateTo($"/booking-detail/{hotelID}/{hotelRoomBooking.HotelRoomBookingID}");
                        _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"{hotelRoomBooking.BookingCode} has been cancelled successfully!");
                        await GetHotelRoomBookingDetail();
                    }
                    else
                    {
                        _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while cancelling {hotelRoomBooking.BookingCode}.");
                    }
                }
            }
            IsBusyCancel = false;
            StateHasChanged();
        }

        private void OnAdditionalRateChanges()
        {
            // Check if the room rate is discounted or involves additional charges
            bool isDiscountedRate = initialRateDetail.IsDiscountedRate; // Discount flag
            decimal? rateAmount = initialRateDetail.AdditionalRateAmount / 100; // Convert rate to decimal percentage (e.g., 5 becomes 0.05)
            decimal? totalAmount = initialRateDetail.TotalAmount;

            if (isDiscountedRate)
            {
                // Apply discount (rateAmount is now in decimal form, e.g., 0.05 for 5% discount)
                decimal? discountAmount = totalAmount * rateAmount; // Calculate discount as percentage of total amount
                initialRateDetail.FinalAmount = totalAmount - discountAmount; // Subtract the discount
                rateExceptionAmount = discountAmount;
                //hotelRoomBookingRequestModel.DiscountedAmount = selectedRoomRateTax;
            }
            else
            {
                // Apply extra charges (rateAmount is now in decimal form, e.g., 0.05 for extra 5% charge)
                decimal? extraCharges = totalAmount * rateAmount; // Calculate extra charge as percentage of total amount
                initialRateDetail.FinalAmount = totalAmount + extraCharges; // Add the extra charge
                rateExceptionAmount = extraCharges;
                //hotelRoomBookingRequestModel.AdditionalRateAmount = selectedRoomRateTax;
            }

            // Ensure the total is not negative
            if (initialRateDetail.TotalAmount < 0)
            {
                initialRateDetail.TotalAmount = 0;
            }
            StateHasChanged();
        }
        private void OnBackClicked()
        {
            _navigationManager.NavigateTo($"/");
        }

        private async void OnViewExtendHistoryClicked(ICollection<HotelRoomBookingRateDetailWebAppModel> hotelRoomBookingRateDetailData, bool isHourly)
        {
            var rateDetailList = hotelRoomBookingRateDetailData.ToList();
            await OnViewExtendHistoryDialog(rateDetailList, isHourly);
        }

        private async void OnViewBookingAuditClicked(ICollection<HotelRoomBookingAuditWebAppModel> hotelRoomBookingAuditData)
        {
            var bookingAuditList = hotelRoomBookingAuditData.OrderByDescending(item => item.ActionDateTime).ToList();
            await OnViewBookingAuditDialog(bookingAuditList);
        }

        private async void OnEarlyCheckOutClicked(HotelRoomBookingRateDetailWebAppModel hotelRoomBookingRateDetail, bool IsHourly)
        {
            var roomExtend = await OnEarlyCheckOutDialog(hotelID, hotelRoomBookingRateDetail, IsHourly);
            if (roomExtend == true)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Room extend successfully!");
                await GetHotelRoomBookingDetail();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Info, "", "Room Extend request has been cancelled.");
            }
            StateHasChanged();
        }

        private async void OnReportFlagClicked(int hotelRoomBookingID, bool isIncludedInReport)
        {
            var confirmationResult = await OnReportFlagClickDialog(isIncludedInReport);
            if (confirmationResult == true)
            {
                var serviceResponse = await OnReportFlagClick(hotelRoomBookingID, isIncludedInReport);
                if (serviceResponse.IsSuccessStatusCode)
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Booking Detail updated Successfully!");
                    await GetHotelRoomBookingDetail();
                }
                else
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while updating Booking Detail.");
                }
            }
            else
            {
                hotelRoomBookingServiceResponseData.IsIncludedInReport = !isIncludedInReport;
            }
            StateHasChanged();
        }

        private async void OnCheckOutDateChangeClick()
        {
            var rateDetailList = hotelRoomBookingServiceResponseData.HotelRoomBookingRateDetails.ToList();
            var checkoutDateChange = await OnCheckOutDateChangeClickDialog(hotelID, rateDetailList, hotelRoomBookingServiceResponseData.ScheduledCheckInDate, hotelRoomBookingServiceResponseData.ScheduledCheckOutDate);
            if (checkoutDateChange == true)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"CheckOut date changed successfully!");
                await GetHotelRoomBookingDetail();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Info, "", "CheckOut date change request has been cancelled.");
            }
            StateHasChanged();
        }

        #endregion

        #region API service calls
        private async Task GetHotelConfiguration()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelConfiguration(hotelID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseHotelConfigurationData = serviceResponse.Content;
            }
            else
            {
                serviceResponseHotelConfigurationData = new HotelConfigurationWebAppModel(); // Initialize as empty list if null
            }

            isLoading = false;
            StateHasChanged();
        }

        private async Task GetHotelDailyRate()
        {

            isLoading = true;
            DateOnly checkInDate = DateOnly.FromDateTime(hotelRoomBookingServiceResponseData.ScheduledCheckOutDate.Value);

            var serviceResponse = await _hotelRoomBookingWebAppService.GetHotelDailyRateByDate(hotelID, checkInDate);
            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {
                serviceResponseHotelDailyRateData = serviceResponse.Content;
            }
            else
            {
                serviceResponseHotelDailyRateData = new HotelDailyRateWebAppModel(); // Initialize as empty list if null
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task GetHotelHourlyRate()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelHourlyRate(hotelID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseHotelHourlyRateDataList = serviceResponse.Content;
            }
            else
            {
                serviceResponseHotelHourlyRateDataList = new List<HotelHourlyRateWebAppModel>(); // Initialize as empty list if null
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task GetHotelRoomBookingDetail()
        {
            isLoading = true;
            var serviceResponse = await _hotelRoomBookingWebAppService.GetRoomBookingDetailsByID(hotelRoomBookingID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                hotelRoomBookingServiceResponseData = serviceResponse.Content;
                initialRateDetail = hotelRoomBookingServiceResponseData.HotelRoomBookingRateDetails.FirstOrDefault(r => r.IsExtend == false);
                //hotelRoomBookingServiceResponseData.IsDiscountedRate = initialRateDetail.IsDiscountedRate;
                //hotelRoomBookingServiceResponseData.AdditionalRateType = initialRateDetail.AdditionalRateType;
                //hotelRoomBookingServiceResponseData.AdditionalRateAmount = initialRateDetail.AdditionalRateAmount;
                //hotelRoomBookingServiceResponseData.MiscellaneousAmount = initialRateDetail.MiscellaneousAmount;
                //hotelRoomBookingServiceResponseData.FinalAmount = initialRateDetail.FinalAmount;
                if (!string.IsNullOrEmpty(initialRateDetail.AdditionalRateType) && initialRateDetail.AdditionalRateAmount.HasValue && initialRateDetail.AdditionalRateAmount.Value != 0)
                {
                    OnAdditionalRateChanges();
                }
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while getting Booking data '{serviceResponse.Error}'.");
                hotelRoomBookingServiceResponseData = new HotelRoomBookingWebAppModel();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task DownloadBookingInvoice()
        {
            IsBusyDownloadBookingInvoice = true;
            var serviceResponse = await _hotelReportWebAppService.DownloadBookingInvoice(hotelRoomBookingID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                byte[] serviceResponseData = serviceResponse.Content;
                await DownloadFileFromStream(serviceResponseData);
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Invoice downloaded successfully!");
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while downloading invoice: '{serviceResponse.Error}'.");
            }
            IsBusyDownloadBookingInvoice = false;
            StateHasChanged();
        }

        private async Task PrintBookingReceipt()
        {
            IsBusyPrintBookingReceipt = true;

            // Downloading the receipt byte array
            var serviceResponse = await _hotelReportWebAppService.PrintBookingReceipt(hotelRoomBookingID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                byte[] serviceResponseData = serviceResponse.Content;

                // Convert byte array to string (HTML content)
                string base64Data = Convert.ToBase64String(serviceResponseData);
                // Trigger print via JavaScript
                await _jsruntime.InvokeVoidAsync("printPDF", base64Data);

            }
            else
            {
                // Notification of failure
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while printing booking receipt: '{serviceResponse.Error}'.");
            }

            IsBusyPrintBookingReceipt = false;
            StateHasChanged();
        }


        #endregion
    }
}
