﻿using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking
{
    public partial class ViewBookingAuditForm : ComponentBase
    {
        #region Parameter
        [Parameter] public List<HotelRoomBookingAuditWebAppModel> hotelRoomBookingAuditData { get; set; }

        #endregion
    }
}
