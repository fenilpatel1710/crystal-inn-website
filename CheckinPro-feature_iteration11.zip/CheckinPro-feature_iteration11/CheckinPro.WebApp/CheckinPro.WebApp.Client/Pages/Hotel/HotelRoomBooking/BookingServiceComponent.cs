﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;
using Refit;
using System.Threading.Tasks;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking
{
    public partial class BookingServiceComponent : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelRoomBookingWebAppService _hotelRoomBookingWebAppService { get; set; }
        [Inject] private IHotelWebAppService _hotelWebAppService { get; set; }
        [Inject] private DialogService _dialogService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }

        #endregion

        #region Parameter

        #endregion

        #region OnRender Method Starts
        public async Task<ApiResponse<int>> OnBookedClick(HotelRoomBookingWebAppModel hotelRoomBookingRequestModel)
        {
            var serviceResponse = await CreateHotelRoomBooking(hotelRoomBookingRequestModel);
            return serviceResponse;
        }
        public async Task<ApiResponse<bool>> OnUpdateBookingClick(HotelRoomBookingWebAppModel hotelRoomBookingRequestModel)
        {
            var serviceResponse = await UpdateHotelRoomBooking(hotelRoomBookingRequestModel);
            return serviceResponse;
        }
        public async Task<ApiResponse<bool>> OnUpdateTotalAmountClick(HotelRoomBookingRateDetailWebAppModel hotelRoomBookingRateDetailRequestModel)
        {
            var serviceResponse = await UpdateHotelRoomBookingTotalAmount(hotelRoomBookingRateDetailRequestModel);
            return serviceResponse;
        }
        public void NavigateToBookingDetail(int hotelID, int hotelRoomBookingID)
        {
            if (hotelRoomBookingID > 0)
            {
                _navigationManager.NavigateTo($"/booking-detail/{hotelID}/{hotelRoomBookingID}");
            }
        }
        public async Task<ApiResponse<bool>> OnCheckInClick(int hotelRoomBookingID, int hotelRoomID)
        {
            var serviceResponse = await RoomCheckIn(hotelRoomBookingID, hotelRoomID);
            return serviceResponse;
        }
        public async Task<ApiResponse<bool>> OnReportFlagClick(int hotelRoomBookingID, bool isIncludedInReport)
        {
            var serviceResponse = await UpdateBookingReportFlag(hotelRoomBookingID, isIncludedInReport);
            return serviceResponse;
        }
        public async Task<bool?> OnReportFlagClickDialog(bool isIncludedInReport)
        {
            var result = await _dialogService.Confirm(
                $"Are you sure you want to " + (isIncludedInReport ? "Include Booking in Daily Report?" : "Exclude Booking from Daily Report?"),
                "Confirm",
                new ConfirmOptions() { OkButtonText = "Yes", CancelButtonText = "No", ShowClose = false });

            return result;
        }

        public async Task<ApiResponse<bool>> OnRoomChangeClick(RoomChangeWebAppModel roomChangeRequestModel)
        {
            var serviceResponse = await RoomChange(roomChangeRequestModel);
            return serviceResponse;
        }

        public async Task<RoomChangeWebAppModel> OnRoomChangeSelectDialog(int hotelID, HotelRoomBookingWebAppModel hotelRoomBookingRequestModel, bool IsRoomChange)
        {
            var dialogName = "Change Room for booking " + hotelRoomBookingRequestModel.BookingCode;
            var dialogOptions = new SideDialogOptions { CloseDialogOnOverlayClick = false, ShowClose = true, Width = "700px", Position = DialogPosition.Right, ShowMask = true };

            var dialogParameters = new Dictionary<string, object>
            {
                { "hotelID", hotelID },
                { "hotelRoomBookingRequestModel", hotelRoomBookingRequestModel },
                { "IsRoomChange", IsRoomChange }
            };

            var dialogResult = await _dialogService.OpenSideAsync<RoomChangeForm>(dialogName, dialogParameters, options: dialogOptions);

            return dialogResult;
        }
        public async Task<ApiResponse<bool>> OnCheckOutClick(UpdateHotelRoomCleaningAuditWebAppModel hotelRoomCleaningAuditRequestModel)
        {
            var serviceResponse = await RoomCheckOut(hotelRoomCleaningAuditRequestModel);
            return serviceResponse;
        }
        public async Task<ApiResponse<bool>> OnCancelledClicked(int hotelRoomBookingID, string cancellationReason)
        {
            var serviceResponse = await RoomCancel(hotelRoomBookingID, cancellationReason);
            return serviceResponse;
        }

        public async Task<bool> OnRoomBookingExtendDialog(int hotelID, HotelRoomBookingWebAppModel hotelRoomBookingRequestModel, bool IsRoomChange)
        {
            var dialogName = "Extend booking for " + hotelRoomBookingRequestModel.BookingCode;
            var dialogOptions = new SideDialogOptions { CloseDialogOnOverlayClick = false, ShowClose = true, Width = "700px", Position = DialogPosition.Right, ShowMask = true };

            var dialogParameters = new Dictionary<string, object>
            {
                { "hotelID", hotelID },
                { "hotelRoomBookingRequestModel", hotelRoomBookingRequestModel }
            };

            var dialogResult = await _dialogService.OpenSideAsync<ExtendBookingForm>(dialogName, dialogParameters, options: dialogOptions);

            return dialogResult;
        }
        public async Task<ApiResponse<bool>> OnRoomExtendClick(HotelRoomBookingWebAppModel hotelRoomBookingRequestModel)
        {
            var serviceResponse = await RoomExtend(hotelRoomBookingRequestModel);
            return serviceResponse;
        }

        public async Task<int> OnCheckedInRoomSelectDialog(int hotelID, HotelRoomBookingWebAppModel hotelRoomBookingRequestModel)
        {
            var dialogName = "Select Room for booking " + hotelRoomBookingRequestModel.BookingCode;
            var dialogOptions = new SideDialogOptions { CloseDialogOnOverlayClick = false, ShowClose = false, Width = "700px", Position = DialogPosition.Right, ShowMask = true };

            var dialogParameters = new Dictionary<string, object>
            {
                { "hotelID", hotelID },
                { "hotelRoomBookingRequestModel", hotelRoomBookingRequestModel }
            };

            var dialogResult = await _dialogService.OpenSideAsync<AvailableRoomListCheckInForm>(dialogName, dialogParameters, options: dialogOptions);

            return dialogResult;
        }
        public async Task<UpdateHotelRoomCleaningAuditWebAppModel> OnCheckOutCommentDialog(decimal? BookingAmount)
        {
            var dialogName = "Any CheckOut Comment";
            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true, ShowClose = false };
            var dialogParameters = new Dictionary<string, object>
            {
                { "BookingAmount", BookingAmount }
            };
            var dialogResult = await _dialogService.OpenAsync<CheckOutCommentForm>(
                dialogName,
                dialogParameters,
                dialogOptions
            );

            return dialogResult;
        }
        public async Task<bool?> ConfirmCancel(string BookingCode)
        {
            var result = await _dialogService.Confirm(
                $"Are you sure you want to cancel the booking <strong>'{BookingCode}'</strong>?",
                "Confirm Cancel",
                new ConfirmOptions() { OkButtonText = "Yes", CancelButtonText = "No", ShowClose = false });

            return result;
        }
        public async Task<string> OnCancelledBookingNotesDialog()
        {
            var dialogName = "Enter Cancellation Reason";
            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true, ShowClose = false };

            var dialogResult = await _dialogService.OpenAsync<CancellationReasonForm>(
                dialogName,
                null,
                dialogOptions
            );

            return dialogResult;
        }

        public async Task<ApiResponse<bool>> OnSaveMiscellaneousAmountClicked(AddEditMiscAmountWebAppModel addEditMiscAmountRequestModel)
        {
            var serviceResponse = await AddEditMiscAmount(addEditMiscAmountRequestModel);
            return serviceResponse;
        }

        public async Task<ApiResponse<bool>> OnSaveBookingPaymentClicked(AddEditHotelRoomPaymentWebAppModel bookingPaymentRequestModel)
        {
            var serviceResponse = await AddEditBookingPayment(bookingPaymentRequestModel);
            return serviceResponse;
        }

        public async Task<ApiResponse<bool>> OnSaveRefundClicked(AddEditHotelRoomPaymentWebAppModel bookingPaymentRequestModel)
        {
            var serviceResponse = await RoomRefund(bookingPaymentRequestModel);
            return serviceResponse;
        }

        public async Task<ApiResponse<bool>> OnUpdateGuestRequestClick(UpdateGuestRequestWebAppModel hotelRoomBookingRequestModel)
        {
            var serviceResponse = await UpdateGuestRequest(hotelRoomBookingRequestModel);
            return serviceResponse;
        }

        public async Task<ApiResponse<bool>> OnAddUpdateGuestClick(int hotelRoomBookingID, AddEditGuestWebAppModel guestRequestModel)
        {
            var serviceResponse = await AddUpdateGuest(hotelRoomBookingID, guestRequestModel);
            return serviceResponse;
        }

        public async Task<RoomChangeWebAppModel> OnViewExtendHistoryDialog(List<HotelRoomBookingRateDetailWebAppModel> hotelRoomBookingRateDetailData, bool isHourly)
        {
            var dialogName = "Extend History";
            var dialogOptions = new SideDialogOptions { CloseDialogOnOverlayClick = false, ShowClose = true, Width = "700px", Position = DialogPosition.Right, ShowMask = true };

            var dialogParameters = new Dictionary<string, object>
            {
                { "hotelRoomBookingRateDetailRequestModel", hotelRoomBookingRateDetailData },
                { "isHourly", isHourly }
            };

            var dialogResult = await _dialogService.OpenSideAsync<ViewExtendHistoryForm>(dialogName, dialogParameters, options: dialogOptions);

            return dialogResult;
        }

        public async Task<string> OnViewBookingAuditDialog(List<HotelRoomBookingAuditWebAppModel> hotelRoomBookingAuditData)
        {
            var dialogName = "Booking Audit";
            var dialogOptions = new SideDialogOptions { CloseDialogOnOverlayClick = true, ShowClose = true, Width = "700px", Position = DialogPosition.Right, ShowMask = true };

            var dialogParameters = new Dictionary<string, object>
            {
                { "hotelRoomBookingAuditData", hotelRoomBookingAuditData },
            };

            var dialogResult = await _dialogService.OpenSideAsync<ViewBookingAuditForm>(dialogName, dialogParameters, options: dialogOptions);

            return dialogResult;
        }

        public async Task<bool> OnEarlyCheckOutDialog(int hotelID, HotelRoomBookingRateDetailWebAppModel hotelRoomBookingRateDetailRequestModel, bool IsHourly)
        {
            var dialogName = "Early CheckOut";
            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = false, ShowClose = true };

            var dialogResult = await _dialogService.OpenAsync<EarlyCheckOutForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelID", hotelID },
                { "hotelRoomBookingRateDetailRequestModel", hotelRoomBookingRateDetailRequestModel },
                { "IsHourly", IsHourly },

            }, dialogOptions);

            return dialogResult;
        }

        public async Task<bool> OnCheckOutDateChangeClickDialog(int hotelID, List<HotelRoomBookingRateDetailWebAppModel> bookingRateDetailList, DateTime? startDate, DateTime? endDate)
        {
            var dialogName = "Change CheckOut Date";
            var dialogOption = new DialogOptions { CloseDialogOnOverlayClick = false, ShowClose = true };

            var dialogResult = await _dialogService.OpenAsync<CheckoutDateChangeForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelID", hotelID },
                {"bookingRateDetailList", bookingRateDetailList },
                {"startDate", startDate },
                {"endDate", endDate }
            }, dialogOption);

            return dialogResult;
        }

        #endregion

        #region API service calls

        private async Task<ApiResponse<List<HotelRoomTypeWebAppModel>>> GetAvailableRoomTypes(int hotelID, HotelRoomBookingWebAppModel hotelRoomBookingRequestModel)
        {

            var serviceResponse = await _hotelRoomBookingWebAppService.GetAvailableRoomTypes(hotelID, hotelRoomBookingRequestModel.ScheduledCheckInDate.Value, hotelRoomBookingRequestModel.ScheduledCheckOutDate.Value);
            return serviceResponse;
        }

        private async Task<ApiResponse<List<HotelTaxRateWebAppModel>>> GetHotelTaxRate(int hotelID)
        {
            var serviceResponse = await _hotelWebAppService.GetHotelTaxRate(hotelID);
            return serviceResponse;
        }

        private async Task<ApiResponse<HotelConfigurationWebAppModel>> GetHotelConfiguration(int hotelID)
        {
            var serviceResponse = await _hotelWebAppService.GetHotelConfiguration(hotelID);
            return serviceResponse;
        }

        private async Task<ApiResponse<HotelDailyRateWebAppModel>> GetHotelDailyRate(int hotelID, HotelRoomBookingWebAppModel hotelRoomBookingRequestModel)
        {
            DateOnly checkInDate = DateOnly.FromDateTime(hotelRoomBookingRequestModel.ScheduledCheckInDate.Value);
            var serviceResponse = await _hotelRoomBookingWebAppService.GetHotelDailyRateByDate(hotelID, checkInDate);
            return serviceResponse;
        }

        private async Task<ApiResponse<List<HotelHourlyRateWebAppModel>>> GetHotelHourlyRate(int hotelID)
        {
            var serviceResponse = await _hotelWebAppService.GetHotelHourlyRate(hotelID);
            return serviceResponse;
        }

        public async Task<ApiResponse<int>> CreateHotelRoomBooking(HotelRoomBookingWebAppModel hotelRoomBookingRequestModel)
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.AddHotelRoomBooking(hotelRoomBookingRequestModel);
            return serviceResponse;
        }

        private async Task<ApiResponse<bool>> UpdateHotelRoomBooking(HotelRoomBookingWebAppModel hotelRoomBookingRequestModel)
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.UpdateHotelRoomBooking(hotelRoomBookingRequestModel);
            return serviceResponse;
        }

        private async Task<ApiResponse<bool>> UpdateHotelRoomBookingTotalAmount(HotelRoomBookingRateDetailWebAppModel hotelRoomBookingRateDetailRequestModel)
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.UpdateHotelRoomBookingTotalAmount(hotelRoomBookingRateDetailRequestModel);
            return serviceResponse;
        }

        private async Task<ApiResponse<bool>> RoomCheckIn(int hotelRoomBookingID, int hotelRoomID)
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.RoomCheckIn(hotelRoomBookingID, hotelRoomID);
            return serviceResponse;
        }

        private async Task<ApiResponse<bool>> RoomChange(RoomChangeWebAppModel roomChangeRequestModel)
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.RoomChange(roomChangeRequestModel);
            return serviceResponse;
        }

        public async Task<ApiResponse<bool>> RoomCheckOut(UpdateHotelRoomCleaningAuditWebAppModel hotelRoomCleaningAuditRequestModel)
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.RoomCheckOut(hotelRoomCleaningAuditRequestModel);
            return serviceResponse;
        }

        public async Task<ApiResponse<bool>> RoomRefund(AddEditHotelRoomPaymentWebAppModel bookingPaymentRequestModel)
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.RoomRefund(bookingPaymentRequestModel);
            return serviceResponse;
        }

        private async Task<ApiResponse<bool>> RoomExtend(HotelRoomBookingWebAppModel hotelRoomBookingRequestModel)
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.RoomExtend(hotelRoomBookingRequestModel);
            return serviceResponse;
        }

        private async Task<ApiResponse<bool>> RoomCancel(int hotelRoomBookingID, string cancellationReason)
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.RoomCancel(hotelRoomBookingID, cancellationReason);
            return serviceResponse;
        }

        private async Task<ApiResponse<bool>> AddEditMiscAmount(AddEditMiscAmountWebAppModel addEditMiscAmountRequestModel)
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.AddEditMiscAmount(addEditMiscAmountRequestModel);
            return serviceResponse;
        }

        private async Task<ApiResponse<bool>> AddEditBookingPayment(AddEditHotelRoomPaymentWebAppModel bookingPaymentRequestModel)
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.AddEditBookingPayment(bookingPaymentRequestModel);
            return serviceResponse;
        }

        private async Task<ApiResponse<bool>> UpdateGuestRequest(UpdateGuestRequestWebAppModel hotelRoomBookingRequestModel)
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.UpdateGuestRequest(hotelRoomBookingRequestModel);
            return serviceResponse;
        }

        private async Task<ApiResponse<bool>> AddUpdateGuest(int hotelRoomBookingID, AddEditGuestWebAppModel guestRequestModel)
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.AddUpdateGuest(hotelRoomBookingID, guestRequestModel);
            return serviceResponse;
        }

        private async Task<ApiResponse<bool>> UpdateBookingReportFlag(int hotelRoomBookingID, bool isIncludedInReport)
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.UpdateBookingReportFlag(hotelRoomBookingID, isIncludedInReport);
            return serviceResponse;
        }



        #endregion
    }
}
