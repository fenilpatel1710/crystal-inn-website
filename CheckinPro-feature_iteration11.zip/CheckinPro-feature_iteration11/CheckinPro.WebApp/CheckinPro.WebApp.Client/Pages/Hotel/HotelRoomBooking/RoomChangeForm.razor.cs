﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Models;
using CheckinPro.WebApp.Models.HotelRoomBooking;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking
{
    public partial class RoomChangeForm : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelRoomBookingWebAppService _hotelRoomBookingWebAppService { get; set; }
        [Inject] private DialogService _dialogService { get; set; }
        #endregion

        #region Parameter
        [Parameter] public int hotelID { get; set; } = 0;
        [Parameter] public HotelRoomBookingWebAppModel hotelRoomBookingRequestModel { get; set; } = new();
        [Parameter] public bool IsRoomChange { get; set; } = false;
        public bool isLoading { get; set; } = true;
        public RoomChangeWebAppModel roomChangeRequestModel { get; set; } = new();
        private List<HotelRoomWebAppModel> serviceResponseHotelRoomDataList { get; set; } = new();

        #endregion
        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            await GetAvailableRoomByDates();

            isLoading = false;
            StateHasChanged();
        }

        private async Task HandleFormOnSubmit()
        {
            _dialogService.CloseSide(roomChangeRequestModel);
            //await OnSubmit.InvokeAsync(hotelRoomBookingRequestModel);
        }

        private void HandleOnCancel()
        {
            roomChangeRequestModel = null;
            _dialogService.CloseSide(roomChangeRequestModel);
        }

        private void SelectRoomChange(HotelRoomWebAppModel hotelRoomWebAppModel)
        {
            roomChangeRequestModel.HotelRoomTypeID = hotelRoomWebAppModel.HotelRoomTypeID;
            roomChangeRequestModel.HotelRoomID = hotelRoomWebAppModel.HotelRoomID;
            roomChangeRequestModel.OldHotelRoomID = hotelRoomBookingRequestModel.HotelRoomID;
            roomChangeRequestModel.RoomNumber = hotelRoomWebAppModel.RoomNumber;
            StateHasChanged();
        }

        private string GetCardClass(int hotelRoomID)
        {
            // If this card is selected, apply the 'selected' class (green color)
            return roomChangeRequestModel.HotelRoomID == hotelRoomID ? "rz-border-radius-3 rz-my-1 rz-link rz-ripple rz-background-color-success-light" : "rz-border-radius-3 rz-my-1 rz-link rz-ripple rz-base-100";
        }

        private void OnHotelRoomTypeChange(int? hotelRoomTypeID)
        {
            if (hotelRoomTypeID.HasValue)
            {
                hotelRoomBookingRequestModel.HotelRoomTypeID = hotelRoomTypeID.Value;
            }
        }

        private async Task searchAvailableRoom()
        {
            isLoading = true;
            await GetAvailableRoomByDates();
            isLoading = false;
            StateHasChanged();
        }
        #endregion


        #region API service calls
        private async Task GetAvailableRoomByDates()
        {
            var serviceResponse = await _hotelRoomBookingWebAppService.GetAvailableRoomByDates(hotelID, hotelRoomBookingRequestModel.HotelRoomTypeID, hotelRoomBookingRequestModel.ScheduledCheckInDate, hotelRoomBookingRequestModel.ScheduledCheckOutDate);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseHotelRoomDataList = serviceResponse.Content;
            }
            else
            {
                serviceResponseHotelRoomDataList = new List<HotelRoomWebAppModel>(); // Initialize as empty list if null
            }
        }
        #endregion
    }
}
