﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;
using Refit;
using System.Threading.Tasks;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking
{
    public partial class EarlyCheckOutForm : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelRoomBookingWebAppService _hotelRoomBookingWebAppService { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion


        #region Parameter
        [Parameter] public int hotelID { get; set; } = 0;
        [Parameter] public HotelRoomBookingRateDetailWebAppModel hotelRoomBookingRateDetailRequestModel { get; set; } = new();
        [Parameter] public bool IsHourly { get; set; }

        public bool isLoading { get; set; } = true;

        private string BookingDuration = string.Empty;

        private DateTime? MaxCheckoutDate;

        private bool isCalculateRoomRate = false;

        private List<HotelHourlyRateWebAppModel> serviceResponseHotelHourlyRateDataList { get; set; } = new();
        private List<HotelTaxRateWebAppModel> serviceResponseHotelTaxRateDataList { get; set; } = new();

        #endregion

        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            MaxCheckoutDate = hotelRoomBookingRateDetailRequestModel.CheckOutDate;
            isLoading = false;
            StateHasChanged();
        }

        private DateTime GetCheckOutMinDate()
        {
            if (hotelRoomBookingRateDetailRequestModel.CheckInDate.Value.Date >= DateTime.Now.Date)
                return hotelRoomBookingRateDetailRequestModel.CheckInDate.Value.Date;
            else
                return DateTime.Now.Date;
        }

        private void OnCheckOutDateChange(DateTime? value)
        {
            if (value.HasValue && value.Value >= hotelRoomBookingRateDetailRequestModel.CheckInDate)
            {
                // Set the selected checkout date and set the time to 11:30 AM
                hotelRoomBookingRateDetailRequestModel.CheckOutDate = value.Value.Date.AddHours(11);
            }
            else
            {
                // Default to check-in date + 1 day and set time to 11:30 AM
                hotelRoomBookingRateDetailRequestModel.CheckOutDate = hotelRoomBookingRateDetailRequestModel.CheckInDate.Value.AddDays(1).Date.AddHours(11);
            }

            // Optionally, call any other necessary function like OnDateChange
            OnDateChange();
        }
        private void OnCheckOutHoursChange(object args)
        {
            int? checkOutHours = args as int?;

            // Ensure check-out hours value is valid
            if (checkOutHours.HasValue && checkOutHours.Value != 0)
            {
                // Only update the check-out date, NOT the check-in date
                hotelRoomBookingRateDetailRequestModel.CheckOutDate = hotelRoomBookingRateDetailRequestModel.CheckInDate.Value.AddHours((double)checkOutHours);

                // Find the hourly rate based on the selected check-out hours
                var matchedRate = serviceResponseHotelHourlyRateDataList
                                   .FirstOrDefault(rate => rate.Hour == checkOutHours);

                if (matchedRate != null)
                {
                    hotelRoomBookingRateDetailRequestModel.HourlyRate = matchedRate.HourlyRate;
                }
                else
                {
                    hotelRoomBookingRateDetailRequestModel.HourlyRate = null;
                }
            }
            else
            {
                // If no valid value for check-out hours, default to 1 hour
                hotelRoomBookingRateDetailRequestModel.CheckOutDate = hotelRoomBookingRateDetailRequestModel.CheckInDate.Value.AddHours(1);
            }

            // Ensure we don't modify the check-in date here
            OnDateChange();
        }
        private async void OnDateChange()
        {
            isCalculateRoomRate = false;
            if (hotelRoomBookingRateDetailRequestModel.CheckInDate != DateTime.MinValue && hotelRoomBookingRateDetailRequestModel.CheckOutDate != DateTime.MinValue)
            {
                var checkIn = hotelRoomBookingRateDetailRequestModel.CheckInDate.Value;
                var checkOut = hotelRoomBookingRateDetailRequestModel.CheckOutDate.Value;

                if (IsHourly == false) // Days
                {
                    var duration = checkOut.Date - checkIn.Date;
                    if (duration.TotalDays >= 1)
                    {
                        hotelRoomBookingRateDetailRequestModel.Duration = Convert.ToInt32(Math.Floor(duration.TotalDays));
                        BookingDuration = $"{Math.Floor(duration.TotalDays)} Day(s)";
                        //IsSearchDisabled = false;
                    }
                    else
                    {
                        BookingDuration = "Invalid duration for days booking.";
                        //IsSearchDisabled = true;
                    }
                }
                else if (IsHourly == true) // Hourly
                {
                    var duration = checkOut - checkIn;
                    if (duration.TotalHours >= 1)
                    {
                        hotelRoomBookingRateDetailRequestModel.Duration = Convert.ToInt32(Math.Floor(duration.TotalHours));
                        BookingDuration = $"{Math.Floor(duration.TotalHours)} Hour(s)";
                        // IsSearchDisabled = false;
                    }
                    else if (duration.TotalMinutes >= 1)
                    {
                        hotelRoomBookingRateDetailRequestModel.Duration = Convert.ToInt32(Math.Floor(duration.TotalMinutes));
                        BookingDuration = $"{Math.Floor(duration.TotalMinutes)} Minute(s)";
                        //IsSearchDisabled = false;
                    }
                    else
                    {
                        BookingDuration = "Invalid duration for hourly booking.";
                        //IsSearchDisabled = true;
                    }
                }
            }
            StateHasChanged();
        }

        private async void OnSearchClicked()
        {
            isLoading = true;
            await CalculateRoomRate();
            isCalculateRoomRate = true;
            isLoading = false;
            StateHasChanged();
        }

        private async Task CalculateRoomRate()
        {
            decimal? RoomRate = 0;
            OnDateChange();
            //await GetHotelConfiguration();
            //await GetAvailableRoomTypes();

            if (hotelRoomBookingRateDetailRequestModel.HotelRoomBookingTaxRates.Any())
            {
                serviceResponseHotelTaxRateDataList = hotelRoomBookingRateDetailRequestModel.HotelRoomBookingTaxRates.Select(h => new HotelTaxRateWebAppModel
                {
                    HotelTaxRateID = h.HotelTaxRateID ?? 0,
                    TaxName = h.BookingTaxRateName,
                    TaxRate = h.BookingTaxRatePercentage,
                }).ToList();
            }

            if (hotelRoomBookingRateDetailRequestModel.CheckInDate != DateTime.MinValue && hotelRoomBookingRateDetailRequestModel.CheckOutDate != DateTime.MinValue)
            {
                // Calculate the duration
                var checkIn = hotelRoomBookingRateDetailRequestModel.CheckInDate.Value;
                var checkOut = hotelRoomBookingRateDetailRequestModel.CheckOutDate.Value;
                var duration = checkOut - checkIn;
                decimal bookingDuration = (decimal)Math.Floor(duration.TotalDays);
                bookingDuration = bookingDuration < 1 ? 1 : bookingDuration;


                // Check if the booking duration is valid
                if (duration.TotalDays <= 0)
                {
                    hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = 0; // Invalid duration
                    hotelRoomBookingRateDetailRequestModel.TotalAmount = 0; // Reset final amount
                    hotelRoomBookingRateDetailRequestModel.FinalAmount = 0; // Reset final amount
                    return;
                }

                if (hotelRoomBookingRateDetailRequestModel?.AdjustmentRate.HasValue == true)
                {
                    RoomRate += hotelRoomBookingRateDetailRequestModel.AdjustmentRate;
                }

                if (IsHourly == false)
                {
                    RoomRate += hotelRoomBookingRateDetailRequestModel.BestAvailableRate;

                }
                else if (IsHourly == true)
                {
                    RoomRate += hotelRoomBookingRateDetailRequestModel.HourlyRate;
                }

                // Calculate total amount based on booking type
                if (IsHourly == false)
                {
                    // For "days" booking (daily rate)
                    if (duration.TotalDays >= 1)
                    {
                        // Calculate the SubTotalAmount based on the rate per day
                        hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = bookingDuration * RoomRate; // Per day rate
                    }
                    else
                    {
                        hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = 0; // Invalid duration for daily booking
                    }

                    hotelRoomBookingRateDetailRequestModel.TotalAmount = hotelRoomBookingRateDetailRequestModel.RoomChargeAmount;
                    hotelRoomBookingRateDetailRequestModel.FinalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount;

                    if (serviceResponseHotelTaxRateDataList.Any())
                    {
                        //HandleTaxRateChange(serviceResponseHotelTaxRateDataList);
                        OnSelectCalculateTaxRate(serviceResponseHotelTaxRateDataList);
                    }
                }
                else if (IsHourly == true)
                {

                    hotelRoomBookingRateDetailRequestModel.TotalAmount = RoomRate;
                    CalculateReverseAmount(serviceResponseHotelTaxRateDataList);
                }
            }
            else
            {
                hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = 0;
                hotelRoomBookingRateDetailRequestModel.TotalAmount = 0;
                hotelRoomBookingRateDetailRequestModel.FinalAmount = 0;
            }

            StateHasChanged();
        }

        private void OnSelectCalculateTaxRate(object selectedTaxRateItem)
        {
            decimal totalTaxRates = 0m;
            decimal subTotalAmount = hotelRoomBookingRateDetailRequestModel.RoomChargeAmount ?? 0m;

            var selectedHotelTaxRate = (IEnumerable<HotelTaxRateWebAppModel>)selectedTaxRateItem;

            // Clear the existing tax rates to avoid duplicates
            hotelRoomBookingRateDetailRequestModel.HotelRoomBookingTaxRates.Clear();

            if (selectedHotelTaxRate.Any())
            {
                foreach (var item in selectedHotelTaxRate)
                {
                    // Add the tax rate to the list
                    totalTaxRates += Convert.ToDecimal(item.TaxRate);
                    var newTaxRate = new HotelRoomBookingTaxRateWebAppModel
                    {
                        HotelTaxRateID = item.HotelTaxRateID,
                        BookingTaxRateName = item.TaxName,
                        BookingTaxRatePercentage = item.TaxRate,
                        BookingTaxRate = (subTotalAmount * (item.TaxRate / 100)),
                    };

                    hotelRoomBookingRateDetailRequestModel.HotelRoomBookingTaxRates.Add(newTaxRate);
                }

                // Calculate the total tax amount using the selected tax rate(s)
                decimal validTaxRate = totalTaxRates / 100; // Convert total tax rate to decimal

                decimal taxAmount = subTotalAmount * validTaxRate;

                // Calculate final amount (subtotal + tax)
                hotelRoomBookingRateDetailRequestModel.TotalAmount = (decimal?)Math.Round(subTotalAmount + taxAmount, 2);
                hotelRoomBookingRateDetailRequestModel.FinalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount;
            }
            else
            {
                if (IsHourly)
                {
                    hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = hotelRoomBookingRateDetailRequestModel.HourlyRate;
                    hotelRoomBookingRateDetailRequestModel.TotalAmount = hotelRoomBookingRateDetailRequestModel.RoomChargeAmount;
                    hotelRoomBookingRateDetailRequestModel.FinalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount;
                }
                else
                {
                    hotelRoomBookingRateDetailRequestModel.TotalAmount = hotelRoomBookingRateDetailRequestModel.RoomChargeAmount;
                    hotelRoomBookingRateDetailRequestModel.FinalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount;
                }
            }

            StateHasChanged();
        }

        private void CalculateReverseAmount(IEnumerable<HotelTaxRateWebAppModel> hotelTaxRateWebAppModel)
        {

            // Ensure FinalAmount is valid
            if (!hotelRoomBookingRateDetailRequestModel.TotalAmount.HasValue || hotelRoomBookingRateDetailRequestModel.TotalAmount == 0)
                return;

            decimal totalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount ?? 0m;

            // Get tax rates dynamically
            var taxPercentages = hotelTaxRateWebAppModel.Where(tax => tax.TaxRate.HasValue).Select(tax => tax.TaxRate.Value).ToList();

            // Calculate the total percentage dynamically
            decimal totalTaxRate = taxPercentages.Sum();

            // Calculate the combined percentage factor (1 + total tax rate / 100)
            decimal percentageFactor = 1 + (totalTaxRate / 100);

            // Reverse calculation to find the room charge
            decimal roomCharge = totalAmount / percentageFactor; // Final amount / 1.17 to get room charge

            // Assign values back to the model
            hotelRoomBookingRateDetailRequestModel.RoomChargeAmount = roomCharge;

            OnSelectCalculateTaxRate(hotelTaxRateWebAppModel);

            StateHasChanged();
        }

        private async Task OnSaveClick()
        {
            await RoomCheckOutDateChange();
            _dialogService.Close(true);
        }
        #endregion


        #region API service calls
        private async Task RoomCheckOutDateChange()
        {
            isLoading = true;
            var serviceResponse = await _hotelRoomBookingWebAppService.RoomCheckOutDateChange(hotelRoomBookingRateDetailRequestModel);
            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"CheckOut date changed successfully.");
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while CheckOut date change");
            }
            isLoading = false;
            StateHasChanged();
        }

        #endregion
    }
}
