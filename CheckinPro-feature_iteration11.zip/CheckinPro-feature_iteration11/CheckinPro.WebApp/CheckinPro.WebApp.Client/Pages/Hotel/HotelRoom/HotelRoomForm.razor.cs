﻿using CheckinPro.Common.Models;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoom
{
    public partial class HotelRoomForm : ComponentBase
    {
        #region Parameter
        [Parameter] public int hotelID { get; set; } = 0;
        [Parameter] public EventCallback<AddEditHotelRoomWebAppModel> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        [Parameter] public AddEditHotelRoomWebAppModel hotelRoomRequestModel { get; set; } = new();
        [Parameter] public bool IsBusy { get; set; } = false;

        #endregion

        #region OnRender Method Starts

        private void OnHotelRoomTypeChange(int? hotelRoomTypeID)
        {
            if (hotelRoomTypeID.HasValue)
            {
                hotelRoomRequestModel.HotelRoomTypeID = hotelRoomTypeID.Value;
            }
        }

        private void OnHotelRoomStatusChange(string? roomStatus)
        {
            if (roomStatus is not null)
            {
                hotelRoomRequestModel.RoomStatus = roomStatus;
                StateHasChanged();
            }
        }

        private async Task HandleFormOnSubmit()
        {
            IsBusy = true;
            await OnSubmit.InvokeAsync(hotelRoomRequestModel);
            IsBusy = false;
        }

        private void HandleOnCancel()
        {
            OnCancel.InvokeAsync();
        }
        #endregion
    }
}
