﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoom
{
    public partial class HotelRoomList : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelWebAppService _hotelWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion


        #region Parameter
        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        bool IsBusy { get; set; } = false;

        [Parameter] public int hotelID { get; set; } = 0;
        public int hotelRoomID { get; set; } = 0;
        public string? roomTypeName { get; set; }
        public string? roomNumber { get; set; }
        public string? roomStatus { get; set; }

        private string pagingSummaryFormat = "Displaying page {0} of {1} (total {2} records)";

        private IEnumerable<int> pageSizeOptions = new int[] { 10, 20, 30 };

        private int selectedIndex = 0;
        private List<HotelRoomWebAppModel> serviceResponseDataList { get; set; } = new();
        private List<IGrouping<int?, HotelRoomWebAppModel>> groupedRooms { get; set; } = new();

        #endregion

        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            var uri = new Uri(_navigationManager.Uri);
            var queryParameters = System.Web.HttpUtility.ParseQueryString(uri.Query);
            var tabIndexParam = queryParameters["roomStatus"];
            if (!string.IsNullOrEmpty(tabIndexParam))
            {
                roomStatus = tabIndexParam;
            }
            else
            {
                roomStatus = string.Empty;
            }
            await GetHotelRooms();
        }       

        private async Task CreateEditHotelRoomDialog(HotelRoomWebAppModel? hotelRoom)
        {
            // If editing, use the passed object; if creating, initialize a new one.
            var hotelRoomRequestModel = new AddEditHotelRoomWebAppModel();
            if (hotelRoom != null)
            {
                hotelRoomRequestModel.HotelRoomID = hotelRoom.HotelRoomID;
                hotelRoomRequestModel.HotelID = hotelRoom.HotelID;
                hotelRoomRequestModel.HotelRoomTypeID = hotelRoom.HotelRoomTypeID;
                hotelRoomRequestModel.RoomNumber = hotelRoom.RoomNumber;
                hotelRoomRequestModel.Floor = hotelRoom.Floor;
                hotelRoomRequestModel.MaxOccupancy = hotelRoom.MaxOccupancy;
                hotelRoomRequestModel.RoomStatus = hotelRoom.RoomStatus;
                hotelRoomRequestModel.Description = hotelRoom.Description;
                hotelRoomRequestModel.IsHotelRoomActive = hotelRoom.IsHotelRoomActive;
                hotelRoomRequestModel.IsHotelRoomDeleted = hotelRoom.IsHotelRoomDeleted;
            }

            // Determine dialog title based on whether we're creating or editing
            var dialogName = hotelRoom == null ? "Add New Room" : "Edit Room";

            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<HotelRoomForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelID", hotelID },
                { "hotelRoomRequestModel", hotelRoomRequestModel },
                { "IsBusy", IsBusy },
                { "OnSubmit", EventCallback.Factory.Create<AddEditHotelRoomWebAppModel>(this, HandleFormOnHotelRoomSubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }


        private async Task HandleFormOnHotelRoomSubmit(AddEditHotelRoomWebAppModel hotelRoomRequestModel)
        {
            _dialogService.Close();
            // Create new room
            await CreateEditHotelRoom(hotelRoomRequestModel);
        }

        private void HandleOnCancel()
        {
            _dialogService.Close();
        }
        #endregion

        #region API service calls

        private async Task GetHotelRooms()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelRooms(hotelID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseDataList = serviceResponse.Content;
                if (serviceResponseDataList is not null)
                {
                    groupedRooms = serviceResponseDataList.GroupBy(room => room.Floor).OrderBy(group => group.Key).ToList();
                }
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while getting Room data '{serviceResponse.Error}'.");
                serviceResponseDataList = new List<HotelRoomWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }              

        private async Task CreateEditHotelRoom(AddEditHotelRoomWebAppModel hotelRoomRequestModel)
        {
            isLoading = true;
            IsBusy = true;
            hotelRoomRequestModel.HotelID = hotelID;
            var serviceResponse = await _hotelWebAppService.AddEditHotelRoom(hotelRoomRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Room saved successfully!");

                await GetHotelRooms();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving Room.");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();

        }
        #endregion
    }
}