﻿using CheckinPro.Common.Models.Constants;
using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Pages.Guest;
using CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Radzen;
using Radzen.Blazor;
using System;
using static CheckinPro.Common.Models.Constants.CommonConstants;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelRoom
{
    public partial class HotelRoomDetailList : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelWebAppService _hotelWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter
        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        bool IsBusy { get; set; } = false;
        [Parameter] public bool IsFloorView { get; set; } = true;
        [Parameter] public int hotelID { get; set; } = 0;
        [Parameter] public bool IsShiftActive { get; set; } = false;

        public int hotelRoomID { get; set; } = 0;
        public string? roomTypeName { get; set; }
        public string? roomNumber { get; set; }

        private string pagingSummaryFormat = "Displaying page {0} of {1} (total {2} records)";

        private IEnumerable<int> pageSizeOptions = new int[] { 10, 20, 50, 100 };
        private List<HotelRoomDetailWebAppModel> serviceResponseDataList { get; set; } = new();
        private List<IGrouping<int?, HotelRoomDetailWebAppModel>> groupedRooms { get; set; } = new();
        #endregion

        #region OnRender Method Starts
        protected override async Task OnInitializedAsync()
        {
            await GetHotelRoomAllDetails();
        }

        private TimeSpan GetTimeLeft(DateTime? scheduledCheckOutDate)
        {
            return scheduledCheckOutDate.HasValue ? scheduledCheckOutDate.Value - DateTime.Now : TimeSpan.Zero;
        }

        private string FormatTimeLeft(TimeSpan timeLeft)
        {
            string timeLeftFormatted = string.Empty;

            if (timeLeft.TotalSeconds >= 0) // Time has not passed yet
            {
                if (timeLeft.TotalDays >= 1)
                {
                    timeLeftFormatted = $"{(int)timeLeft.TotalDays} days {timeLeft.Hours} hrs {timeLeft.Minutes} min";
                }
                else if (timeLeft.TotalHours >= 1)
                {
                    timeLeftFormatted = $"{(int)timeLeft.TotalHours} hrs {timeLeft.Minutes} min";
                }
                else
                {
                    timeLeftFormatted = $"{timeLeft.Minutes} min";
                }
            }
            else // Time has passed (negative time)
            {
                // When the time is negative, i.e., overdue
                timeLeftFormatted = $"{Math.Abs((int)timeLeft.TotalDays)}d {Math.Abs(timeLeft.Hours)}h {Math.Abs(timeLeft.Minutes)}m overdue";
            }

            return timeLeftFormatted;
        }

        void RowRender(RowRenderEventArgs<HotelRoomDetailWebAppModel> args)
        {
            args.Attributes.Add("style", $"font-weight: {(args.Data.RoomStatus != null ? "bold" : "normal")};");
        }

        void CellRender(DataGridCellRenderEventArgs<HotelRoomDetailWebAppModel> args)
        {
            //args.Attributes.Add("style", $"background-color: {GetRoomBackgroundColor(args.Data.RoomStatus)};");

            var timeLeft = GetTimeLeft(args.Data.ScheduledCheckOutDate);

            if (timeLeft.TotalSeconds < 0) // Time is overdue
            {
                // Apply red background color for overdue time
                //args.Attributes.Add("style", "background-color: red; color: white;");
                args.Attributes.Add("class", GetRoomStatusClass(BookingStatusMessages.OverDue));
            }
            else
            {
                args.Attributes.Add("class", GetRoomStatusClass(args.Data.RoomStatus));
            }
        }

        private string GetRoomClass(HotelRoomDetailWebAppModel hotelRoomData)
        {
            var timeLeft = GetTimeLeft(hotelRoomData.ScheduledCheckOutDate);

            if (timeLeft.TotalSeconds < 0) // Time is overdue
            {
                return GetRoomStatusClass(BookingStatusMessages.OverDue);
            }
            else
            {
                return GetRoomStatusClass(hotelRoomData.RoomStatus);
            }
        }

        private string GetRoomStatusClass(string roomStatus)
        {
            return roomStatus switch
            {
                RoomStatusMessages.Booked => "status-booked",
                RoomStatusMessages.ReadyToCheckIn => "status-readytocheckin",
                RoomStatusMessages.PendingCleaning => "status-pendingcleaning",
                RoomStatusMessages.OutOfService => "status-outofservice",
                BookingStatusMessages.OverDue => "status-overdue",
                _ => "status-default" // Default class if status is unknown
            };
        }

        private void RedirectToBooking(HotelRoomDetailWebAppModel hotelRoomDetail)
        {

            switch (hotelRoomDetail.RoomStatus)
            {
                case RoomStatusMessages.Booked:
                    _navigationManager.NavigateTo($"/booking-detail/{hotelID}/{hotelRoomDetail.HotelRoomBookingID}");
                    break;

                case RoomStatusMessages.ReadyToCheckIn:
                    if (IsShiftActive)
                    {
                        _navigationManager.NavigateTo($"/room-booking/{hotelID}/{hotelRoomDetail.HotelRoomTypeID}/{hotelRoomDetail.HotelRoomID}/{hotelRoomDetail.RoomNumber}");
                        break;
                    }
                    else
                    {
                        _notificationAlertComponent.ShowNotification(NotificationSeverity.Warning, "", "Please start the shift to continue with the booking process");
                        break;
                    }

                case RoomStatusMessages.PendingCleaning:
                    _navigationManager.NavigateTo($"/room-cleaning/list/{hotelID}");
                    break;

                case RoomStatusMessages.OutOfService:
                    _navigationManager.NavigateTo($"/hotel/room/list/{hotelID}?roomStatus={RoomStatusMessages.OutOfService}");
                    break;

                default:
                    break;
            }
        }
        #endregion


        #region API service calls
        private async Task GetHotelRoomAllDetails()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelRoomAllDetails(hotelID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseDataList = serviceResponse.Content;
                if (serviceResponseDataList is not null)
                {
                    groupedRooms = serviceResponseDataList.GroupBy(room => room.Floor).OrderBy(group => group.Key).ToList();
                }
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while getting room data '{serviceResponse.Error}'.");
                serviceResponseDataList = new List<HotelRoomDetailWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }
        #endregion

    }
}
