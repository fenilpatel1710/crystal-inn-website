﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Pages.Hotel.HotelRoom;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelExpense
{
    public partial class HotelExpenseList : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelWebAppService _hotelWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter
        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        bool IsBusy { get; set; } = false;

        [Parameter] public int hotelID { get; set; } = 0;
        public DateOnly? expenseDate { get; set; }
        public string? expenseType { get; set; }
        public string? expenseAmount { get; set; }

        private string pagingSummaryFormat = "Displaying page {0} of {1} (total {2} records)";

        private IEnumerable<int> pageSizeOptions = new int[] { 10, 20, 30 };

        private List<HotelExpenseWebAppModel> serviceResponseDataList { get; set; } = new();

        #endregion

        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            await GetHotelExpense();
            isLoading = false;
        }

        private async Task CreateEditHotelExpenseDialog(HotelExpenseWebAppModel? hotelExpense)
        {
            // If editing, use the passed object; if creating, initialize a new one.
            var hotelExpenseRequestModel = new HotelExpenseWebAppModel();
            if (hotelExpense != null)
            {
                hotelExpenseRequestModel.HotelExpenseID = hotelExpense.HotelExpenseID;
                hotelExpenseRequestModel.HotelID = hotelExpense.HotelID;
                hotelExpenseRequestModel.ExpenseDate = hotelExpense.ExpenseDate;
                hotelExpenseRequestModel.ExpenseType = hotelExpense.ExpenseType;
                hotelExpenseRequestModel.ExpenseAmount = hotelExpense.ExpenseAmount;
                hotelExpenseRequestModel.ExpenseDescription = hotelExpense.ExpenseDescription;
                hotelExpenseRequestModel.Attachment = hotelExpense.Attachment;
            }

            // Determine dialog title based on whether we're creating or editing
            var dialogName = hotelExpense == null ? "Add New Expense" : "Edit Expense";

            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<HotelExpenseForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelExpenseRequestModel", hotelExpenseRequestModel },
                { "IsBusy", IsBusy },
                { "OnSubmit", EventCallback.Factory.Create<HotelExpenseWebAppModel>(this, HandleFormOnHotelExpenseSubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }

        private async Task HandleFormOnHotelExpenseSubmit(HotelExpenseWebAppModel hotelExpenseRequestModel)
        {
            _dialogService.Close();
            // Create new expense
            if (hotelExpenseRequestModel.HotelExpenseID == 0)
            {
                await CreateHotelExpense(hotelExpenseRequestModel);
            }
            else
            {
                await UpdateHotelExpense(hotelExpenseRequestModel);
            }

        }

        private void HandleOnCancel()
        {
            _dialogService.Close();
        }

        private async Task ConfirmDelete(int hotelExpenseID, string? expenseType)
        {
            var result = await _dialogService.Confirm($"Are you sure you want to delete hotel expense <strong>'{expenseType}'</strong>?", "Confirm Delete",
                new ConfirmOptions() { OkButtonText = "Yes", CancelButtonText = "No", ShowClose = true });

            if (result.HasValue && result.Value)
            {
                await DeleteHotelExpense(hotelExpenseID);
            }
        }

        #endregion

        #region API service calls

        private async Task GetHotelExpense()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelExpense(hotelID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseDataList = serviceResponse.Content.OrderByDescending(item => item.ExpenseDate).ToList();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while getting Hotel Expense '{serviceResponse.Error}'.");
                serviceResponseDataList = new List<HotelExpenseWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task CreateHotelExpense(HotelExpenseWebAppModel hotelExpenseRequestModel)
        {
            isLoading = true;
            IsBusy = true;
            hotelExpenseRequestModel.HotelID = hotelID;
            var serviceResponse = await _hotelWebAppService.AddHotelExpense(hotelExpenseRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Hotel Expense saved successfully!");

                await GetHotelExpense();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving Hotel Expense.");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();

        }

        private async Task UpdateHotelExpense(HotelExpenseWebAppModel hotelExpenseRequestModel)
        {
            isLoading = true;
            IsBusy = true;
            var serviceResponse = await _hotelWebAppService.UpdateHotelExpense(hotelExpenseRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Hotel Expense saved successfully!");

                await GetHotelExpense();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving Hotel Expense.");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();

        }

        private async Task DeleteHotelExpense(int hotelExpenseID)
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.DeleteHotelExpense(hotelExpenseID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Hotel Expense deleted successfully!");

                await GetHotelExpense();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while deleting Hotel Expense '{serviceResponse.Error}'.");
            }
            isLoading = false;
            StateHasChanged();
        }


        #endregion

    }
}
