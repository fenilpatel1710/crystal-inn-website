﻿using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;
using System;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelExpense
{
    public partial class HotelExpenseForm : ComponentBase
    {
        #region Parameter
        [Parameter] public int hotelID { get; set; } = 0;
        [Parameter] public EventCallback<HotelExpenseWebAppModel> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        [Parameter] public HotelExpenseWebAppModel hotelExpenseRequestModel { get; set; } = new();
        [Parameter] public bool IsBusy { get; set; } = false;

        #endregion

        #region OnRender Method Starts

        private async Task HandleFormOnSubmit()
        {
            IsBusy = true;
            await OnSubmit.InvokeAsync(hotelExpenseRequestModel);
            IsBusy = false;
        }

        private void HandleOnCancel()
        {
            OnCancel.InvokeAsync();
        }

        private async void OnChange(UploadChangeEventArgs args)
        {

            foreach (var file in args.Files)
            {

                try
                {
                    long maxFileSize = 10 * 1024 * 1024;
                    // read file
                    var stream = file.OpenReadStream(maxFileSize);
                    using var ms = new MemoryStream();
                    await stream.CopyToAsync(ms);
                    hotelExpenseRequestModel.Attachment = ms.ToArray();
                    stream.Close();
                }
                catch (Exception ex)
                {

                }
            }
        }

        #endregion
    }
}
