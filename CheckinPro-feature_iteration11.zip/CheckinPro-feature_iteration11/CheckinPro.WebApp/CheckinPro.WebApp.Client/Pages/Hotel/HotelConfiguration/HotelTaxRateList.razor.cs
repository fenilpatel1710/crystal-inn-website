﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelConfiguration
{
    public partial class HotelTaxRateList : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelWebAppService _hotelWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter
        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        bool IsBusy { get; set; } = false;
        [Parameter] public int hotelID { get; set; } = 0;
        public string? taxRateName { get; set; }

        private string pagingSummaryFormat = "Displaying page {0} of {1} (total {2} records)";

        private IEnumerable<int> pageSizeOptions = new int[] { 10, 20, 30 };
        private List<HotelTaxRateWebAppModel> serviceResponseTaxRateDataList { get; set; } = new();
        private HotelTaxRateWebAppModel hotelTaxRateRequestModel { get; set; } = new();
        #endregion

        #region OnRender Method Starts
        protected override async Task OnInitializedAsync()
        {
            await GetHotelTaxRate();
        }

        private async Task CreateEditHotelTaxRateDialog(HotelTaxRateWebAppModel? hotelTaxRate)
        {
            // If editing, use the passed object; if creating, initialize a new one.
            var hotelTaxRateRequestModel = hotelTaxRate ?? new HotelTaxRateWebAppModel();

            // Determine dialog title based on whether we're creating or editing
            var dialogName = hotelTaxRate == null ? "Create New Tax Rate" : "Edit Tax Rate";

            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<HotelTaxRateForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelTaxRateRequestModel", hotelTaxRateRequestModel },
                { "IsBusy", IsBusy },
                { "OnSubmit", EventCallback.Factory.Create<HotelTaxRateWebAppModel>(this, HandleFormOnSubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }

        private async Task HandleFormOnSubmit(HotelTaxRateWebAppModel hotelTaxRateRequestModel)
        {
            await CreateHotelTaxRate(hotelTaxRateRequestModel);
            _dialogService.Close();
        }

        private void HandleOnCancel()
        {
            _dialogService.Close();
        }

        #endregion

        #region API service calls
        private async Task GetHotelTaxRate()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelTaxRate(hotelID);
            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {
                serviceResponseTaxRateDataList = serviceResponse.Content;
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while getting TaxRate data '{serviceResponse.Error}'.");
                serviceResponseTaxRateDataList = new List<HotelTaxRateWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task CreateHotelTaxRate(HotelTaxRateWebAppModel hotelTaxRateRequestModel)
        {
            isLoading = true;
            IsBusy = true;
            hotelTaxRateRequestModel.HotelID = hotelID;
            var serviceResponse = await _hotelWebAppService.AddEditHotelTaxRate(hotelTaxRateRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"TaxRate saved successfully!");

                await GetHotelTaxRate();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving TaxRate.");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();
        }
        #endregion
    }
}
