﻿using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelConfiguration
{
    public partial class HotelDailyRateForm : ComponentBase
    {
        #region Parameter
        [Parameter] public EventCallback<HotelDailyRateWebAppModel> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        [Parameter] public HotelDailyRateWebAppModel hotelDailyRateRequestModel { get; set; } = new();
        [Parameter] public bool IsBusy { get; set; } = false;

        #endregion

        #region OnRender Method Starts
        private async Task HandleFormOnSubmit()
        {
            IsBusy = true;
            await OnSubmit.InvokeAsync(hotelDailyRateRequestModel);
            IsBusy = false;
        }

        private void HandleOnCancel()
        {
            OnCancel.InvokeAsync();
        }
        #endregion
    }
}
