﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelConfiguration
{
    public partial class HotelRateConfigurationList : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelWebAppService _hotelWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter
        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        bool IsBusy { get; set; } = false;
        [Parameter] public int hotelID { get; set; } = 0;

        private int selectedIndex = 0;
        private bool IsChangeDateDisabled { get; set; }
        public string? dailyBestAvailableRate { get; set; }
        public string? hour { get; set; }
        public string? roomTypeName { get; set; }
        public string? additionalRateName { get; set; }

        private string pagingSummaryFormat = "Displaying page {0} of {1} (total {2} records)";

        private IEnumerable<int> pageSizeOptions = new int[] { 10, 20, 30 };
        private HotelConfigurationWebAppModel hotelMasterConfigurationRequestModel { get; set; } = new();
        private List<HotelDailyRateWebAppModel> serviceResponseDailyRateDataList { get; set; } = new();
        private List<HotelHourlyRateWebAppModel> serviceResponseHourlyRateDataList { get; set; } = new();
        private List<HotelRoomTypeWebAppModel> serviceResponseRoomTypeData { get; set; } = new();
        private List<HotelAdditionalRateWebAppModel> serviceResponseAdditionalRateData { get; set; } = new();

        #endregion

        #region OnRender Method Starts
        protected override async Task OnInitializedAsync()
        {
            var uri = new Uri(_navigationManager.Uri);
            var queryParameters = System.Web.HttpUtility.ParseQueryString(uri.Query);
            var tabIndexParam = queryParameters["tabIndex"];

            if (!string.IsNullOrEmpty(tabIndexParam) && int.TryParse(tabIndexParam, out int tabIndex))
            {
                selectedIndex = tabIndex;
            }
            else
            {
                selectedIndex = 0;
            }

            // Call API based on the initial tab selection
            OnTabsChange(selectedIndex);
            isLoading = false;
        }
     

        private async void OnTabsChange(int index)
        {
            switch (index)
            {
                case 0:
                    // Call the first API
                    await GetHotelConfiguration();
                    await GetHotelDailyRate();
                    break;
                case 1:
                    // Call the second API
                    await GetHotelHourlyRate();
                    break;
                case 2:
                    // Call the third API
                    await GetHotelRoomTypeRate();
                    break;
                case 3:
                    // Call the fourth API
                    await GetHotelAdditionalRate();
                    break;
                default:
                    break;
            }
        }

        private async Task CreateEditHotelDailyRateDialog(HotelDailyRateWebAppModel? hotelDailyRate)
        {
            // If editing, use the passed object; if creating, initialize a new one.
            var hotelDailyRateRequestModel = hotelDailyRate ?? new HotelDailyRateWebAppModel();

            // Determine dialog title based on whether we're creating or editing
            var dialogName = hotelDailyRate == null ? "Create New Daily Rate" : "Edit Daily Rate";

            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<HotelDailyRateForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelDailyRateRequestModel", hotelDailyRateRequestModel },
                { "IsBusy", IsBusy },
                { "OnSubmit", EventCallback.Factory.Create<HotelDailyRateWebAppModel>(this, HandleFormOnDailyRateSubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }

        private async Task HandleFormOnDailyRateSubmit(HotelDailyRateWebAppModel hotelDailyRateRequestModel)
        {
            _dialogService.Close();
            await CreateEditHotelDailyRate(hotelDailyRateRequestModel);

        }

        private async Task CreateEditHotelHourlyRateDialog(HotelHourlyRateWebAppModel? hotelHourlyRate)
        {
            // If editing, use the passed object; if creating, initialize a new one.
            var hotelHourlyRateRequestModel = hotelHourlyRate ?? new HotelHourlyRateWebAppModel();

            // Determine dialog title based on whether we're creating or editing
            var dialogName = hotelHourlyRate == null ? "Create New Hourly Rate" : "Edit Hourly Rate";

            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<HotelHourlyRateForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelHourlyRateRequestModel", hotelHourlyRateRequestModel },
                { "IsBusy", IsBusy },
                { "OnSubmit", EventCallback.Factory.Create<HotelHourlyRateWebAppModel>(this, HandleFormOnHourlyRateSubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }

        private async Task HandleFormOnHourlyRateSubmit(HotelHourlyRateWebAppModel hotelHourlyRateRequestModel)
        {
            _dialogService.Close();
            await CreateEditHotelHourlyRate(hotelHourlyRateRequestModel);
        }

        private async Task CreateEditHotelRoomTypeDialog(HotelRoomTypeWebAppModel? hotelRoomTypeRate)
        {
            // If editing, use the passed object; if creating, initialize a new one.
            var hotelRoomTypeRequestModel = hotelRoomTypeRate ?? new HotelRoomTypeWebAppModel();

            // Determine dialog title based on whether we're creating or editing
            var dialogName = hotelRoomTypeRate == null ? "Create New Room Type Rate" : "Edit Room Type Rate";

            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<HotelRoomTypeForm>(dialogName, new Dictionary<string, object>
            {
                { "BestAvailableRate", hotelMasterConfigurationRequestModel.BestAvailableRate },
                { "hotelRoomTypeRequestModel", hotelRoomTypeRequestModel },
                { "IsBusy", IsBusy },
                { "OnSubmit", EventCallback.Factory.Create<HotelRoomTypeWebAppModel>(this, HandleFormOnRoomTypeRateSubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }

        private async Task HandleFormOnRoomTypeRateSubmit(HotelRoomTypeWebAppModel hotelRoomTypeRequestModel)
        {
            _dialogService.Close();
            await CreateEditHotelRoomTypeRate(hotelRoomTypeRequestModel);
        }

        private async Task CreateEditHotelAdditionalRateDialog(HotelAdditionalRateWebAppModel? hotelAdditionalRate)
        {
            // If editing, use the passed object; if creating, initialize a new one.
            var hotelAdditionalRateRequestModel = hotelAdditionalRate ?? new HotelAdditionalRateWebAppModel();

            // Determine dialog title based on whether we're creating or editing
            var dialogName = hotelAdditionalRate == null ? "Create New Additional Rate" : "Edit Additional Rate";

            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<HotelAdditionalRateForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelAdditionalRateRequestModel", hotelAdditionalRateRequestModel },
                { "IsBusy", IsBusy },
                { "OnSubmit", EventCallback.Factory.Create<HotelAdditionalRateWebAppModel>(this, HandleFormOnAdditionalRateSubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }

        private async Task HandleFormOnAdditionalRateSubmit(HotelAdditionalRateWebAppModel hotelAdditionalRateRequestModel)
        {
            _dialogService.Close();
            await CreateEditHotelAdditionalRate(hotelAdditionalRateRequestModel);
        }

        private void HandleOnCancel()
        {
            _dialogService.Close();
        }

        private async void OnMasterConfigurationSaveClicked()
        {
            await CreateEditHotelonfiguration();
        }

        private async Task ConfirmDeleteHotelDailyRate(int hotelDailyRateID, DateOnly? date)
        {
            string formattedDate = date.HasValue ? date.Value.ToString("ddd, dd MMM yyyy") : "N/A";

            var result = await _dialogService.Confirm($"Are you sure you want to delete Hotel Daily Rate <strong>'{formattedDate}'</strong>?", "Confirm Delete",
                new ConfirmOptions() { OkButtonText = "Yes", CancelButtonText = "No", ShowClose = true }
            );

            if (result.HasValue && result.Value)
            {
                await DeleteHotelDailyRate(hotelDailyRateID);
            }
        }
        #endregion

        #region API service calls

        private async Task GetHotelConfiguration()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelConfiguration(hotelID);
            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {
                hotelMasterConfigurationRequestModel = serviceResponse.Content;
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task CreateEditHotelonfiguration()
        {
            isLoading = true;
            IsBusy = true;
            hotelMasterConfigurationRequestModel.HotelID = hotelID;
            var serviceResponse = await _hotelWebAppService.AddEditHotelConfiguration(hotelMasterConfigurationRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"BAR saved successfully!");

                await GetHotelConfiguration();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving BAR.");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();
        }

        private async Task GetHotelDailyRate()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelDailyRate(hotelID);
            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {
                serviceResponseDailyRateDataList = serviceResponse.Content;
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while getting DailyRate data '{serviceResponse.Error}'.");
                serviceResponseDailyRateDataList = new List<HotelDailyRateWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task CreateEditHotelDailyRate(HotelDailyRateWebAppModel hotelDailyRateRequestModel)
        {
            isLoading = true;
            IsBusy = true;
            hotelDailyRateRequestModel.HotelID = hotelID;
            var serviceResponse = await _hotelWebAppService.AddEditHotelDailyRate(hotelDailyRateRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"DailyRate saved successfully!");

                await GetHotelDailyRate();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving DailyRate");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();
        }

        private async Task GetHotelHourlyRate()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelHourlyRate(hotelID);
            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {
                serviceResponseHourlyRateDataList = serviceResponse.Content;
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while getting HourlyRate data '{serviceResponse.Error}'.");
                serviceResponseHourlyRateDataList = new List<HotelHourlyRateWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task CreateEditHotelHourlyRate(HotelHourlyRateWebAppModel hotelHourlyRateRequestModel)
        {
            isLoading = true;
            IsBusy = true;
            hotelHourlyRateRequestModel.HotelID = hotelID;
            var serviceResponse = await _hotelWebAppService.AddEditHotelHourlyRate(hotelHourlyRateRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"HourlyRate saved successfully!");

                await GetHotelHourlyRate();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving HourlyRate.");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();
        }

        private async Task GetHotelRoomTypeRate()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelRoomType(hotelID);
            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {
                serviceResponseRoomTypeData = serviceResponse.Content;
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while getting RoomTypeRate data '{serviceResponse.Error}'.");
                serviceResponseRoomTypeData = new List<HotelRoomTypeWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task CreateEditHotelRoomTypeRate(HotelRoomTypeWebAppModel hotelRoomTypeRequestModel)
        {
            isLoading = true;
            IsBusy = true;
            hotelRoomTypeRequestModel.HotelID = hotelID;
            var serviceResponse = await _hotelWebAppService.AddEditHotelRoomType(hotelRoomTypeRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"RoomTypeRate saved successfully!");

                await GetHotelRoomTypeRate();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving RoomTypeRate.");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();
        }


        private async Task GetHotelAdditionalRate()
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotelAdditionalRate(hotelID);
            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {
                serviceResponseAdditionalRateData = serviceResponse.Content;
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while getting AdditionalRate data '{serviceResponse.Error}'.");
                serviceResponseAdditionalRateData = new List<HotelAdditionalRateWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task CreateEditHotelAdditionalRate(HotelAdditionalRateWebAppModel hotelAdditionalRateRequestModel)
        {
            isLoading = true;
            IsBusy = true;
            hotelAdditionalRateRequestModel.HotelID = hotelID;
            var serviceResponse = await _hotelWebAppService.AddEditHotelAdditionalRate(hotelAdditionalRateRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"AdditionalRate saved successfully!");

                await GetHotelAdditionalRate();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving AdditionalRate.");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();
        }

        private async Task DeleteHotelDailyRate(int hotelDailyRateID)
        {
            isLoading = true;
            var serviceResponse = await _hotelWebAppService.DeleteHotelDailyRate(hotelDailyRateID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Hotel Daily Rate deleted successfully!");

                await GetHotelDailyRate();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while deleting Hotel Daily Rate '{serviceResponse.Error}'.");
            }
            isLoading = false;
            StateHasChanged();
        }

        #endregion
    }
}
