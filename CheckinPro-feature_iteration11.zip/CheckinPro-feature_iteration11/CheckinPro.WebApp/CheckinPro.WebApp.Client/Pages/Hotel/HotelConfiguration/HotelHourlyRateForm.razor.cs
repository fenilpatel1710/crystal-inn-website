﻿using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;

namespace CheckinPro.WebApp.Client.Pages.Hotel.HotelConfiguration
{
    public partial class HotelHourlyRateForm : ComponentBase
    {
        #region Parameter
        [Parameter] public EventCallback<HotelHourlyRateWebAppModel> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        [Parameter] public HotelHourlyRateWebAppModel hotelHourlyRateRequestModel { get; set; } = new();
        [Parameter] public bool IsBusy { get; set; } = false;

        #endregion

        #region OnRender Method Starts
        private async Task HandleFormOnSubmit()
        {
            IsBusy = true;
            await OnSubmit.InvokeAsync(hotelHourlyRateRequestModel);
            IsBusy = false;
        }

        private void HandleOnCancel()
        {
            OnCancel.InvokeAsync();
        }
        #endregion
    }
}
