using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.Hotel
{
    public partial class HotelList : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelWebAppService _hotelWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new NotificationAlert();
        #endregion

        #region Parameter

        private bool isLoading { get; set; } = true;

        bool IsBusy { get; set; } = false;

        private string pagingSummaryFormat = "Displaying page {0} of {1} (total {2} records)";

        private IEnumerable<int> pageSizeOptions = new int[] { 10, 20, 30 };

        private string? businessLLCName;

        private string? hotelCode;

        private List<GetHotelWebAppModel> serviceResponseData { get; set; } = new();

        [Parameter] public int hotelID { get; set; } = 0;

        #endregion

        #region Page Method Starts
        protected override async Task OnAfterRenderAsync(bool firstRender)
        {
            if (firstRender)
            {
                await GetHotels();
            }
        }

        private void OnCreateNewClick()
        {
            _navigationManager.NavigateTo("/hotel/add");
        }

        private async void NavigateToViewPage(int hotelID)
        {
            // Use navigation manager to redirect to the Edit amenity page
            //_navigationManager.NavigateTo($"/hotel/details/{hotelID}");
            await HotelDetailDialog(hotelID);
        }

        private async Task HotelDetailDialog(int hotelID)
        {

            //var dialogName = "Quick CheckIn for " + hotelRoomDetail.RoomNumber + "(" + hotelRoomDetail.RoomTypeName + ")";
            var dialogOptions = new SideDialogOptions { CloseDialogOnOverlayClick = true, Width = "1000px", Position = DialogPosition.Right, ShowMask = true };

            await _dialogService.OpenSideAsync<HotelDetails>("", new Dictionary<string, object>
            {
                { "hotelID", hotelID },
            }, options: dialogOptions);
        }


        private async Task ShowDialog()
        {
            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true };

            await _dialogService.OpenAsync<AddHotel>("List New Hotel", new Dictionary<string, object>
            {
                { "OnSubmit", EventCallback.Factory.Create<AddHotelWebAppModel>(this, HandleFormSubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleCancel) },
                { "IsBusy", IsBusy }
            }, dialogOptions);
        }

        private async void HandleFormSubmit(AddHotelWebAppModel hotelRequestModel)
        {
            await CreateNewHotel(hotelRequestModel);
        }

        private void HandleCancel()
        {

        }

        private async Task OnActiveInactiveOwnerDashboard(bool isActive, GetHotelWebAppModel context)
        {

            // Show confirmation dialog before making API call
            var confirmMessage = isActive
                ? $"Are you sure you want to activate the Owner Dashboard for <strong>'{context.BusinessLLCName}'</strong>?"
                : $"Are you sure you want to deactivate the Owner Dashboard for <strong>'{context.BusinessLLCName}'</strong>?";

            var confirmTitle = isActive ? "Confirm Activate" : "Confirm Inactivate";

            // Show the confirmation dialog
            var result = await _dialogService.Confirm(confirmMessage, confirmTitle,
                new ConfirmOptions { OkButtonText = "Yes", CancelButtonText = "No", ShowClose = true });

            if (result.HasValue && result.Value)
            {
                // If confirmed, call the API
                try
                {


                    // Call the API to activate the  hotel staff
                    await ActiveInactiveOwnerDashboard(context.HotelID, isActive);


                }
                catch (Exception ex)
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error processing request.");
                }
                finally
                {
                    // Refresh the data grid after making the API call
                    await GetHotels();
                }
            }
            else
            {
                // If the user cancels, do nothing
                return;
            }
        }

        private async Task OnActiveInactiveHotel(bool isActive, GetHotelWebAppModel context)
        {

            // Show confirmation dialog before making API call
            var confirmMessage = isActive
                ? $"Are you sure you want to activate the Hotel <strong>'{context.BusinessLLCName}'</strong>?"
                : $"Are you sure you want to deactivate the Hotel <strong>'{context.BusinessLLCName}'</strong>?";

            var confirmTitle = isActive ? "Confirm Activate" : "Confirm Inactivate";

            // Show the confirmation dialog
            var result = await _dialogService.Confirm(confirmMessage, confirmTitle,
                new ConfirmOptions { OkButtonText = "Yes", CancelButtonText = "No", ShowClose = true });

            if (result.HasValue && result.Value)
            {
                // If confirmed, call the API
                try
                {
                    // Call the API to activate the  hotel staff
                    await ActiveInactiveHotel(context.HotelID, isActive);

                }
                catch (Exception ex)
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error processing request.");
                }
                finally
                {
                    // Refresh the data grid after making the API call
                    await GetHotels();
                }
            }
            else
            {
                // If the user cancels, do nothing
                return;
            }
        }


        #endregion

        #region API service calls
        private async Task GetHotels()
        {

            isLoading = true;
            var serviceResponse = await _hotelWebAppService.GetHotels();
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseData = serviceResponse.Content;
            }
            else
            {
                serviceResponseData = new List<GetHotelWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task CreateNewHotel(AddHotelWebAppModel hotelRequestModel)
        {
            isLoading = true;

            var serviceResponse = await _hotelWebAppService.AddHotel(hotelRequestModel);
            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Hotel added successfully!");
                _navigationManager.NavigateTo("/hotel/list");
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while saving Hotel.");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();

        }

        private async Task ActiveInactiveOwnerDashboard(int hotelID, bool isActive)
        {

            isLoading = true;
            var serviceResponse = await _hotelWebAppService.ActiveInactiveOwnerDashboard(hotelID, isActive);
            if (serviceResponse.IsSuccessStatusCode)
            {
                if (isActive)
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", "Owner Dashboard activated successfully!");
                }
                else
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", "Owner Dashboard deactivated successfully!");
                }

            }
            else
            {
                if (isActive)
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", "Error while activating Owner Dashboard'.");
                }
                else
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", "Error while deactivating Owner Dashboard'.");
                }
            }
            isLoading = false;
            StateHasChanged();
        }
        private async Task ActiveInactiveHotel(int hotelID, bool isActive)
        {

            isLoading = true;
            var serviceResponse = await _hotelWebAppService.ActiveInactiveHotel(hotelID, isActive);
            if (serviceResponse.IsSuccessStatusCode)
            {
                if (isActive)
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", "Hotel activated successfully!");
                }
                else
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", "Hotel deactivated successfully!");
                }

            }
            else
            {
                if (isActive)
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", "Error while activating Hotel'.");
                }
                else
                {
                    _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", "Error while deactivating Hotel'.");
                }
            }
            isLoading = false;
            StateHasChanged();
        }
        #endregion
    }
}