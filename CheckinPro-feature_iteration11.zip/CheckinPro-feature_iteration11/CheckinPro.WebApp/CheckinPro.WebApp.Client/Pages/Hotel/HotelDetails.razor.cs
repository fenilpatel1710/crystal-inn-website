﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using Radzen;
using static CheckinPro.Common.Models.Constants.CommonConstants;

namespace CheckinPro.WebApp.Client.Pages.Hotel
{
    public partial class HotelDetails : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelWebAppService _hotelWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        [Inject] private IJSRuntime _jsruntime { get; set; }
        #endregion

        #region Parameter
        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        bool IsBusy { get; set; } = false;

        [Parameter]
        public int hotelID { get; set; } = 0;

        private GetHotelWebAppModel serviceResponseData { get; set; } = new();

        private ElementReference textToCopy;      
        #endregion

        #region OnRender Method Starts

        protected override async Task OnAfterRenderAsync(bool firstRender)
        {
            if (firstRender)
            {
                await GetHotelById();
            }
        }

        private async Task CopyToClipboard()
        {
            // Get the full string from the element
            var text = $"{ApplicationURLs.ScannerURL}{serviceResponseData.HotelUniqueID}";

            await _jsruntime.InvokeVoidAsync("navigator.clipboard.writeText", text);
        }
        #endregion

        #region API service calls

        private async Task GetHotelById()
        {
            isLoading = true;
            IsBusy = true;
            var serviceResponse = await _hotelWebAppService.GetHotelById(hotelID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseData = serviceResponse.Content;
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while getting Hotel data '{serviceResponse.Error}'.");
                serviceResponseData = new GetHotelWebAppModel();
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();
        }
        #endregion
    }
}
