﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.Guest
{
    public partial class GuestList : ComponentBase
    {
        #region Inject Services
        [Inject] private IGuestWebAppService _guestWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion


        #region Parameter
        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        bool IsBusy { get; set; } = false;

        [Parameter]
        public int hotelID { get; set; } = 0;
        public string? guestCode { get; set; }
        public string? firstName { get; set; }
        public string? lastName { get; set; }
        public string? identityType { get; set; }
        public string? identityNumber { get; set; }
        public string? mobileNumber { get; set; }

        private string pagingSummaryFormat = "Displaying page {0} of {1} (total {2} records)";

        private IEnumerable<int> pageSizeOptions = new int[] { 10, 20, 30 };

        private int selectedIndex = 0;
        private List<GetGuestWebAppModel> serviceResponseDataList { get; set; } = new();
        #endregion

        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            await GetGuests();
        }

        private async Task ViewGuestDetail(GetGuestWebAppModel? hotelGuest)
        {
            var guestRequestModel = new AddEditGuestWebAppModel();
            if (hotelGuest != null)
            {

                guestRequestModel.GuestID = hotelGuest.GuestID;
                guestRequestModel.FirstName = hotelGuest.FirstName;
                guestRequestModel.LastName = hotelGuest.LastName;
                guestRequestModel.IdentityType = hotelGuest.IdentityType;
                guestRequestModel.IdentityNumber = hotelGuest.IdentityNumber;
                guestRequestModel.FrontSideImage = hotelGuest.FrontSideImage;
                guestRequestModel.Email = hotelGuest.Email;
                guestRequestModel.MobileNumber = hotelGuest.MobileNumber;
                guestRequestModel.Address1 = hotelGuest.Address1;
                guestRequestModel.Address2 = hotelGuest.Address2;
                guestRequestModel.Country = hotelGuest.Country;
                guestRequestModel.State = hotelGuest.State;
                guestRequestModel.City = hotelGuest.City;
                guestRequestModel.ZipCode = hotelGuest.ZipCode;
                guestRequestModel.IsPrimaryGuest = hotelGuest.IsPrimaryGuest;
                guestRequestModel.IsGuestScanned = hotelGuest.IsGuestScanned;
                guestRequestModel.TotalRewardPoint = hotelGuest.TotalRewardPoint;
            }

            var dialogName = "Guest Detail";
            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true, Width = "1000px", };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<GuestForm>(dialogName, new Dictionary<string, object>
            {
                { "guestRequestModel", guestRequestModel },
                //{ "selectedCountryId", selectedCountryId },
                { "IsDisabled", true },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }

        private async Task HandleOnCancel()
        {
            _dialogService.Close();
        }

        #endregion


        #region API service calls

        private async Task GetGuests()
        {
            isLoading = true;
            var serviceResponse = await _guestWebAppService.GetGuestByHotelID(hotelID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseDataList = serviceResponse.Content;
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while getting guest data: '{serviceResponse.Error}'.");
                serviceResponseDataList = new List<GetGuestWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }
        #endregion
    }
}