﻿using CheckinPro.Common.Models.Constants;
using CheckinPro.Common.Models;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using System.Linq;
using System.Threading.Tasks;

namespace CheckinPro.WebApp.Client.Pages.Guest
{
    public partial class GuestSearchListForm : ComponentBase
    {
        #region Parameter
        [Parameter] public EventCallback<AddEditGuestWebAppModel> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        [Parameter] public List<GetGuestWebAppModel> guestData { get; set; } = new();
        public AddEditGuestWebAppModel guestRequestModel { get; set; } = new();

        public bool IsBusy { get; set; } = false;
        public bool IsGuestSelected { get; set; } = false;
        private int? SelectedGuestId { get; set; } = null;
        #endregion

        #region OnRender Method Starts

        private async Task HandleFormOnSubmit()
        {
            IsBusy = true;
            await OnSubmit.InvokeAsync(guestRequestModel);
            IsBusy = false;
        }

        private void HandleOnCancel()
        {
            OnCancel.InvokeAsync();
        }

        private async Task SelectGuest(GetGuestWebAppModel guestData)
        {
            IsBusy = true;
            if (guestData != null)
            {
                SelectedGuestId = guestData.GuestID;
                guestRequestModel = new AddEditGuestWebAppModel
                {
                    GuestID = guestData.GuestID,
                    GuestCode = guestData.GuestCode,
                    FirstName = guestData.FirstName,
                    LastName = guestData.LastName,
                    IdentityType = guestData.IdentityType,
                    IdentityNumber = guestData.IdentityNumber,
                    FrontSideImage = guestData.FrontSideImage,
                    Email = guestData.Email,
                    MobileNumber = guestData.MobileNumber,
                    Address1 = guestData.Address1,
                    Address2 = guestData.Address2,
                    Country = guestData.Country,
                    State = guestData.State,
                    City = guestData.City,
                    ZipCode = guestData.ZipCode,
                    HotelRoomBookings = guestData.HotelRoomBookings.Where(hrb => hrb.HotelRoomBookingID != 0 && hrb.GuestNotes != null && hrb.GuestNoteType != null).Select(hrb => new HotelRoomBookingWebAppModel
                    {
                        HotelRoomBookingID = hrb.HotelRoomBookingID,
                        ScheduledCheckInDate = hrb.ScheduledCheckInDate,
                        GuestNoteType = hrb.GuestNoteType,
                        GuestNotes = hrb.GuestNotes,
                    }).ToList()
                };
            }
            IsBusy = false;
            await HandleFormOnSubmit();
            StateHasChanged();
        }
        #endregion


    }
}
