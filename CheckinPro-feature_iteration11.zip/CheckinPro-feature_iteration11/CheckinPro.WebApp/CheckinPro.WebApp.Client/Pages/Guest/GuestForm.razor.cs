﻿using CheckinPro.Common.Models;
using CheckinPro.Common.Models.Constants;
using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.Guest
{
    public partial class GuestForm : ComponentBase
    {

        #region Inject Services
        [Inject] private IGuestWebAppService _guestWebAppService { get; set; }

        [Inject] private DialogService _dialogService { get; set; }
        #endregion

        #region Parameter
        private bool isLoading { get; set; } = true;

        [Parameter] public EventCallback<AddEditGuestWebAppModel> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        [Parameter] public AddEditGuestWebAppModel guestRequestModel { get; set; } = new();
        [Parameter] public bool IsDisabled { get; set; } = false;
        [Parameter] public int hotelID { get; set; } = 0;

        public bool IsBusy { get; set; } = false;

        private bool isGuestPresent = false;

        private bool IsGuestScanned = false;

        private string? guestFrontSideImage;


        private List<SelectionItemModel> IdentityTypes = CommonConstants.IdentityTypes;
        // identityTypes = new List<SelectionItemModel>(CommonConstants.IdentityTypes);

        #endregion

        #region OnRender Method Starts
        protected override async Task OnInitializedAsync()
        {
            if (guestRequestModel.IsGuestScanned.HasValue)
            {
                IsGuestScanned = guestRequestModel.IsGuestScanned.Value;
            }
            StateHasChanged();
        }
        private async Task HandleFormOnSubmit()
        {
            IsBusy = true;
            await OnSubmit.InvokeAsync(guestRequestModel);
            IsBusy = false;
        }

        private void HandleOnCancel()
        {
            OnCancel.InvokeAsync();
        }

        //private async Task OnCountryChange(int? countryId)
        //{
        //    // Fetch states for the selected country
        //    if (countryId.HasValue)
        //    {
        //        selectedCountryId = countryId.Value;
        //    }
        //}

        private async void OnMobileNumberChange()
        {
            //await GetGuestByMobile();
        }
        private async Task GuestOldBookingNotesDialog(List<HotelRoomBookingWebAppModel> hotelRoomBooking)
        {
            // If editing, use the passed object; if creating, initialize a new one.
            var hotelRoomBookingModel = hotelRoomBooking ?? new List<HotelRoomBookingWebAppModel>();

            // Determine dialog title based on whether we're creating or editing
            var dialogName = "Guest Old Booking Notes";

            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<GuestNoteTimelineForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelRoomBookingModel", hotelRoomBookingModel },
                { "IsBusy", IsBusy },
                { "OnSubmit", EventCallback.Factory.Create<List<HotelRoomBookingWebAppModel> >(this, HandleFormOnGuestNotesSubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }

        private async Task HandleFormOnGuestNotesSubmit(List<HotelRoomBookingWebAppModel> hotelRoomBookingModel)
        {
            _dialogService.Close();
        }

        private void OnFileChange(object value)
        {
            if (value is string base64WithPrefix)
            {
                // Strip the "data:image/jpeg;base64," part if present
                var base64Only = base64WithPrefix;

                var base64Index = base64WithPrefix.IndexOf("base64,");
                if (base64Index >= 0)
                {
                    base64Only = base64WithPrefix.Substring(base64Index + 7);
                }

                guestRequestModel.FrontSideImage = base64Only;

            }
        }

        private async Task GuestScanDetailDialog()
        {
            var dialogName = "List of Scanned IDs";
            var dialogOptions = new SideDialogOptions { CloseDialogOnOverlayClick = true, Width = "1000px", Position = DialogPosition.Right, ShowMask = true };

            await _dialogService.OpenSideAsync<ScanGuestDetailForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelID", hotelID },
                { "OnSubmit", EventCallback.Factory.Create<AddEditGuestWebAppModel>(this, HandleFormOnSubmitGuestDetail) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) }
            }, options: dialogOptions);
        }
        private async Task HandleFormOnSubmitGuestDetail(AddEditGuestWebAppModel guestRequestModel)
        {
            BindGuestDataToModel(guestRequestModel);
            StateHasChanged();
            _dialogService.CloseSide();

            //await CreateEditHotelAdditionalRate(hotelAdditionalRateRequestModel);
        }

        private void BindGuestDataToModel(AddEditGuestWebAppModel guestData)
        {
            if (guestData == null) return;

            guestRequestModel.GuestID = guestData.GuestID;
            guestRequestModel.FirstName = guestData.FirstName;
            guestRequestModel.LastName = guestData.LastName;
            guestRequestModel.IdentityType = guestData.IdentityType;
            guestRequestModel.IdentityNumber = guestData.IdentityNumber;
            guestRequestModel.FrontSideImage = guestData.FrontSideImage;
            guestRequestModel.Email = guestData.Email;
            guestRequestModel.MobileNumber = guestData.MobileNumber;
            guestRequestModel.Address1 = guestData.Address1;
            guestRequestModel.Address2 = guestData.Address2;
            guestRequestModel.Country = guestData.Country;
            guestRequestModel.State = guestData.State;
            guestRequestModel.City = guestData.City;
            guestRequestModel.ZipCode = guestData.ZipCode;
            guestRequestModel.ScanID = guestData.ScanID;
            guestRequestModel.IsGuestScanned = guestData.IsGuestScanned;
            IsGuestScanned = guestRequestModel.IsGuestScanned.Value;
        }

        private async Task SearchGuest(string filterBy)
        {

            switch (filterBy)
            {
                case "IdentityNumber":
                    guestRequestModel.GuestCode = string.Empty;
                    guestRequestModel.MobileNumber = string.Empty;
                    break;
                case "MobileNumber":
                    guestRequestModel.GuestCode = string.Empty;
                    guestRequestModel.IdentityNumber = string.Empty;
                    break;

                default:
                    guestRequestModel.IdentityNumber = string.Empty;
                    guestRequestModel.MobileNumber = string.Empty;
                    break;
            }
            isLoading = true;
            var serviceResponse = await _guestWebAppService.GetGuestByCodeOrIdentityNumberOrMobile(guestRequestModel.GuestCode, guestRequestModel.IdentityNumber, guestRequestModel.MobileNumber);

            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {
                var guestData = serviceResponse.Content;

                guestRequestModel.GuestID = guestData.GuestID;
                guestRequestModel.GuestCode = guestData.GuestCode;
                guestRequestModel.FirstName = guestData.FirstName;
                guestRequestModel.LastName = guestData.LastName;
                guestRequestModel.IdentityType = guestData.IdentityType;
                guestRequestModel.IdentityNumber = guestData.IdentityNumber;
                guestRequestModel.FrontSideImage = guestData.FrontSideImage;
                guestRequestModel.Email = guestData.Email;
                guestRequestModel.MobileNumber = guestData.MobileNumber;
                guestRequestModel.Address1 = guestData.Address1;
                guestRequestModel.Address2 = guestData.Address2;
                guestRequestModel.Country = guestData.Country;
                guestRequestModel.State = guestData.State;
                guestRequestModel.City = guestData.City;
                guestRequestModel.ZipCode = guestData.ZipCode;
                // Map the HotelRoomBookings list correctly
                guestData.HotelRoomBookings.Where(hrb => hrb.HotelRoomBookingID != 0 && hrb.GuestNotes != null && hrb.GuestNoteType != null).Select(hrb => new HotelRoomBookingWebAppModel
                {
                    HotelRoomBookingID = hrb.HotelRoomBookingID,
                    ScheduledCheckInDate = hrb.ScheduledCheckInDate,
                    GuestNoteType = hrb.GuestNoteType,
                    GuestNotes = hrb.GuestNotes,
                }).ToList();
                // Check if the guest has any hotel room bookings
                if (guestRequestModel.HotelRoomBookings.Count > 0)
                {
                    var guestNotes = guestRequestModel.HotelRoomBookings.ToList();
                    await GuestOldBookingNotesDialog(guestNotes);
                }
                isGuestPresent = true;
            }
            else
            {
                // Show an error notification if the guest details could not be retrieved
                //_notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", "Error getting guest details.");
            }
            StateHasChanged();
        }
        #endregion

        #region API service calls
        private async Task GetGuestByMobile()
        {
            isLoading = true;
            var serviceResponse = await _guestWebAppService.GetGuestByMobile(guestRequestModel.MobileNumber);
            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {

                var guestData = serviceResponse.Content;
                guestRequestModel.GuestID = guestData.GuestID;
                guestRequestModel.GuestID = guestData.GuestID;
                guestRequestModel.FirstName = guestData.FirstName;
                guestRequestModel.LastName = guestData.LastName;
                guestRequestModel.IdentityType = guestData.IdentityType;
                guestRequestModel.IdentityNumber = guestData.IdentityNumber;
                guestRequestModel.FrontSideImage = guestData.FrontSideImage;
                guestRequestModel.Email = guestData.Email;
                guestRequestModel.MobileNumber = guestData.MobileNumber;
                guestRequestModel.Address1 = guestData.Address1;
                guestRequestModel.Address2 = guestData.Address2;
                guestRequestModel.Country = guestData.Country;
                guestRequestModel.State = guestData.State;
                guestRequestModel.City = guestData.City;
                guestRequestModel.ZipCode = guestData.ZipCode;
                guestRequestModel.HotelRoomBookings = guestData.HotelRoomBookings.Select(hrb => new HotelRoomBookingWebAppModel
                {
                    HotelRoomBookingID = hrb.HotelRoomBookingID,
                    ScheduledCheckInDate = hrb.ScheduledCheckInDate,
                    GuestNoteType = hrb.GuestNoteType,
                    GuestNotes = hrb.GuestNotes,
                }).ToList();
                isGuestPresent = true;


                if (guestRequestModel.HotelRoomBookings.Count > 0)
                {
                    var GuestNotes = guestRequestModel.HotelRoomBookings.ToList();
                    await GuestOldBookingNotesDialog(GuestNotes);
                }

            }
            else
            {
                // _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "Error", $"Error getting Guest details.");
            }
            isLoading = false;
            StateHasChanged();
        }

        #endregion

    }
}
