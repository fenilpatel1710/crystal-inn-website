﻿using CheckinPro.Common.Models;
using CheckinPro.Common.Models.Constants;
using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;
using System.Threading.Tasks;
using static CheckinPro.Common.Models.Constants.CommonConstants;

namespace CheckinPro.WebApp.Client.Pages.Guest
{
    public partial class ScanGuestDetailForm : ComponentBase
    {
        #region Inject Services
        [Inject] private IGuestWebAppService _guestWebAppService { get; set; }

        [Inject] private DialogService _dialogService { get; set; }
        #endregion

        #region Parameter
        private bool isLoading { get; set; } = true;

        [Parameter] public EventCallback<AddEditGuestWebAppModel> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        [Parameter] public int hotelID { get; set; }
        public AddEditGuestWebAppModel guestRequestModel { get; set; } = new();
        public List<AddEditGuestWebAppModel> serviceResponseGuestScanDataList { get; set; } = new();
        public AddEditGuestWebAppModel lastScan => serviceResponseGuestScanDataList.FirstOrDefault();
        public List<AddEditGuestWebAppModel> todaysScans => serviceResponseGuestScanDataList.Skip(1).ToList();

        public bool IsBusy { get; set; } = false;

        #endregion

        #region OnRender Method Starts
        protected override async Task OnInitializedAsync()
        {
            await GetGuestScanDetail();
            StateHasChanged();
        }

        private async Task HandleFormOnSubmit()
        {
            IsBusy = true;
            await OnSubmit.InvokeAsync(guestRequestModel);
            IsBusy = false;
        }
        private void HandleOnCancel()
        {
            OnCancel.InvokeAsync();
        }

        private void SelectGuest(AddEditGuestWebAppModel guestRequestWebAppModel)
        {
            guestRequestModel = guestRequestWebAppModel;
            guestRequestModel.IsGuestScanned = true;

            StateHasChanged();
        }
        private string GetCardClass(int? scanID)
        {
            // If this card is selected, apply the 'selected' class (green color)
            return guestRequestModel.ScanID == scanID ? "rz-border-radius-3 rz-my-1 rz-link rz-ripple rz-background-color-success-light" : "rz-border-radius-3 rz-my-1 rz-link rz-ripple";
        }

        private async Task OnRefreshClicked()
        {
            await GetGuestScanDetail();
        }
        #endregion

        #region API service calls
        private async Task GetGuestScanDetail()
        {
            isLoading = true;
            IsBusy = true;
            var serviceResponse = await _guestWebAppService.GetGuestScanDetail(hotelID);
            if (serviceResponse.IsSuccessStatusCode && serviceResponse.Content is not null)
            {
                serviceResponseGuestScanDataList = serviceResponse.Content;
            }
            else
            {
                serviceResponseGuestScanDataList = new();
                // _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error getting Guest details.");
            }
            IsBusy = false;
            isLoading = false;
            StateHasChanged();
        }

        #endregion
    }
}
