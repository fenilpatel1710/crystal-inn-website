﻿using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;

namespace CheckinPro.WebApp.Client.Pages.HouseKeeping
{
    public partial class RoomCleaningNoteForm : ComponentBase
    {
        #region Parameter
        [Parameter] public EventCallback<UpdateHotelRoomCleaningAuditWebAppModel> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        [Parameter] public UpdateHotelRoomCleaningAuditWebAppModel hotelRoomCleaningAuditRequestModel { get; set; }

        #endregion

        #region OnRender Method Starts
        private async Task HandleFormOnSubmit()
        {
            await OnSubmit.InvokeAsync(hotelRoomCleaningAuditRequestModel);
        }

        private void HandleOnCancel()
        {
            OnCancel.InvokeAsync();
        }
        #endregion
    }
}
