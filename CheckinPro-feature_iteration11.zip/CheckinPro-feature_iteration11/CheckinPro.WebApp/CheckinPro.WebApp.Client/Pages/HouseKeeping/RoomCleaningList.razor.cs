﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Pages.Hotel.HotelRoomBooking;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;
using static CheckinPro.Common.Models.Constants.CommonConstants;

namespace CheckinPro.WebApp.Client.Pages.HouseKeeping
{
    public partial class RoomCleaningList : ComponentBase
    {
        #region Inject Services
        [Inject] private IHotelRoomBookingWebAppService _hotelRoomBookingWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter
        private bool isLoading { get; set; } = true;
        bool IsBusy { get; set; } = false;
        [Parameter] public int hotelID { get; set; } = 0;
        private List<HotelRoomCleaningAuditWebAppModel> serviceResponseDataList { get; set; } = new();
        private List<IGrouping<int?, HotelRoomCleaningAuditWebAppModel>> groupedRoomFloors { get; set; } = new();
        #endregion

        #region OnRender Method Starts
        protected override async Task OnInitializedAsync()
        {
            await GetPendingRoomCleaningList();
        }

        private async void MarkRoomCleaned(HotelRoomCleaningAuditWebAppModel hotelRoomCleaningAuditData)
        {
            await OnMarkRoomCleanedDialog(hotelRoomCleaningAuditData);
        }

        private async Task OnMarkRoomCleanedDialog(HotelRoomCleaningAuditWebAppModel hotelRoomCleaningAuditData)
        {
            var dialogName = "Enter Guest Note or Cleaning Comment";

            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true };

            var hotelRoomCleaningAuditRequestModel = new UpdateHotelRoomCleaningAuditWebAppModel();
            if (hotelRoomCleaningAuditData != null)
            {
                hotelRoomCleaningAuditRequestModel.HotelRoomCleaningAuditID = hotelRoomCleaningAuditData.HotelRoomCleaningAuditID;
                hotelRoomCleaningAuditRequestModel.HotelRoomBookingID = hotelRoomCleaningAuditData.HotelRoomBookingID;
                hotelRoomCleaningAuditRequestModel.HotelRoomID = hotelRoomCleaningAuditData.HotelRoomID;
            }

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<RoomCleaningNoteForm>(dialogName, new Dictionary<string, object>
            {
                { "hotelRoomCleaningAuditRequestModel", hotelRoomCleaningAuditRequestModel },
                { "OnSubmit", EventCallback.Factory.Create<UpdateHotelRoomCleaningAuditWebAppModel>(this, HandleFormOnSubmitCancelled) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }

        private async Task HandleFormOnSubmitCancelled(UpdateHotelRoomCleaningAuditWebAppModel hotelRoomCleaningAuditRequestModel)
        {
            _dialogService.Close();
            await RoomCleaning(hotelRoomCleaningAuditRequestModel);
        }

        private void HandleOnCancel()
        {
            _dialogService.Close();
        }
        #endregion

        #region API service calls

        private async Task GetPendingRoomCleaningList()
        {
            isLoading = true;
            var serviceResponse = await _hotelRoomBookingWebAppService.GetPendingRoomCleaningList(hotelID);

            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseDataList = serviceResponse.Content;

                if (serviceResponseDataList is not null)
                {
                    groupedRoomFloors = serviceResponseDataList.GroupBy(room => room.Floor).OrderBy(group => group.Key).ToList();
                }
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while getting Room data '{serviceResponse.Error}'.");
                serviceResponseDataList = new List<HotelRoomCleaningAuditWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task RoomCleaning(UpdateHotelRoomCleaningAuditWebAppModel hotelRoomCleaningAuditRequestModel)
        {
            isLoading = true;
            var serviceResponse = await _hotelRoomBookingWebAppService.RoomCleaning(hotelRoomCleaningAuditRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"Room cleaning status changed successfully!");
                await GetPendingRoomCleaningList();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while updating Room cleaning status.");
            }
            IsBusy = false;
            isLoading = false;
            StateHasChanged();
        }
        #endregion
    }
}
