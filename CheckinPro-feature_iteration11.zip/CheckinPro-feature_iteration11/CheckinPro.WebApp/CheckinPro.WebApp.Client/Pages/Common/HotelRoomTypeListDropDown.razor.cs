﻿using CheckinPro.Common.Models;
using CheckinPro.WebApp.Client.IServices;
using Microsoft.AspNetCore.Components;

namespace CheckinPro.WebApp.Client.Pages.Common
{
    public partial class HotelRoomTypeListDropDown : ComponentBase
    {
        #region Inject Services
        [Inject] private IDropdownWebAppService _dropDownWebAppService { get; set; }

        #endregion


        #region Parameter
        [Parameter] public int hotelID { get; set; }
        [Parameter] public int? Value { get; set; }

        [Parameter] public EventCallback<int?> ValueChanged { get; set; }

        private List<SelectionItemModel> serviceResponseData { get; set; } = new();

        #endregion

        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            await GetHotelRoomTypes();
        }

        private async Task OnHotelRoomTypeChange(int? hotelRoomTypeId)
        {
            Value = hotelRoomTypeId;
            await ValueChanged.InvokeAsync(Value);
            StateHasChanged();
        }
        #endregion

        #region API service calls
        private async Task GetHotelRoomTypes()
        {
            var serviceResponse = await _dropDownWebAppService.GetHotelRoomTypesForDropdown(hotelID);
            if (serviceResponse.IsSuccessStatusCode)
            {
                var hotelRoomTypeList = serviceResponse.Content.Select(item => new SelectionItemModel
                {
                    ItemID = item.ItemID,
                    ItemName = item.ItemName,
                    ItemIcon = item.ItemIcon
                }).ToList();

                serviceResponseData = hotelRoomTypeList;
            }
            else
            {
                serviceResponseData = new List<SelectionItemModel>();
            }
            StateHasChanged();
        }
        #endregion
    }
}
