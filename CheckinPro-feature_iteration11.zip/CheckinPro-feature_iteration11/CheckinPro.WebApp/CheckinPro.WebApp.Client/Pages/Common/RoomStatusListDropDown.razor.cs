﻿using CheckinPro.Common.Models;
using CheckinPro.WebApp.Client.IServices;
using Microsoft.AspNetCore.Components;


namespace CheckinPro.WebApp.Client.Pages.Common
{
    public partial class RoomStatusListDropDown : ComponentBase
    {
        #region Inject Services
        [Inject] private IDropdownWebAppService _dropDownWebAppService { get; set; }

        #endregion

        #region Parameter
        [Parameter] public string? Value { get; set; }

        [Parameter] public EventCallback<string?> ValueChanged { get; set; }

        private List<SelectionItemModel> serviceResponseData { get; set; } = new();

        #endregion

        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            await GetRoomStatuses();
        }

        private async Task OnRoomStatusChange(string itemName)
        {
            Value = itemName;
            await ValueChanged.InvokeAsync(itemName);
            StateHasChanged();
        }
        #endregion

        #region API service calls
        private async Task GetRoomStatuses()
        {
            var serviceResponse = await _dropDownWebAppService.GetRoomStatusesForDropdown();
            if (serviceResponse.IsSuccessStatusCode)
            {
                var RoomStatusData = serviceResponse.Content;

                var roomStatusList = RoomStatusData.Select(item => new SelectionItemModel
                {
                    ItemID = item.ItemID,
                    ItemName = item.ItemName,
                    ItemIcon = item.ItemIcon
                }).ToList();

                serviceResponseData = roomStatusList;
            }
            else
            {
                serviceResponseData = new List<SelectionItemModel>();
            }
            StateHasChanged();
        }
        #endregion
    }
}