﻿using CheckinPro.Common.Models;
using CheckinPro.WebApp.Client.IServices;
using Microsoft.AspNetCore.Components;


namespace CheckinPro.WebApp.Client.Pages.Common
{
    public partial class RoleListDropDown : ComponentBase
    {
        #region Inject Services
        [Inject] private IDropdownWebAppService _dropDownWebAppService { get; set; }

        #endregion

        #region Parameter
        int? selectedRoleId;

        [Parameter]
        public int? Value { get; set; }

        [Parameter]
        public EventCallback<int?> ValueChanged { get; set; }

        private List<SelectionItemModel> serviceResponseData { get; set; } = new();

        #endregion

        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            await GetRoles();
        }

        private async Task OnRoleChange(int? roleId)
        {
            Value = roleId;
            await ValueChanged.InvokeAsync(Value);
            StateHasChanged();
        }
        #endregion

        #region API service calls
        private async Task GetRoles()
        {
            var serviceResponse = await _dropDownWebAppService.GetRolesForDropdown();
            if (serviceResponse.IsSuccessStatusCode)
            {
                var RoleData = serviceResponse.Content;

                var roleList = RoleData.Select(item => new SelectionItemModel
                {
                    ItemID = item.ItemID,
                    ItemName = item.ItemName
                }).ToList();

                serviceResponseData = roleList;
            }
            else
            {
                serviceResponseData = new List<SelectionItemModel>();
            }
            StateHasChanged();
        }
        #endregion
    }
}