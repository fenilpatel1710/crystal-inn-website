using CheckinPro.Common.Models;
using CheckinPro.WebApp.Client.IServices;
using Microsoft.AspNetCore.Components;

namespace CheckinPro.WebApp.Client.Pages.Common
{
    public partial class StateListDropDown : ComponentBase
    {

        #region Inject Services
        [Inject] private IDropdownWebAppService _dropDownWebAppService { get; set; }

        #endregion


        #region Parameter
        [Parameter]
        public int? SelectedCountryId { get; set; }

        [Parameter]
        public int? Value { get; set; }

        [Parameter]
        public EventCallback<int?> ValueChanged { get; set; }

        private List<SelectionItemModel> serviceResponseData { get; set; } = new();

        [Parameter]
        public bool isStateDropdownDisabled { get; set; } = false;

        #endregion

        #region OnRender Method Starts

        protected override async Task OnParametersSetAsync()
        {
            await GetStates();
        }

        protected override async Task OnInitializedAsync()
        {
            await GetStates();
        }
        private async Task OnValueChanged(int? stateID)
        {
            Value = stateID;
            await ValueChanged.InvokeAsync(stateID);
        }
        #endregion

        #region API service calls
        private async Task GetStates()
        {
            if (SelectedCountryId == null)
            {
                serviceResponseData = new List<SelectionItemModel>();
                return;
            }

            var serviceResponse = await _dropDownWebAppService.GetStatesForDropdown(SelectedCountryId.Value);
            if (serviceResponse.IsSuccessStatusCode)
            {
                var stateData = serviceResponse.Content;
                serviceResponseData = stateData.Select(item => new SelectionItemModel
                {
                    ItemID = item.ItemID,
                    ItemName = item.ItemName
                }).ToList();
            }
            else
            {
                serviceResponseData = new List<SelectionItemModel>();
            }
            StateHasChanged();
        }
        #endregion        
    }
}