using CheckinPro.Common.Models;
using CheckinPro.WebApp.Client.IServices;
using Microsoft.AspNetCore.Components;


namespace CheckinPro.WebApp.Client.Pages.Common
{
    public partial class CountryListDropDown : ComponentBase
    {
        #region Inject Services
        [Inject] private IDropdownWebAppService _dropDownWebAppService { get; set; }

        #endregion


        #region Parameter
        [Parameter]
        public int? Value { get; set; }

        [Parameter]
        public EventCallback<int?> ValueChanged { get; set; }

        private List<SelectionItemModel> serviceResponseData { get; set; } = new();

        [Parameter]
        public bool isCountryDropdownDisabled { get; set; } = false;
        #endregion

        #region OnRender Method Starts

        protected override async Task OnInitializedAsync()
        {
            await GetCountries();
        }

        private async Task OnCountryChange(int? countryId)
        {
            Value = countryId;
            await ValueChanged.InvokeAsync(Value);
            StateHasChanged();
        }
        #endregion

        #region API service calls
        private async Task GetCountries()
        {

            var serviceResponse = await _dropDownWebAppService.GetCountriesForDropdown();
            if (serviceResponse.IsSuccessStatusCode)
            {
                var CountryData = serviceResponse.Content;

                var countryList = CountryData.Select(item => new SelectionItemModel
                {
                    ItemID = item.ItemID,
                    ItemName = item.ItemName
                }).ToList();

                serviceResponseData = countryList;
            }
            else
            {
                serviceResponseData = new List<SelectionItemModel>();
            }
            StateHasChanged();
        }
        #endregion
    }
}