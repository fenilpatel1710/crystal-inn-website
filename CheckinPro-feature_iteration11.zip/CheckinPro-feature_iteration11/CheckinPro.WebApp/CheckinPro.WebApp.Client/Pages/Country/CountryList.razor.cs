﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Pages.Role;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.Country
{
    public partial class CountryList : ComponentBase
    {
        #region Inject Services
        [Inject] private ICountryWebAppService _countryWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter

        private bool isLoading { get; set; } = true;
        public bool IsBusy { get; set; } = false;

        private string pagingSummaryFormat = "Displaying page {0} of {1} (total {2} records)";

        private IEnumerable<int> pageSizeOptions = new int[] { 10, 20, 30 };

        private string? countryName;
        private List<CountryWebAppModel> serviceResponseData { get; set; } = new();
        private List<CountryWebAppModel> activeCountries => serviceResponseData.Where(a => !a.IsCountryDeleted).OrderByDescending(a => a.IsCountryActive).ToList();
        
        #endregion

        #region Page Method Starts
        protected override async Task OnAfterRenderAsync(bool firstRender)
        {
            if (firstRender)
            {
                await GetCountries();
            }
        }

        private async Task EditCountryDialog(CountryWebAppModel? countryRequestModel)
        {
            var dialogName = countryRequestModel == null ? "Add New Country" : "Edit Country";

            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<CountryForm>(dialogName, new Dictionary<string, object>
            {
                { "countryRequestModel", countryRequestModel },
                { "IsBusy", IsBusy },
                { "OnSubmit", EventCallback.Factory.Create<CountryWebAppModel>(this, HandleFormOnCountrySubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }


        private async Task HandleFormOnCountrySubmit(CountryWebAppModel countryRequestModel)
        {
            _dialogService.Close();
            await UpdateCountry(countryRequestModel);
        }

        private void HandleOnCancel()
        {
            _dialogService.Close();
        }

        private void NavigateToEditPage(int countryID)
        {
            // Use navigation manager to redirect to the Edit amenity page
            _navigationManager.NavigateTo($"/country/edit/{countryID}");
        }

        #endregion

        #region API service calls
        private async Task GetCountries()
        {
            isLoading = true;
            var serviceResponse = await _countryWebAppService.GetAllCountries();
            if (serviceResponse.IsSuccessStatusCode)
            {
                serviceResponseData = serviceResponse.Content;
            }
            else
            {
                serviceResponseData = new List<CountryWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task UpdateCountry(CountryWebAppModel countryRequestModel)
        {
            isLoading = true;
            IsBusy = true;
            var serviceResponse = await _countryWebAppService.UpdateCountry(countryRequestModel.CountryID, countryRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"'{countryRequestModel.CountryName}' updated successfully!");
                await GetCountries();
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error updating '{countryRequestModel.CountryName}'.");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();
        }
        #endregion
    }
}
