﻿using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;

namespace CheckinPro.WebApp.Client.Pages.State
{
    public partial class StateForm: ComponentBase
    {
        #region Parameter
        [Parameter] public EventCallback<StateWebAppModel> OnSubmit { get; set; }
        [Parameter] public EventCallback OnCancel { get; set; }
        [Parameter] public StateWebAppModel stateRequestModel { get; set; } = new();
        [Parameter] public bool IsBusy { get; set; } = false;

        #endregion

        #region OnRender Method Starts

        private async Task HandleFormOnSubmit()
        {
            IsBusy = true;
            await OnSubmit.InvokeAsync(stateRequestModel);
            IsBusy = false;
        }

        private void HandleOnCancel()
        {
            OnCancel.InvokeAsync();
        }
        #endregion
    }
}
