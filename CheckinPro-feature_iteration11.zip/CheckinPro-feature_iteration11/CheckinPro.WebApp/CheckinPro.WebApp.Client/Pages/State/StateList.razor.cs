﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Pages.Country;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.State
{
    public partial class StateList : ComponentBase
    {
        #region Inject Services
        [Inject] private IStateWebAppService _stateWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }
        [Inject] private DialogService _dialogService { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter
        
        private int selectedCountryID;

        private bool isLoading { get; set; } = true;

        public bool IsBusy { get; set; } = false;

        private string pagingSummaryFormat = "Displaying page {0} of {1} (total {2} records)";

        private IEnumerable<int> pageSizeOptions = new int[] { 10, 20, 30 };

        private string? stateName;
        private List<StateWebAppModel> servicecStateResponseData { get; set; } = new();

        #endregion

        #region Page Method Starts

        private async Task OnCountryChange(int? countryId)
        {
            // Fetch states for the selected country
            if (countryId.HasValue)
            {
                selectedCountryID = countryId.Value;
                await GetStates(countryId.Value);
            }
        }

        protected override async Task OnInitializedAsync()
        {
            isLoading = false;
        }

        private async Task EditStateDialog(StateWebAppModel? stateRequestModel)
        {
            var dialogName = stateRequestModel == null ? "Add New State" : "Edit State";

            var dialogOptions = new DialogOptions { CloseDialogOnOverlayClick = true };

            // Open the dialog with the necessary parameters
            await _dialogService.OpenAsync<StateForm>(dialogName, new Dictionary<string, object>
            {
                { "stateRequestModel", stateRequestModel },
                { "IsBusy", IsBusy },
                { "OnSubmit", EventCallback.Factory.Create<StateWebAppModel>(this, HandleFormOnStateSubmit) },
                { "OnCancel", EventCallback.Factory.Create(this, HandleOnCancel) },
            }, dialogOptions);
        }


        private async Task HandleFormOnStateSubmit(StateWebAppModel stateRequestModel)
        {
            _dialogService.Close();
            await UpdateState(stateRequestModel);
        }

        private void HandleOnCancel()
        {
            _dialogService.Close();
        }

        private void NavigateToEditPage(int stateID)
        {
            // Use navigation manager to redirect to the Edit amenity page
            _navigationManager.NavigateTo($"/state/edit/{stateID}");
        }

        #endregion

        #region API service calls
        private async Task GetStates(int countryId)
        {
            isLoading = true;
            var serviceResponse = await _stateWebAppService.GetAllStatesByCountryId(countryId);
            if (serviceResponse.IsSuccessStatusCode)
            {
                servicecStateResponseData = serviceResponse.Content;
            }
            else
            {
                servicecStateResponseData = new List<StateWebAppModel>();
            }
            isLoading = false;
            StateHasChanged();
        }

        private async Task UpdateState(StateWebAppModel stateRequestModel)
        {
            isLoading = true;
            IsBusy = true;
            var serviceResponse = await _stateWebAppService.UpdateState(stateRequestModel.StateID, stateRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Success, "", $"'{stateRequestModel.StateName}' updated successfully!");
                await GetStates(selectedCountryID);
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error updating '{stateRequestModel.StateName}'.");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();
        }
        #endregion
    }
}
