﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.UserAccount
{
    public partial class ValidateOTP : ComponentBase
    {
        #region Inject Services
        [Inject] private IUserAccountWebAppService _userAccountWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter

        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        bool IsBusy { get; set; } = false;
        private ValidateOTPWebAppModel validateOTPRequestModel { get; set; } = new();

        [Parameter]
        public string EmailID { get; set; } = string.Empty;

        #endregion

        #region OnRender Method Starts

        protected override async Task OnAfterRenderAsync(bool firstRender)
        {
            if (firstRender)
            {
                isLoading = false;
            }
        }

        #endregion

        #region API service calls
        async void OnValidateClicked()
        {
            IsBusy = true;
            await UserAccountValidateOTP();
            IsBusy = false;
            StateHasChanged();
        }

        private async Task UserAccountValidateOTP()
        {
            isLoading = true;
            validateOTPRequestModel.EmailID = EmailID;

            var serviceResponse = await _userAccountWebAppService.ValidateOTP(validateOTPRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _navigationManager.NavigateTo($"/resetpassword/{EmailID}");
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"OTP Verification Failed");
            }
            isLoading = false;
        }

        #endregion
    }
}