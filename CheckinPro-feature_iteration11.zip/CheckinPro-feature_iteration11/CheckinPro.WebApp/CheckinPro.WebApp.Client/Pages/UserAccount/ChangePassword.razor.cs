﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Providers;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;


namespace CheckinPro.WebApp.Client.Pages.UserAccount
{
    public partial class ChangePassword : CustomComponentBase
    {
        #region Inject Services
        [Inject] private IUserAccountWebAppService _userAccountWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter

        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        bool IsBusy { get; set; } = false;
        private ChangePasswordWebAppModel changePasswordRequestModel { get; set; } = new();

        [Parameter]
        public string EmailID { get; set; } = string.Empty;

        #endregion

        #region OnRender Method Starts

        protected override async Task OnAfterRenderAsync(bool firstRender)
        {
            if (firstRender)
            {
                isLoading = false;
            }
        }

        #endregion

        #region API service calls
        async void OnChangePasswordClicked()
        {
            await UserChangePassword();
        }

        private async Task UserChangePassword()
        {
            isLoading = true;
            IsBusy = true;

            var data = await GetCurrentUser();

            if (data.EmailID is not null)
            {

                changePasswordRequestModel.EmailID = data.EmailID;
            }
            else
            {

                changePasswordRequestModel.EmailID = EmailID;
            }
            var serviceResponse = await _userAccountWebAppService.ChangePassword(changePasswordRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _navigationManager.NavigateTo("/resetpasswordsuccess");
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Change Password Failed!");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();
        }

        #endregion
    }
}