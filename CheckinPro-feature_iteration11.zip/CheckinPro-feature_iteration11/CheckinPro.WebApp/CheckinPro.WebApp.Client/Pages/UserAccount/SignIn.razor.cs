﻿using Blazored.LocalStorage;
using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.UserAccount
{
    public partial class SignIn : ComponentBase
    {
        #region Inject Services
        [Inject] private IUserAccountWebAppService _userAccountWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        [Inject] private ILocalStorageService _localStorageService { get; set; }
        [Inject] private AuthenticationStateProvider _authStateProvider { get; set; }

        #endregion

        #region Parameter

        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        bool IsBusy { get; set; } = false;
        bool IsPasswordChanged { get; set; } = false;

        private SignInRequestWebAppModel signInRequestModel { get; set; } = new();

        #endregion

        #region OnRender Method Starts

        protected override async Task OnAfterRenderAsync(bool firstRender)
        {
            if (firstRender)
            {
                isLoading = false;
            }
        }

        private void NavigateToforgotpassword()
        {
            _navigationManager.NavigateTo("/forgotpassword");
        }

        #endregion

        #region API service calls
        async void OnSignInClicked()
        {
            IsBusy = true;
            await UserAccountSignIn();
            IsBusy = false;
            StateHasChanged();
        }

        private async Task UserAccountSignIn()
        {
            isLoading = true;
            var serviceResponse = await _userAccountWebAppService.SignIn(signInRequestModel);

            if (serviceResponse.IsSuccessStatusCode)
            {
                await _localStorageService.SetItemAsStringAsync("IsAuthenticated", "true");

                if (serviceResponse.Content)
                {
                    _navigationManager.NavigateTo("/");
                }
                else
                {
                    IsPasswordChanged = true;
                    //_navigationManager.NavigateTo($"/changepassword/{serviceResponse.Content.EmailID}");
                }

            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"Error while User SignIn.");
            }
            isLoading = false;
        }
        #endregion
    }
}
