﻿using CheckinPro.WebApp.Client.IServices;
using CheckinPro.WebApp.Client.Shared;
using CheckinPro.WebApp.Models;
using Microsoft.AspNetCore.Components;
using Radzen;

namespace CheckinPro.WebApp.Client.Pages.UserAccount
{
    public partial class ForgotPassword : ComponentBase
    {
        #region Inject Services
        [Inject] private IUserAccountWebAppService _userAccountWebAppService { get; set; }
        [Inject] private NavigationManager _navigationManager { get; set; }

        private NotificationAlert _notificationAlertComponent = new();
        #endregion

        #region Parameter

        private bool isLoading { get; set; } = true;
        bool popup { get; set; } = true;
        bool IsBusy { get; set; } = false;
        public ForgotPasswordWebAppModel forgotPasswordRequestModel { get; set; } = new();

        #endregion

        #region OnRender Method Starts

        protected override async Task OnAfterRenderAsync(bool firstRender)
        {
            if (firstRender)
            {
                isLoading = false;
            }
        }

        #endregion

        #region API service calls
        async void OnForgotPasswordClicked()
        {
            await UserAccountForgotPassword();
        }

        private async Task UserAccountForgotPassword()
        {
            isLoading = true;
            IsBusy = true;
            var serviceResponse = await _userAccountWebAppService.ForgotPassword(forgotPasswordRequestModel.Email);


            if (serviceResponse.IsSuccessStatusCode)
            {
                isLoading = false;
                _navigationManager.NavigateTo($"/validateotp/{forgotPasswordRequestModel.Email}");
            }
            else
            {
                _notificationAlertComponent.ShowNotification(NotificationSeverity.Error, "", $"No user found with this email address");
            }
            isLoading = false;
            IsBusy = false;
            StateHasChanged();
        }

        #endregion
    }
}
