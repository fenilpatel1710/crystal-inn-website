﻿window.downloadFileFromStream = async (fileName, contentStreamReference) => {
    const arrayBuffer = await contentStreamReference.arrayBuffer();
    const blob = new Blob([arrayBuffer], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);

    const anchorElement = document.createElement("a");
    anchorElement.href = url;
    anchorElement.download = fileName;
    document.body.appendChild(anchorElement);
    anchorElement.click();
    document.body.removeChild(anchorElement);

    URL.revokeObjectURL(url);
};

window.copyText = (text) => {
    navigator.clipboard.writeText(text).catch(() => {
        const textarea = document.createElement("textarea");
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand("copy");
        document.body.removeChild(textarea);
    });
};

//function previewAndPrintPDF(base64Pdf) {
//    // Create an iframe element to embed the PDF for preview
//    const iframe = document.createElement('iframe');
//    iframe.style.width = '100%';
//    iframe.style.height = '500px';  // Adjust size as needed
//    iframe.style.border = 'none';

//    // Set the source to the base64 PDF
//    iframe.src = `data:application/pdf;base64,${base64Pdf}`;

//    // Append the iframe to the body (or to a specific element in your Blazor page)
//    document.body.appendChild(iframe);

//    // Wait for the iframe to load, then trigger the print dialog
//    iframe.onload = function () {
//        setTimeout(() => {
//            iframe.contentWindow.print();  // Trigger the print dialog
//        }, 1000);  // Wait a bit before triggering print
//    };
//}

//working
//function previewAndPrintPDF(base64Data) {
//    // Create a Blob from the base64 string (representing the PDF)
//    var byteCharacters = atob(base64Data);
//    var byteArrays = [];

//    for (var offset = 0; offset < byteCharacters.length; offset += 1024) {
//        var slice = byteCharacters.slice(offset, offset + 1024);
//        var byteNumbers = new Array(slice.length);
//        for (var i = 0; i < slice.length; i++) {
//            byteNumbers[i] = slice.charCodeAt(i);
//        }
//        var byteArray = new Uint8Array(byteNumbers);
//        byteArrays.push(byteArray);
//    }

//    var blob = new Blob(byteArrays, { type: 'application/pdf' });

//    // Create a link element and simulate a click to open the PDF in a new tab
//    var link = document.createElement('a');
//    link.href = URL.createObjectURL(blob);
//    link.target = '_blank';  // Open in a new tab
//    link.click();
//}

function previewAndPrintPDF(base64Data) {
    // Create a Blob from the base64 string (representing the PDF)
    var byteCharacters = atob(base64Data);
    var byteArrays = [];

    for (var offset = 0; offset < byteCharacters.length; offset += 1024) {
        var slice = byteCharacters.slice(offset, offset + 1024);
        var byteNumbers = new Array(slice.length);
        for (var i = 0; i < slice.length; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        byteArrays.push(byteArray);
    }

    var blob = new Blob(byteArrays, { type: 'application/pdf' });

    // Create an invisible iframe
    var iframe = document.createElement('iframe');
    iframe.style.position = 'absolute';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = 'none';

    // Create an Object URL for the Blob
    var url = URL.createObjectURL(blob);
    iframe.src = url;

    // Append the iframe to the document
    document.body.appendChild(iframe);

    // Once the PDF is loaded, trigger the print dialog
    iframe.onload = function () {
        var iframeWindow = iframe.contentWindow;

        // Try triggering the print dialog
        iframeWindow.print();

        // Wait for a short moment to see if the print dialog comes up
        setTimeout(function () {
            var hasPrinter = false;
            try {
                // Try to detect if a printer is available (this is just a heuristic)
                hasPrinter = !!(iframeWindow.document.querySelector('embed') || iframeWindow.document.querySelector('object'));
            } catch (e) { }

            if (!hasPrinter) {
                // If no printer is detected, give the user the option to download the PDF
                var downloadLink = document.createElement('a');
                downloadLink.href = url;
                downloadLink.download = 'document.pdf';
                downloadLink.click();
            }

            // We now remove the iframe after everything is done
            // Delay removal to avoid race condition with dialog
            setTimeout(function () {
                document.body.removeChild(iframe);
            }, 5000);
        }, 5000);
    };
}


function printPDF(base64Data) {
    // Create a Blob from the base64 string (representing the PDF)
    var byteCharacters = atob(base64Data);
    var byteArrays = [];

    for (var offset = 0; offset < byteCharacters.length; offset += 1024) {
        var slice = byteCharacters.slice(offset, offset + 1024);
        var byteNumbers = new Array(slice.length);
        for (var i = 0; i < slice.length; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        byteArrays.push(byteArray);
    }

    var blob = new Blob(byteArrays, { type: 'application/pdf' });

    // Create an invisible iframe
    var iframe = document.createElement('iframe');
    iframe.style.position = 'absolute';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = 'none';

    // Create an Object URL for the Blob
    var url = URL.createObjectURL(blob);
    iframe.src = url;

    // Append the iframe to the document
    document.body.appendChild(iframe);

    // Once the PDF is loaded, trigger the print dialog
    iframe.onload = function () {
        iframe.contentWindow.print();
    };

    // Listen for the 'afterprint' event to remove the iframe
    window.addEventListener('afterprint', function () {
        document.body.removeChild(iframe);
    });
}
