﻿using CheckinPro.WebApp.Models;
using Refit;

namespace CheckinPro.WebApp.Client.IServices
{
    public interface ICountryWebAppService
    {
        //[Get("/Country/GetCountries")]
        //Task<ApiResponse<List<CountryDropDownWebAppModel>>> GetCountries();

        [Get("/Country/GetCountries")]
        Task<ApiResponse<List<CountryWebAppModel>>> GetAllCountries();

        //[Get("/Country/GetActiveCountries")]
        //Task<ApiResponse<List<CountryWebAppModel>>> GetActiveCountries();

        [Get("/Country/GetCountryById/{countryID}")]
        Task<ApiResponse<CountryWebAppModel>> GetCountryById(int countryID);

        [Put("/Country/UpdateCountry/{countryID}")]
        Task<ApiResponse<Boolean>> UpdateCountry(int countryID, [Body] CountryWebAppModel countryRequestModel);

    }
}
