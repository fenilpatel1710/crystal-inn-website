﻿using CheckinPro.WebApp.Models;
using Refit;

namespace CheckinPro.WebApp.Client.IServices
{
    public interface IGuestWebAppService
    {
        [Get("/Guest/GetGuests")]
        Task<ApiResponse<List<GetGuestWebAppModel>>> GetGuestByHotelID([AliasAs("hotelId")] int? hotelId = null);

        [Get("/Guest/GetGuestByCodeOrIdentityNumberOrMobile")]
        Task<ApiResponse<GetGuestWebAppModel>> GetGuestByCodeOrIdentityNumberOrMobile([AliasAs("guestCode")] string? guestCode = null, [AliasAs("identityNumber")] string? identityNumber = null, [AliasAs("mobileNumber")] string? mobileNumber = null);

        [Get("/Guest/GetGuestByMobile")]
        Task<ApiResponse<GetGuestWebAppModel>> GetGuestByMobile([AliasAs("mobileNumber")] string mobileNumber = null);

        [Get("/Guest/GetGuestByName")]
        Task<ApiResponse<List<GetGuestWebAppModel>>> GetGuestByName([AliasAs("firstName")] string? firstName = null, [AliasAs("lastName")] string? lastName = null);

        [Get("/Scanner/GetGuestScanDetail")]
        Task<ApiResponse<List<AddEditGuestWebAppModel>>> GetGuestScanDetail([AliasAs("hotelID")] int? hotelID = null);

        [Get("/Guest/GetGuestRewardPoint")]
        Task<ApiResponse<GuestRewardWebAppModel>> GetGuestRewardPoint(int hotelID, int guestID);
    }
}
