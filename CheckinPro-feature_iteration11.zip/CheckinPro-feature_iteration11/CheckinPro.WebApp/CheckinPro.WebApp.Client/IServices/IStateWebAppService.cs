﻿using CheckinPro.WebApp.Models;
using Refit;

namespace CheckinPro.WebApp.Client.IServices
{
    public interface IStateWebAppService
    {
        //[Get("/State/GetStatesByCountryId/{countryId}")]
        //Task<ApiResponse<List<StateDropDownWebAppModel>>> GetStatesByCountryId(int countryId);

        [Get("/State/GetStatesByCountryId/{countryId}")]
        Task<ApiResponse<List<StateWebAppModel>>> GetAllStatesByCountryId(int countryId);

        [Get("/Country/GetActiveCountries")]
        Task<ApiResponse<List<CountryWebAppModel>>> GetActiveCountries();

        [Put("/State/UpdateState/{stateID}")]
        Task<ApiResponse<Boolean>> UpdateState(int stateID, [Body] StateWebAppModel stateRequestModel);

        [Get("/state/GetStatesByStateId/{stateID}")]
        Task<ApiResponse<StateWebAppModel>> GetStatesByStateId(int stateID);
    }
}
