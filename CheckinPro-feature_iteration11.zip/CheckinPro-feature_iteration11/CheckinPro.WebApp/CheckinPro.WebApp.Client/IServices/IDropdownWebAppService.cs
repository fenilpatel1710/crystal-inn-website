﻿using CheckinPro.Common.Models;
using Refit;

namespace CheckinPro.WebApp.Client.IServices
{
    public interface IDropdownWebAppService
    {
        [Get("/Dropdown/GetRolesForDropdown")]
        Task<ApiResponse<List<SelectionItemModel>>> GetRolesForDropdown();

        [Get("/Dropdown/GetCountriesForDropdown")]
        Task<ApiResponse<List<SelectionItemModel>>> GetCountriesForDropdown();

        [Get("/Dropdown/GetStatesForDropdown/{countryID}")]
        Task<ApiResponse<List<SelectionItemModel>>> GetStatesForDropdown(int countryID);

        [Get("/Dropdown/GetHotelRoomTypesForDropdown/{hotelID}")]
        Task<ApiResponse<List<SelectionItemModel>>> GetHotelRoomTypesForDropdown(int hotelID);

        [Get("/Dropdown/GetRoomStatusesForDropdown")]
        Task<ApiResponse<List<SelectionItemModel>>> GetRoomStatusesForDropdown();
    }
}