﻿using CheckinPro.WebApp.Models;
using Refit;

namespace CheckinPro.WebApp.Client.IServices
{
    public interface IUserAccountWebAppService
    {
        [Get("/UserAccount/GetSignInUserDetail")]
        Task<ApiResponse<SignInResponseWebAppModel>> GetSignInUserDetail();

        [Post("/UserAccount/SignIn")]
        Task<ApiResponse<Boolean>> SignIn([Body] SignInRequestWebAppModel signInRequestModel);

        [Post("/UserAccount/ChangePassword")]
        Task<ApiResponse<Boolean>> ChangePassword([Body] ChangePasswordWebAppModel changePasswordModel);

        [Post("/UserAccount/ForgotPassword/{EmailID}")]
        Task<ApiResponse<Boolean>> ForgotPassword(string EmailID);

        [Post("/UserAccount/ValidateOTP")]
        Task<ApiResponse<Boolean>> ValidateOTP([Body] ValidateOTPWebAppModel validateOTPModel);

        [Post("/UserAccount/ResetPassword")]
        Task<ApiResponse<Boolean>> ResetPassword([Body] ResetPasswordWebAppModel resetPasswordModel);

        [Post("/UserAccount/SignOut")]
        Task<ApiResponse<GetUserWebAppModel>> SignOutAsync();
    }
}
