﻿using CheckinPro.WebApp.Models;
using CheckinPro.WebApp.Models.HotelRoomBooking;
using Microsoft.AspNetCore.Mvc;
using Refit;

namespace CheckinPro.WebApp.Client.IServices
{
    public interface IHotelRoomBookingWebAppService
    {
        [Get("/HotelRoomBooking/GetHotelDailyRateByDate")]
        Task<ApiResponse<HotelDailyRateWebAppModel>> GetHotelDailyRateByDate([AliasAs("hotelID")] int hotelID, [AliasAs("checkInDate")] DateOnly CheckInDate);

        [Get("/HotelRoomBooking/GetHotelRoomsByDates")]
        Task<ApiResponse<List<HotelRoomWebAppModel>>> GetHotelRoomsByDates([AliasAs("hotelID")] int hotelID, [AliasAs("checkInDate")] DateTime CheckInDate, [AliasAs("checkOutDate")] DateTime CheckOutDate);

        [Get("/HotelRoomBooking/GetBookedHotelRoomsByHotelID/{hotelID}")]
        Task<ApiResponse<List<GetHotelRoomBookingWebAppModel>>> GetBookedHotelRoomsByHotelID(int hotelID);

        [Get("/HotelRoomBooking/GetAvailableRoomTypes")]
        Task<ApiResponse<List<HotelRoomTypeWebAppModel>>> GetAvailableRoomTypes(int hotelID, DateTime checkInDate, DateTime checkOutDate);

        [Get("/HotelRoomBooking/GetAvailableRoomByDates")]
        Task<ApiResponse<List<HotelRoomWebAppModel>>> GetAvailableRoomByDates(int hotelID, int hotelRoomTypeID, DateTime? checkInDate, DateTime? checkOutDate);

        [Get("/HotelRoomBooking/GetRoomBookingDetailsByID/{hotelRoomBookingID}")]
        Task<ApiResponse<HotelRoomBookingWebAppModel>> GetRoomBookingDetailsByID(int hotelRoomBookingID);

        [Get("/HotelRoomBooking/GetMobileNumbers")]
        Task<ApiResponse<List<string>>> GetMobileNumbers(string searchTerm = null);

        [Get("/HotelRoomBooking/GetTodaysCheckOutRoomsByHotelID/{hotelID}")]
        Task<ApiResponse<List<GetHotelRoomBookingWebAppModel>>> GetTodaysCheckOutRoomsByHotelID(int hotelID);

        [Get("/HotelRoomBooking/GetTodaysBookingsByHotelID/{hotelID}")]
        Task<ApiResponse<List<GetHotelRoomBookingWebAppModel>>> GetTodaysBookingsByHotelID(int hotelID);

        [Get("/HotelRoomBooking/GetBookedRoomsByCheckOutDate")]
        Task<ApiResponse<List<GetBookedRoomDetailsWebAppModel>>> GetBookedRoomsByCheckOutDate([AliasAs("hotelRoomBookingID")] int hotelRoomBookingID, [AliasAs("checkOutDate")] DateTime? CheckOutDate);

        [Post("/HotelRoomBooking/AddHotelRoomBooking")]
        Task<ApiResponse<int>> AddHotelRoomBooking([Body] HotelRoomBookingWebAppModel hotelRoomBookingRequestModel);

        [Put("/HotelRoomBooking/UpdateHotelRoomBooking")]
        Task<ApiResponse<Boolean>> UpdateHotelRoomBooking([Body] HotelRoomBookingWebAppModel hotelRoomBookingRequestModel);
        
        [Put("/HotelRoomBooking/UpdateHotelRoomBookingTotalAmount")]
        Task<ApiResponse<Boolean>> UpdateHotelRoomBookingTotalAmount([Body] HotelRoomBookingRateDetailWebAppModel hotelRoomBookingRateDetailRequestModel);

        [Put("/HotelRoomBooking/RoomCheckIn/{hotelRoomBookingID}/{hotelRoomID}")]
        Task<ApiResponse<Boolean>> RoomCheckIn(int hotelRoomBookingID, int hotelRoomID);

        [Put("/HotelRoomBooking/RoomChange")]
        Task<ApiResponse<Boolean>> RoomChange([Body] RoomChangeWebAppModel roomChangeRequestModel);

        [Put("/HotelRoomBooking/RoomCheckOut")]
        Task<ApiResponse<Boolean>> RoomCheckOut(UpdateHotelRoomCleaningAuditWebAppModel hotelRoomCleaningAuditRequestModel);

        [Put("/HotelRoomBooking/RoomCheckOutDateChange")]
        Task<ApiResponse<Boolean>> RoomCheckOutDateChange(HotelRoomBookingRateDetailWebAppModel hotelRoomBookingRateDetailRequestModel);

        [Put("/HotelRoomBooking/RoomExtend")]
        Task<ApiResponse<Boolean>> RoomExtend([Body] HotelRoomBookingWebAppModel hotelRoomBookingRequestModel);

        [Put("/HotelRoomBooking/RoomCancel/{hotelRoomBookingID}")]
        Task<ApiResponse<Boolean>> RoomCancel(int hotelRoomBookingID, [AliasAs("cancellationReason")] string? cancellationReason);

        [Put("/HotelRoomBooking/RoomRefund")]
        Task<ApiResponse<Boolean>> RoomRefund([Body] AddEditHotelRoomPaymentWebAppModel bookingPaymentRequestModel);

        [Put("/HotelRoomBooking/RoomCleaning")]
        Task<ApiResponse<Boolean>> RoomCleaning([Body] UpdateHotelRoomCleaningAuditWebAppModel hotelRoomCleaningAuditRequestModel);

        [Get("/HotelRoomBooking/GetPendingRoomCleaningList/{hotelID}")]
        Task<ApiResponse<List<HotelRoomCleaningAuditWebAppModel>>> GetPendingRoomCleaningList(int hotelID);


        [Put("/HotelRoomBooking/UpdateHotelRoomBookingStatus")]
        Task<ApiResponse<Boolean>> UpdateHotelRoomBookingStatus([Body] HotelRoomBookingWebAppModel hotelRoomBookingRequestModel);


        [Put("/HotelRoomBooking/AddEditMiscAmount")]
        Task<ApiResponse<Boolean>> AddEditMiscAmount(AddEditMiscAmountWebAppModel addEditMiscAmountRequestModel);

        [Post("/HotelRoomBooking/AddEditBookingPayment")]
        Task<ApiResponse<Boolean>> AddEditBookingPayment(AddEditHotelRoomPaymentWebAppModel bookingPaymentRequestModel);

        [Get("/HotelRoomBooking/SearchHotelRoomBooking")]
        Task<ApiResponse<List<GetHotelRoomBookingSearchListWebAppModel>>> SearchHotelRoomBooking([AliasAs("findHotelRoomBookingRequestModel")] FindHotelRoomBookingWebAppModel findHotelRoomBookingRequestModel);
        
        [Put("/HotelRoomBooking/UpdateGuestRequest")]
        Task<ApiResponse<Boolean>> UpdateGuestRequest([Body] UpdateGuestRequestWebAppModel hotelRoomBookingRequestModel);

        [Post("/HotelRoomBooking/AddUpdateGuest")]
        Task<ApiResponse<Boolean>> AddUpdateGuest(int hotelRoomBookingID, [Body] AddEditGuestWebAppModel guestRequestModel);

        [Put("/HotelRoomBooking/UpdateBookingReportFlag")]
        Task<ApiResponse<Boolean>> UpdateBookingReportFlag([AliasAs("hotelRoomBookingID")] int hotelRoomBookingID, [AliasAs("isIncludedInReport")] bool isIncludedInReport);

        [Get("/HotelRoomBooking/GetRoomBookingMiscAmount/{hotelRoomBookingID}")]
        Task<ApiResponse<List<AddEditMiscAmountWebAppModel>>> GetRoomBookingMiscAmount(int hotelRoomBookingID);

        [Delete("/HotelRoomBooking/DeleteMiscAmount/{hotelRoomBookingMiscellaneousID}")]
        Task<ApiResponse<Boolean>> DeleteMiscAmount(int hotelRoomBookingMiscellaneousID);
    }
}
