﻿using CheckinPro.WebApp.Models;
using Refit;

namespace CheckinPro.WebApp.Client.IServices
{
    public interface IRoleWebAppService
    {
        [Get("/Role/GetRoles")]
        Task<ApiResponse<List<RoleWebAppModel>>> GetRoles();

        [Get("/Role/GetRoleById/{roleID}")]
        Task<ApiResponse<RoleWebAppModel>> GetRoleById(int roleID);

        [Put("/Role/UpdateRole/{roleID}")]
        Task<ApiResponse<Boolean>> UpdateRole(int roleID, [Body] RoleWebAppModel roleRequestModel);
    }
}
