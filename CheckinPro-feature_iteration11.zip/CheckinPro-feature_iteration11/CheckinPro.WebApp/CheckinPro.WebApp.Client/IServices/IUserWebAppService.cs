﻿using CheckinPro.WebApp.Models;
using Refit;

namespace CheckinPro.WebApp.Client.IServices
{
    public interface IUserWebAppService
    {

        [Get("/User/GetUsers/{hotelID}")]
        Task<ApiResponse<List<GetUserWebAppModel>>> GetUsers(int hotelID);

        [Get("/User/GetUserById")]
        Task<ApiResponse<GetUserWebAppModel>> GetUserById();

        [Post("/User/AddUser")]
        Task<ApiResponse<Boolean>> AddUser([Body] UserAddEditWebAppModel userRequestModel);

        [Put("/User/UpdateUser")]
        Task<ApiResponse<Boolean>> UpdateUser([Body] UserAddEditWebAppModel userRequestModel);

        [Put("/User/BlockUser/{userID}")]
        Task<ApiResponse<Boolean>> BlockUser(int userID);

        [Put("/User/ActivateUser/{userID}")]
        Task<ApiResponse<Boolean>> ActivateUser(int userID);
    }
}
