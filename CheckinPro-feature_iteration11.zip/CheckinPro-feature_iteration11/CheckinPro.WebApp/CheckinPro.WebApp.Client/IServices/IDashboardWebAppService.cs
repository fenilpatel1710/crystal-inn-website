﻿using CheckinPro.WebApp.Models;
using Refit;

namespace CheckinPro.WebApp.Client.IServices
{
    public interface IDashboardWebAppService
    {
        [Get("/Dashboard/GetDashboard/{hotelID}")]
        Task<ApiResponse<GetDashboardWebAppModel>> GetDashboard(int hotelID);

        [Get("/Dashboard/GetHotelShiftDetailByDate")]
        Task<ApiResponse<List<HotelShiftWebAppModel>>> GetHotelShiftDetailByDate([AliasAs("hotelId")] int hotelId, [AliasAs("fromDate")] DateOnly fromDate, [AliasAs("toDate")] DateOnly toDate);

        [Get("/Dashboard/GetHotelShiftDetail/{hotelID}")]
        Task<ApiResponse<HotelShiftWebAppModel>> GetHotelShiftDetail(int hotelID);

        [Post("/Dashboard/StartHotelShift")]
        Task<ApiResponse<HotelShiftWebAppModel>> StartHotelShift(HotelShiftWebAppModel hotelShiftRequestModel);

        [Put("/Dashboard/EndHotelShift")]
        Task<ApiResponse<HotelShiftWebAppModel>> EndHotelShift(HotelShiftWebAppModel hotelShiftRequestModel);

        [Get("/Dashboard/GetHotelMetricsByDateRange")]
        Task<ApiResponse<List<GetHotelOwnerDashboardWebAppModel>>> GetHotelMetricsByDateRange([AliasAs("hotelId")] int hotelId, [AliasAs("selectedDate")] DateTime selectedDate, [AliasAs("metrix")] string metrix);

        [Get("/Dashboard/GetHotelRoomRevenueByYear")]
        Task<ApiResponse<List<GetHotelRoomRevenueWebAppModel>>> GetHotelRoomRevenueByYear([AliasAs("hotelId")] int hotelId, [AliasAs("year")] int year);

    }
}
