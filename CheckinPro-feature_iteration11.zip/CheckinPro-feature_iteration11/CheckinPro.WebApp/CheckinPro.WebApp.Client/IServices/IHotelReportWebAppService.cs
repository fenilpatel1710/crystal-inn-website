﻿using CheckinPro.WebApp.Models;
using Refit;

namespace CheckinPro.WebApp.Client.IServices
{
    public interface IHotelReportWebAppService
    {
        [Get("/HotelReport/PrintBookingReceipt/{hotelRoomBookingID}")]
        Task<ApiResponse<byte[]>> PrintBookingReceipt(int hotelRoomBookingID);

        [Get("/HotelReport/DownloadBookingInvoice/{hotelRoomBookingID}")]
        Task<ApiResponse<byte[]>> DownloadBookingInvoice(int hotelRoomBookingID);

        [Get("/HotelReport/DownloadDailyAuditReport")]
        Task<ApiResponse<byte[]>> DownloadDailyAuditReport([AliasAs("hotelId")] int hotelId, [AliasAs("fromDate")] DateOnly fromDate, [AliasAs("toDate")] DateOnly toDate);

        [Get("/HotelReport/DownloadRoomTaxCollectedReport")]
        Task<ApiResponse<byte[]>> DownloadRoomTaxCollectedReport([AliasAs("hotelId")] int hotelId, [AliasAs("fromDate")] DateOnly fromDate, [AliasAs("toDate")] DateOnly toDate);

        [Get("/HotelReport/DownloadSummaryIncomeReport")]
        Task<ApiResponse<byte[]>> DownloadSummaryIncomeReport([AliasAs("hotelId")] int hotelId, [AliasAs("fromDate")] DateOnly fromDate, [AliasAs("toDate")] DateOnly toDate);

        [Get("/HotelReport/DownloadRoomRevenueReport")]
        Task<ApiResponse<byte[]>> DownloadRoomRevenueReport([AliasAs("hotelId")] int hotelId, [AliasAs("fromDate")] DateOnly fromDate, [AliasAs("toDate")] DateOnly toDate);

        [Get("/HotelReport/DownloadIncomeBreakdownReport")]
        Task<ApiResponse<byte[]>> DownloadIncomeBreakdownReport([AliasAs("hotelId")] int hotelId, [AliasAs("fromDate")] DateOnly fromDate, [AliasAs("toDate")] DateOnly toDate);

        [Get("/HotelReport/DownloadShiftReport")]
        Task<ApiResponse<byte[]>> DownloadShiftReport([AliasAs("hotelId")] int hotelId, [AliasAs("hotelShiftData")] HotelShiftWebAppModel hotelShiftData, [AliasAs("fromDate")] DateOnly fromDate, [AliasAs("toDate")] DateOnly toDate);
    }
}
