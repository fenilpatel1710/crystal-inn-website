﻿using CheckinPro.WebApp.Models;
using Refit;

namespace CheckinPro.WebApp.Client.IServices
{
    public interface IHotelWebAppService
    {
        [Get("/Hotel/GetHotelProfileCompletionStatus/{hotelID}")]
        Task<ApiResponse<HotelProfileStatusWebAppModel>> GetHotelProfileCompletionStatus(int hotelID);

        [Get("/Hotel/GetHotels")]
        Task<ApiResponse<List<GetHotelWebAppModel>>> GetHotels();

        [Get("/Hotel/HotelRoom/GetHotelRoomAllDetails/{hotelID}")]
        Task<ApiResponse<List<HotelRoomDetailWebAppModel>>> GetHotelRoomAllDetails(int hotelID);

        [Get("/Hotel/GetHotelById/{hotelID}")]
        Task<ApiResponse<GetHotelWebAppModel>> GetHotelById(int hotelID);

        [Post("/Hotel/AddHotel")]
        Task<ApiResponse<Boolean>> AddHotel([Body] AddHotelWebAppModel hotelRequestModel);


        [Get("/Hotel/GetHotelTaxRate/{hotelID}")]
        Task<ApiResponse<List<HotelTaxRateWebAppModel>>> GetHotelTaxRate(int hotelID);

        [Post("/Hotel/AddEditHotelTaxRate")]
        Task<ApiResponse<Boolean>> AddEditHotelTaxRate([Body] HotelTaxRateWebAppModel hotelTaxRateRequestModel);


        [Get("/Hotel/GetHotelConfiguration/{hotelID}")]
        Task<ApiResponse<HotelConfigurationWebAppModel>> GetHotelConfiguration(int hotelID);

        [Post("/Hotel/AddEditHotelConfiguration")]
        Task<ApiResponse<Boolean>> AddEditHotelConfiguration([Body] HotelConfigurationWebAppModel hotelMasterConfigurationRequestModel);


        [Get("/Hotel/GetHotelDailyRate/{hotelID}")]
        Task<ApiResponse<List<HotelDailyRateWebAppModel>>> GetHotelDailyRate(int hotelID);

        [Post("/Hotel/AddEditHotelDailyRate")]
        Task<ApiResponse<Boolean>> AddEditHotelDailyRate([Body] HotelDailyRateWebAppModel hotelDailyRateRequestModel);



        [Get("/Hotel/GetHotelHourlyRate/{hotelID}")]
        Task<ApiResponse<List<HotelHourlyRateWebAppModel>>> GetHotelHourlyRate(int hotelID);

        [Post("/Hotel/AddEditHotelHourlyRate")]
        Task<ApiResponse<Boolean>> AddEditHotelHourlyRate([Body] HotelHourlyRateWebAppModel hotelHourlyRateRequestModel);


        [Get("/Hotel/GetHotelRoomType/{hotelID}")]
        Task<ApiResponse<List<HotelRoomTypeWebAppModel>>> GetHotelRoomType(int hotelID);

        [Get("/Hotel/GetHotelRoomTypeById/{hotelRoomTypeID}")]
        Task<ApiResponse<HotelRoomTypeWebAppModel>> GetHotelRoomTypeById(int? hotelRoomTypeID);

        [Post("/Hotel/AddEditHotelRoomType")]
        Task<ApiResponse<Boolean>> AddEditHotelRoomType([Body] HotelRoomTypeWebAppModel hotelRoomTypeRequestModel);



        [Get("/Hotel/GetHotelAdditionalRate/{hotelID}")]
        Task<ApiResponse<List<HotelAdditionalRateWebAppModel>>> GetHotelAdditionalRate(int hotelID);

        [Post("/Hotel/AddEditHotelAdditionalRate")]
        Task<ApiResponse<Boolean>> AddEditHotelAdditionalRate([Body] HotelAdditionalRateWebAppModel hotelAdditionalRateRequestModel);




        [Get("/Hotel/HotelRoom/GetHotelRooms/{hotelID}")]
        Task<ApiResponse<List<HotelRoomWebAppModel>>> GetHotelRooms(int hotelID);

        [Get("/Hotel/HotelRoom/GetHotelRoomById/{hotelRoomID}")]
        Task<ApiResponse<HotelRoomWebAppModel>> GetHotelRoomById(int hotelRoomID);

        [Post("/Hotel/HotelRoom/AddEditHotelRoom")]
        Task<ApiResponse<Boolean>> AddEditHotelRoom([Body] AddEditHotelRoomWebAppModel hotelRoomRequestModel);

        [Put("/Hotel/HotelRoom/UpdateHotelRoom/{hotelRoomID}")]
        Task<ApiResponse<Boolean>> UpdateHotelRoomStatus(int hotelRoomID, string RoomStatus);

        [Put("/Hotel/ActiveInactiveOwnerDashboard/{hotelID}")]
        Task<ApiResponse<Boolean>> ActiveInactiveOwnerDashboard(int hotelID, bool isActive);

        [Put("/Hotel/ActiveInactiveHotel/{hotelID}")]
        Task<ApiResponse<Boolean>> ActiveInactiveHotel(int hotelID, bool isActive);


        [Get("/Hotel/GetHotelExpense/{hotelID}")]
        Task<ApiResponse<List<HotelExpenseWebAppModel>>> GetHotelExpense(int hotelID);

        [Post("/Hotel/AddHotelExpense")]
        Task<ApiResponse<Boolean>> AddHotelExpense([Body] HotelExpenseWebAppModel hotelExpenseRequestModel);

        [Put("/Hotel/UpdateHotelExpense")]
        Task<ApiResponse<Boolean>> UpdateHotelExpense([Body] HotelExpenseWebAppModel hotelExpenseRequestModel);

        [Delete("/Hotel/DeleteHotelExpense/{hotelExpenseID}")]
        Task<ApiResponse<Boolean>> DeleteHotelExpense(int hotelExpenseID);

        [Delete("/Hotel/DeleteHotelDailyRate/{hotelDailyRateID}")]
        Task<ApiResponse<Boolean>> DeleteHotelDailyRate(int hotelDailyRateID);


        [Get("/Hotel/GetDirectBillingCompany/{hotelID}")]
        Task<ApiResponse<List<DirectBillingCompanyWebAppModel>>> GetDirectBillingCompany(int hotelID);

        [Post("/Hotel/AddUpdateDirectBillingCompany")]
        Task<ApiResponse<Boolean>> AddUpdateDirectBillingCompany([Body] DirectBillingCompanyWebAppModel directBillingCompanyRequestModel);
    }
}
