﻿using CheckinPro.Common.Models;
using CheckinPro.WebApp.Models;
using Refit;

namespace CheckinPro.WebApp.Client.IServices
{
    public interface IRoomStatusWebAppService
    {
        [Get("/RoomStatus/GetRoomStatuses")]
        Task<ApiResponse<List<GetRoomStatusWebAppModel>>> GetRoomStatuses();

        [Get("/RoomStatus/GetRoomStatusById/{RoomStatusID}")]
        Task<ApiResponse<GetRoomStatusWebAppModel>> GetRoomStatusById(int RoomStatusID);

        [Post("/RoomStatus/AddRoomStatus")]
        Task<ApiResponse<Boolean>> AddRoomStatus([Body] AddRoomStatusWebAppModel RoomStatusRequestModel);


        [Put("/RoomStatus/UpdateRoomStatus/{RoomStatusID}")]
        Task<ApiResponse<Boolean>> UpdateRoomStatus(int RoomStatusID, [Body] UpdateRoomStatusWebAppModel RoomStatusRequestModel);


        [Put("/RoomStatus/DeleteRoomStatus/{RoomStatusID}")]
        Task<ApiResponse<Boolean>> DeleteRoomStatus(int RoomStatusID, [Body] AuditInfoModel auditInfoModel);
    }
}