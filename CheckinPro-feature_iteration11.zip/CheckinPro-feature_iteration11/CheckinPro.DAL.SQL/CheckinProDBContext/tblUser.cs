﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblUser
{
    public int UserID { get; set; }

    public int RoleID { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string EmailID { get; set; } = null!;

    public string MobileNumber { get; set; } = null!;

    public string? Address1 { get; set; }

    public string? Address2 { get; set; }

    public int? StateID { get; set; }

    public string? City { get; set; }

    public string? ZipCode { get; set; }

    public string? ProfilePicture { get; set; }

    public string? Password { get; set; }

    public bool IsPasswordChanged { get; set; }

    public string? OTP { get; set; }

    public bool IsOTPVerified { get; set; }

    public bool IsProfileActive { get; set; }

    public bool IsProfileBlocked { get; set; }

    public bool IsProfileDeleted { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public DateTime? LastLoginDate { get; set; }

    public DateTime? LastPasswordChangeDate { get; set; }

    public virtual tblRole Role { get; set; } = null!;

    public virtual tblState? State { get; set; }

    public virtual ICollection<tblHotelUser> tblHotelUsers { get; set; } = new List<tblHotelUser>();
}
