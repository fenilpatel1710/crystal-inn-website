﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelDirectBillingCompany
{
    public int CompanyID { get; set; }

    public int HotelID { get; set; }

    public string? CompanyName { get; set; }

    public string? BillingAddress { get; set; }

    public string? MobileNumber { get; set; }

    public string? Email { get; set; }

    public string? ManagerFirstName { get; set; }

    public string? ManagerLastName { get; set; }

    public string? ManagerAddress { get; set; }

    public string? NameOnCreditCard { get; set; }

    public string? CreditCardNumber { get; set; }

    public DateOnly? ExpirationDate { get; set; }

    public string? SecurityCode { get; set; }

    public string? AccountNumber { get; set; }

    public string? RoutingNumber { get; set; }

    public string? Notes { get; set; }

    public bool IsDirectBillingCompanyActive { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblHotel Hotel { get; set; } = null!;
}
