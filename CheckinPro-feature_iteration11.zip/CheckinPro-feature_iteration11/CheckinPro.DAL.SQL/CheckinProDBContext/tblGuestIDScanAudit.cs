﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblGuestIDScanAudit
{
    public int ScanAuditID { get; set; }

    public int? ScanID { get; set; }

    public DateTime? ActionDateTime { get; set; }

    public string? ActionComment { get; set; }
}
