﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelRoomBookingMiscDetail
{
    public int HotelRoomBookingMiscellaneousID { get; set; }

    public int? HotelRoomBookingID { get; set; }

    public DateTime? MiscellaneousDate { get; set; }

    public decimal? MiscellaneousAmount { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public virtual tblHotelRoomBooking? HotelRoomBooking { get; set; }
}
