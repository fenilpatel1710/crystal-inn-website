﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelHourlyRate
{
    public int HotelHourlyRateID { get; set; }

    public int HotelID { get; set; }

    public int? Hour { get; set; }

    public decimal? HourlyRate { get; set; }

    public bool IsHotelHourlyRateActive { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblHotel Hotel { get; set; } = null!;
}
