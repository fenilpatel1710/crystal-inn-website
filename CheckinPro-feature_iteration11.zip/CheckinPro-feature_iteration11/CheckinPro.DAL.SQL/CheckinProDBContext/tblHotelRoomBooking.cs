﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelRoomBooking
{
    public int HotelRoomBookingID { get; set; }

    public int HotelRoomTypeID { get; set; }

    public int? HotelRoomID { get; set; }

    public string? BookingCode { get; set; }

    public DateTime? ScheduledCheckInDate { get; set; }

    public DateTime? ScheduledCheckOutDate { get; set; }

    public int? Duration { get; set; }

    public DateTime? ActualCheckInDate { get; set; }

    public DateTime? ActualCheckOutDate { get; set; }

    public int? NumberOfGuests { get; set; }

    public bool IsHourlyBooking { get; set; }

    public string? BookingStatus { get; set; }

    public string? GuestSpecialRequests { get; set; }

    public string? GuestNoteType { get; set; }

    public string? GuestNotes { get; set; }

    public bool IsBookingCancelled { get; set; }

    public string? CancellationReason { get; set; }

    public bool IsIncludedInReport { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblHotelRoom? HotelRoom { get; set; }

    public virtual tblHotelRoomType HotelRoomType { get; set; } = null!;

    public virtual ICollection<tblHotelRoomBookingAudit> tblHotelRoomBookingAudits { get; set; } = new List<tblHotelRoomBookingAudit>();

    public virtual ICollection<tblHotelRoomBookingGuest> tblHotelRoomBookingGuests { get; set; } = new List<tblHotelRoomBookingGuest>();

    public virtual ICollection<tblHotelRoomBookingMiscDetail> tblHotelRoomBookingMiscDetails { get; set; } = new List<tblHotelRoomBookingMiscDetail>();

    public virtual ICollection<tblHotelRoomBookingRateDetail> tblHotelRoomBookingRateDetails { get; set; } = new List<tblHotelRoomBookingRateDetail>();

    public virtual ICollection<tblHotelRoomBookingTaxRate> tblHotelRoomBookingTaxRates { get; set; } = new List<tblHotelRoomBookingTaxRate>();

    public virtual ICollection<tblHotelRoomCleaningAudit> tblHotelRoomCleaningAudits { get; set; } = new List<tblHotelRoomCleaningAudit>();

    public virtual ICollection<tblPayment> tblPayments { get; set; } = new List<tblPayment>();
}
