﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelRoom
{
    public int HotelRoomID { get; set; }

    public int HotelID { get; set; }

    public int HotelRoomTypeID { get; set; }

    public string? RoomNumber { get; set; }

    public int? Floor { get; set; }

    public int? MaxOccupancy { get; set; }

    public string? RoomStatus { get; set; }

    public string? Description { get; set; }

    public bool IsHotelRoomActive { get; set; }

    public bool IsHotelRoomDeleted { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblHotel Hotel { get; set; } = null!;

    public virtual tblHotelRoomType HotelRoomType { get; set; } = null!;

    public virtual ICollection<tblHotelRoomBooking> tblHotelRoomBookings { get; set; } = new List<tblHotelRoomBooking>();

    public virtual ICollection<tblHotelRoomCleaningAudit> tblHotelRoomCleaningAudits { get; set; } = new List<tblHotelRoomCleaningAudit>();
}
