﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelExpense
{
    public int HotelExpenseID { get; set; }

    public int HotelID { get; set; }

    public DateOnly? ExpenseDate { get; set; }

    public string? ExpenseType { get; set; }

    public decimal? ExpenseAmount { get; set; }

    public string? ExpenseDescription { get; set; }

    public byte[]? Attachment { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public virtual tblHotel Hotel { get; set; } = null!;
}
