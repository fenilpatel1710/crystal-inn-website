﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelRoomCleaningAudit
{
    public int HotelRoomCleaningAuditID { get; set; }

    public int? HotelRoomBookingID { get; set; }

    public int? HotelRoomID { get; set; }

    public string? CheckOutComment { get; set; }

    public bool IsRoomClean { get; set; }

    public DateTime? ActionDateTime { get; set; }

    public string? ActionBy { get; set; }

    public string? ActionComment { get; set; }

    public virtual tblHotelRoom? HotelRoom { get; set; }

    public virtual tblHotelRoomBooking? HotelRoomBooking { get; set; }
}
