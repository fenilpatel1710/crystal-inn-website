﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblGuestRewardHistory
{
    public int GuestRewardHistoryID { get; set; }

    public int? HotelRoomBookingGuestID { get; set; }

    public decimal? EarnedRewardPoint { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }
}
