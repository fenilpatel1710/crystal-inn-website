﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelDailyRate
{
    public int HotelDailyRateID { get; set; }

    public int HotelID { get; set; }

    public DateOnly? DailyRateDate { get; set; }

    public decimal? DailyBestAvailableRate { get; set; }

    public bool IsDailyRateActive { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblHotel Hotel { get; set; } = null!;
}
