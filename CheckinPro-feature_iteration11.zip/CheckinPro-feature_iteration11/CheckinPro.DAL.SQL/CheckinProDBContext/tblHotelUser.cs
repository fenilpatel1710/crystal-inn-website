﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelUser
{
    public int HotelUserID { get; set; }

    public int HotelID { get; set; }

    public int UserID { get; set; }

    public bool IsHotelUserActive { get; set; }

    public bool IsHotelUserBlocked { get; set; }

    public bool IsHotelUserDeleted { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblHotel Hotel { get; set; } = null!;

    public virtual tblUser User { get; set; } = null!;
}
