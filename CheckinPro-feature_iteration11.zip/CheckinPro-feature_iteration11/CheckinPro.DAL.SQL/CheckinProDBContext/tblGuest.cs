﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblGuest
{
    public int GuestID { get; set; }

    public string? GuestCode { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? FullName { get; set; }

    public string? MobileNumber { get; set; }

    public string? IdentityType { get; set; }

    public string? IdentityNumber { get; set; }

    public byte[]? FrontSideImage { get; set; }

    public string? Email { get; set; }

    public string? Address1 { get; set; }

    public string? Address2 { get; set; }

    public string? Country { get; set; }

    public string? State { get; set; }

    public string? City { get; set; }

    public string? ZipCode { get; set; }

    public int? ScanID { get; set; }

    public bool? IsGuestScanned { get; set; }

    public string? ProfilePicture { get; set; }

    public string? Password { get; set; }

    public bool? IsPasswordChanged { get; set; }

    public bool? IsProfileActive { get; set; }

    public bool? IsProfileBlocked { get; set; }

    public bool? IsProfileDeleted { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public DateTime? LastLoginDate { get; set; }

    public DateTime? LastPasswordChangeDate { get; set; }

    public virtual ICollection<tblGuestFeedback> tblGuestFeedbacks { get; set; } = new List<tblGuestFeedback>();

    public virtual ICollection<tblHotelRoomBookingGuest> tblHotelRoomBookingGuests { get; set; } = new List<tblHotelRoomBookingGuest>();
}
