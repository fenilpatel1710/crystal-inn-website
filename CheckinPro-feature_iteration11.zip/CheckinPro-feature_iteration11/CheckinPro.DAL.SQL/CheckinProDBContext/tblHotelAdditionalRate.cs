﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelAdditionalRate
{
    public int HotelAdditionalRateID { get; set; }

    public int HotelID { get; set; }

    public string? AdditionalRateName { get; set; }

    public decimal? AdditionalRate { get; set; }

    public bool IsDiscountedRate { get; set; }

    public bool IsAdditionalRateActive { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblHotel Hotel { get; set; } = null!;
}
