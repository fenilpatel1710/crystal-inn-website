﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblPayment
{
    public int PaymentID { get; set; }

    public int HotelRoomBookingID { get; set; }

    public DateTime? PaymentDate { get; set; }

    public decimal? Amount { get; set; }

    public decimal? UsedRewardPoint { get; set; }

    public string? PaymentMode { get; set; }

    public string? PaymentType { get; set; }

    public string? PaymentStatus { get; set; }

    public string? PaymentGateway { get; set; }

    public string? PaymentNotes { get; set; }

    public string? TransactionID { get; set; }

    public string? TransactionType { get; set; }

    public bool IsRefunded { get; set; }

    public DateTime? RefundDate { get; set; }

    public decimal? RefundAmount { get; set; }

    public string? RefundNotes { get; set; }

    public DateTime? PaymentCompletedOn { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblHotelRoomBooking HotelRoomBooking { get; set; } = null!;
}
