﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelRoomType
{
    public int HotelRoomTypeID { get; set; }

    public int HotelID { get; set; }

    public string? RoomTypeName { get; set; }

    public string? Description { get; set; }

    public string? RoomTypeIcon { get; set; }

    public decimal? AdjustmentRate { get; set; }

    public bool IsHotelRoomTypeActive { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblHotel Hotel { get; set; } = null!;

    public virtual ICollection<tblHotelRoomBooking> tblHotelRoomBookings { get; set; } = new List<tblHotelRoomBooking>();

    public virtual ICollection<tblHotelRoom> tblHotelRooms { get; set; } = new List<tblHotelRoom>();
}
