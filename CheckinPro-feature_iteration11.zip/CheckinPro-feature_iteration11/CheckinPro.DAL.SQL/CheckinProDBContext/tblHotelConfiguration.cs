﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelConfiguration
{
    public int HotelMasterConfigurationID { get; set; }

    public int HotelID { get; set; }

    public decimal? BestAvailableRate { get; set; }

    public decimal? CashDrawerAmount { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblHotel Hotel { get; set; } = null!;
}
