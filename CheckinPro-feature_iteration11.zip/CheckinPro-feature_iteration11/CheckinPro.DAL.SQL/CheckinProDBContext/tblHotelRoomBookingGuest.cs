﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelRoomBookingGuest
{
    public int HotelRoomBookingGuestID { get; set; }

    public int? HotelRoomBookingID { get; set; }

    public int? GuestID { get; set; }

    public bool IsPrimaryGuest { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblGuest? Guest { get; set; }

    public virtual tblHotelRoomBooking? HotelRoomBooking { get; set; }
}
