﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelRoomBookingRateDetail
{
    public int HotelRoomBookingRateDetailID { get; set; }

    public int? HotelRoomBookingID { get; set; }

    public DateTime? CheckInDate { get; set; }

    public DateTime? CheckOutDate { get; set; }

    public int? Duration { get; set; }

    public decimal? BestAvailableRate { get; set; }

    public decimal? AdjustmentRate { get; set; }

    public decimal? HourlyRate { get; set; }

    public decimal? RoomChargeAmount { get; set; }

    public decimal? TotalAmount { get; set; }

    public bool IsDiscountedRate { get; set; }

    public string? AdditionalRateType { get; set; }

    public decimal? AdditionalRateAmount { get; set; }

    public decimal? DiscountedAmount { get; set; }

    public decimal? MiscellaneousAmount { get; set; }

    public decimal? FinalAmount { get; set; }

    public decimal? Balance { get; set; }

    public bool IsExtend { get; set; }

    public int? TaxStatus { get; set; }

    public bool IsBookingActive { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblHotelRoomBooking? HotelRoomBooking { get; set; }

    public virtual ICollection<tblHotelRoomBookingTaxRate> tblHotelRoomBookingTaxRates { get; set; } = new List<tblHotelRoomBookingTaxRate>();
}
