﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotel
{
    public int HotelID { get; set; }

    public string? HotelCode { get; set; }

    public Guid? HotelUniqueID { get; set; }

    public string BusinessLLCName { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string MobileNumber { get; set; } = null!;

    public string? Address1 { get; set; }

    public string? Address2 { get; set; }

    public int? StateID { get; set; }

    public string? City { get; set; }

    public string? ZipCode { get; set; }

    public string? Website { get; set; }

    public string? Description { get; set; }

    public bool IsHotelVerified { get; set; }

    public bool IsHotelActive { get; set; }

    public bool IsOwnerDashboardVisible { get; set; }

    public bool IsHotelBlocked { get; set; }

    public bool IsHotelDeleted { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblState? State { get; set; }

    public virtual ICollection<tblGuestFeedback> tblGuestFeedbacks { get; set; } = new List<tblGuestFeedback>();

    public virtual ICollection<tblHotelAdditionalRate> tblHotelAdditionalRates { get; set; } = new List<tblHotelAdditionalRate>();

    public virtual ICollection<tblHotelConfiguration> tblHotelConfigurations { get; set; } = new List<tblHotelConfiguration>();

    public virtual ICollection<tblHotelDailyRate> tblHotelDailyRates { get; set; } = new List<tblHotelDailyRate>();

    public virtual ICollection<tblHotelDirectBillingCompany> tblHotelDirectBillingCompanies { get; set; } = new List<tblHotelDirectBillingCompany>();

    public virtual ICollection<tblHotelExpense> tblHotelExpenses { get; set; } = new List<tblHotelExpense>();

    public virtual ICollection<tblHotelHourlyRate> tblHotelHourlyRates { get; set; } = new List<tblHotelHourlyRate>();

    public virtual ICollection<tblHotelRoomType> tblHotelRoomTypes { get; set; } = new List<tblHotelRoomType>();

    public virtual ICollection<tblHotelRoom> tblHotelRooms { get; set; } = new List<tblHotelRoom>();

    public virtual ICollection<tblHotelShift> tblHotelShifts { get; set; } = new List<tblHotelShift>();

    public virtual ICollection<tblHotelTaxRate> tblHotelTaxRates { get; set; } = new List<tblHotelTaxRate>();

    public virtual ICollection<tblHotelUser> tblHotelUsers { get; set; } = new List<tblHotelUser>();
}
