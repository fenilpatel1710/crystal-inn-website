﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelRoomBookingTaxRate
{
    public int HotelRoomBookingTaxRateID { get; set; }

    public int HotelRoomBookingID { get; set; }

    public int HotelRoomBookingRateDetailID { get; set; }

    public int? HotelTaxRateID { get; set; }

    public string? BookingTaxRateName { get; set; }

    public decimal? BookingTaxRatePercentage { get; set; }

    public decimal? BookingTaxRate { get; set; }

    public bool IsBookingTaxRateActive { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblHotelRoomBooking HotelRoomBooking { get; set; } = null!;

    public virtual tblHotelRoomBookingRateDetail HotelRoomBookingRateDetail { get; set; } = null!;

    public virtual tblHotelTaxRate? HotelTaxRate { get; set; }
}
