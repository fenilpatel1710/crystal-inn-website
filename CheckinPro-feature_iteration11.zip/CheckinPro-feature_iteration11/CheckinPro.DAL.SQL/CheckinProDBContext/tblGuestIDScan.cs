﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblGuestIDScan
{
    public int ScanID { get; set; }

    public Guid? HotelUniqueID { get; set; }

    public string? Document_Number { get; set; }

    public DateTime? Document_Scan_Date { get; set; }

    public string? Scanner_JSON_File { get; set; }

    public string? Scanner_XML_File { get; set; }

    public DateTime? CreatedDate { get; set; }
}
