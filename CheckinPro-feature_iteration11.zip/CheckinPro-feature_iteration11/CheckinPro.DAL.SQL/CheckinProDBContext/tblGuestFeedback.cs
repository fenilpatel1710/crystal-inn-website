﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblGuestFeedback
{
    public int GuestFeedbackID { get; set; }

    public int GuestID { get; set; }

    public int HotelID { get; set; }

    public int? Rating { get; set; }

    public string? Feedback { get; set; }

    public DateTime? FeedbackDate { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblGuest Guest { get; set; } = null!;

    public virtual tblHotel Hotel { get; set; } = null!;
}
