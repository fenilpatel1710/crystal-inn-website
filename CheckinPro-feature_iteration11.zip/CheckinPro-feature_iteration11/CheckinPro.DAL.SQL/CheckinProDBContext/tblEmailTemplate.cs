﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblEmailTemplate
{
    public int EmailTemplateID { get; set; }

    public string? EmailTemplateName { get; set; }

    public string? EmailTemplateSubject { get; set; }

    public string? EmailTemplateDesign { get; set; }

    public bool? IsEmailTemplateActive { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }
}
