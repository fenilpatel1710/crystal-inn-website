﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelShift
{
    public int HotelShiftID { get; set; }

    public int HotelID { get; set; }

    public int? ShiftNo { get; set; }

    public DateTime? StartDate { get; set; }

    public DateTime? EndDate { get; set; }

    public decimal? StartingCash { get; set; }

    public decimal? TotalCashReceived { get; set; }

    public decimal? DropCash { get; set; }

    public decimal? EndingCash { get; set; }

    public decimal? EndingCashDrawer { get; set; }

    public bool IsShiftActive { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblHotel Hotel { get; set; } = null!;
}
