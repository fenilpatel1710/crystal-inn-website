﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelRoomBookingAudit
{
    public int HotelRoomBookingAuditID { get; set; }

    public int? HotelRoomBookingID { get; set; }

    public string? ActionName { get; set; }

    public DateTime? ActionDateTime { get; set; }

    public string? ActionBy { get; set; }

    public string? ActionComment { get; set; }

    public virtual tblHotelRoomBooking? HotelRoomBooking { get; set; }
}
