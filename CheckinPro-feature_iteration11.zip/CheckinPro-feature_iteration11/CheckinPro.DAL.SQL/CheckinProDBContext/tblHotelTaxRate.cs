﻿using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class tblHotelTaxRate
{
    public int HotelTaxRateID { get; set; }

    public int HotelID { get; set; }

    public string? TaxName { get; set; }

    public decimal? TaxRate { get; set; }

    public bool IsTaxRateActive { get; set; }

    public int? CreatedBy { get; set; }

    public DateTime? CreatedDate { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedDate { get; set; }

    public virtual tblHotel Hotel { get; set; } = null!;

    public virtual ICollection<tblHotelRoomBookingTaxRate> tblHotelRoomBookingTaxRates { get; set; } = new List<tblHotelRoomBookingTaxRate>();
}
