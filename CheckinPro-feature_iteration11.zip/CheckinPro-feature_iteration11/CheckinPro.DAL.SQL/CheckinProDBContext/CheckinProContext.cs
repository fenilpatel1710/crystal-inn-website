﻿using CheckinPro.WebApi.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace CheckinPro.DAL.SQL.CheckinProDBContext;

public partial class CheckinProContext : DbContext
{
    public CheckinProContext()
    {
    }

    public CheckinProContext(DbContextOptions<CheckinProContext> options)
        : base(options)
    {
    }

    public virtual DbSet<tblCountry> tblCountries { get; set; }

    public virtual DbSet<tblEmailTemplate> tblEmailTemplates { get; set; }

    public virtual DbSet<tblGuest> tblGuests { get; set; }

    public virtual DbSet<tblGuestFeedback> tblGuestFeedbacks { get; set; }

    public virtual DbSet<tblGuestIDScan> tblGuestIDScans { get; set; }

    public virtual DbSet<tblGuestIDScanAudit> tblGuestIDScanAudits { get; set; }

    public virtual DbSet<tblGuestReward> tblGuestRewards { get; set; }

    public virtual DbSet<tblGuestRewardHistory> tblGuestRewardHistories { get; set; }

    public virtual DbSet<tblHotel> tblHotels { get; set; }

    public virtual DbSet<tblHotelAdditionalRate> tblHotelAdditionalRates { get; set; }

    public virtual DbSet<tblHotelConfiguration> tblHotelConfigurations { get; set; }

    public virtual DbSet<tblHotelDailyRate> tblHotelDailyRates { get; set; }

    public virtual DbSet<tblHotelDirectBillingCompany> tblHotelDirectBillingCompanies { get; set; }

    public virtual DbSet<tblHotelExpense> tblHotelExpenses { get; set; }

    public virtual DbSet<tblHotelHourlyRate> tblHotelHourlyRates { get; set; }

    public virtual DbSet<tblHotelRoom> tblHotelRooms { get; set; }

    public virtual DbSet<tblHotelRoomBooking> tblHotelRoomBookings { get; set; }

    public virtual DbSet<tblHotelRoomBookingAudit> tblHotelRoomBookingAudits { get; set; }

    public virtual DbSet<tblHotelRoomBookingGuest> tblHotelRoomBookingGuests { get; set; }

    public virtual DbSet<tblHotelRoomBookingMiscDetail> tblHotelRoomBookingMiscDetails { get; set; }

    public virtual DbSet<tblHotelRoomBookingRateDetail> tblHotelRoomBookingRateDetails { get; set; }

    public virtual DbSet<tblHotelRoomBookingTaxRate> tblHotelRoomBookingTaxRates { get; set; }

    public virtual DbSet<tblHotelRoomCleaningAudit> tblHotelRoomCleaningAudits { get; set; }

    public virtual DbSet<tblHotelRoomType> tblHotelRoomTypes { get; set; }

    public virtual DbSet<tblHotelShift> tblHotelShifts { get; set; }

    public virtual DbSet<tblHotelTaxRate> tblHotelTaxRates { get; set; }

    public virtual DbSet<tblHotelUser> tblHotelUsers { get; set; }

    public virtual DbSet<tblPayment> tblPayments { get; set; }

    public virtual DbSet<tblRole> tblRoles { get; set; }

    public virtual DbSet<tblRoomStatus> tblRoomStatuses { get; set; }

    public virtual DbSet<tblState> tblStates { get; set; }

    public virtual DbSet<tblUser> tblUsers { get; set; }


    //CUSTOM TYPES FOR RETURNED DATA FROM STORED PROCEDURE
    public virtual DbSet<GetHotelRoomBookingSearchListModel> sp_FindHotelRoomBooking { get; set; }
    public virtual DbSet<GetHotelOwnerDashboardModel> sp_GetHotelMetricsByDateRange { get; set; }
    public virtual DbSet<GetHotelRoomRevenueModel> sp_GETHotelRoomRevenueByYear { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<tblCountry>(entity =>
        {
            entity.HasKey(e => e.CountryID);

            entity.ToTable("tblCountry");

            entity.Property(e => e.Capital)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CountryName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Currency)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.ISO2)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.ISO3)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.PhoneCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<tblEmailTemplate>(entity =>
        {
            entity.HasKey(e => e.EmailTemplateID);

            entity.ToTable("tblEmailTemplate");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.EmailTemplateDesign).IsUnicode(false);
            entity.Property(e => e.EmailTemplateName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.EmailTemplateSubject)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<tblGuest>(entity =>
        {
            entity.HasKey(e => e.GuestID);

            entity.ToTable("tblGuest");

            entity.Property(e => e.Address1).IsUnicode(false);
            entity.Property(e => e.Address2).IsUnicode(false);
            entity.Property(e => e.City)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Country)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.FirstName)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.FullName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.GuestCode)
                .HasMaxLength(4000)
                .HasComputedColumnSql("(format([GuestID],'00000'))", false);
            entity.Property(e => e.IdentityNumber).IsUnicode(false);
            entity.Property(e => e.IdentityType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.IsGuestScanned).HasDefaultValue(false);
            entity.Property(e => e.LastLoginDate).HasColumnType("datetime");
            entity.Property(e => e.LastName)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.LastPasswordChangeDate).HasColumnType("datetime");
            entity.Property(e => e.MobileNumber)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Password)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ProfilePicture).IsUnicode(false);
            entity.Property(e => e.State)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.ZipCode)
                .HasMaxLength(15)
                .IsUnicode(false);
        });

        modelBuilder.Entity<tblGuestFeedback>(entity =>
        {
            entity.HasKey(e => e.GuestFeedbackID);

            entity.ToTable("tblGuestFeedback");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.Feedback).IsUnicode(false);
            entity.Property(e => e.FeedbackDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.Guest).WithMany(p => p.tblGuestFeedbacks)
                .HasForeignKey(d => d.GuestID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblGuestFeedback_tblGuest");

            entity.HasOne(d => d.Hotel).WithMany(p => p.tblGuestFeedbacks)
                .HasForeignKey(d => d.HotelID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblGuestFeedback_tblHotel");
        });

        modelBuilder.Entity<tblGuestIDScan>(entity =>
        {
            entity.HasKey(e => e.ScanID).HasName("PK_tblHotelGuestIDScan");

            entity.ToTable("tblGuestIDScan");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.Document_Number)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Document_Scan_Date).HasColumnType("datetime");
            entity.Property(e => e.Scanner_XML_File).HasColumnType("xml");
        });

        modelBuilder.Entity<tblGuestIDScanAudit>(entity =>
        {
            entity.HasKey(e => e.ScanAuditID);

            entity.ToTable("tblGuestIDScanAudit");

            entity.Property(e => e.ActionComment)
                .HasMaxLength(300)
                .IsUnicode(false);
            entity.Property(e => e.ActionDateTime).HasColumnType("datetime");
        });

        modelBuilder.Entity<tblGuestReward>(entity =>
        {
            entity.HasKey(e => e.GuestRewardID);

            entity.ToTable("tblGuestReward");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.TotalRewardPoint).HasColumnType("decimal(18, 0)");
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<tblGuestRewardHistory>(entity =>
        {
            entity.HasKey(e => e.GuestRewardHistoryID);

            entity.ToTable("tblGuestRewardHistory");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.EarnedRewardPoint).HasColumnType("decimal(18, 0)");
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<tblHotel>(entity =>
        {
            entity.HasKey(e => e.HotelID);

            entity.ToTable("tblHotel");

            entity.Property(e => e.Address1).IsUnicode(false);
            entity.Property(e => e.Address2).IsUnicode(false);
            entity.Property(e => e.BusinessLLCName)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.City)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.Description).IsUnicode(false);
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.HotelCode)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasComputedColumnSql("('H'+CONVERT([varchar](9),[HotelID]))", false);
            entity.Property(e => e.HotelUniqueID).HasDefaultValueSql("(newsequentialid())");
            entity.Property(e => e.MobileNumber)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.Website)
                .HasMaxLength(90)
                .IsUnicode(false);
            entity.Property(e => e.ZipCode)
                .HasMaxLength(15)
                .IsUnicode(false);

            entity.HasOne(d => d.State).WithMany(p => p.tblHotels)
                .HasForeignKey(d => d.StateID)
                .HasConstraintName("FK_tblHotel_tblState");
        });

        modelBuilder.Entity<tblHotelAdditionalRate>(entity =>
        {
            entity.HasKey(e => e.HotelAdditionalRateID);

            entity.ToTable("tblHotelAdditionalRate");

            entity.Property(e => e.AdditionalRate).HasColumnType("decimal(18, 0)");
            entity.Property(e => e.AdditionalRateName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.Hotel).WithMany(p => p.tblHotelAdditionalRates)
                .HasForeignKey(d => d.HotelID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblHotelAdditionalRate_tblHotel");
        });

        modelBuilder.Entity<tblHotelConfiguration>(entity =>
        {
            entity.HasKey(e => e.HotelMasterConfigurationID).HasName("PK_tblHotelMasterConfiguration");

            entity.ToTable("tblHotelConfiguration");

            entity.Property(e => e.BestAvailableRate).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CashDrawerAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.Hotel).WithMany(p => p.tblHotelConfigurations)
                .HasForeignKey(d => d.HotelID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblHotelConfiguration_tblHotel");
        });

        modelBuilder.Entity<tblHotelDailyRate>(entity =>
        {
            entity.HasKey(e => e.HotelDailyRateID);

            entity.ToTable("tblHotelDailyRate");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DailyBestAvailableRate).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.Hotel).WithMany(p => p.tblHotelDailyRates)
                .HasForeignKey(d => d.HotelID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblHotelDailyRate_tblHotel");
        });

        modelBuilder.Entity<tblHotelDirectBillingCompany>(entity =>
        {
            entity.HasKey(e => e.CompanyID);

            entity.ToTable("tblHotelDirectBillingCompany");

            entity.Property(e => e.AccountNumber)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.BillingAddress).IsUnicode(false);
            entity.Property(e => e.CompanyName)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.CreditCardNumber)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ManagerAddress).IsUnicode(false);
            entity.Property(e => e.ManagerFirstName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ManagerLastName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MobileNumber)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.NameOnCreditCard)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Notes).IsUnicode(false);
            entity.Property(e => e.RoutingNumber)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.SecurityCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.Hotel).WithMany(p => p.tblHotelDirectBillingCompanies)
                .HasForeignKey(d => d.HotelID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblHotelDirectBillingCompany_tblHotel");
        });

        modelBuilder.Entity<tblHotelExpense>(entity =>
        {
            entity.HasKey(e => e.HotelExpenseID);

            entity.ToTable("tblHotelExpense");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.ExpenseAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ExpenseDescription).IsUnicode(false);
            entity.Property(e => e.ExpenseType)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.Hotel).WithMany(p => p.tblHotelExpenses)
                .HasForeignKey(d => d.HotelID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblHotelExpense_tblHotel");
        });

        modelBuilder.Entity<tblHotelHourlyRate>(entity =>
        {
            entity.HasKey(e => e.HotelHourlyRateID);

            entity.ToTable("tblHotelHourlyRate");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.HourlyRate).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.Hotel).WithMany(p => p.tblHotelHourlyRates)
                .HasForeignKey(d => d.HotelID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblHotelHourlyRate_tblHotel");
        });

        modelBuilder.Entity<tblHotelRoom>(entity =>
        {
            entity.HasKey(e => e.HotelRoomID);

            entity.ToTable("tblHotelRoom");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.Description).IsUnicode(false);
            entity.Property(e => e.RoomNumber)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.RoomStatus)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.Hotel).WithMany(p => p.tblHotelRooms)
                .HasForeignKey(d => d.HotelID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblHotelRoom_tblHotel");

            entity.HasOne(d => d.HotelRoomType).WithMany(p => p.tblHotelRooms)
                .HasForeignKey(d => d.HotelRoomTypeID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblHotelRoom_tblHotelRoomType");
        });

        modelBuilder.Entity<tblHotelRoomBooking>(entity =>
        {
            entity.HasKey(e => e.HotelRoomBookingID);

            entity.ToTable("tblHotelRoomBooking");

            entity.HasIndex(e => e.BookingCode, "UQ_BookingCode").IsUnique();

            entity.Property(e => e.ActualCheckInDate).HasColumnType("datetime");
            entity.Property(e => e.ActualCheckOutDate).HasColumnType("datetime");
            entity.Property(e => e.BookingCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BookingStatus)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CancellationReason)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.GuestNoteType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.GuestNotes)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.GuestSpecialRequests)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.IsIncludedInReport).HasDefaultValue(true);
            entity.Property(e => e.ScheduledCheckInDate).HasColumnType("datetime");
            entity.Property(e => e.ScheduledCheckOutDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.HotelRoom).WithMany(p => p.tblHotelRoomBookings)
                .HasForeignKey(d => d.HotelRoomID)
                .HasConstraintName("FK_tblHotelRoomBooking_tblHotelRoom");

            entity.HasOne(d => d.HotelRoomType).WithMany(p => p.tblHotelRoomBookings)
                .HasForeignKey(d => d.HotelRoomTypeID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblHotelRoomBooking_tblHotelRoomType");
        });

        modelBuilder.Entity<tblHotelRoomBookingAudit>(entity =>
        {
            entity.HasKey(e => e.HotelRoomBookingAuditID);

            entity.ToTable("tblHotelRoomBookingAudit");

            entity.Property(e => e.ActionBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ActionComment)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.ActionDateTime).HasColumnType("datetime");
            entity.Property(e => e.ActionName)
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.HasOne(d => d.HotelRoomBooking).WithMany(p => p.tblHotelRoomBookingAudits)
                .HasForeignKey(d => d.HotelRoomBookingID)
                .HasConstraintName("FK_tblHotelRoomBookingAudit_tblHotelRoomBooking");
        });

        modelBuilder.Entity<tblHotelRoomBookingGuest>(entity =>
        {
            entity.HasKey(e => e.HotelRoomBookingGuestID);

            entity.ToTable("tblHotelRoomBookingGuest");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.Guest).WithMany(p => p.tblHotelRoomBookingGuests)
                .HasForeignKey(d => d.GuestID)
                .HasConstraintName("FK_tblHotelRoomBookingGuest_tblGuest");

            entity.HasOne(d => d.HotelRoomBooking).WithMany(p => p.tblHotelRoomBookingGuests)
                .HasForeignKey(d => d.HotelRoomBookingID)
                .HasConstraintName("FK_tblHotelRoomBookingGuest_tblHotelRoomBooking");
        });

        modelBuilder.Entity<tblHotelRoomBookingMiscDetail>(entity =>
        {
            entity.HasKey(e => e.HotelRoomBookingMiscellaneousID).HasName("PK_tblHotelRoomBookingMiscellaneous");

            entity.ToTable("tblHotelRoomBookingMiscDetail");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.MiscellaneousAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.MiscellaneousDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.HotelRoomBooking).WithMany(p => p.tblHotelRoomBookingMiscDetails)
                .HasForeignKey(d => d.HotelRoomBookingID)
                .HasConstraintName("FK_tblHotelRoomBookingMiscellaneous_tblHotelRoomBookingMiscellaneous");
        });

        modelBuilder.Entity<tblHotelRoomBookingRateDetail>(entity =>
        {
            entity.HasKey(e => e.HotelRoomBookingRateDetailID);

            entity.ToTable("tblHotelRoomBookingRateDetail");

            entity.Property(e => e.AdditionalRateAmount).HasColumnType("decimal(18, 0)");
            entity.Property(e => e.AdditionalRateType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.AdjustmentRate).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Balance).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.BestAvailableRate).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CheckInDate).HasColumnType("datetime");
            entity.Property(e => e.CheckOutDate).HasColumnType("datetime");
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.DiscountedAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.FinalAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.HourlyRate).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.IsBookingActive).HasDefaultValue(true);
            entity.Property(e => e.MiscellaneousAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.RoomChargeAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.TotalAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.HotelRoomBooking).WithMany(p => p.tblHotelRoomBookingRateDetails)
                .HasForeignKey(d => d.HotelRoomBookingID)
                .HasConstraintName("FK_tblHotelRoomBookingRateDetail_tblHotelRoomBooking");
        });

        modelBuilder.Entity<tblHotelRoomBookingTaxRate>(entity =>
        {
            entity.HasKey(e => e.HotelRoomBookingTaxRateID);

            entity.ToTable("tblHotelRoomBookingTaxRate");

            entity.Property(e => e.BookingTaxRate).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.BookingTaxRateName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.BookingTaxRatePercentage).HasColumnType("decimal(4, 0)");
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.IsBookingTaxRateActive).HasDefaultValue(true);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.HotelRoomBooking).WithMany(p => p.tblHotelRoomBookingTaxRates)
                .HasForeignKey(d => d.HotelRoomBookingID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblHotelRoomBookingTaxRate_tblHotelRoomBooking");

            entity.HasOne(d => d.HotelRoomBookingRateDetail).WithMany(p => p.tblHotelRoomBookingTaxRates)
                .HasForeignKey(d => d.HotelRoomBookingRateDetailID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblHotelRoomBookingTaxRate_tblHotelRoomBookingRateDetail");

            entity.HasOne(d => d.HotelTaxRate).WithMany(p => p.tblHotelRoomBookingTaxRates)
                .HasForeignKey(d => d.HotelTaxRateID)
                .HasConstraintName("FK_tblHotelRoomBookingTaxRate_tblHotelTaxRate");
        });

        modelBuilder.Entity<tblHotelRoomCleaningAudit>(entity =>
        {
            entity.HasKey(e => e.HotelRoomCleaningAuditID);

            entity.ToTable("tblHotelRoomCleaningAudit");

            entity.Property(e => e.ActionBy)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ActionComment)
                .HasMaxLength(300)
                .IsUnicode(false);
            entity.Property(e => e.ActionDateTime).HasColumnType("datetime");
            entity.Property(e => e.CheckOutComment)
                .HasMaxLength(300)
                .IsUnicode(false);

            entity.HasOne(d => d.HotelRoomBooking).WithMany(p => p.tblHotelRoomCleaningAudits)
                .HasForeignKey(d => d.HotelRoomBookingID)
                .HasConstraintName("FK_tblHotelRoomCleaningAudit_tblHotelRoomBooking");

            entity.HasOne(d => d.HotelRoom).WithMany(p => p.tblHotelRoomCleaningAudits)
                .HasForeignKey(d => d.HotelRoomID)
                .HasConstraintName("FK_tblHotelRoomCleaningAudit_tblHotelRoom");
        });

        modelBuilder.Entity<tblHotelRoomType>(entity =>
        {
            entity.HasKey(e => e.HotelRoomTypeID);

            entity.ToTable("tblHotelRoomType");

            entity.Property(e => e.AdjustmentRate).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.Description).IsUnicode(false);
            entity.Property(e => e.RoomTypeIcon)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RoomTypeName)
                .HasMaxLength(90)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.Hotel).WithMany(p => p.tblHotelRoomTypes)
                .HasForeignKey(d => d.HotelID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblHotelRoomType_tblHotel");
        });

        modelBuilder.Entity<tblHotelShift>(entity =>
        {
            entity.HasKey(e => e.HotelShiftID);

            entity.ToTable("tblHotelShift");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.DropCash).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.EndingCash).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.EndingCashDrawer).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.StartingCash).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.TotalCashReceived).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.Hotel).WithMany(p => p.tblHotelShifts)
                .HasForeignKey(d => d.HotelID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblHotelShift_tblHotel");
        });

        modelBuilder.Entity<tblHotelTaxRate>(entity =>
        {
            entity.HasKey(e => e.HotelTaxRateID);

            entity.ToTable("tblHotelTaxRate");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.TaxName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TaxRate).HasColumnType("decimal(4, 0)");
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.Hotel).WithMany(p => p.tblHotelTaxRates)
                .HasForeignKey(d => d.HotelID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblHotelTaxRate_tblHotel");
        });

        modelBuilder.Entity<tblHotelUser>(entity =>
        {
            entity.HasKey(e => e.HotelUserID);

            entity.ToTable("tblHotelUser");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.Hotel).WithMany(p => p.tblHotelUsers)
                .HasForeignKey(d => d.HotelID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblHotelUser_tblHotel");

            entity.HasOne(d => d.User).WithMany(p => p.tblHotelUsers)
                .HasForeignKey(d => d.UserID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblHotelUser_tblUser");
        });

        modelBuilder.Entity<tblPayment>(entity =>
        {
            entity.HasKey(e => e.PaymentID);

            entity.ToTable("tblPayment");

            entity.Property(e => e.Amount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.PaymentCompletedOn).HasColumnType("datetime");
            entity.Property(e => e.PaymentDate).HasColumnType("datetime");
            entity.Property(e => e.PaymentGateway)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PaymentMode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PaymentNotes)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.PaymentStatus)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PaymentType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RefundAmount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.RefundDate).HasColumnType("datetime");
            entity.Property(e => e.RefundNotes)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.TransactionType)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.UsedRewardPoint).HasColumnType("decimal(18, 0)");

            entity.HasOne(d => d.HotelRoomBooking).WithMany(p => p.tblPayments)
                .HasForeignKey(d => d.HotelRoomBookingID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblPayment_tblHotelRoomBooking");
        });

        modelBuilder.Entity<tblRole>(entity =>
        {
            entity.HasKey(e => e.RoleID);

            entity.ToTable("tblRole");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.Description).IsUnicode(false);
            entity.Property(e => e.RoleName)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<tblRoomStatus>(entity =>
        {
            entity.HasKey(e => e.RoomStatusID);

            entity.ToTable("tblRoomStatus");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.Description).IsUnicode(false);
            entity.Property(e => e.RoomStatusIcon)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RoomStatusName)
                .HasMaxLength(90)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<tblState>(entity =>
        {
            entity.HasKey(e => e.StateID);

            entity.ToTable("tblState");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.StateName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

            entity.HasOne(d => d.Country).WithMany(p => p.tblStates)
                .HasForeignKey(d => d.CountryID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblState_tblCountry");
        });

        modelBuilder.Entity<tblUser>(entity =>
        {
            entity.HasKey(e => e.UserID);

            entity.ToTable("tblUser");

            entity.Property(e => e.Address1).IsUnicode(false);
            entity.Property(e => e.Address2).IsUnicode(false);
            entity.Property(e => e.City)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DeletedDate).HasColumnType("datetime");
            entity.Property(e => e.EmailID)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.FirstName)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.LastLoginDate).HasColumnType("datetime");
            entity.Property(e => e.LastName)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.LastPasswordChangeDate).HasColumnType("datetime");
            entity.Property(e => e.MobileNumber)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.OTP)
                .HasMaxLength(6)
                .IsUnicode(false);
            entity.Property(e => e.Password).IsUnicode(false);
            entity.Property(e => e.ProfilePicture).IsUnicode(false);
            entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            entity.Property(e => e.ZipCode)
                .HasMaxLength(15)
                .IsUnicode(false);

            entity.HasOne(d => d.Role).WithMany(p => p.tblUsers)
                .HasForeignKey(d => d.RoleID)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_tblUser_tblRole");

            entity.HasOne(d => d.State).WithMany(p => p.tblUsers)
                .HasForeignKey(d => d.StateID)
                .HasConstraintName("FK_tblUser_tblState");
        });

        //CUSTOM TYPES FOR RETURNED DATA FROM STORED PROCEDURE
        modelBuilder.Entity<GetHotelRoomBookingSearchListModel>().HasNoKey();
        modelBuilder.Entity<GetHotelOwnerDashboardModel>().HasNoKey();
        modelBuilder.Entity<GetHotelRoomRevenueModel>().HasNoKey();

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
