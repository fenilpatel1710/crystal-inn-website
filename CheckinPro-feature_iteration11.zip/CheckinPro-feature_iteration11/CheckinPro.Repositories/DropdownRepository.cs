﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Repositories.IRepository;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Repositories
{
    public class DropdownRepository : IDropdownRepository
    {
        private readonly ILogger _logger;
        private readonly CheckinProContext _checkinProContext;

        public DropdownRepository(ILogger<DropdownRepository> logger, CheckinProContext checkinPro_Context)
        {
            _logger = logger;
            _checkinProContext = checkinPro_Context;
        }


        /// <summary>
        /// Retrieves a list of roles for dropdown.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="SelectionItemModel"/> representing the role data.</returns>
        public async Task<Result<List<SelectionItemModel>>> GetRolesForDropdown()
        {
            try
            {
                _logger.LogInformation("Repository: GetRolesForDrodown method initiated.");
                // Transform the entities into RoleModel instances
                var roleModels = await _checkinProContext.tblRoles.Where(item => item.IsRoleActive == true).Select(item => new SelectionItemModel
                {
                    ItemID = item.RoleID,
                    ItemName = item.RoleName
                }).ToListAsync();

                _logger.LogInformation("Repository: GetRolesForDrodown method execution completed.");
                _logger.LogInformation($"Repository: GetRolesForDrodown method execution completed. Total countries retrieved: {roleModels.Count}.");


                // Return the list of RoleModel
                return Result.Success(roleModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetRolesForDrodown method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching active roles.");
            }
        }

        /// <summary>
        /// Retrieves a list of countries for dropdown.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="SelectionItemModel"/> representing the country data.</returns>
        public async Task<Result<List<SelectionItemModel>>> GetCountriesForDropdown()
        {
            try
            {
                _logger.LogInformation("Repository: GetActiveCountries method initiated.");
                // Transform the entities into CountryModel instances
                var countryModels = await _checkinProContext.tblCountries.Where(item => item.IsCountryActive == true && item.IsCountryDeleted == false).Select(item => new SelectionItemModel
                {
                    ItemID = item.CountryID,
                    ItemName = item.CountryName
                }).ToListAsync();

                _logger.LogInformation("Repository: GetActiveCountries method execution completed.");
                _logger.LogInformation($"Repository: GetActiveCountries method execution completed. Total countries retrieved: {countryModels.Count}.");


                // Return the list of CountryModel
                return Result.Success(countryModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetActiveCountries method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching active countries.");
            }
        }

        /// <summary>
        /// Retrieves a list of states for dropdown.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="SelectionItemModel"/> representing the state data.</returns>
        public async Task<Result<List<SelectionItemModel>>> GetStatesForDropdown(int countryID)
        {
            try
            {
                _logger.LogInformation("Repository: GetStatesForDropdown method initiated.");
                // Transform the entities into StateModel instances
                var stateModels = await _checkinProContext.tblStates.Where(item => item.CountryID == countryID && item.IsStateActive == true && item.IsStateDeleted == false).Select(item => new SelectionItemModel
                {
                    ItemID = item.StateID,
                    ItemName = item.StateName
                }).ToListAsync();

                _logger.LogInformation("Repository: GetStatesForDropdown method execution completed.");
                _logger.LogInformation($"Repository: GetStatesForDropdown method execution completed. Total States retrieved: {stateModels.Count}.");


                // Return the list of StateModel
                return Result.Success(stateModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetStatesForDropdown method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching active State.");
            }
        }

        /// <summary>
        /// Retrieves a list of hotel room types for dropdown.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="SelectionItemModel"/> representing the hotel room type data.</returns>
        public async Task<Result<List<SelectionItemModel>>> GetHotelRoomTypesForDropdown(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelRoomTypesForDropdown method initiated.");
                // Transform the entities into RoomTypeModel instances
                var roomTypeModels = await _checkinProContext.tblHotelRoomTypes.Where(item => item.HotelID == hotelID && item.IsHotelRoomTypeActive == true).Select(item => new SelectionItemModel
                {
                    ItemID = item.HotelRoomTypeID,
                    ItemName = item.RoomTypeName,
                    ItemIcon = item.RoomTypeIcon
                }).ToListAsync();

                _logger.LogInformation("Repository: GetHotelRoomTypesForDropdown method execution completed.");
                _logger.LogInformation($"Repository: GetHotelRoomTypesForDropdown method execution completed. Total room types retrieved: {roomTypeModels.Count}.");


                // Return the list of GetRoomTypeModel
                return Result.Success(roomTypeModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelRoomTypesForDropdown method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching active room types.");
            }
        }

        /// <summary>
        /// Retrieves a list of room  status for dropdown.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="SelectionItemModel"/> representing the room  status data.</returns>
        public async Task<Result<List<SelectionItemModel>>> GetRoomStatusesForDropdown()
        {
            try
            {
                _logger.LogInformation("Repository: GetRoomStatusesForDropdown method initiated.");
                // Transform the entities into GetRoomStatusModel instances
                var roomStatusModels = await _checkinProContext.tblRoomStatuses.Where(item => item.IsActive == true && item.IsDeleted == false).Select(item => new SelectionItemModel
                {
                    ItemID = item.RoomStatusID,
                    ItemName = item.RoomStatusName,
                    ItemIcon = item.RoomStatusIcon
                }).ToListAsync();

                _logger.LogInformation("Repository: GetRoomStatusesForDropdown method execution completed.");
                _logger.LogInformation($"Repository: GetRoomStatusesForDropdown method execution completed. Total room  status retrieved: {roomStatusModels.Count}.");


                // Return the list of room  status
                return Result.Success(roomStatusModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetRoomStatusesForDropdown method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching active room  statuses.");
            }
        }
    }
}
