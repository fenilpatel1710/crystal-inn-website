﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.Common.Models.Constants;
using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Report.Templates;
using CheckinPro.Repositories.IRepository;
using CheckinPro.WebApi.Models;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System.Data;
using static CheckinPro.Common.Models.Constants.CommonConstants;

namespace CheckinPro.Repositories
{
    public class DashboardRepository : IDashboardRepository
    {
        private readonly ILogger _logger;
        private readonly CheckinProContext _checkinProContext;
        private readonly IHotelReportRepository _hotelReportRepository;

        public DashboardRepository(ILogger<DashboardRepository> logger, CheckinProContext checkinProContext, IHotelReportRepository hotelReportRepository)
        {
            _logger = logger;
            _checkinProContext = checkinProContext;
            _hotelReportRepository = hotelReportRepository;
        }
        /// <summary>
        /// Retrieves the count of various hotel room statuses for a given hotel.
        /// </summary>
        /// <param name="hotelID">The unique identifier of the hotel.</param>
        /// <returns>A <see cref="Result"/> containing a <see cref="GetDashboardModel"/> object with the counts of different room statuses.</returns>
        public async Task<Result<GetDashboardModel>> GetHotelRoomStatusCounts(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelRoomStatusCounts method initiated for HotelID: {HotelID}", hotelID);

                var checkInWindowStart = CommonConstants.GetSystemMinDate();
                var checkInWindowEnd = CommonConstants.GetSystemMaxDate();


                // Fetch all hotel rooms in a single query
                var hotelRooms = await _checkinProContext.tblHotelRooms.Where(r => r.HotelID == hotelID).ToListAsync();

                // Fetch all bookings in a single query with necessary filtering
                //var hotelRoomIds = hotelRooms.Select(r => r.HotelRoomID).ToList();
                //var hotelBookings = await _checkinProContext.tblHotelRoomBookings.Where(b => b.ScheduledCheckInDate.Value.Date == today && _checkinProContext.tblHotelRoomTypes.Any(rt => rt.HotelRoomTypeID == b.HotelRoomTypeID && rt.HotelID == hotelID)).ToListAsync();
                //var hotelBookings = await _checkinProContext.tblHotelRoomBookings.Where(b => b.ScheduledCheckInDate.Value.Date == today && b.HotelRoomType.HotelID == hotelID).ToListAsync();

                var hotelBookings = await _checkinProContext.tblHotelRoomBookings
                    .Where(item => item.HotelRoomType.HotelID == hotelID &&
                                   ((item.ScheduledCheckInDate >= checkInWindowStart && item.ScheduledCheckInDate <= checkInWindowEnd) ||
                                   (item.ScheduledCheckOutDate >= checkInWindowStart && item.ScheduledCheckOutDate <= checkInWindowEnd) ||
                                   (item.ScheduledCheckInDate <= checkInWindowStart && item.ScheduledCheckOutDate >= checkInWindowEnd))
                          ).ToListAsync();

                var result = new GetDashboardModel
                {

                    InHouseCount = hotelBookings.Count(b => b.BookingStatus == BookingStatusMessages.CheckedIn),
                    DirtyRoomCount = hotelRooms.Count(r => r.RoomStatus == RoomStatusMessages.PendingCleaning),
                    PendingCheckOutCount = hotelBookings.Count(booking => booking.BookingStatus == BookingStatusMessages.CheckedIn && booking.ScheduledCheckOutDate >= checkInWindowStart && booking.ScheduledCheckOutDate <= checkInWindowEnd),
                    CheckedOutCount = hotelBookings.Count(b => b.BookingStatus == BookingStatusMessages.CheckedOut),
                    ArrivalsCount = hotelBookings.Count(r => r.BookingStatus == RoomStatusMessages.Booked),
                    Cancelled = hotelBookings.Count(b => b.BookingStatus == BookingStatusMessages.Cancelled),
                    TotalRoomsCount = hotelRooms.Count,
                    OutOfServiceCount = hotelRooms.Count(r => r.RoomStatus == RoomStatusMessages.OutOfService),
                    SoldCount = hotelBookings.Count(b => b.BookingStatus == BookingStatusMessages.CheckedIn),
                    AvailableRoomsCount = hotelRooms.Count
                          - hotelRooms.Count(r => r.RoomStatus == RoomStatusMessages.OutOfService)
                          - hotelBookings.Count(b => b.BookingStatus == BookingStatusMessages.CheckedIn),
                };

                return Result.Success(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching hotel room status counts for HotelID: {HotelID}", hotelID);
                return Result.Error("An error occurred while fetching hotel room status counts.");
            }
        }

        public async Task<Result<List<HotelShiftModel>>> GetHotelShiftDetailByDate(int hotelID, DateOnly fromDate, DateOnly toDate)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelShiftDetail method initiated.");

                List<HotelShiftModel> dbhotelShiftData = new();

                var (startDateTime, endDateTime) = CommonConstants.GetAdjustedHotelDateRange(fromDate, toDate);

                var shiftData = _checkinProContext.tblHotelShifts.Where(shift => shift.HotelID == hotelID && shift.StartDate >= startDateTime && shift.StartDate <= endDateTime).ToList();

                foreach (var shift in shiftData)
                {
                    decimal? shiftCashReceived = 0;
                    if (shift.IsShiftActive)
                    {
                        var bookingData = _checkinProContext.tblHotels
                     .Include(roomType => roomType.tblHotelRoomTypes)
                         .ThenInclude(booking => booking.tblHotelRoomBookings)
                             .ThenInclude(payment => payment.tblPayments)
                     .Where(hotel => hotel.HotelID == hotelID).FirstOrDefault();

                        shiftCashReceived = bookingData.tblHotelRoomTypes
                           .SelectMany(booking => booking.tblHotelRoomBookings)
                           .SelectMany(booking => booking.tblPayments.Where(payment => payment.PaymentMode == "Cash" && payment.PaymentStatus == CommonConstants.PaymentStatusMessages.Completed && !payment.IsRefunded && (payment.PaymentCompletedOn >= shift.StartDate && payment.PaymentCompletedOn <= DateTime.Now)))
                           .Sum(payment => payment.Amount);
                    }

                    var dbUserData = _checkinProContext.tblUsers.Where(item => item.UserID == shift.CreatedBy).FirstOrDefault();

                    var hotelShiftData = new HotelShiftModel
                    {
                        HotelShiftID = shift.HotelShiftID,
                        ShiftNo = shift.ShiftNo,
                        StartDate = shift.StartDate,
                        EndDate = shift.EndDate,
                        StartingCash = shift.StartingCash,
                        TotalCashReceived = shift.IsShiftActive ? shiftCashReceived : shift.TotalCashReceived,
                        DropCash = shift.DropCash,
                        EndingCash = shift.EndingCash,
                        EndingCashDrawer = shift.EndingCashDrawer,
                        IsShiftActive = shift.IsShiftActive,
                        CreatedBy = shift.CreatedBy,
                        ShiftOwnerName = dbUserData.FirstName + " " + dbUserData.LastName
                    };

                    dbhotelShiftData.Add(hotelShiftData);
                }

                return Result.Success(dbhotelShiftData); // ✅ Return after processing all shifts
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching hotel room status counts for HotelID: {HotelID}", hotelID);
                return Result.Error("An error occurred while fetching hotel room status counts.");
            }
        }

        public async Task<Result<HotelShiftModel>> GetHotelShiftDetail(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelShiftDetail method initiated.");

                var shiftData = _checkinProContext.tblHotelShifts.Where(shift => shift.HotelID == hotelID && shift.IsShiftActive).FirstOrDefault();

                if (shiftData != null)
                {
                    var bookingData = _checkinProContext.tblHotels
                    .Include(roomType => roomType.tblHotelRoomTypes)
                        .ThenInclude(booking => booking.tblHotelRoomBookings)
                            .ThenInclude(payment => payment.tblPayments)
                    .Where(hotel => hotel.HotelID == hotelID).FirstOrDefault();

                    var shiftCashReceived = bookingData.tblHotelRoomTypes
                       .SelectMany(booking => booking.tblHotelRoomBookings)
                       .SelectMany(booking => booking.tblPayments)
                       .Where(payment => payment.PaymentMode == "Cash" && payment.PaymentStatus == CommonConstants.PaymentStatusMessages.Completed && !payment.IsRefunded && (payment.PaymentCompletedOn >= shiftData.StartDate && payment.PaymentCompletedOn <= DateTime.Now))
                       .Sum(payment => payment.Amount);

                    var shiftCashRefund = bookingData.tblHotelRoomTypes
                     .SelectMany(booking => booking.tblHotelRoomBookings)
                     .SelectMany(booking => booking.tblPayments)
                     .Where(payment => payment.PaymentMode == "Cash" && payment.PaymentStatus == CommonConstants.PaymentStatusMessages.Completed && payment.IsRefunded && (payment.RefundDate >= shiftData.StartDate && payment.RefundDate <= DateTime.Now))
                     .Sum(payment => payment.RefundAmount);

                    var hotelShiftData = new HotelShiftModel
                    {
                        HotelShiftID = shiftData.HotelShiftID,
                        ShiftNo = shiftData.ShiftNo,
                        StartDate = shiftData.StartDate,
                        EndDate = shiftData.EndDate,
                        StartingCash = shiftData.StartingCash,
                        TotalCashReceived = shiftCashReceived - shiftCashRefund,
                        DropCash = shiftData.DropCash,
                        EndingCash = shiftData.EndingCash,
                        EndingCashDrawer = shiftData.EndingCashDrawer,
                        IsShiftActive = shiftData.IsShiftActive,
                        CreatedBy = shiftData.CreatedBy
                    };
                    return Result.Success(hotelShiftData);
                }
                else
                {

                    return Result.NotFound();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching hotel room status counts for HotelID: {HotelID}", hotelID);
                return Result.Error("An error occurred while fetching hotel room status counts.");
            }
        }

        public async Task<Result> StartHotelShift(HotelShiftModel hotelShiftRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: StartHotelShift method initiated.");

                    // Validate the request model
                    if (hotelShiftRequestModel == null)
                    {
                        _logger.LogWarning("Repository: StartHotelShift called with a null hotelShiftRequestModel.");
                        return Result.NoContent();
                    }

                    // Get the current date for today's shift
                    var currentDate = DateTime.Now.Date;

                    // Check if there is already an active shift for the hotel on the current date
                    var activeShift = await _checkinProContext.tblHotelShifts
                        .Where(shift => shift.HotelID == hotelShiftRequestModel.HotelID && shift.StartDate.HasValue && shift.StartDate.Value.Date == currentDate && shift.IsShiftActive)
                        .FirstOrDefaultAsync();

                    if (activeShift != null)
                    {
                        _logger.LogWarning($"Repository: A shift is already active for HotelID {hotelShiftRequestModel.HotelID} on {currentDate}. Cannot start a new shift.");
                        return Result.Error("A shift is already active for today. Cannot start a new shift.");
                    }

                    // Find the last shift number for the same day and hotel
                    var lastShift = await _checkinProContext.tblHotelShifts
                        .Where(shift => shift.HotelID == hotelShiftRequestModel.HotelID && shift.StartDate.HasValue && shift.StartDate.Value.Date == currentDate)
                        .OrderByDescending(shift => shift.ShiftNo)
                        .FirstOrDefaultAsync();

                    // Determine the next shift number
                    int? nextShiftNo = lastShift != null ? lastShift.ShiftNo + 1 : 1;

                    // Create a new hotel shift entry
                    tblHotelShift dbHotelShift = new tblHotelShift
                    {
                        HotelID = hotelShiftRequestModel.HotelID,
                        StartDate = DateTime.Now,
                        StartingCash = hotelShiftRequestModel.StartingCash,
                        ShiftNo = nextShiftNo,
                        IsShiftActive = true,
                        CreatedBy = auditInfoModel.AuditUserID,
                        CreatedDate = DateTime.Now
                    };

                    // Insert the new shift into the database
                    await _checkinProContext.tblHotelShifts.AddAsync(dbHotelShift);
                    await _checkinProContext.SaveChangesAsync();

                    // Commit transaction
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully added hotel shift with ShiftNo {nextShiftNo}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while adding shift. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: StartHotelShift Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while adding the hotel shift.");
                }
            }
        }

        public async Task<Result> EndHotelShift(HotelShiftModel hotelShiftRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: EndHotelShift method initiated.");

                    // Validate the request model
                    if (hotelShiftRequestModel == null)
                    {
                        _logger.LogWarning("Repository: StartHotelShift called with a null hotelShiftRequestModel.");
                        return Result.NoContent();
                    }

                    // Find the active shift for the given hotel
                    var activeShift = await _checkinProContext.tblHotelShifts
                        .Where(shift => shift.HotelShiftID == hotelShiftRequestModel.HotelShiftID && shift.IsShiftActive)
                        .FirstOrDefaultAsync();

                    if (activeShift == null)
                    {
                        _logger.LogWarning($"Repository: No active shift found.");
                        return Result.Error("No active shift found for the specified hotel.");
                    }

                    // Update the found active shift with end details
                    activeShift.EndDate = DateTime.Now;
                    activeShift.TotalCashReceived = hotelShiftRequestModel.TotalCashReceived;
                    activeShift.DropCash = hotelShiftRequestModel.DropCash;
                    activeShift.EndingCash = hotelShiftRequestModel.EndingCash;
                    activeShift.EndingCashDrawer = hotelShiftRequestModel.EndingCashDrawer;
                    activeShift.IsShiftActive = false;
                    activeShift.UpdatedBy = auditInfoModel.AuditUserID;
                    activeShift.UpdatedDate = DateTime.Now;

                    // Save changes to the database
                    _checkinProContext.tblHotelShifts.Update(activeShift);
                    await _checkinProContext.SaveChangesAsync();

                    // Commit the transaction
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully ended shift.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while ending shift. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: EndHotelShift Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while ending the hotel shift.");
                }
            }
        }

        public async Task<Result<List<GetHotelOwnerDashboardModel>>> GetHotelMetricsByDateRange(int hotelID, DateTime? selectedDate, string metrix)
        {
            try
            {
                var startDate = DateOnly.FromDateTime(selectedDate!.Value);
                var endDate = startDate;

                List<GetHotelOwnerDashboardModel> responseDataList = new List<GetHotelOwnerDashboardModel>();

                if (metrix == "DTD")
                {
                    var DTY_CY = await _hotelReportRepository.GetHotelDashboardDetails(hotelID, startDate, endDate, "DTY_CY");
                    responseDataList.Add(DTY_CY);

                    var lastYearStartDateDTY = startDate.AddYears(-1);
                    var lastYearEndDateDTY = endDate.AddYears(-1);
                    var DTY_LY = await _hotelReportRepository.GetHotelDashboardDetails(hotelID, lastYearStartDateDTY, lastYearEndDateDTY, "DTY_LY");
                    responseDataList.Add(DTY_LY);
                }
                else if (metrix == "MTD")
                {
                    var monthStartDate = new DateOnly(startDate.Year, startDate.Month, 1);
                    var MTD_CY = await _hotelReportRepository.GetHotelDashboardDetails(hotelID, monthStartDate, endDate, "MTD_CY");
                    responseDataList.Add(MTD_CY);

                    var lastYearStartDateMTY = monthStartDate.AddYears(-1);
                    var lastYearEndDateMTY = endDate.AddYears(-1);
                    var MTD_LY = await _hotelReportRepository.GetHotelDashboardDetails(hotelID, lastYearStartDateMTY, lastYearEndDateMTY, "MTD_LY");
                    responseDataList.Add(MTD_LY);
                }
                else
                {
                    var yearStartDate = new DateOnly(startDate.Year, 1, 1);
                    var YTD_CY = await _hotelReportRepository.GetHotelDashboardDetails(hotelID, yearStartDate, endDate, "YTD_CY");
                    responseDataList.Add(YTD_CY);

                    var lastYearStartDateYTY = yearStartDate.AddYears(-1);
                    var lastYearEndDateYTY = endDate.AddYears(-1);
                    var YTD_LY = await _hotelReportRepository.GetHotelDashboardDetails(hotelID, lastYearStartDateYTY, lastYearEndDateYTY, "YTD_LY");
                    responseDataList.Add(YTD_LY);
                }
                return Result.Success(responseDataList);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelMetricsByDateRange method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel owner dashboard details.");
            }
        }

        public async Task<Result<List<GetHotelRoomRevenueModel>>> GetHotelRoomRevenueByYear(int hotelID, int year)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelRoomRevenueByYear method initiated.");

                var spParams = new SqlParameter[]
                {
                    new SqlParameter("@HotelID", SqlDbType.Int) { Value = hotelID },
                    new SqlParameter("@Year", SqlDbType.Int) { Value = year },
                };

                List<GetHotelRoomRevenueModel> dbHotelRoomRevenueData = await _checkinProContext.sp_GETHotelRoomRevenueByYear
               .FromSqlRaw("EXEC sp_GETHotelRoomRevenueByYear @HotelID, @Year", spParams)
               .ToListAsync();


                return Result.Success(dbHotelRoomRevenueData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelRoomRevenueByYear method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel room revenue details.");
            }
        }

    }
}
