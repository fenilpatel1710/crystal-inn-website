﻿using CheckinPro.Repositories.IRepository;
using Microsoft.Extensions.Options;

namespace CheckinPro.Repositories
{
    public class EmailRepository : IEmailRepository
    {
        private readonly SmtpSettings _smtpSettings;

        public EmailRepository(IOptions<SmtpSettings> smtpSettings)
        {
            _smtpSettings = smtpSettings.Value;
        }

        public async Task SendEmailAsync(string to, string subject, string body)
        {
            using (var client = new System.Net.Mail.SmtpClient(_smtpSettings.SMTPHost, _smtpSettings.SMTPPort))
            {
                client.Credentials = new System.Net.NetworkCredential(_smtpSettings.SMTPUsername, _smtpSettings.SMTPPassword);
                client.EnableSsl = _smtpSettings.SMTPEnableSsl;

                var mailMessage = new System.Net.Mail.MailMessage
                {
                    From = new System.Net.Mail.MailAddress(_smtpSettings.SMTPUsername),
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = true
                };
                mailMessage.To.Add(to);

                await client.SendMailAsync(mailMessage);
            }
        }
    }
}
