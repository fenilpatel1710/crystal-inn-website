﻿using Ardalis.Result;
using CheckinPro.Common.Models.Constants;
using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Repositories.IRepository;
using CheckinPro.WebApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Text;

namespace CheckinPro.Repositories
{
    public class UserAccountRepository : IUserAccountRepository
    {
        private readonly ILogger _logger;
        private readonly CheckinProContext _checkinProContext;
        private readonly IEmailRepository _emailService;
        public UserAccountRepository(ILogger<UserAccountRepository> logger, CheckinProContext checkinProContext, IEmailRepository emailService)
        {
            _logger = logger;
            _checkinProContext = checkinProContext;
            _emailService = emailService;
        }

        /// <summary>
        /// Authenticates a user based on the provided sign-in credentials.
        /// </summary>
        /// <param name="signInRequestModel">The <see cref="SignInRequestModel"/> containing the user's email and password for authentication.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the user Signin operation.</returns>
        public async Task<Result<SignInUserResponseModel>> GetSignInUserDetail(string emailID)
        {
            try
            {
                _logger.LogInformation($"Repository: SignIn method initiated for User EmailID: {emailID}.");

                // Fetch the user model based on the EmailID
                var dbUserData = await _checkinProContext.tblHotelUsers
                    .Where(hu => hu.User.EmailID == emailID)
                    .Include(hu => hu.Hotel)
                     .ThenInclude(hc=> hc.tblHotelConfigurations)
                    .Include(hu => hu.User)
                    .ThenInclude(u => u.Role)
                    .FirstOrDefaultAsync();

                if (dbUserData != null)
                {
                    if (dbUserData.Hotel.IsHotelActive)
                    {
                        if (dbUserData.User.IsProfileActive)
                        {
                            var response = new SignInUserResponseModel
                            {
                                UserID = dbUserData.User.UserID,
                                HotelID = dbUserData.Hotel.HotelID,
                                UserName = dbUserData.User.FirstName + " " + dbUserData.User.LastName,
                                EmailID = dbUserData.User.EmailID,
                                RoleName = dbUserData.User.Role.RoleName,
                                IsPasswordChanged = dbUserData.User.IsPasswordChanged,
                                IsProfileActive = dbUserData.User.IsProfileActive,
                                IsOwnerDashboardVisible = dbUserData.Hotel.IsOwnerDashboardVisible
                            };

                            if (dbUserData.User.Role.RoleName == CommonConstants.ApplicationUserRole.HotelManager || dbUserData.User.Role.RoleName == CommonConstants.ApplicationUserRole.HotelOwner)
                            {
                                var shiftData = _checkinProContext.tblHotelShifts.Where(shift => shift.HotelID == dbUserData.HotelID && shift.IsShiftActive).FirstOrDefault();
                                response.IsShiftActive = shiftData != null ? shiftData.IsShiftActive : false;
                            }


                            return Result<SignInUserResponseModel>.Success(response);
                        }
                        else
                        {
                            _logger.LogWarning($"Repository: User profile is not active. Profile is either blocked or deleted: {emailID}.");
                            return Result.Error($"User profile is not active: {emailID}.");
                        }
                    }
                    else
                    {
                        _logger.LogWarning($"Repository: Hotel is not active. Hotel is either blocked or deleted: {emailID}.");
                        return Result.Error($"Hotel is not active. Contact Administrator.");
                    }

                    
                }
                else
                {
                    _logger.LogWarning($"Repository: No user found with EmailID: {emailID}.");
                    return Result.NotFound($"No user found with EmailID: {emailID}.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: SignIn Exception occurred for UserID: {emailID}. Stacktrace: {ex}");
                return Result<SignInUserResponseModel>.Error("An error occurred while signing in.");
            }
        }

        /// <summary>
        /// Initiates a password change for the user identified by the specified email address.
        /// </summary>
        /// <param name="changePasswordModel">The model containing the user's email address, current password, and new password.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the change password operation.</returns>
        public async Task<Result> ChangePassword(ChangePasswordModel changePasswordModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: ChangePassword method initiated for EmailID: {changePasswordModel.EmailID}.");

                    // Check if the user exists
                    var dbUserData = await _checkinProContext.tblUsers.Where(item => item.EmailID == changePasswordModel.EmailID).FirstOrDefaultAsync();

                    if (dbUserData == null)
                    {
                        _logger.LogWarning($"Repository: No user found with EmailID: {changePasswordModel.EmailID}.");
                        return Result.NotFound($"No user found with EmailID: {changePasswordModel.EmailID}.");
                    }

                    if (!dbUserData.IsProfileActive)
                    {
                        _logger.LogWarning($"Repository: User profile is not active. Profile is either blocked or deleted: {changePasswordModel.EmailID}.");
                        return Result.Error($"User profile is not active: {changePasswordModel.EmailID}.");
                    }

                    //Saving the new password
                    dbUserData.Password = changePasswordModel.NewPassword;
                    dbUserData.IsPasswordChanged = true;
                    dbUserData.LastPasswordChangeDate = DateTime.Now;
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Password changed successfully for EmailID: {changePasswordModel.EmailID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while changing password. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: ChangePassword Exception occurred for EmailID: {changePasswordModel.EmailID}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while changing the password.");
                }
            }
        }

        /// <summary>
        /// Initiates a password reset process for the user identified by the provided EmailID.
        /// </summary>
        /// <param name="EmailID">The user's email address for which forgot password process should be initiated</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the forgot password operation.</returns>
        public async Task<Result> ForgotPassword(string emailID)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: ForgotPassword method initiated for EmailID: {emailID}.");

                    // Check if the user exists
                    var dbUserData = await _checkinProContext.tblUsers.Where(item => item.EmailID == emailID).FirstOrDefaultAsync();
                    if (dbUserData == null)
                    {
                        _logger.LogWarning($"Repository: No user found with emailID: {emailID}.");
                        return Result.NotFound($"No user found with emailID: {emailID}.");
                    }

                    if (!dbUserData.IsProfileActive)
                    {
                        _logger.LogWarning($"Repository: User profile is not active. Profile is either blocked or deleted: {emailID}.");
                        return Result.Error($"User profile is not active: {emailID}.");
                    }

                    //Generating OTP
                    var otp = GenerateOtp();
                    dbUserData.OTP = otp;
                    dbUserData.IsOTPVerified = false;
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();
                    var emailTemplate = await _checkinProContext.tblEmailTemplates.Where(item => item.EmailTemplateName == "OTP").FirstOrDefaultAsync();

                    if (emailTemplate != null)
                    {
                        var messageBody = emailTemplate.EmailTemplateDesign;
                        StringBuilder strmsg = new StringBuilder();
                        messageBody = messageBody.Replace("[Recipient_Name]", dbUserData.FirstName + " " + dbUserData.LastName);
                        messageBody = messageBody.Replace("[OTP]", Convert.ToString(otp));
                        _emailService.SendEmailAsync(dbUserData.EmailID, emailTemplate.EmailTemplateSubject, messageBody.ToString());
                    }

                    _logger.LogInformation($"Repository: OTP sent to emailID: {emailID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while forgot password step. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: ForgotPassword Exception occurred for emailID: {emailID}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while password reset.");
                }
            }
        }

        /// <summary>
        /// Verifies whether the provided input OTP matches the stored OTP.
        /// </summary>
        /// <param name="validateOTPModel">The <see cref="ValidateOTPModel"/> containing the user's email and OTP for verification.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the OTP verification operation.</returns>
        public async Task<Result> ValidateOTP(ValidateOTPModel validateOTPModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: ValidateOTP method initiated for EmailID: {validateOTPModel.EmailID}.");

                    // Check if the user exists
                    var dbUserData = await _checkinProContext.tblUsers.Where(item => item.EmailID == validateOTPModel.EmailID).FirstOrDefaultAsync();
                    if (dbUserData == null)
                    {
                        _logger.LogWarning($"Repository: No user found with EmailID: {validateOTPModel.EmailID}.");
                        return Result.NotFound($"No user found with EmailID: {validateOTPModel.EmailID}.");
                    }

                    //Validating OTP
                    if (dbUserData.OTP != validateOTPModel.OTP)
                    {
                        _logger.LogWarning($"Repository: OTP validation failed: {validateOTPModel.EmailID}.");
                        return Result.Error($"OTP validation failed: {validateOTPModel.EmailID}.");
                    }

                    dbUserData.IsOTPVerified = true;
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();
                    _logger.LogInformation($"Repository: OTP is validated successfully.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while validating OTP. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: ValidateOTP Exception occurred for EmailID: {validateOTPModel.EmailID}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while validating the password.");
                }
            }
        }

        /// <summary>
        /// For password reset.
        /// </summary>
        /// <param name="resetPasswordModel">The <see cref="ResetPasswordModel"/> containing the user's email and new password for reset.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the password reset operation.</returns>
        public async Task<Result> ResetPassword(ResetPasswordModel resetPasswordModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: ResetPassword method initiated for EmailID: {resetPasswordModel.EmailID}.");

                    // Check if the user exists
                    var dbUserData = await _checkinProContext.tblUsers.Where(item => item.EmailID == resetPasswordModel.EmailID).FirstOrDefaultAsync();
                    if (dbUserData == null)
                    {
                        _logger.LogWarning($"Repository: No user found with EmailID: {resetPasswordModel.EmailID}.");
                        return Result.NotFound($"No user found with EmailID: {resetPasswordModel.EmailID}.");
                    }

                    if (!dbUserData.IsProfileActive)
                    {
                        _logger.LogWarning($"Repository: User profile is not active. Profile is either blocked or deleted: {resetPasswordModel.EmailID}.");
                        return Result.Error($"User profile is not active: {resetPasswordModel.EmailID}.");
                    }

                    //Saving the new password
                    dbUserData.Password = resetPasswordModel.NewPassword;
                    dbUserData.LastPasswordChangeDate = DateTime.Now;
                    if (!dbUserData.IsPasswordChanged)
                    {
                        dbUserData.IsPasswordChanged = true;
                    }
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Password changed successfully for EmailID: {resetPasswordModel.EmailID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while password reset. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: ResetPassword Exception occurred for EmailID: {resetPasswordModel.EmailID}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while password reset.");
                }
            }
        }

        /// <summary>
        /// Initiates to get password for the user identified by the provided EmailID.
        /// </summary>
        /// <param name="EmailID">The user's email address for which password process should be initiated</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the password operation.</returns>
        public async Task<Result<string>> GetPasswordToVerify(string emailID)
        {
            try
            {
                _logger.LogInformation($"Repository: GetPasswordToVerify method initiated for EmailID: {emailID}.");

                var dbUserData = await _checkinProContext.tblUsers.Where(item => item.EmailID == emailID).FirstOrDefaultAsync();
                if (dbUserData == null)
                {
                    _logger.LogWarning($"Repository: No user found with EmailID: {emailID}.");
                    return Result.NotFound($"No user found with EmailID: {emailID}.");
                }
                else
                {
                    if (dbUserData.IsProfileActive)
                    {
                        return Result<string>.Success(dbUserData.Password);
                    }
                    else
                    {
                        _logger.LogWarning($"Repository: User profile is not active. Profile is either blocked or deleted: {emailID}.");
                        return Result.Error($"User profile is not active: {emailID}.");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetPasswordToVerify Exception occurred for EmailID: {emailID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while featching password.");
            }
        }

        /// <summary>
        /// Generates a random 6-digit one-time password (OTP) for user verification.
        /// </summary>
        /// <returns>A string representing a 6-digit OTP.</returns>
        private string GenerateOtp()
        {
            //using a random number generator
            var random = new Random();
            return random.Next(100000, 999999).ToString(); // Generates a 6-digit OTP
        }
    }
}