﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Repositories.IRepository;
using CheckinPro.WebApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Repositories
{
    public class RoomStatusRepository : IRoomStatusRepository
    {
        private readonly ILogger _logger;
        private readonly CheckinProContext _checkinProContext;
        public RoomStatusRepository(ILogger<RoomStatusRepository> logger, CheckinProContext checkinProContext)
        {
            _logger = logger;
            _checkinProContext = checkinProContext;
        }

        /// <summary>
        /// Retrieves a list of Room Cleaning Statuses.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetRoomStatusModel"/> representing the room cleaning statuses data.</returns>
        public async Task<Result<List<GetRoomStatusModel>>> GetRoomStatuses()
        {
            try
            {
                _logger.LogInformation("Repository: GetRoomStatuses method initiated.");
                // Transform the entities into RoomStatusModel instances
                var dbRoomStatusesData = await _checkinProContext.tblRoomStatuses.Select(item => new GetRoomStatusModel
                {
                    RoomStatusID = item.RoomStatusID,
                    RoomStatusName = item.RoomStatusName,
                    Description = item.Description,
                    RoomStatusIcon = item.RoomStatusIcon,
                    IsActive = item.IsActive,
                    IsDeleted = item.IsDeleted
                }).ToListAsync();

                _logger.LogInformation("Repository: GetRoomStatuses method execution completed.");
                _logger.LogInformation($"Repository: GetRoomStatuses method execution completed. Total room cleaning statuses retrieved: {dbRoomStatusesData.Count}.");


                // Return the list of RoomStatusesModel
                return Result.Success(dbRoomStatusesData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetRoomStatuses method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching room cleaning statuses.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific RoomStatus by its ID.
        /// </summary>
        /// <param name="RoomStatusID">The ID of the room cleaning status to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetRoomStatusModel"/> for the specified room cleaning status.</returns>
        public async Task<Result<GetRoomStatusModel>> GetRoomStatusById(int RoomStatusID)
        {
            try
            {
                _logger.LogInformation($"Repository: GetRoomStatusById method initiated for RoomStatusID: {RoomStatusID}.");

                // Fetch the room cleaning status data based on the RoomStatusID
                var dbAmenitiesData = await _checkinProContext.tblRoomStatuses
                    .Where(item => item.RoomStatusID == RoomStatusID)
                    .Select(item => new GetRoomStatusModel
                    {
                        RoomStatusID = item.RoomStatusID,
                        RoomStatusName = item.RoomStatusName,
                        Description = item.Description,
                        RoomStatusIcon = item.RoomStatusIcon,
                        IsActive = item.IsActive,
                        IsDeleted = item.IsDeleted
                    })
                    .FirstOrDefaultAsync();

                // Return the RoomStatusModel or null
                if (dbAmenitiesData == null)
                {
                    _logger.LogWarning($"Repository: No room cleaning status found with RoomStatusID: {RoomStatusID}.");
                    return Result.NotFound($"No room cleaning status found with RoomStatusID: {RoomStatusID}.");
                }
                else
                {
                    _logger.LogInformation($"Repository: Successfully retrieved room cleaning status for RoomStatusID: {RoomStatusID}.");
                    return Result.Success(dbAmenitiesData);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetRoomStatusById Exception occurred for RoomStatusID: {RoomStatusID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the room cleaning status.");
            }

        }

        /// <summary>
        /// Adds a new room cleaning status record based on the provided RoomStatusRequestModel.
        /// </summary>
        /// <param name="RoomStatusRequestModel">The <see cref="GetRoomStatusModel"/> containing data for the new room cleaning status.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the room cleaning status addition operation.</returns>
        public async Task<Result> AddRoomStatus(AddEditRoomStatusModel RoomStatusRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddRoomStatus method initiated.");

                    // Validate the request model
                    if (RoomStatusRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddRoomStatus called with a null RoomStatusRequestModel.");
                        return Result.NoContent();
                    }

                    // Create a new room cleaning status entity dbRoomStatus and add it to the database

                    tblRoomStatus dbRoomStatus = new tblRoomStatus
                    {
                        RoomStatusName = RoomStatusRequestModel.RoomStatusName,
                        Description = RoomStatusRequestModel.Description,
                        RoomStatusIcon = RoomStatusRequestModel.RoomStatusIcon,
                        IsActive = RoomStatusRequestModel.IsActive,
                        CreatedBy = auditInfoModel.AuditUserID,
                        CreatedDate = DateTime.Now
                    };

                    await _checkinProContext.tblRoomStatuses.AddAsync(dbRoomStatus);
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully added room cleaning status with ID: {dbRoomStatus.RoomStatusID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while adding RoomStatus. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: AddRoomStatus Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while adding the room cleaning status.");
                }
            }
        }

        /// <summary>
        /// Updates an existing room cleaning status record based on the provided RoomStatusID and RoomStatusRequestModel.
        /// </summary>
        /// <param name="RoomStatusID">The ID of the room cleaning status to be updated.</param>
        /// <param name="RoomStatusRequestModel">The <see cref="UpdateRoomStatusModel"/> containing updated data for the room cleaning status.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the room cleaning status update operation.</returns>
        public async Task<Result> UpdateRoomStatus(int RoomStatusID, UpdateRoomStatusModel RoomStatusRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: UpdateRoomStatus method initiated for RoomStatusID: {RoomStatusID}.");

                    // Validate the request model
                    if (RoomStatusRequestModel == null)
                    {
                        _logger.LogWarning("Repository: UpdateRoomStatus called with a null RoomStatusModel.");
                        return Result.NoContent();
                    }

                    // Fetch the existing room cleaning status entity
                    var dbRoomStatus = await _checkinProContext.tblRoomStatuses.FindAsync(RoomStatusID);
                    if (dbRoomStatus == null)
                    {
                        _logger.LogWarning($"Repository: No room cleaning status found with RoomStatusID: {RoomStatusID}.");
                        return Result.NoContent();
                    }

                    // Update the properties
                    dbRoomStatus.RoomStatusName = RoomStatusRequestModel.RoomStatusName;
                    dbRoomStatus.RoomStatusIcon = RoomStatusRequestModel.RoomStatusIcon;
                    dbRoomStatus.Description = RoomStatusRequestModel.Description;
                    dbRoomStatus.IsActive = RoomStatusRequestModel.IsActive;
                    dbRoomStatus.UpdatedBy = auditInfoModel.AuditUserID;
                    dbRoomStatus.UpdatedDate = DateTime.Now;

                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully updated room cleaning status with ID: {RoomStatusID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while updating RoomStatus. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: UpdateRoomStatus Exception occurred for RoomStatusID: {RoomStatusID}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while updating the room cleaning status.");
                }
            }
        }

        /// <summary>
        /// Deletes a room cleaning status based on the provided RoomStatusID.
        /// </summary>
        /// <param name="RoomStatusID">The ID of the room cleaning status to be deleted.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the soft delete operation.</returns>
        public async Task<Result> DeleteRoomStatus(int RoomStatusID, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: DeleteRoomStatus method initiated for RoomStatusID: {RoomStatusID}.");

                    // Fetch the existing room cleaning status entity
                    var dbRoomStatus = await _checkinProContext.tblRoomStatuses.FindAsync(RoomStatusID);
                    if (dbRoomStatus == null)
                    {
                        _logger.LogWarning($"Repository: No room cleaning status found with RoomStatusID: {RoomStatusID}.");
                        return Result.NoContent();
                    }

                    dbRoomStatus.IsDeleted = true;
                    dbRoomStatus.DeletedBy = auditInfoModel.AuditUserID;
                    dbRoomStatus.DeletedDate = DateTime.Now;
                    dbRoomStatus.IsActive = false;

                    _checkinProContext.tblRoomStatuses.Update(dbRoomStatus);
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: No room cleaning status found with RoomStatusID:  {RoomStatusID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while deleting RoomStatus. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: DeleteRoomStatus Exception occurred for RoomStatusID: {RoomStatusID}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while deleting the room cleaning status.");
                }
            }
        }
    }
}
