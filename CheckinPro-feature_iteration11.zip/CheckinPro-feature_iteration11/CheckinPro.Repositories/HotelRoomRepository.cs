﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.Common.Models.Constants;
using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Repositories.IRepository;
using CheckinPro.WebApi.Models;
using CheckinPro.WebApi.Models.HotelRoomModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using static CheckinPro.Common.Models.Constants.CommonConstants;

namespace CheckinPro.Repositories
{
    public class HotelRoomRepository : IHotelRoomRepository
    {
        private readonly ILogger _logger;
        private readonly CheckinProContext _checkinProContext;

        public HotelRoomRepository(ILogger<HotelRoomRepository> logger, CheckinProContext checkinProContext)
        {
            _logger = logger;
            _checkinProContext = checkinProContext;
        }

        /// <summary>
        /// Retrieves a list of hotel rooms.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelRoomModel"/> representing all hotel rooms data.</returns>
        public async Task<Result<List<HotelRoomModel>>> GetHotelRoom(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelRoom method initiated.");

                var dbHotelRoomData = await _checkinProContext.tblHotelRooms
                    .Where(item => item.HotelID == hotelID && !item.IsHotelRoomDeleted)
                    .Include(item => item.Hotel)
                    .Select(item => new HotelRoomModel
                    {
                        HotelRoomID = item.HotelRoomID,
                        HotelID = item.HotelID,
                        HotelRoomTypeID = item.HotelRoomTypeID,
                        RoomNumber = item.RoomNumber,
                        Floor = item.Floor,
                        MaxOccupancy = item.MaxOccupancy,
                        RoomStatus = item.RoomStatus,
                        Description = item.Description,
                        IsHotelRoomActive = item.IsHotelRoomActive,
                        Hotel = new GetHotelModel
                        {
                            BusinessLLCName = item.Hotel.BusinessLLCName,
                        },
                        HotelRoomType = new HotelRoomTypeModel
                        {
                            HotelRoomTypeID = item.HotelRoomType.HotelRoomTypeID,
                            RoomTypeName = item.HotelRoomType.RoomTypeName,
                            RoomTypeIcon = item.HotelRoomType.RoomTypeIcon,
                            AdjustmentRate = item.HotelRoomType.AdjustmentRate,
                            IsHotelRoomTypeActive = item.HotelRoomType.IsHotelRoomTypeActive,
                        },
                    }).ToListAsync();

                _logger.LogInformation("Repository: GetHotelRoom method execution completed.");
                _logger.LogInformation($"Repository: GetHotelRoom method execution completed. Total Room Types retrieved: {dbHotelRoomData.Count}.");


                // Return the list of GetHotelRoomModel
                return Result.Success(dbHotelRoomData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelRoom method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel room list.");
            }
        }

        /// <summary>
        /// Retrieves a list of hotel room details including booking and guest information.
        /// </summary>
        /// <param name="hotelID">The ID of the hotel.</param>
        /// <returns>A <see cref="Result"/> containing a list of hotel room details.</returns>
        public async Task<Result<List<HotelRoomDetailModel>>> GetHotelRoomAllDetails(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelRoomDetails method initiated.");

                var rooms = await _checkinProContext.tblHotelRooms
                                                      .AsNoTracking()
                                                      .Where(r =>
                                                          r.HotelID == hotelID &&
                                                          !r.IsHotelRoomDeleted &&
                                                          r.IsHotelRoomActive)
                                                      .Select(r => new HotelRoomDetailModel
                                                      {
                                                          HotelRoomID = r.HotelRoomID,
                                                          HotelRoomTypeID = r.HotelRoomTypeID,
                                                          RoomNumber = r.RoomNumber,
                                                          Floor = r.Floor,
                                                          RoomTypeName = r.HotelRoomType.RoomTypeName,
                                                          RoomTypeIcon = r.HotelRoomType.RoomTypeIcon,
                                                          RoomStatus = r.RoomStatus
                                                      }).OrderBy(item => item.Floor).ThenBy(item => item.RoomNumber).ToListAsync();

                var checkedInBookings = await _checkinProContext.tblHotelRoomBookings
                                                                      .AsNoTracking()
                                                                      .Where(b =>
                                                                          b.BookingStatus == CommonConstants.BookingStatusMessages.CheckedIn &&
                                                                          b.HotelRoom.HotelID == hotelID)
                                                                      .Select(b => new
                                                                      {
                                                                          b.HotelRoomID,
                                                                          b.HotelRoomBookingID,
                                                                          b.IsHourlyBooking,
                                                                          b.ScheduledCheckInDate,
                                                                          b.ScheduledCheckOutDate,
                                                                          b.ActualCheckInDate,
                                                                          b.ActualCheckOutDate,
                                                                          b.BookingStatus,

                                                                          GuestName = b.tblHotelRoomBookingGuests
                                                                              .Select(bg => bg.Guest.FirstName + " " + bg.Guest.LastName)
                                                                              .FirstOrDefault(),

                                                                          FinalAmount = b.tblHotelRoomBookingRateDetails
                                                                              .Sum(r => (decimal?)r.FinalAmount) ?? 0
                                                                      }).ToListAsync();

                var bookingLookup = checkedInBookings.ToDictionary(b => b.HotelRoomID);

                foreach (var room in rooms)
                {
                    if (bookingLookup.TryGetValue(room.HotelRoomID, out var booking))
                    {
                        room.HotelRoomBookingID = booking.HotelRoomBookingID;
                        room.GuestName = booking.GuestName;
                        room.IsHourlyBooking = booking.IsHourlyBooking;
                        room.ScheduledCheckInDate = booking.ScheduledCheckInDate;
                        room.ScheduledCheckOutDate = booking.ScheduledCheckOutDate;
                        room.ActualCheckInDate = booking.ActualCheckInDate;
                        room.ActualCheckOutDate = booking.ActualCheckOutDate;
                        room.FinalAmount = booking.FinalAmount;
                        room.BookingStatus = booking.BookingStatus;
                    }
                }

                _logger.LogInformation("Repository: GetHotelRoomDetails method execution completed.");
                _logger.LogInformation($"Repository: GetHotelRoomDetails method execution completed. Total Rooms retrieved: {rooms.Count}.");

                return Result.Success(rooms);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelRoomDetails method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel room details.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific hotel room by its ID.
        /// </summary>
        /// <param name="hotelRoomID">The ID of the hotel room to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetHotelRoomModel"/> for the specified hotel room Id.</returns>
        public async Task<Result<HotelRoomModel>> GetHotelRoomById(int hotelRoomID)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelRoomById method initiated.");

                var dbHotelRoomData = await _checkinProContext.tblHotelRooms
                 .Where(item => item.HotelRoomID == hotelRoomID && !item.IsHotelRoomDeleted && item.IsHotelRoomActive)
                 .Include(item => item.Hotel)
                     .Select(item => new HotelRoomModel
                     {
                         HotelRoomID = item.HotelRoomID,
                         HotelID = item.HotelID,
                         HotelRoomTypeID = item.HotelRoomTypeID,
                         RoomNumber = item.RoomNumber,
                         Floor = item.Floor,
                         MaxOccupancy = item.MaxOccupancy,
                         RoomStatus = item.RoomStatus,
                         Description = item.Description,
                         IsHotelRoomActive = item.IsHotelRoomActive,
                         Hotel = new GetHotelModel
                         {
                             BusinessLLCName = item.Hotel.BusinessLLCName,
                         },
                     }).FirstOrDefaultAsync();

                // Return the GetHotelRoomModel or null
                if (dbHotelRoomData == null)
                {
                    _logger.LogWarning($"Repository: No hotel room found with hotelRoomID: {hotelRoomID}.");
                    return Result.NotFound($"No hotel room found with hotelRoomID: {hotelRoomID}.");
                }
                if (!dbHotelRoomData.IsHotelRoomActive)
                {
                    _logger.LogWarning($"Repository: This hotel room is inactive with hotelRoomID: {hotelRoomID}.");
                    return Result.NotFound($"Hotel room is inactive with hotelRoomID: {hotelRoomID}.");
                }
                else
                {
                    _logger.LogInformation($"Repository: Successfully retrieved hotel room for hotelRoomID: {hotelRoomID}.");
                    return Result.Success(dbHotelRoomData);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelRoomById method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel room list.");
            }
        }

        public async Task<Result<List<HotelRoomModel>>> GetHotelRoomPendingCleaning(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelRoomPendingCleaning method initiated.");

                var dbHotelRoomData = await _checkinProContext.tblHotelRooms
                    .Where(item => item.HotelID == hotelID
                                   && !item.IsHotelRoomDeleted
                                   && item.IsHotelRoomActive
                                   && item.RoomStatus == CommonConstants.RoomStatusMessages.PendingCleaning)
                    .Include(item => item.Hotel)
                    .Include(item => item.tblHotelRoomBookings)
                        .ThenInclude(roombooking => roombooking.tblHotelRoomCleaningAudits)
                    .Select(item => new HotelRoomModel
                    {
                        HotelRoomID = item.HotelRoomID,
                        HotelID = item.HotelID,
                        HotelRoomTypeID = item.HotelRoomTypeID,
                        RoomNumber = item.RoomNumber,
                        Floor = item.Floor,
                        MaxOccupancy = item.MaxOccupancy,
                        RoomStatus = item.RoomStatus,
                        Description = item.Description,
                        IsHotelRoomActive = item.IsHotelRoomActive,
                        Hotel = new GetHotelModel
                        {
                            BusinessLLCName = item.Hotel.BusinessLLCName,
                        },
                        HotelRoomType = new HotelRoomTypeModel
                        {
                            HotelRoomTypeID = item.HotelRoomType.HotelRoomTypeID,
                            RoomTypeName = item.HotelRoomType.RoomTypeName,
                            RoomTypeIcon = item.HotelRoomType.RoomTypeIcon,
                            AdjustmentRate = item.HotelRoomType.AdjustmentRate,
                            IsHotelRoomTypeActive = item.HotelRoomType.IsHotelRoomTypeActive,
                        },

                    }).ToListAsync();

                _logger.LogInformation("Repository: GetHotelRoomPendingCleaning method execution completed.");
                _logger.LogInformation($"Repository: GetHotelRoomPendingCleaning method execution completed. Total Pending Cleaning Rooms retrieved: {dbHotelRoomData.Count}.");

                // Return the list of GetHotelRoomModel
                return Result.Success(dbHotelRoomData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelRoomPendingCleaning method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching rooms pending cleaning.");
            }
        }


        /// <summary> 
        /// Adds a new hotel room record based on the provided hotelRoomRequestModel.
        /// </summary>
        /// <param name="hotelRoomRequestModel">The <see cref="AddEditHotelRoomModel"/> containing data for the new hotel room.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel room creation operation.</returns>
        public async Task<Result> AddEditHotelRoom(AddEditHotelRoomModel hotelRoomRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddEditHotelRoom method initiated.");

                    // Validate the request model
                    if (hotelRoomRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddEditHotelRoom called with a null hotelRoomRequestModel.");
                        return Result.NoContent();
                    }

                    var dbHotelRoomData = await _checkinProContext.tblHotelRooms.FirstOrDefaultAsync(hr => hr.HotelRoomID == hotelRoomRequestModel.HotelRoomID);
                    if (dbHotelRoomData != null)
                    {
                        // Update the basic properties
                        dbHotelRoomData.HotelRoomTypeID = hotelRoomRequestModel.HotelRoomTypeID;
                        dbHotelRoomData.RoomNumber = hotelRoomRequestModel.RoomNumber;
                        dbHotelRoomData.Floor = hotelRoomRequestModel.Floor;
                        dbHotelRoomData.MaxOccupancy = hotelRoomRequestModel.MaxOccupancy;
                        dbHotelRoomData.RoomStatus = hotelRoomRequestModel.RoomStatus;
                        dbHotelRoomData.Description = hotelRoomRequestModel.Description;
                        dbHotelRoomData.IsHotelRoomActive = hotelRoomRequestModel.IsHotelRoomActive;
                        dbHotelRoomData.UpdatedBy = auditInfoModel.AuditUserID;
                        dbHotelRoomData.UpdatedDate = DateTime.Now;

                        if (hotelRoomRequestModel.RoomStatus == RoomStatusMessages.PendingCleaning)
                        {
                            dbHotelRoomData.tblHotelRoomCleaningAudits.Add(new tblHotelRoomCleaningAudit
                            {
                                //HotelRoomBookingID = hotelRoomCleaningAuditRequestModel.HotelRoomBookingID,
                                HotelRoomID = dbHotelRoomData.HotelRoomID,
                                CheckOutComment = "Room status changed to clean"
                            });
                        }

                        _checkinProContext.Update(dbHotelRoomData);
                    }
                    else
                    {
                        // 1. Check if the room number and floor combination already exists for the given HotelID
                        var existingRoom = await _checkinProContext.tblHotelRooms.FirstOrDefaultAsync(r => r.HotelID == hotelRoomRequestModel.HotelID
                               && r.RoomNumber == hotelRoomRequestModel.RoomNumber
                               && r.Floor == hotelRoomRequestModel.Floor);

                        if (existingRoom != null)
                        {
                            _logger.LogWarning($"Repository: Room number {hotelRoomRequestModel.RoomNumber} on floor {hotelRoomRequestModel.Floor} already exists for HotelID {hotelRoomRequestModel.HotelID}.");
                            return Result.Error("Room number and floor combination already exists for the given hotel.");
                        }


                        // Create a new hotel room  entity and add it to the database
                        tblHotelRoom dbHotelRoom = new tblHotelRoom
                        {
                            HotelID = hotelRoomRequestModel.HotelID,
                            HotelRoomTypeID = hotelRoomRequestModel.HotelRoomTypeID,
                            RoomNumber = hotelRoomRequestModel.RoomNumber,
                            Floor = hotelRoomRequestModel.Floor,
                            MaxOccupancy = hotelRoomRequestModel.MaxOccupancy,
                            RoomStatus = hotelRoomRequestModel.RoomStatus,
                            Description = hotelRoomRequestModel.Description,
                            IsHotelRoomActive = hotelRoomRequestModel.IsHotelRoomActive,
                            CreatedBy = auditInfoModel.AuditUserID,
                            CreatedDate = DateTime.Now,
                        };


                        if (hotelRoomRequestModel.RoomStatus == RoomStatusMessages.PendingCleaning)
                        {
                            dbHotelRoomData.tblHotelRoomCleaningAudits.Add(new tblHotelRoomCleaningAudit
                            {
                                //HotelRoomBookingID = hotelRoomCleaningAuditRequestModel.HotelRoomBookingID,
                                HotelRoomID = dbHotelRoomData.HotelRoomID,
                                CheckOutComment = "Room status changed to clean"
                            });
                        }

                        await _checkinProContext.tblHotelRooms.AddAsync(dbHotelRoom);

                    }
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully added hotel room with ID: {hotelRoomRequestModel.RoomNumber}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while adding hotelRoom. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: AddEditHotelRoom Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while adding the hotel room.");
                }
            }
        }

        /// <summary>
        /// Updates an existing hotel room record based on the provided hotelRoomID and hotelRoomRequestModel.
        /// </summary>
        /// <param name="hotelRoomID">The ID of the hotel room to be updated.</param>
        /// <param name="hotelRoomRequestModel">The <see cref="AddEditHotelRoomModel"/> containing updated data for the hotel room.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel room update operation.</returns>
        //public async Task<Result> UpdateHotelRoom(int hotelRoomID, AddHotelRoomModel hotelRoomRequestModel, AuditInfoModel auditInfoModel)
        //{
        //    using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
        //    {
        //        try
        //        {

        //            _logger.LogInformation($"Repository: UpdateHotelRoom method initiated for hotelRoomID: {hotelRoomID}.");

        //            // Validate the request model
        //            if (hotelRoomRequestModel == null)
        //            {
        //                _logger.LogWarning("Repository: UpdateHotelRoom called with a null hotelRoomRequestModel.");
        //                return Result.NoContent();
        //            }

        //            var dbHotelRoomData = await _checkinProContext.tblHotelRooms
        //                .Include(hr => hr.tblHotelRoomRates)
        //                .Include(hr => hr.tblHotelRoomFeatures)
        //                .FirstOrDefaultAsync(hr => hr.HotelRoomID == hotelRoomID);
        //            if (dbHotelRoomData == null)
        //            {
        //                _logger.LogWarning($"Repository: No hotel room found with hotelRoomID: {hotelRoomID}.");
        //                return Result.NoContent();
        //            }

        //            if (!dbHotelRoomData.IsHotelRoomActive)
        //            {
        //                _logger.LogWarning($"Repository: This hotel room is inactive with hotelRoomID: {hotelRoomID}.");
        //                return Result.NotFound($"Hotel room is inactive with hotelRoomID: {hotelRoomID}.");
        //            }

        //            // Update the properties
        //            dbHotelRoomData.HotelID = hotelRoomRequestModel.HotelID;
        //            dbHotelRoomData.RoomTypeID = hotelRoomRequestModel.RoomTypeID;
        //            dbHotelRoomData.RoomNumber = hotelRoomRequestModel.RoomNumber;
        //            dbHotelRoomData.Floor = hotelRoomRequestModel.Floor;
        //            dbHotelRoomData.MaxOccupancy = hotelRoomRequestModel.MaxOccupancy;
        //            dbHotelRoomData.Description = hotelRoomRequestModel.Description;
        //            dbHotelRoomData.IsHotelRoomActive = hotelRoomRequestModel.IsHotelRoomActive;
        //            dbHotelRoomData.UpdatedBy = auditInfoModel.AuditUserID;
        //            dbHotelRoomData.UpdatedDate = DateTime.Now;
        //            dbHotelRoomData.tblHotelRoomRates = hotelRoomRequestModel.HotelRoomRates.Select(h => new tblHotelRoomRate
        //            {
        //                RoomRateTypeID = h.RoomRateTypeID,
        //                RateAmount = h.RateAmount,
        //                IsDefaultRate = h.IsDefaultRate,
        //                IsHotelRoomRateActive = true,
        //                CreatedBy = auditInfoModel.AuditUserID,
        //                CreatedDate = DateTime.Now
        //            }).ToList();
        //            dbHotelRoomData.tblHotelRoomFeatures = hotelRoomRequestModel.HotelRoomFeatures.Select(h => new tblHotelRoomFeature
        //            {
        //                RoomFeatureID = h.RoomFeatureID,
        //                IsHotelRoomFeatureActive = true,
        //                CreatedBy = auditInfoModel.AuditUserID,
        //                CreatedDate = DateTime.Now
        //            }).ToList();


        //            await _checkinProContext.SaveChangesAsync();
        //            await transaction.CommitAsync();

        //            _logger.LogInformation($"Repository: Successfully updated hotel room with ID: {hotelRoomID}.");
        //            return Result.Success();
        //        }
        //        catch (DbUpdateException dbEx)
        //        {
        //            await transaction.RollbackAsync();
        //            _logger.LogError($"Repository: Database error occurred while updating hotelRoom. {dbEx.Message}");
        //            return Result.Error("A database error occurred. Please try again later.");
        //        }
        //        catch (Exception ex)
        //        {
        //            await transaction.RollbackAsync();
        //            _logger.LogError($"Repository: UpdateHotelRoom Exception occurred for hotelRoomID: {hotelRoomID}. Stacktrace: {ex}");
        //            return Result.Error("An error occurred while updating the hotel room.");
        //        }
        //    }
        //}

        public async Task<Result> UpdateHotelRoomStatus(int hotelRoomID, string RoomStatus, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: UpdateHotelRoomStatus method initiated for hotelRoomID: {hotelRoomID}.");


                    var dbHotelRoomData = await _checkinProContext.tblHotelRooms
                        .FirstOrDefaultAsync(hr => hr.HotelRoomID == hotelRoomID);

                    if (dbHotelRoomData == null)
                    {
                        _logger.LogWarning($"Repository: No hotel room found with hotelRoomID: {hotelRoomID}.");
                        return Result.NoContent();
                    }

                    if (!dbHotelRoomData.IsHotelRoomActive)
                    {
                        _logger.LogWarning($"Repository: This hotel room is inactive with hotelRoomID: {hotelRoomID}.");
                        return Result.NotFound($"Hotel room is inactive with hotelRoomID: {hotelRoomID}.");
                    }

                    dbHotelRoomData.RoomStatus = RoomStatus;
                    dbHotelRoomData.UpdatedBy = auditInfoModel.AuditUserID;
                    dbHotelRoomData.UpdatedDate = DateTime.Now;

                    // Save changes and commit transaction
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully updated hotel room with ID: {hotelRoomID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while updating hotelRoom. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: UpdateHotelRoomStatus Exception occurred for hotelRoomID: {hotelRoomID}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while updating the hotel room.");
                }
            }
        }

        /// <summary>
        /// Deletes a hotel room based on the provided hotelRoomID.
        /// </summary>
        /// <param name="hotelRoomID">The ID of the hotel room to be deleted.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the delete operation.</returns>
        public async Task<Result> DeleteHotelRoom(int hotelRoomID, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: DeleteHotelRoom method initiated for hotelRoomID: {hotelRoomID}.");

                    var dbHotelRoomData = await _checkinProContext.tblHotelRooms.FindAsync(hotelRoomID);
                    if (dbHotelRoomData == null)
                    {
                        _logger.LogWarning($"Repository: No hotel room found with hotelRoomID: {hotelRoomID}.");
                        return Result.NoContent();
                    }

                    dbHotelRoomData.IsHotelRoomDeleted = true;
                    dbHotelRoomData.IsHotelRoomActive = false;
                    dbHotelRoomData.DeletedBy = auditInfoModel.AuditUserID;
                    dbHotelRoomData.DeletedDate = DateTime.Now;

                    _checkinProContext.tblHotelRooms.Update(dbHotelRoomData);
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully deleted hotel room with ID: {hotelRoomID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while deleting hotelRoom. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: DeleteRoomType Exception occurred for hotelRoomID: {hotelRoomID}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while deleting the hotel room.");
                }
            }
        }
    }
}
