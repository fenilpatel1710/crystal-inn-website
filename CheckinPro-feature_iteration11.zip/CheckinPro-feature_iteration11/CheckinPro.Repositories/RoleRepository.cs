﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Repositories.IRepository;
using CheckinPro.WebApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Repositories
{
    public class RoleRepository : IRoleRepository
    {
        private readonly ILogger _logger;
        private readonly CheckinProContext _checkinProContext;

        public RoleRepository(ILogger<RoleRepository> logger, CheckinProContext checkinProContext)
        {
            _logger = logger;
            _checkinProContext = checkinProContext;
        }

        /// <summary>
        /// Retrieves a list of Roles.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="RoleModel> representing role data.</returns>
        public async Task<Result<List<RoleModel>>> GetRoles()
        {
            try
            {
                _logger.LogInformation("Repository: GetRoles method initiated.");
                // Transform the entities into RoleModel instances
                var roleModel = await _checkinProContext.tblRoles.Select(item => new RoleModel
                {
                    RoleID = item.RoleID,
                    RoleName = item.RoleName,
                    Description = item.Description,
                    IsRoleActive = item.IsRoleActive,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    UpdatedBy = item.UpdatedBy,
                    UpdatedDate = item.UpdatedDate,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                }).ToListAsync();

                _logger.LogInformation("Repository: GetRoles method execution completed.");
                _logger.LogInformation($"Repository: GetRoles method execution completed. Total roles retrieved: {roleModel.Count}.");


                // Return the list of CountryModel
                return Result.Success(roleModel);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetRoles method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching roles.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific room type by its ID.
        /// </summary>
        /// <param name="roleID">The ID of the room type to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetRoleModel"/> for the specified room type Id.</returns>
        public async Task<Result<RoleModel>> GetRoleById(int roleID)
        {
            try
            {
                _logger.LogInformation("Repository: GetRoleById method initiated.");
                // Fetch the rle data based on the roleID
                var dbRoleData = await _checkinProContext.tblRoles
                    .Where(item => item.RoleID == roleID)
                    .Select(item => new RoleModel
                    {
                        RoleID = item.RoleID,
                        RoleName = item.RoleName,
                        Description = item.Description,
                        IsRoleActive = item.IsRoleActive
                    }).FirstOrDefaultAsync();

                // Return the RoleModel or null
                if (dbRoleData == null)
                {
                    _logger.LogWarning($"Repository: No role found with RoleID: {roleID}.");
                    return Result.NotFound($"No role found with RoleID: {roleID}.");
                }
                else
                {
                    _logger.LogInformation($"Repository: Successfully retrieved room type for RoleID: {roleID}.");
                    return Result.Success(dbRoleData);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetRoleById method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching role.");
            }
        }

        /// <summary>
        /// Updates an existing role record based on the provided roleID and roleRequestModel.
        /// </summary>
        /// <param name="roleID">The ID of the role to be updated.</param>
        /// <param name="roleRequestModel">The <see cref="RoleModel"/> containing updated data for the role.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the role update operation.</returns>
        public async Task<Result> UpdateRole(int roleID, RoleModel roleRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: UpdateRole method initiated for roleID: {roleID}.");

                    // Validate the request model
                    if (roleRequestModel == null)
                    {
                        _logger.LogWarning("Repository: UpdateRole called with a null RoleModel.");
                        return Result.NoContent();
                    }

                    // Fetch the existing role entity
                    var dbRole = await _checkinProContext.tblRoles.FindAsync(roleID);
                    if (dbRole == null)
                    {
                        _logger.LogWarning($"Repository: No role found with roleID: {roleID}.");
                        return Result.NoContent();
                    }

                    // Update the properties
                    dbRole.RoleName = roleRequestModel.RoleName;
                    dbRole.Description = roleRequestModel.Description;
                    dbRole.IsRoleActive = roleRequestModel.IsRoleActive;
                    dbRole.UpdatedBy = auditInfoModel.AuditUserID;
                    dbRole.UpdatedDate = DateTime.Now;

                    // Save changes to the database
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully updated role with ID: {roleID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while updating role. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: UpdateroleRequestModel Exception occurred for roleID: {roleID}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while updating the role.");
                }
            }
        }
    }
}
