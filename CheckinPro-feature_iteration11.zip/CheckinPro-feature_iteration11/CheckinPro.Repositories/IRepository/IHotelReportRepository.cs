﻿using Ardalis.Result;
using CheckinPro.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.Repositories.IRepository
{
    public interface IHotelReportRepository
    {
        Task<Result<byte[]>> PrintBookingReceipt(int hotelRoomBookingID);
        Task<Result<byte[]>> DownloadBookingInvoice(int hotelRoomBookingID);
        Task<Result<byte[]>> DownloadDailyAuditReport(int hotelId, DateOnly fromDate, DateOnly toDate);
        Task<Result<byte[]>> DownloadRoomTaxCollectedReport(int hotelId, DateOnly fromDate, DateOnly toDate);
        Task<Result<byte[]>> DownloadSummaryIncomeReport(int hotelId, DateOnly fromDate, DateOnly toDate);
        Task<Result<byte[]>> DownloadRoomRevenueReport(int hotelId, DateOnly fromDate, DateOnly toDate);
        Task<Result<byte[]>> DownloadIncomeBreakdownReport(int hotelId, DateOnly fromDate, DateOnly toDate);
        Task<Result<byte[]>> DownloadShiftReport(int hotelId, HotelShiftModel hotelShiftData, DateOnly fromDate, DateOnly toDate);
        Task<GetHotelOwnerDashboardModel> GetHotelDashboardDetails(int hotelID, DateOnly fromDate, DateOnly toDate, string metrixType);
    }
}