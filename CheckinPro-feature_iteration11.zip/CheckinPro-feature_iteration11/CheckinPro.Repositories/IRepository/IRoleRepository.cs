﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.WebApi.Models;

namespace CheckinPro.Repositories.IRepository
{
    public interface IRoleRepository
    {
        /// <summary>
        /// Retrieves a list of roles.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="RoleModel"/> representing the role data.</returns>
        Task<Result<List<RoleModel>>> GetRoles();

        /// <summary>
        /// Retrieves details of a specific role by its ID.
        /// </summary>
        /// <param name="roleID">The ID of the role to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="RoleModel"/> for the specified role.</returns>
        Task<Result<RoleModel>> GetRoleById(int roleID);

        /// <summary>
        /// Updates an existing role record based on the provided roleID and roleRequestModel.
        /// </summary>
        /// <param name="roleID">The ID of the role to be updated.</param>
        /// <param name="roleRequestModel">The <see cref="RoleModel"/> containing updated data for the role.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the role update operation.</returns>
        Task<Result> UpdateRole(int roleID, RoleModel roleRequestModel, AuditInfoModel auditInfoModel);
    }
}
