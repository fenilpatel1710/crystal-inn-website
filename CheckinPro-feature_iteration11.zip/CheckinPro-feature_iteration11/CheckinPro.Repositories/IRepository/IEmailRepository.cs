﻿namespace CheckinPro.Repositories.IRepository
{
    public interface IEmailRepository
    {
        Task SendEmailAsync(string to, string subject, string body);
    }
}
