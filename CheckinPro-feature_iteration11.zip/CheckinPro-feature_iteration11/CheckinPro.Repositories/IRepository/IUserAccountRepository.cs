﻿using Ardalis.Result;
using CheckinPro.WebApi.Models;

namespace CheckinPro.Repositories.IRepository
{
    public interface IUserAccountRepository
    {
        /// <summary>
        /// Retrieves details of a specific user by its emailID.
        /// </summary>
        /// <param name="emailID">The emailID of the user to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="SignInUserResponseModel"/> for the specified emailID.</returns>       
        Task<Result<SignInUserResponseModel>> GetSignInUserDetail(string emailID);

        /// <summary>
        /// Initiates a password change for the user identified by the specified email address.
        /// </summary>
        /// <param name="changePasswordModel">The model containing the user's email address, current password, and new password.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the change password operation.</returns>
        Task<Result> ChangePassword(ChangePasswordModel changePasswordModel);

        /// <summary>
        /// Initiates a password reset process for the user identified by the provided emailID.
        /// </summary>
        /// <param name="emailID">The user's email address for which forgot password process should be initiated</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the forgot password operation.</returns>
        Task<Result> ForgotPassword(string emailID);

        /// <summary>
        /// Verifies whether the provided input OTP matches the stored OTP.
        /// </summary>
        /// <param name="ValidateOTPModel">The <see cref="ValidateOTPModel"/> containing the user's email and OTP for verification.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the OTP verification operation.</returns>
        Task<Result> ValidateOTP(ValidateOTPModel validateOTPModel);

        /// <summary>
        /// For password reset.
        /// </summary>
        /// <param name="resetPasswordModel">The <see cref="ResetPasswordModel"/> containing the user's email and new password for reset.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the password reset operation.</returns>
        Task<Result> ResetPassword(ResetPasswordModel resetPasswordModel);

        /// <summary>
        /// Initiates to get password for the user identified by the provided emailID.
        /// </summary>
        /// <param name="emailID">The user's email address for which password process should be initiated</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the password operation.</returns>
        Task<Result<string>> GetPasswordToVerify(string emailID);
    }
}
