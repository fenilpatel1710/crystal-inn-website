﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.Repositories.IRepository
{
    public interface IDashboardRepository
    {
        /// <summary>
        /// Retrieves the count of various hotel room statuses for a given hotel.
        /// </summary>
        /// <param name="hotelID">The unique identifier of the hotel.</param>
        /// <returns>A <see cref="Result"/> containing a <see cref="GetDashboardModel"/> object with the counts of different room statuses.</returns>
        Task<Result<GetDashboardModel>> GetHotelRoomStatusCounts(int hotelID);

        Task<Result<List<HotelShiftModel>>> GetHotelShiftDetailByDate(int hotelID, DateOnly fromDate, DateOnly toDate);

        Task<Result<HotelShiftModel>> GetHotelShiftDetail(int hotelID);

        Task<Result> StartHotelShift(HotelShiftModel hotelShiftRequestModel, AuditInfoModel auditInfoModel);

        Task<Result> EndHotelShift(HotelShiftModel hotelShiftRequestModel, AuditInfoModel auditInfoModel);

        Task<Result<List<GetHotelOwnerDashboardModel>>> GetHotelMetricsByDateRange(int hotelID, DateTime? selectedDate, string metrix);
        
        Task<Result<List<GetHotelRoomRevenueModel>>> GetHotelRoomRevenueByYear(int hotelID, int year);
    }
}
