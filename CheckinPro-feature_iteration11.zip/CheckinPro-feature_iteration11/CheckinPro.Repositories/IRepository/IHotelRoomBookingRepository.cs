﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.WebApi.Models;

namespace CheckinPro.Repositories.IRepository
{
    public interface IHotelRoomBookingRepository
    {
        Task<Result<HotelDailyRateModel>> GetHotelDailyRateByDate(int hotelID, DateOnly checkInDate);
        Task<Result<List<GetHotelRoomBookingSearchListModel>>> SearchHotelRoomBooking(FindHotelRoomBookingModel findHotelRoomBookingRequestModel);

        /// <summary>
        /// Retrieves a list of booked hotel rooms having check-out today.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelRoomBookingModel"/> representing all hotel rooms data.</returns>
        Task<Result<List<GetHotelRoomBookingModel>>> GetTodaysCheckOutRoomsByHotelID(int hotelID);
        Task<Result<List<GetHotelRoomBookingModel>>> GetTodaysBookingsByHotelID(int hotelID);
        /// <summary>
        /// Retrieves a list of room types along with the number of available rooms for a given hotel.
        /// </summary>
        /// <param name="hotelID">The ID of the hotel.</param>
        /// <returns>A <see cref="Result"/> containing a list of room types with available room counts.</returns>
        Task<Result<List<HotelRoomTypeModel>>> GetAvailableRoomTypesByHotel(int hotelID, DateTime checkInDate, DateTime checkOutDate);

        /// <summary>
        /// Retrieves a list of mobile number.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of mobile numbers</returns>
        Task<Result<List<string>>> GetMobileNumbers(string searchTerm = null);


        /// <summary>
        /// Retrieves a list of hotel rooms.
        /// </summary>
        /// <param name="dates">Check-in and check-out dates of the hotel rooms to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelRoomModel"/> representing all hotel rooms data.</returns>
        Task<Result<List<HotelRoomModel>>> GetHotelRoomByDates(int hotelID, DateTime checkInDate, DateTime checkOutDate);
        Task<Result<List<HotelRoomModel>>> GetAvailableRoomByDates(int hotelID, int hotelRoomTypeID, DateTime checkInDate, DateTime checkOutDate);


        /// <summary>
        /// Retrieves a list of booked hotel rooms.
        /// </summary>
        /// <param name="hotelID">The ID of the hotel to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelRoomBookingModel"/> representing all hotel rooms data.</returns>
        Task<Result<List<GetHotelRoomBookingModel>>> GetBookedHotelRoomsByHotelID(int hotelID);

        /// <summary>
        /// Retrieves a list of booked hotel rooms.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a details of <see cref="GetHotelRoomBookingModel"/> booked room.</returns>
        Task<Result<HotelRoomBookingModel>> GetRoomBookingDetailsByID(int hotelRoomBookingID);

        /// <summary> 
        /// Adds a new hotel room booking record based on the provided hotelRoomBookingRequestModel.
        /// </summary>
        /// <param name="hotelRoomBookingRequestModel">The <see cref="HotelRoomBookingModel"/> containing data for the new hotel room booking.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel room booking creation operation.</returns>
        Task<Result<int>> AddHotelRoomBooking(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel);

        Task<Result> UpdateHotelRoomBooking(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> UpdateHotelRoomBookingTotalAmount(HotelRoomBookingRateDetailModel hotelRoomBookingRateDetailRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> RoomCheckIn(int hotelRoomBookingID, int hotelRoomID, AuditInfoModel auditInfoModel);
        Task<Result> RoomChange(RoomChangeModel roomChangeRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> RoomCheckOut(UpdateHotelRoomCleaningAuditModel hotelRoomCleaningAuditRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> RoomCheckOutDateChange(HotelRoomBookingRateDetailModel hotelRoomBookingRateDetailRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> RoomExtend(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> RoomCancel(int hotelRoomBookingID, string? cancellationReason, AuditInfoModel auditInfoModel);
        Task<Result> RoomRefund(AddPaymentModel bookingPaymentRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> RoomCleaning(UpdateHotelRoomCleaningAuditModel hotelRoomCleaningAuditRequestModel, AuditInfoModel auditInfoModel);
        Task<Result<List<HotelRoomCleaningAuditModel>>> GetPendingRoomCleaningList(int hotelID);
        Task<Result> UpdateHotelRoomBookingStatus(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> AddEditMiscAmount(AddEditMiscAmountModel addEditMiscAmountRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> AddUpdateBookingPayment(AddPaymentModel bookingPaymentRequestModel, AuditInfoModel auditInfoModel);

        /// <summary> 
        /// Retrieves booked hotel room details based on the provided hotelRoomBookingID and checkOutDate.
        /// </summary>
        /// <param name="hotelRoomBookingID">The unique identifier of the hotel room booking to exclude from the search.</param>
        /// <param name="checkOutDate">The <see cref="DateTime"/> representing the check-out date to filter bookings.</param>
        /// <returns>
        /// A <see cref="Task{Result{List{GetBookedRoomDetailsModel}}}"/> containing a list of booked rooms, including check-in date, 
        /// check-out date, guest name, room type, and room number.
        /// </returns>
        Task<Result<List<GetBookedRoomDetailsModel>>> GetBookedRoomDetailsByCheckOutDate(int hotelRoomBookingID, DateTime checkOutDate);
        Task<Result> AddUpdateGuest(int hotelRoomBookingID, AddGuestModel guestRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> UpdateGuestRequest(UpdateGuestRequestModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> UpdateBookingReportFlag(int hotelRoomBookingID, bool isIncludedInReport, AuditInfoModel auditInfoModel);
        Task<Result<List<AddEditMiscAmountModel>>> GetRoomBookingMiscAmount(int hotelRoomBookingID);
        Task<Result> DeleteMiscAmount(int hotelRoomBookingMiscellaneousID);
    }
}
