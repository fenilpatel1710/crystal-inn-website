﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.WebApi.Models;

namespace CheckinPro.Repositories.IRepository
{
    public interface IRoomStatusRepository
    {
        /// <summary>
        /// Retrieves a list of Room CleaningStatuses.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetRoomStatusModel"/> representing the room cleaning statuses data.</returns>
        Task<Result<List<GetRoomStatusModel>>> GetRoomStatuses();

        /// <summary>
        /// Retrieves details of a specific room cleaning status by its ID.
        /// </summary>
        /// <param name="RoomStatusID">The ID of the room cleaning status to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetRoomStatusModel"/> for the specified room cleaning status.</returns>
        Task<Result<GetRoomStatusModel>> GetRoomStatusById(int RoomStatusID);

        /// <summary>
        /// Adds a new room cleaning status record based on the provided RoomStatusRequestModel.
        /// </summary>
        /// <param name="RoomStatusRequestModel">The <see cref="AddEditRoomStatusModel"/> containing data for the new room cleaning status.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the room cleaning status addition operation.</returns>
        Task<Result> AddRoomStatus(AddEditRoomStatusModel RoomStatusRequestModel, AuditInfoModel auditInfoModel);

        /// <summary>
        /// Updates an existing room cleaning status record based on the provided RoomStatusID and RoomStatusRequestModel.
        /// </summary>
        /// <param name="RoomStatusID">The ID of the room cleaning status to be updated.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <param name="RoomStatusRequestModel">The <see cref="UpdateRoomStatusModel"/> containing updated data for the room cleaning status.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the room cleaning status update operation.</returns>
        Task<Result> UpdateRoomStatus(int RoomStatusID, UpdateRoomStatusModel RoomStatusRequestModel, AuditInfoModel auditInfoModel);

        /// <summary>
        /// Deletes a room cleaning status based on the provided RoomStatusID.
        /// </summary>
        /// <param name="RoomStatusID">The ID of the room cleaning status to be deleted.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the soft delete operation.</returns>
        Task<Result> DeleteRoomStatus(int RoomStatusID, AuditInfoModel auditInfoModel);
    }
}
