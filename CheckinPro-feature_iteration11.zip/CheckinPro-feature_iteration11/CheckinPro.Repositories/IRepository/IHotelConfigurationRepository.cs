﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.WebApi.Models;


namespace CheckinPro.Repositories.IRepository
{
    public interface IHotelConfigurationRepository
    {
        /// <summary>
        /// Retrieves a list of hotel tax rate.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="HotelTaxRateModel"/> representing all hotel tax rate data.</returns>
        Task<Result<List<HotelTaxRateModel>>> GetHotelTaxRate(int hotelID);

        /// <summary> 
        /// Adds a new hotel tax rate record based on the provided hotelTaxRateRequestModel.
        /// </summary>
        /// <param name="hotelTaxRateRequestModel">The <see cref="HotelTaxRateModel"/> containing data for the new hotel tax rate.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel tax rate creation operation.</returns>
        Task<Result> AddEditHotelTaxRate(HotelTaxRateModel hotelTaxRateRequestModel, AuditInfoModel auditInfoModel);

        Task<Result<HotelConfigurationModel>> GetHotelMasterConfiguration(int hotelID);
        Task<Result> AddEditHotelMasterConfiguration(HotelConfigurationModel hotelMasterConfigurationRequestModel, AuditInfoModel auditInfoModel);

        Task<Result<List<HotelDailyRateModel>>> GetHotelDailyRate(int hotelID);
        Task<Result> AddEditHotelDailyRate(HotelDailyRateModel hotelDailyRateRequestModel, AuditInfoModel auditInfoModel);

        Task<Result<List<HotelHourlyRateModel>>> GetHotelHourlyRate(int hotelID);
        Task<Result> AddEditHotelHourlyRate(HotelHourlyRateModel hotelHourlyRateRequestModel, AuditInfoModel auditInfoModel);

        Task<Result<List<HotelRoomTypeModel>>> GetHotelRoomType(int hotelID);
        Task<Result<HotelRoomTypeModel>> GetHotelRoomTypeById(int hotelRoomTypeID);
        Task<Result> AddEditHotelRoomType(HotelRoomTypeModel hotelRoomTypeRequestModel, AuditInfoModel auditInfoModel);


        Task<Result<List<HotelAdditionalRateModel>>> GetHotelAdditionalRate(int hotelID);
        Task<Result> AddEditHotelAdditionalRate(HotelAdditionalRateModel hotelAdditionalRateRequestModel, AuditInfoModel auditInfoModel);

        Task<Result> DeleteHotelDailyRate(int hotelDailyRateID);

    }
}
