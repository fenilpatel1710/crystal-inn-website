﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.WebApi.Models;

namespace CheckinPro.Repositories.IRepository
{
    public interface IStateRepository
    {
        /// <summary>
        /// Retrieves a list of states.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="StateModel"/> representing the state data.</returns>
        Task<Result<List<StateModel>>> GetStates(int countryId);

        /// <summary>
        /// Retrieves a list of active states.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="StateModel"/> representing the state data.</returns>
        Task<Result<List<StateModel>>> GetActiveStates(int countryId);

        /// <summary>
        /// Retrieves details of a specific state by its ID.
        /// </summary>
        /// <param name="stateID">The ID of the state to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="StateModel"/> for the specified state.</returns>
        Task<Result<StateModel>> GetStateByStateID(int stateId);

        /// <summary>
        /// Adds a new state record based on the provided stateRequestModel.
        /// </summary>
        /// <param name="stateRequestModel">The <see cref="StateModel"/> containing data for the new state.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the state addition operation.</returns>
        Task<Result> AddState(StateModel stateRequestModel, AuditInfoModel auditInfoModel);

        /// <summary>
        /// Update an existing state record based on the provided stateID stateRequestModel.
        /// </summary>
        /// <param name="stateID">The ID of the state to be updated.</param>
        /// <param name="stateRequestModel">The <see cref="StateModel"/> containing updated data for the state.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the state update operation.</returns>
        Task<Result> UpdateState(int stateID, StateModel stateRequestModel, AuditInfoModel auditInfoModel);

        /// <summary>
        /// Deletes a state based on the provided stateID.
        /// </summary>
        /// <param name="stateID">The ID of the state to be deleted.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the delete operation.</returns>
        Task<Result> DeleteState(int stateID, StateModel stateRequestModel, AuditInfoModel auditInfoModel);
    }
}
