﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.Repositories.IRepository
{
    public interface IScannerRepository
    {
        Task<Result<List<AddGuestModel>>> GetGuestScanDetail(int hotelID);
        Task<Result> AddGuestScanDetail(GuestIDScan guestIDScan);

    }
}
