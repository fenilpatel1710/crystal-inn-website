﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.WebApi.Models;

namespace CheckinPro.Repositories.IRepository
{
    public interface IHotelRepository
    {
        /// <summary>
        /// Checks if records exist for the given HotelID across multiple tables.
        /// </summary>
        /// <param name="hotelId">The ID of the hotel to check.</param>
        /// <returns>A <see cref="Result"/> containing a dictionary with presence status of each table.</returns>
        Task<Result<HotelProfileStatusModel>> GetHotelProfileCompletionStatus(int hotelId);

        /// <summary>
        /// Retrieves a list of Hotels.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelModel"/> representing the hotel data.</returns>
        Task<Result<List<GetHotelModel>>> GetHotels();

        /// <summary>
        /// Retrieves details of a specific hotel by its ID.
        /// </summary>
        /// <param name="hotelID">The ID of the hotel to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetHotelModel"/> for the specified hotel.</returns>
        Task<Result<GetHotelModel>> GetHotelById(int hotelID);

        /// <summary>
        /// Adds a new hotel record based on the provided hotelRequestModel.
        /// </summary>
        /// <param name="hotelRequestModel">The <see cref="AddHotelModel"/> containing data for the new hotel.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel creation operation.</returns>
        Task<Result> AddHotel(AddHotelModel hotelRequestModel, string randomPassword, AuditInfoModel auditInfoModel);

        Task<Result> ActiveInactiveOwnerDashboard(int hotelID, bool isActive, AuditInfoModel auditInfoModel);

        Task<Result> ActiveInactiveHotel(int hotelID, bool isActive, AuditInfoModel auditInfoModel);

        Task<Result> AddHotelExpense(HotelExpenseModel hotelExpenseRequestModel, AuditInfoModel auditInfoModel);

        Task<Result<List<HotelExpenseModel>>> GetHotelExpense(int hotelID);

        Task<Result> UpdateHotelExpense(HotelExpenseModel hotelExpenseRequestModel, AuditInfoModel auditInfoModel);

        Task<Result> DeleteHotelExpense(int hotelExpenseID);
        Task<Result<List<DirectBillingCompanyModel>>> GetDirectBillingCompany(int hotelID);
        Task<Result> AddUpdateDirectBillingCompany(DirectBillingCompanyModel directBillingCompanyRequestModel, AuditInfoModel auditInfoModel);
    }
}
