﻿using Ardalis.Result;
using CheckinPro.WebApi.Models;


namespace CheckinPro.Repositories.IRepository
{
    public interface IGuestRepository
    {
        /// <summary>
        /// Retrieves  list of all guests.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetGuestModel"/> representing the Guest data.</returns>
        Task<Result<List<GetGuestModel>>> GetGuestByHotelID(int hotelID);

        /// <summary>
        /// Retrieves details of a specific Guest by its ID.
        /// </summary>
        /// <param name="guestId">The ID of the Guest to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetGuestModel"/> for the specified Guest Id.</returns>
        Task<Result<GetGuestModel>> GetGuestByCodeOrIdentityNumberOrMobile(string? guestCode = null, string? identityNumber = null, string? mobileNumber = null);

        /// <summary>
        /// Retrieves details of a specific Guest by its mobileNumber.
        /// </summary>
        /// <param name="mobileNumber">The mobileNumber of the Guest to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetGuestModel"/> for the specified Guest mobileNumber.</returns>
        Task<Result<GetGuestModel>> GetGuestByMobile(string mobileNumber = null);

        /// <summary>
        /// Retrieves details of a specific guest by its ID.
        /// </summary>
        /// <param name="guestID">The ID of the guest to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetGuestModel"/> for the specified guest.</returns>
        Task<Result<List<GetGuestModel>>> GetGuestById(int guestID);

        Task<Result<List<GetGuestModel>>> GetGuestByName(string? firstName = null, string? lastName = null);

        Task<Result<GuestRewardModel>> GetGuestRewardPoint(int hotelID, int guestID);

    }
}
