﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Repositories.IRepository;
using CheckinPro.WebApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Text;

namespace CheckinPro.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly ILogger _logger;
        private readonly CheckinProContext _checkinProContext;
        private readonly IEmailRepository _emailService;
        public UserRepository(ILogger<UserRepository> logger, CheckinProContext checkinProContext, IEmailRepository emailService)
        {
            _logger = logger;
            _checkinProContext = checkinProContext;
            _emailService = emailService;
        }

        /// <summary>
        /// Retrieves  list of all users.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetUserModel"/> representing the user data.</returns>
        public async Task<Result<List<GetUserModel>>> GetUsers(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetUsers method initiated.");

                var dbHotelUserData = await _checkinProContext.tblHotelUsers
                    .Where(hu => hu.HotelID == hotelID && (hu.User.RoleID == 3 || hu.User.RoleID == 4))
                    .Include(hu => hu.User)
                        .ThenInclude(u => u.Role)
                    .Include(hu => hu.User)
                        .ThenInclude(u => u.State)
                            .ThenInclude(s => s.Country)
                    .Select(hu => new GetUserModel
                    {
                        UserID = hu.User.UserID,
                        RoleName = hu.User.Role.RoleName,
                        FullName = hu.User.FirstName + " " + hu.User.LastName,
                        EmailID = hu.User.EmailID,
                        MobileNumber = hu.User.MobileNumber,
                        Address = string.Join(", ",
                        hu.User.Address1,
                        hu.User.Address2,
                        hu.User.City,
                        hu.User.State.StateName,
                        hu.User.State.Country.CountryName,
                        hu.User.ZipCode),
                        ProfilePicture = hu.User.ProfilePicture,
                        IsPasswordChanged = hu.User.IsPasswordChanged,
                        IsProfileActive = hu.User.IsProfileActive,
                        IsProfileBlocked = hu.User.IsProfileBlocked,
                        IsProfileDeleted = hu.User.IsProfileDeleted
                    }).ToListAsync();


                if (dbHotelUserData.Any())
                {
                    _logger.LogInformation("Repository: GetUsers method execution completed.");
                    _logger.LogInformation($"Repository: GetUsers method execution completed. Total users retrieved: {dbHotelUserData.Count}.");

                    // Return the list of UserModel
                    return Result.Success(dbHotelUserData);
                }
                else
                {
                    _logger.LogWarning($"Repository: No hotel user found.");
                    return Result.NotFound($"Repository: No hotel user found.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetUsersList method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching users.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific user by its ID.
        /// </summary>
        /// <param name="userID">The ID of the user to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetUserModel"/> for the specified user Id.</returns>
        public async Task<Result<GetUserModel>> GetUserById(int userID)
        {
            try
            {
                _logger.LogInformation($"Repository: GetUserById method initiated for UserID: {userID}.");

                // Fetch the user model based on the UserID
                var dbUserData = await _checkinProContext.tblUsers.Where(item => item.UserID == userID)
                    .Include(u => u.Role)
                    .Include(u => u.State)
                    .ThenInclude(s => s.Country)
                   .Select(u => new GetUserModel
                   {
                       UserID = u.UserID,
                       RoleName = u.Role.RoleName,
                       FullName = u.FirstName + " " + u.LastName,
                       EmailID = u.EmailID,
                       MobileNumber = u.MobileNumber,
                       Address1 = u.Address1,
                       Address2 = u.Address2,
                       CountryID = u.State.Country.CountryID,
                       StateID = u.StateID,
                       City = u.City,
                       ZipCode = u.ZipCode,
                       ProfilePicture = u.ProfilePicture,
                       LastLoginDate = u.LastLoginDate,
                       IsPasswordChanged = u.IsPasswordChanged,
                       IsProfileActive = u.IsProfileActive,
                       IsProfileBlocked = u.IsProfileBlocked,
                       IsProfileDeleted = u.IsProfileDeleted,
                   }).FirstOrDefaultAsync();

                // Return the dbUserData or null
                if (dbUserData == null)
                {
                    _logger.LogWarning($"Repository: No user found with UserID: {userID}.");
                    return Result.NotFound($"No user found with UserID: {userID}.");
                }
                else
                {
                    _logger.LogInformation($"Repository: Successfully retrieved user for UserID: {userID}.");
                    return Result.Success(dbUserData);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetUserById Exception occurred for UserID: {userID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the user.");
            }
        }

        /// <summary>
        /// Adds a new user record based on the provided addUserRequestModel.
        /// </summary>
        /// <param name="addUserRequestModel">The <see cref="AddUserModel"/> containing data for the new user.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the user creation operation.</returns>
        public async Task<Result> AddUser(AddUserModel addUserRequestModel, string randomPassword, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddUser method initiated.");

                    // Validate the request model
                    if (addUserRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddUser called with a null userRequestModel.");
                        return Result.NoContent();
                    }

                    var checkUserHotelData = await _checkinProContext.tblHotels.FirstOrDefaultAsync(u => u.HotelID == addUserRequestModel.HotelID);
                    if (checkUserHotelData == null)
                    {
                        _logger.LogWarning("Repository: Hotel not exists.");
                        return Result.Error("Hotel not exists.");
                    }

                    var checkUserData = await _checkinProContext.tblUsers.FirstOrDefaultAsync(u => u.EmailID == addUserRequestModel.EmailID);
                    if (checkUserData != null)
                    {
                        _logger.LogWarning("Repository: User already exists.");
                        return Result.Error("User already exists.");
                        //return Result.du("User already exists.");
                    }

                    // Create a new user entity dbUser and add it to the database
                    tblUser dbUser = new tblUser()
                    {
                        RoleID = addUserRequestModel.RoleID,
                        FirstName = addUserRequestModel.FirstName,
                        LastName = addUserRequestModel.LastName,
                        EmailID = addUserRequestModel.EmailID,
                        MobileNumber = addUserRequestModel.MobileNumber,
                        Address1 = addUserRequestModel.Address1,
                        Address2 = addUserRequestModel.Address2,
                        StateID = addUserRequestModel.StateID,
                        City = addUserRequestModel.City,
                        ZipCode = addUserRequestModel.ZipCode,
                        Password = addUserRequestModel.Password,
                        IsProfileActive = true,
                        CreatedBy = auditInfoModel.AuditUserID,
                        CreatedDate = DateTime.Now
                    };

                    tblHotelUser dbHotelUser = new tblHotelUser()
                    {
                        HotelID = addUserRequestModel.HotelID,
                        IsHotelUserActive = true,
                        CreatedBy = 1,
                        CreatedDate = DateTime.Now,
                        User = dbUser
                    };


                    await _checkinProContext.tblHotelUsers.AddAsync(dbHotelUser);
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();
                    //Sending invite mail with password to the owner
                    var emailTemplate = await _checkinProContext.tblEmailTemplates.Where(item => item.EmailTemplateName == "NewAccount").FirstOrDefaultAsync();
                    if (emailTemplate != null && !string.IsNullOrEmpty(emailTemplate.EmailTemplateDesign))
                    {
                        var messageBody = emailTemplate.EmailTemplateDesign;
                        StringBuilder strmsg = new StringBuilder(messageBody);
                        strmsg.Replace("[Recipient_Name]", addUserRequestModel.FirstName + " " + addUserRequestModel.LastName);
                        strmsg.Replace("[HoteL_Name]", checkUserHotelData.BusinessLLCName);
                        strmsg.Replace("[HoteL_Code]", checkUserHotelData.HotelCode);
                        strmsg.Replace("[Email]", addUserRequestModel.EmailID);
                        strmsg.Replace("[Generated_Password]", randomPassword);
                        strmsg.Replace("[SignIn_URL]", "https://localhost:7020/signin");
                        await _emailService.SendEmailAsync(addUserRequestModel.EmailID, emailTemplate.EmailTemplateSubject, strmsg.ToString());
                    }
                    else
                    {
                        _logger.LogWarning("Repository: Email template is missing or incomplete.");
                        return Result.Error("Email template is missing or incomplete.");
                    }

                    _logger.LogInformation($"Repository: Successfully added user with ID: {dbUser.UserID}.");
                    return Result.Success();
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Repository: AddUser Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while adding the user.");
                }
            }
        }

        /// <summary>
        /// Updates an existing user record based on the provided userID and updateUserRequestModel.
        /// </summary>
        /// <param name="userID">The ID of the user to be updated.</param>
        /// <param name="updateUserRequestModel">The <see cref="UpdateUserModel"/> containing updated data for the user.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the user update operation.</returns>
        public async Task<Result> UpdateUser(int userID, UpdateUserModel updateUserRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: UpdateUser method initiated for userID: {userID}.");

                    // Validate the request model
                    if (updateUserRequestModel == null)
                    {
                        _logger.LogWarning("Repository: UpdateUser called with a null UserModel.");
                        return Result.NoContent();
                    }

                    // Fetch the existing country entity
                    var dbUserData = await _checkinProContext.tblUsers.FindAsync(userID);
                    if (dbUserData == null)
                    {
                        _logger.LogWarning($"Repository: No user found with userID: {userID}.");
                        return Result.NoContent();
                    }

                    // Update the properties
                    dbUserData.EmailID = updateUserRequestModel.EmailID;
                    dbUserData.MobileNumber = updateUserRequestModel.MobileNumber;
                    dbUserData.Address1 = updateUserRequestModel.Address1;
                    dbUserData.Address2 = updateUserRequestModel.Address2;
                    dbUserData.StateID = updateUserRequestModel.StateID;
                    dbUserData.City = updateUserRequestModel.City;
                    dbUserData.ZipCode = updateUserRequestModel.ZipCode;
                    dbUserData.ProfilePicture = updateUserRequestModel.ProfilePicture;
                    dbUserData.UpdatedBy = auditInfoModel.AuditUserID;
                    dbUserData.UpdatedDate = DateTime.Now;
                    // Update other properties as necessary

                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully updated user with ID: {userID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while updating user. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: UpdateUser Exception occurred for userID: {userID}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while updating the user.");
                }
            }
        }

        /// <summary>
        /// Deletes an user based on the provided userID.
        /// </summary>
        /// <param name="userID">The ID of the user to be deleted.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the delete operation.</returns>
        public async Task<Result> DeleteUser(int userId, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: DeleteUser method initiated for UserID: {userId}.");

                    //Fetch the existing entity
                    var dbUserData = await _checkinProContext.tblUsers.FindAsync(userId);
                    if (dbUserData == null)
                    {
                        _logger.LogWarning($"Repository: No user found with UserID: {userId}.");
                        return Result.NoContent();
                    }

                    //updating the delete flags
                    dbUserData.IsProfileDeleted = true;
                    dbUserData.IsProfileActive = false;
                    dbUserData.DeletedBy = auditInfoModel.AuditUserID;
                    dbUserData.DeletedDate = DateTime.Now;

                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully deleted user with ID: {userId}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while deleting user. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: DeleteUser Exception occurred for UserID: {userId}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while deleting the user.");
                }
            }
        }

        /// <summary>
        /// Blocks an user based on the provided userID.
        /// </summary>
        /// <param name="userID">The ID of the user to be blocked.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the block operation.</returns>
        public async Task<Result> BlockUser(int userId, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: BlockUser method initiated for UserID: {userId}.");

                    // Fetch the existing entity
                    var dbUserData = await _checkinProContext.tblUsers.FindAsync(userId);
                    if (dbUserData == null)
                    {
                        _logger.LogWarning($"Repository: No user found with UserID: {userId}.");
                        return Result.NoContent();
                    }

                    if (!dbUserData.IsProfileActive)
                    {
                        _logger.LogWarning("Repository: User profile is not active.");
                        return Result.Error("User profile is not active.");
                    }

                    //updating the flag
                    dbUserData.IsProfileBlocked = true;
                    dbUserData.IsProfileActive = false;
                    dbUserData.UpdatedBy = auditInfoModel.AuditUserID;
                    dbUserData.UpdatedDate = DateTime.Now;

                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully blocked user with ID: {userId}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while blocking user. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: BlockUser Exception occurred for UserID: {userId}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while blocking the user.");
                }
            }
        }

        /// <summary>
        /// Activates the user based on the provided userID.
        /// </summary>
        /// <param name="userID">The ID of the user to be activated.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the profile activation operation.</returns>
        public async Task<Result> ActivateUser(int userId, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: ActivateUser method initiated for UserID: {userId}.");

                    // Fetch the existing entity
                    var dbUserData = await _checkinProContext.tblUsers.FindAsync(userId);
                    if (dbUserData == null)
                    {
                        _logger.LogWarning($"Repository: No user found with UserID: {userId}.");
                        return Result.NoContent();
                    }

                    if (dbUserData.IsProfileDeleted)
                    {
                        _logger.LogWarning("Repository: User profile is already deleted.");
                        return Result.Error("User profile is already deleted.");
                    }

                    //updating the flag
                    dbUserData.IsProfileBlocked = false;
                    dbUserData.IsProfileActive = true;
                    dbUserData.UpdatedBy = auditInfoModel.AuditUserID;
                    dbUserData.UpdatedDate = DateTime.Now;

                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully activated user with ID: {userId}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while activating user. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: ActivateUser Exception occurred for UserID: {userId}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while activating the user.");
                }
            }
        }
    }

}