﻿using Ardalis.Result;
using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Repositories.IRepository;
using CheckinPro.WebApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

namespace CheckinPro.Repositories
{
    public class GuestRepository : IGuestRepository
    {
        private readonly ILogger _logger;
        private readonly CheckinProContext _checkinProContext;
        public GuestRepository(ILogger<UserRepository> logger, CheckinProContext checkinProContext)
        {
            _logger = logger;
            _checkinProContext = checkinProContext;
        }

        /// <summary>
        /// Retrieves a list of Guests.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetGuestModel"/> representing the guest data.</returns>
        public async Task<Result<List<GetGuestModel>>> GetGuestByHotelID(int hotelID)
        {
            try
            {
                
                _logger.LogInformation($"Repository: GetGuestByHotelID method initiated for HotelID: {hotelID}");
                
                var dbGuestData = await _checkinProContext.tblGuests
                .AsNoTracking()
                .Where(guest => guest.IsProfileDeleted != true &&
                guest.tblHotelRoomBookingGuests.Any(bg => bg.HotelRoomBooking.HotelRoomType.HotelID == hotelID))
                .Select(guest => new GetGuestModel
                {
                    GuestID = guest.GuestID,
                    GuestCode = guest.GuestCode,
                    FirstName = guest.FirstName,
                    LastName = guest.LastName,
                    IdentityType = guest.IdentityType,
                    IdentityNumber = guest.IdentityNumber,
                    MobileNumber = guest.MobileNumber,
                    Email = guest.Email,
                    Address1 = guest.Address1,
                    Address2 = guest.Address2,
                    Country = guest.Country,
                    State = guest.State,
                    City = guest.City,
                    ZipCode = guest.ZipCode,
                    IsGuestScanned = guest.IsGuestScanned,
                    TotalRewardPoint = _checkinProContext.tblGuestRewards.Where(gr => gr.HotelID == hotelID && gr.GuestID == guest.GuestID).Select(gr => gr.TotalRewardPoint).FirstOrDefault(),
                }).ToListAsync();

                if (dbGuestData == null || dbGuestData.Count == 0)
                {
                    _logger.LogWarning($"Repository: No guests found for HotelID: {hotelID}.");
                    return Result.Success(new List<GetGuestModel>());
                }

                _logger.LogInformation($"Repository: Successfully retrieved guests for HotelID: {hotelID}.");
                return Result.Success(dbGuestData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetGuestByHotelID method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the guest data.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific guest by its ID.
        /// </summary>
        /// <param name="guestID">The ID of the guest to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetGuestModel"/> for the specified guest.</returns>
        public async Task<Result<List<GetGuestModel>>> GetGuestById(int guestID)
        {
            try
            {
                _logger.LogInformation($"Repository: GetGuestById method initiated for Guest details");

                var dbGuestData = new List<GetGuestModel>();
                //            var dbUserDataQuery = _checkinProContext.tblGuests.AsQueryable();
                //            var dbHotelRoomBooking = _checkinProContext.tblHotelRoomBookings.AsQueryable();
                //            var dbHotelRoom = _checkinProContext.tblHotelRooms.AsQueryable();
                //            var hotels = await _checkinProContext.tblHotels.ToListAsync();
                //            var dbGuestData = await (from guest in _checkinProContext.tblGuests
                //                                     join booking in _checkinProContext.tblHotelRoomBookings on guest.GuestID equals booking.GuestID into bookingGroup
                //                                     from booking in bookingGroup.DefaultIfEmpty() // Left join
                //                                     join room in _checkinProContext.tblHotelRooms on booking.HotelRoomID equals room.HotelRoomID into roomGroup
                //                                     from room in roomGroup.DefaultIfEmpty() // Left join
                //                                     join hotel in _checkinProContext.tblHotels on room.HotelID equals hotel.HotelID into hotelGroup
                //                                     from hotel in hotelGroup.DefaultIfEmpty() // Left join
                //                                     where guest.GuestID == guestID
                //                                     select new
                //                                     {
                //                                         Guest = guest,
                //                                         Booking = booking,
                //                                         Room = room,
                //                                         Hotel = hotel
                //                                     })
                //.GroupBy(x => x.Guest)
                //.Select(group => new GetGuestModel
                //{
                //    GuestID = group.Key.GuestID,
                //    FirstName = group.Key.FirstName,
                //    LastName = group.Key.LastName,
                //    Email = group.Key.Email,
                //    MobileNumber = group.Key.MobileNumber,
                //    Address1 = group.Key.Address1,
                //    Address2 = group.Key.Address2,
                //    City = group.Key.City,
                //    ZipCode = group.Key.ZipCode,
                //    HotelRoomBookings = group.Where(g => g.Booking != null).Select(g => new GetHotelRoomBookingModel
                //    {
                //        HotelRoomBookingID = g.Booking.HotelRoomBookingID,
                //        GuestID = g.Booking.GuestID,
                //        HotelRoomID = g.Booking.HotelRoomID,
                //        ScheduledCheckInDate = g.Booking.ScheduledCheckInDate,
                //        ScheduledCheckOutDate = g.Booking.ScheduledCheckOutDate,
                //        NumberOfGuests = g.Booking.NumberOfGuests ?? 0,
                //        TotalAmount = g.Booking.TotalAmount ?? 0M,
                //        BookingStatus = g.Booking.BookingStatus ?? string.Empty,
                //        PaymentStatus = g.Booking.PaymentStatus ?? string.Empty,
                //        GetHotelRoom = g.Room == null ? null : new GetHotelRoomModel
                //        {
                //            HotelRoomID = g.Room.HotelRoomID,
                //            RoomNumber = g.Room.RoomNumber,
                //            Floor = g.Room.Floor,
                //            MaxOccupancy = g.Room.MaxOccupancy,
                //            Description = g.Room.Description,
                //            IsHotelRoomActive = g.Room.IsHotelRoomActive
                //        }
                //    }).ToList()
                //}).ToListAsync();




                if (dbGuestData == null || !dbGuestData.Any())
                {
                    _logger.LogWarning($"Repository: No guest found with the provided parameters (GuestId: {guestID}).");
                    return Result.NotFound("No guest found with the provided parameters.");
                }

                _logger.LogInformation($"Repository: Successfully retrieved guests for GuestId: {guestID}.");
                return Result.Success(dbGuestData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetGuestById Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the guest details.");
            }
        }

        public async Task<Result<GetGuestModel>> GetGuestByCodeOrIdentityNumberOrMobile(string? guestCode = null, string? identityNumber = null, string? mobileNumber = null)
        {
            try
            {
                _logger.LogInformation($"Repository: GetGuestByCodeOrIdentityNumberOrMobile method initiated.");

                // Start the query to fetch the user data
                var dbUserDataQuery = _checkinProContext.tblGuests.AsQueryable();

                // Apply filters based on the provided parameters
                if (!string.IsNullOrEmpty(guestCode))
                {
                    dbUserDataQuery = dbUserDataQuery.Where(guest => guest.GuestCode == guestCode);
                }
                else if (!string.IsNullOrEmpty(identityNumber))
                {
                    dbUserDataQuery = dbUserDataQuery.Where(guest => guest.IdentityNumber == identityNumber);
                }
                else if (!string.IsNullOrEmpty(mobileNumber))
                {
                    dbUserDataQuery = dbUserDataQuery.Where(guest => guest.MobileNumber == mobileNumber);
                }
                //else if (!string.IsNullOrEmpty(firstName) || !string.IsNullOrEmpty(lastName))
                //{
                //    dbUserDataQuery = dbUserDataQuery.Where(guest => guest.FirstName == firstName|| guest.LastName == lastName);
                //}
                else
                {
                    _logger.LogWarning("Repository: No valid parameters provided for search.");
                    return Result.Error("No valid parameters provided for search.");
                }

                var dbUserData = await dbUserDataQuery
                    .Include(guest => guest.tblHotelRoomBookingGuests)
                        .ThenInclude(booking => booking.HotelRoomBooking)
                    .Select(guest => new GetGuestModel
                    {
                        GuestID = guest.GuestID,
                        GuestCode = guest.GuestCode,
                        FirstName = guest.FirstName,
                        LastName = guest.LastName,
                        IdentityType = guest.IdentityType,
                        IdentityNumber = guest.IdentityNumber,
                        FrontSideImage = guest.FrontSideImage,
                        MobileNumber = guest.MobileNumber,
                        Email = guest.Email,
                        Address1 = guest.Address1,
                        Address2 = guest.Address2,
                        Country = guest.Country,
                        State = guest.State,
                        City = guest.City,
                        ZipCode = guest.ZipCode,
                        IsGuestScanned = guest.IsGuestScanned,
                        //State = guest.State == null ? null : new GetStateModel
                        //{
                        //    StateID = guest.State.StateID,
                        //    StateName = guest.State.StateName,
                        //    Country = new GetCountryModel
                        //    {
                        //        CountryID = guest.State.CountryID,
                        //        CountryName = guest.State.Country.CountryName,
                        //    }
                        //},
                        HotelRoomBookings = guest.tblHotelRoomBookingGuests
                        .Where(hrb => hrb.HotelRoomBooking != null && hrb.HotelRoomBooking.GuestNotes != null && hrb.HotelRoomBooking.GuestNoteType != null)
                        .Select(hrb => new GetHotelRoomBookingModel
                        {
                            HotelRoomBookingID = hrb.HotelRoomBooking.HotelRoomBookingID,
                            ScheduledCheckInDate = hrb.HotelRoomBooking.ScheduledCheckInDate,
                            ScheduledCheckOutDate = hrb.HotelRoomBooking.ScheduledCheckOutDate,
                            GuestNoteType = hrb.HotelRoomBooking.GuestNoteType,
                            GuestNotes = hrb.HotelRoomBooking.GuestNotes,
                        }).ToList()
                    }).FirstOrDefaultAsync();

                // Check if user data is found
                if (dbUserData == null)
                {
                    _logger.LogWarning($"Repository: No guest found.");
                    return Result.NotFound("No guest found with the provided parameters.");
                }
                else
                {
                    _logger.LogInformation($"Repository: Successfully retrieved guest.");
                    return Result.Success(dbUserData);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetGuestByIdOrEmailOrMobile Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the user.");
            }
        }

        public async Task<Result<GetGuestModel>> GetGuestByMobile(string mobileNumber = null)
        {
            try
            {
                _logger.LogInformation($"Repository: GetGuestByMobile method initiated for MobileNumber: {mobileNumber}");

                var dbGuestData = await _checkinProContext.tblGuests.Where(guest => guest.MobileNumber.StartsWith(mobileNumber) || guest.IdentityNumber.StartsWith(mobileNumber))
                    .Include(guest => guest.tblHotelRoomBookingGuests)
                        .ThenInclude(hrb => hrb.HotelRoomBooking)
                    .Select(guest => new GetGuestModel
                    {
                        GuestID = guest.GuestID,
                        GuestCode = guest.GuestCode,
                        FirstName = guest.FirstName,
                        LastName = guest.LastName,
                        IdentityType = guest.IdentityType,
                        IdentityNumber = guest.IdentityNumber,
                        FrontSideImage = guest.FrontSideImage,
                        MobileNumber = guest.MobileNumber,
                        Email = guest.Email,
                        Address1 = guest.Address1,
                        Address2 = guest.Address2,
                        Country = guest.Country,
                        State = guest.State,
                        City = guest.City,
                        ZipCode = guest.ZipCode,
                        IsGuestScanned = guest.IsGuestScanned,
                        //State = new GetStateModel
                        //{
                        //    StateID = guest.State.StateID,
                        //    StateName = guest.State.StateName,
                        //    Country = new GetCountryModel
                        //    {
                        //        CountryID = guest.State.CountryID,
                        //        CountryName = guest.State.Country.CountryName,
                        //    }
                        //},
                        HotelRoomBookings = guest.tblHotelRoomBookingGuests
                        .Where(hrb => hrb.HotelRoomBooking != null && hrb.HotelRoomBooking.GuestNotes != null && hrb.HotelRoomBooking.GuestNoteType != null)
                        .Select(hrb => new GetHotelRoomBookingModel
                        {
                            HotelRoomBookingID = hrb.HotelRoomBooking.HotelRoomBookingID,
                            ScheduledCheckInDate = hrb.HotelRoomBooking.ScheduledCheckInDate,
                            ScheduledCheckOutDate = hrb.HotelRoomBooking.ScheduledCheckOutDate,
                            GuestNoteType = hrb.HotelRoomBooking.GuestNoteType,
                            GuestNotes = hrb.HotelRoomBooking.GuestNotes,
                        }).ToList()
                    }).FirstOrDefaultAsync();

                // Check if guest data is found
                if (dbGuestData == null)
                {
                    _logger.LogWarning($"Repository: No guest found with the provided parameters MobileNumber: {mobileNumber}.");
                    return Result.NotFound("No guest found with the provided parameters.");
                }
                else
                {
                    _logger.LogInformation($"Repository: Successfully retrieved guest for MobileNumber: {mobileNumber}.");
                    return Result.Success(dbGuestData);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetGuestByMobile Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the user.");
            }
        }

        public async Task<Result<List<GetGuestModel>>> GetGuestByName(string? firstName = null, string? lastName = null)
        {
            try
            {
                _logger.LogInformation($"Repository: GetGuestByCodeOrIdentityNumberOrMobile method initiated.");

                // Start the query to fetch the user data
                var dbUserDataQuery = _checkinProContext.tblGuests.AsQueryable();

                // Apply filters based on the provided parameters
                if (!string.IsNullOrEmpty(firstName) && !string.IsNullOrEmpty(lastName))
                {
                    // If both firstName and lastName are provided, filter by both
                    dbUserDataQuery = dbUserDataQuery.Where(guest => guest.FirstName.StartsWith(firstName) && guest.LastName.StartsWith(lastName));
                }
                else if (!string.IsNullOrEmpty(firstName))
                {
                    dbUserDataQuery = dbUserDataQuery.Where(guest => guest.FirstName.StartsWith(firstName));

                }
                else if (!string.IsNullOrEmpty(lastName))
                {
                    dbUserDataQuery = dbUserDataQuery.Where(guest => guest.LastName.StartsWith(lastName));
                }
                else
                {
                    _logger.LogWarning("Repository: No valid parameters provided for search.");
                    return Result.Error("No valid parameters provided for search.");
                }

                var dbUserData = await dbUserDataQuery
                    .Include(guest => guest.tblHotelRoomBookingGuests)
                        .ThenInclude(booking => booking.HotelRoomBooking)
                    .Select(guest => new GetGuestModel
                    {
                        GuestID = guest.GuestID,
                        GuestCode = guest.GuestCode,
                        FirstName = guest.FirstName,
                        LastName = guest.LastName,
                        IdentityType = guest.IdentityType,
                        IdentityNumber = guest.IdentityNumber,
                        FrontSideImage = guest.FrontSideImage,
                        MobileNumber = guest.MobileNumber,
                        Email = guest.Email,
                        Address1 = guest.Address1,
                        Address2 = guest.Address2,
                        Country = guest.Country,
                        State = guest.State,
                        City = guest.City,
                        ZipCode = guest.ZipCode,
                        IsGuestScanned = guest.IsGuestScanned,
                        //State = guest.State == null ? null : new GetStateModel
                        //{
                        //    StateID = guest.State.StateID,
                        //    StateName = guest.State.StateName,
                        //    Country = new GetCountryModel
                        //    {
                        //        CountryID = guest.State.CountryID,
                        //        CountryName = guest.State.Country.CountryName,
                        //    }
                        //},
                        HotelRoomBookings = guest.tblHotelRoomBookingGuests
                        .Where(hrb => hrb.HotelRoomBooking != null && hrb.HotelRoomBooking.GuestNotes != null && hrb.HotelRoomBooking.GuestNoteType != null)
                        .Select(hrb => new GetHotelRoomBookingModel
                        {
                            HotelRoomBookingID = hrb.HotelRoomBooking.HotelRoomBookingID,
                            ScheduledCheckInDate = hrb.HotelRoomBooking.ScheduledCheckInDate,
                            ScheduledCheckOutDate = hrb.HotelRoomBooking.ScheduledCheckOutDate,
                            GuestNoteType = hrb.HotelRoomBooking.GuestNoteType,
                            GuestNotes = hrb.HotelRoomBooking.GuestNotes,
                        }).ToList()
                    }).ToListAsync();

                // Check if user data is found
                if (dbUserData == null)
                {
                    _logger.LogWarning($"Repository: No guest found.");
                    return Result.NotFound("No guest found with the provided parameters.");
                }
                else
                {
                    _logger.LogInformation($"Repository: Successfully retrieved guest.");
                    return Result.Success(dbUserData);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetGuestByIdOrEmailOrMobile Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the user.");
            }
        }

        public async Task<Result<GuestRewardModel>> GetGuestRewardPoint(int hotelID, int guestID)
        {
            try
            {
                _logger.LogInformation($"Repository: GetGuestRewardPoint method initiated");

                var dbGuestRewardData = await _checkinProContext.tblGuestRewards.Where(item => item.HotelID == hotelID && item.GuestID == guestID)
                      .Select(guest => new GuestRewardModel
                      {
                          GuestRewardID = guest.GuestRewardID,
                          GuestID = guest.GuestID,
                          HotelID = guest.HotelID,
                          TotalRewardPoint = guest.TotalRewardPoint

                      }).FirstOrDefaultAsync();

                // Check if guest data is found
                if (dbGuestRewardData == null)
                {
                    _logger.LogWarning($"Repository: No Reward Point found");
                    return Result.NotFound("No Reward Point found");
                }
                else
                {
                    _logger.LogInformation($"Repository: Successfully retrieved guest Reward Point");
                    return Result.Success(dbGuestRewardData);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetGuestRewardPoint Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the data.");
            }
        }
    }
}
