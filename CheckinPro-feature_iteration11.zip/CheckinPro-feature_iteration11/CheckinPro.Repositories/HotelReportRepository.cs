﻿using Ardalis.Result;
using CheckinPro.Common.Models.Constants;
using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Report.Templates;
using CheckinPro.Repositories.IRepository;
using CheckinPro.WebApi.Models;
using iText.Html2pdf;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using static CheckinPro.Common.Models.Constants.CommonConstants;

namespace CheckinPro.Repositories
{
    public class HotelReportRepository : IHotelReportRepository
    {
        private readonly ILogger _logger;
        private readonly CheckinProContext _checkinProContext;
        private readonly IHtmlGenerator _htmlGenerator;
        public HotelReportRepository(ILogger<HotelReportRepository> logger, CheckinProContext checkinProContext, IHtmlGenerator htmlGenerator)
        {
            _logger = logger;
            _checkinProContext = checkinProContext;
            _htmlGenerator = htmlGenerator; 
        }

        public async Task<Result<byte[]>> PrintBookingReceipt(int hotelRoomBookingID)
        {
            try
            {
                _logger.LogInformation("Repository: PrintBookingReceipt method initiated.");

                var dbHotelRoomBookingData = await _checkinProContext.tblHotelRoomBookings
     .Include(booking => booking.HotelRoomType)
         .ThenInclude(hotel => hotel.Hotel)
             .ThenInclude(state => state.State)
                 .ThenInclude(country => country.Country)
     .Include(booking => booking.HotelRoom)
     .Include(booking => booking.tblHotelRoomBookingGuests)
         .ThenInclude(guest => guest.Guest)
     .Include(booking => booking.tblPayments)
     .Include(booking => booking.tblHotelRoomBookingTaxRates)
     .Include(booking => booking.tblHotelRoomBookingRateDetails)
     .Where(booking => booking.HotelRoomBookingID == hotelRoomBookingID)
     .FirstOrDefaultAsync();

                if (dbHotelRoomBookingData == null)
                    return null;

                // Primary guest
                var primaryGuest = dbHotelRoomBookingData.tblHotelRoomBookingGuests
                    .FirstOrDefault(g => g.IsPrimaryGuest)?.Guest;

                // Rate details
                var baseRateDetail = dbHotelRoomBookingData.tblHotelRoomBookingRateDetails.ToList();

                // Active shift
                var shiftNo = _checkinProContext.tblHotelShifts
                    .FirstOrDefault(s => s.IsShiftActive)?.ShiftNo ?? 0;

                // Create the model
                var bookingReceiptHTMLModel = new BookingReceiptHTMLModel
                {
                    hotelHTMLModel = BindHotelModel(dbHotelRoomBookingData.HotelRoomType.Hotel),
                    ShiftNo = shiftNo,
                    RoomNumber = dbHotelRoomBookingData.HotelRoom?.RoomNumber,
                    GuestName = $"{primaryGuest?.FirstName} {primaryGuest?.LastName}".Trim(),
                    GuestCode = primaryGuest?.GuestCode,
                    Address1 = primaryGuest?.Address1,
                    Address2 = primaryGuest?.Address2,
                    Country = primaryGuest?.Country,
                    State = primaryGuest?.State,
                    City = primaryGuest?.City,
                    ZipCode = primaryGuest?.ZipCode,
                    ScheduledCheckInDate = dbHotelRoomBookingData.ScheduledCheckInDate,
                    ScheduledCheckOutDate = dbHotelRoomBookingData.ScheduledCheckOutDate,
                    ActualCheckInDate = dbHotelRoomBookingData.ActualCheckInDate,
                    Duration = dbHotelRoomBookingData.Duration,
                    NumberOfGuests = dbHotelRoomBookingData.NumberOfGuests,
                    IsHourlyBooking = dbHotelRoomBookingData.IsHourlyBooking,
                    BestAvailableRate = baseRateDetail.FirstOrDefault(r => r.IsExtend == false)?.BestAvailableRate ?? 0,
                    AdjustmentRate = baseRateDetail.FirstOrDefault(r => r.IsExtend == false)?.AdjustmentRate ?? 0,
                    HourlyRate = baseRateDetail.FirstOrDefault(r => r.IsExtend == false)?.HourlyRate ?? 0,
                    SubTotalAmount = baseRateDetail.Sum(item => item.RoomChargeAmount),
                    TotalAmount = baseRateDetail.Sum(item => item.TotalAmount),
                    AdditionalRateType = baseRateDetail.FirstOrDefault(r => r.IsExtend == false)?.AdditionalRateType,
                    AdditionalRateAmount = baseRateDetail.FirstOrDefault(r => r.IsExtend == false)?.AdditionalRateAmount ?? 0,
                    DiscountedAmount = baseRateDetail.FirstOrDefault(r => r.IsExtend == false)?.DiscountedAmount ?? 0,
                    MiscellaneousAmount = baseRateDetail.FirstOrDefault(r => r.IsExtend == false)?.MiscellaneousAmount ?? 0,
                    FinalAmount = baseRateDetail.Sum(item => item.FinalAmount),
                    Payment = baseRateDetail.Sum(item => item.FinalAmount),
                    Tax = dbHotelRoomBookingData.tblHotelRoomBookingTaxRates.Sum(item => item.BookingTaxRate),
                    Cash = dbHotelRoomBookingData.tblPayments.Where(item => item.PaymentMode == PaymentModeOption.Cash).Sum(item => item.Amount),
                    Credit = dbHotelRoomBookingData.tblPayments.Where(item => item.PaymentMode != PaymentModeOption.Cash && item.PaymentMode != PaymentModeOption.RewardPoint).Sum(item => item.Amount),
                    Reward = dbHotelRoomBookingData.tblPayments.Where(item => item.PaymentMode == PaymentModeOption.RewardPoint).Sum(item => item.Amount),
                    Balance = dbHotelRoomBookingData.tblPayments.Sum(payment => payment.Amount) - (baseRateDetail.Sum(item => item.FinalAmount)),
                    Refund = dbHotelRoomBookingData.tblPayments.Where(item => item.IsRefunded).Sum(item => item.RefundAmount),
                };


                var bookingReceiptHTML = await _htmlGenerator.getBookingReceiptHTML(bookingReceiptHTMLModel);

                byte[] PDF = ConvertHTMLToPDF(bookingReceiptHTML);

                _logger.LogInformation($"Repository: PrintBookingReceipt method execution completed.");

                return Result.Success(PDF);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: Print BookingReceipt method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Print Booking Receipt.");
            }
        }

        public async Task<Result<byte[]>> DownloadBookingInvoice(int hotelRoomBookingID)
        {
            try
            {
                _logger.LogInformation("Repository: DownloadBookingInvoice method initiated.");

                var dbHotelRoomBookingData = await _checkinProContext.tblHotelRoomBookings
                .Include(booking => booking.HotelRoomType)
                    .ThenInclude(hotel => hotel.Hotel)
                        .ThenInclude(state => state.State)
                            .ThenInclude(country => country.Country)
                .Include(booking => booking.HotelRoom)
                .Include(booking => booking.tblHotelRoomBookingGuests)
                    .ThenInclude(booking => booking.Guest)
                .Include(booking => booking.tblPayments.Where(item => !item.IsRefunded && item.PaymentStatus == PaymentStatusMessages.Completed))
                .Include(booking => booking.tblHotelRoomBookingTaxRates)
                .Where(booking => booking.HotelRoomBookingID == hotelRoomBookingID)
                .Select(booking => new BookingInvoiceHTMLModel
                {
                    hotelHTMLModel = BindHotelModel(booking.HotelRoomType.Hotel),
                    HotelRoomBookingID = booking.HotelRoomBookingID,
                    RoomTypeName = booking.HotelRoomType.RoomTypeName,
                    RoomNumber = booking.HotelRoom.RoomNumber,
                    Floor = booking.HotelRoom.Floor,
                    ScheduledCheckInDate = booking.ScheduledCheckInDate,
                    ScheduledCheckOutDate = booking.ScheduledCheckOutDate,
                    ActualCheckInDate = booking.ActualCheckInDate,
                    Duration = booking.Duration,
                    NumberOfGuests = booking.NumberOfGuests,
                    IsHourlyBooking = booking.IsHourlyBooking,
                    BestAvailableRate = booking.tblHotelRoomBookingRateDetails.FirstOrDefault().BestAvailableRate,
                    AdjustmentRate = booking.tblHotelRoomBookingRateDetails.FirstOrDefault().AdjustmentRate,
                    HourlyRate = booking.tblHotelRoomBookingRateDetails.FirstOrDefault().HourlyRate,
                    SubTotalAmount = booking.tblHotelRoomBookingRateDetails.FirstOrDefault().RoomChargeAmount,
                    TotalAmount = booking.tblHotelRoomBookingRateDetails.FirstOrDefault().TotalAmount,
                    AdditionalRateType = booking.tblHotelRoomBookingRateDetails.FirstOrDefault().AdditionalRateType,
                    AdditionalRateAmount = booking.tblHotelRoomBookingRateDetails.FirstOrDefault().AdditionalRateAmount,
                    DiscountedAmount = booking.tblHotelRoomBookingRateDetails.FirstOrDefault().DiscountedAmount,
                    //MiscellaneousAmount = booking.MiscellaneousAmount,
                    FinalAmount = booking.tblHotelRoomBookingRateDetails.FirstOrDefault().FinalAmount,
                    BookingStatus = booking.BookingStatus,
                    GuestName = booking.tblHotelRoomBookingGuests.FirstOrDefault(booking => booking.IsPrimaryGuest).Guest.FirstName + " " + booking.tblHotelRoomBookingGuests.FirstOrDefault(booking => booking.IsPrimaryGuest).Guest.LastName,
                    GuestCode = booking.tblHotelRoomBookingGuests.FirstOrDefault(booking => booking.IsPrimaryGuest).Guest.GuestCode,
                    hotelRoomBookingTaxRateHTMLModels = booking.tblHotelRoomBookingTaxRates.Select(item => new HotelRoomBookingTaxRateHTMLModel
                    {
                        BookingTaxRateName = item.BookingTaxRateName,
                        BookingTaxRatePercentage = item.BookingTaxRatePercentage,
                        BookingTaxRate = item.BookingTaxRate,
                    }).ToList(),
                    bookingPaymentHTMLModels = booking.tblPayments.Select(item => new BookingPaymentHTMLModel
                    {
                        PaymentDate = item.PaymentDate,
                        Amount = item.Amount,
                        PaymentMode = item.PaymentMode,
                        PaymentStatus = item.PaymentStatus,
                        PaymentGateway = item.PaymentGateway,
                        TransactionID = item.TransactionID,
                        TransactionType = item.TransactionType,
                        PaymentNotes = item.PaymentNotes,
                        IsRefunded = item.IsRefunded,
                        RefundDate = item.RefundDate,
                        RefundAmount = item.RefundAmount,
                        RefundNotes = item.RefundNotes,
                    }).ToList(),
                }).FirstOrDefaultAsync();

                var bookingInvoiceHTML = await _htmlGenerator.getBookingInvoiceHTML(dbHotelRoomBookingData);

                byte[] PDF = ConvertHTMLToPDF(bookingInvoiceHTML);

                _logger.LogInformation($"Repository: DownloadBookingInvoice method execution completed.");

                return Result.Success(PDF);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: Download BookingInvoice method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Download Booking Invoice.");
            }
        }

        public async Task<Result<byte[]>> DownloadDailyAuditReport(int hotelId, DateOnly fromDate, DateOnly toDate)
        {
            try
            {
                _logger.LogInformation("Repository: DownloadDailyAuditReport method initiated.");

                var dailyAuditReportData = await GetDailyAuditReportSummary(hotelId, fromDate, toDate);

                var dailyAuditReportHTMLModel = new DailyAuditReportHTMLModel
                {
                    FromDate = dailyAuditReportData.FromDate,
                    ToDate = dailyAuditReportData.ToDate,
                    hotelHTMLModel = dailyAuditReportData.hotelHTMLModel,
                    dailyAuditReportBookingSummaries = dailyAuditReportData.dailyAuditReportBookingSummaries,
                    dailyAuditReportTotalSummary = dailyAuditReportData.dailyAuditReportTotalSummary,
                    dailyAuditReportSummary = dailyAuditReportData.dailyAuditReportSummary,
                    dailyAuditReportTaxSummary = dailyAuditReportData.dailyAuditReportTaxSummary,

                };

                var dailyAuditReportHTML = await _htmlGenerator.getDailyAuditReportHTML(dailyAuditReportHTMLModel);

                byte[] PDF = ConvertHTMLToPDF(dailyAuditReportHTML);

                _logger.LogInformation($"Repository: DownloadDailyAuditReport method execution completed.");

                return Result.Success(PDF);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelTaxReport method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel tax report.");
            }
        }

        public async Task<Result<byte[]>> DownloadRoomTaxCollectedReport(int hotelId, DateOnly fromDate, DateOnly toDate)
        {
            try
            {
                _logger.LogInformation("Repository: DownloadRoomTaxCollectedReport method initiated.");

                var dailyAuditReportHTMLModel = await GetDailyAuditReportSummary(hotelId, fromDate, toDate);

                List<RoomTaxHTMLModel> roomTaxHTMLModels = new();

                // Group bookings by ScheduledCheckInDate (not CreatedDate)
                foreach (var group in dailyAuditReportHTMLModel.dailyAuditReportBookingSummaries
                    .GroupBy(booking => booking.BookingDate)
                    .OrderBy(group => group.Key))
                {
                    roomTaxHTMLModels.Add(new RoomTaxHTMLModel
                    {
                        Date = group.Key,
                        Rooms = group.Sum(item => item.Rented),
                        RoomChargeAmount = group.Sum(item => item.RoomChargeAmount.GetValueOrDefault()),
                        Total = group.Sum(booking => booking.Total.GetValueOrDefault()),
                        hotelRoomBookingTaxRateHTMLModels = group.SelectMany(booking => booking.hotelRoomBookingTaxRateHTMLModels)
                                                                  .GroupBy(taxRate => taxRate.BookingTaxRateName)
                                                                  .Select(group => new HotelRoomBookingTaxRateHTMLModel
                                                                  {
                                                                      BookingTaxRateName = group.Key,
                                                                      BookingTaxRatePercentage = group.First().BookingTaxRatePercentage,
                                                                      BookingTaxRate = group.Sum(taxRate => taxRate.BookingTaxRate)
                                                                  }).ToList()
                    });
                }

                // Room tax totals for the entire date range
                var roomTaxTotalHTMLModel = new RoomTaxHTMLModel
                {
                    Rooms = roomTaxHTMLModels.Sum(model => model.Rooms),
                    RoomChargeAmount = roomTaxHTMLModels.Sum(model => model.RoomChargeAmount),
                    Total = roomTaxHTMLModels.Sum(model => model.Total),
                    hotelRoomBookingTaxRateHTMLModels = roomTaxHTMLModels
                        .SelectMany(model => model.hotelRoomBookingTaxRateHTMLModels)
                        .GroupBy(taxRate => taxRate.BookingTaxRateName)
                        .Select(group => new HotelRoomBookingTaxRateHTMLModel
                        {
                            BookingTaxRateName = group.Key,
                            BookingTaxRatePercentage = group.First().BookingTaxRatePercentage,
                            BookingTaxRate = group.Sum(taxRate => taxRate.BookingTaxRate)
                        }).ToList()
                };

                // Now assign the roomTaxHTMLModels to the RoomTaxCollectedHTMLModel
                var roomTaxCollectedHTMLModel = new RoomTaxCollectedHTMLModel
                {
                    FromDate = fromDate,
                    ToDate = toDate,
                    hotelHTMLModel = dailyAuditReportHTMLModel.hotelHTMLModel,
                    roomTaxHTMLModels = roomTaxHTMLModels,
                    roomTaxTotalHTMLModel = roomTaxTotalHTMLModel
                };

                // Generate the HTML report
                var roomTaxCollectedReportHTML = await _htmlGenerator.getRoomTaxCollectedReportHTML(roomTaxCollectedHTMLModel);

                // Convert the HTML report to PDF
                byte[] PDF = ConvertHTMLToPDF(roomTaxCollectedReportHTML);

                _logger.LogInformation("Repository: DownloadRoomTaxCollectedReport method execution completed.");

                return Result.Success(PDF);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: DownloadRoomTaxCollectedReport method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the room tax collected report.");
            }
        }

        public async Task<Result<byte[]>> DownloadSummaryIncomeReport(int hotelId, DateOnly fromDate, DateOnly toDate)
        {
            try
            {
                _logger.LogInformation("Repository: DownloadSummaryIncomeReport method initiated.");

                var dailyAuditReportHTMLModel = await GetDailyAuditReportSummary(hotelId, fromDate, toDate);

                // Initialize daily totals
                var dailyTotals = new List<SummaryIncomeHTMLModel>();

                // Group bookings by ScheduledCheckInDate and calculate daily totals
                foreach (var group in dailyAuditReportHTMLModel.dailyAuditReportBookingSummaries
                   .GroupBy(booking => booking.BookingDate)
                   .OrderBy(group => group.Key))
                {
                    var dailyTotal = new SummaryIncomeHTMLModel
                    {
                        Date = group.Key,
                        Rooms = group.Sum(item => item.Rented),
                        NonTaxableRevenue = group.Sum(item => item.NonTaxableRevenue.GetValueOrDefault()),
                        PartialTaxableRevenue = group.Sum(item => item.PartialTaxableRevenue.GetValueOrDefault()),
                        TaxableRevenue = group.Sum(item => item.TaxableRevenue.GetValueOrDefault()),
                        Gross = group.Sum(item => item.RoomChargeAmount.GetValueOrDefault()),
                        Tax = group.Sum(item => item.Tax.GetValueOrDefault()),
                        MiscellaneousAmount = group.Sum(item => item.MiscellaneousAmount.GetValueOrDefault()),
                        Total = group.Sum(item => item.Total.GetValueOrDefault()),
                        Cash = group.Sum(item => item.Cash.GetValueOrDefault()),
                        Credit = group.Sum(item => item.Credit.GetValueOrDefault()),
                        Reward = group.Sum(item => item.Reward.GetValueOrDefault()),
                        Payment = group.Sum(item => item.Payment.GetValueOrDefault()),
                    };

                    dailyTotals.Add(dailyTotal);
                }

                // Calculate overall totals
                var summaryIncomeHTMLModel = new SummaryIncomeHTMLModel
                {
                    Rooms = dailyTotals.Sum(model => model.Rooms),
                    NonTaxableRevenue = dailyTotals.Sum(model => model.NonTaxableRevenue),
                    PartialTaxableRevenue = dailyTotals.Sum(model => model.PartialTaxableRevenue),
                    TaxableRevenue = dailyTotals.Sum(model => model.TaxableRevenue),
                    Gross = dailyTotals.Sum(model => model.Gross),
                    Tax = dailyTotals.Sum(model => model.Tax),
                    MiscellaneousAmount = dailyTotals.Sum(model => model.MiscellaneousAmount),
                    Total = dailyTotals.Sum(model => model.Total),
                    Cash = dailyTotals.Sum(model => model.Cash),
                    Credit = dailyTotals.Sum(model => model.Credit),
                    Reward = dailyTotals.Sum(model => model.Reward),
                    Payment = dailyTotals.Sum(model => model.Payment),
                };

                var summaryIncomeTaxBreakdownSummary = new SummaryIncomeTaxBreakdownSummary
                {
                    NonTaxableRevenue = summaryIncomeHTMLModel.NonTaxableRevenue,
                    PartialTaxableRevenue = summaryIncomeHTMLModel.PartialTaxableRevenue,
                    TaxableRevenue = summaryIncomeHTMLModel.TaxableRevenue,
                    Rented = dailyAuditReportHTMLModel.dailyAuditReportTaxSummary.Rented,
                    ADR = dailyAuditReportHTMLModel.dailyAuditReportTaxSummary.ADR,
                    OCC = dailyAuditReportHTMLModel.dailyAuditReportTaxSummary.OCC,
                    hotelRoomBookingTaxRateHTMLModels = dailyAuditReportHTMLModel.dailyAuditReportTaxSummary.hotelRoomBookingTaxRateHTMLModels
                };

                var summaryIncomeReportHTMLModel = new SummaryIncomeReportHTMLModel
                {
                    FromDate = fromDate,
                    ToDate = toDate,
                    hotelHTMLModel = dailyAuditReportHTMLModel.hotelHTMLModel,
                    summaryIncomeHTMLModels = dailyTotals,
                    summaryIncomeHTMLModel = summaryIncomeHTMLModel,
                    summaryIncomeTaxBreakdownSummary = summaryIncomeTaxBreakdownSummary
                };

                // Generate the HTML report
                var summaryIncomeReportHTML = await _htmlGenerator.getSummaryIncomeReportHTML(summaryIncomeReportHTMLModel);

                // Convert the HTML report to PDF
                byte[] PDF = ConvertHTMLToPDF(summaryIncomeReportHTML);

                _logger.LogInformation("Repository: DownloadSummaryIncomeReport method execution completed.");

                return Result.Success(PDF);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: DownloadSummaryIncomeReport method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel report.");
            }
        }

        public async Task<Result<byte[]>> DownloadRoomRevenueReport(int hotelId, DateOnly fromDate, DateOnly toDate)
        {
            try
            {
                _logger.LogInformation("Repository: DownloadRoomRevenueReport method initiated.");

                var dailyAuditReportHTMLModel = await GetDailyAuditReportSummary(hotelId, fromDate, toDate);

                var roomRevenueHTMLModels = dailyAuditReportHTMLModel.dailyAuditReportBookingSummaries
                    .GroupBy(booking => booking.BookingDate)
                    .OrderBy(group => group.Key)
                    .Select(group => new RoomRevenueHTMLModel
                    {
                        Date = group.Key,
                        GrossRevenue = group.Sum(item => item.RoomChargeAmount.GetValueOrDefault()),
                        NonTaxableRevenue = group.Sum(item => item.NonTaxableRevenue.GetValueOrDefault()),
                        PartialTaxableRevenue = group.Sum(item => item.PartialTaxableRevenue.GetValueOrDefault()),
                        TaxableRevenue = group.Sum(item => item.TaxableRevenue.GetValueOrDefault()),
                        Tax = group.Sum(item => item.Tax.GetValueOrDefault()),
                        MiscellaneousAmount = group.Sum(item => item.MiscellaneousAmount.GetValueOrDefault()),
                        Total = group.Sum(item => item.Total.GetValueOrDefault()),
                        OCC_Rooms = group.Sum(item => item.Rented),
                        OCC_Rate = CalculateOccupancyPercentage(group.Sum(item => item.Rented), dailyAuditReportHTMLModel.dailyAuditReportTaxSummary.TotalRoom),
                        ADR = CalculateADR(group.Sum(item => item.RoomChargeAmount.GetValueOrDefault()), group.Sum(item => item.Rented)),
                        Rev_Par = Math.Round(CalculateRavPar((decimal)group.Sum(item => item.RoomChargeAmount.GetValueOrDefault()), dailyAuditReportHTMLModel.dailyAuditReportTaxSummary.TotalRoom ?? 0), 2)
                    }).ToList();

                var roomRevenueHTMLModel = new RoomRevenueHTMLModel
                {
                    GrossRevenue = roomRevenueHTMLModels.Sum(item => item.GrossRevenue),
                    NonTaxableRevenue = roomRevenueHTMLModels.Sum(item => item.NonTaxableRevenue),
                    PartialTaxableRevenue = roomRevenueHTMLModels.Sum(item => item.PartialTaxableRevenue),
                    TaxableRevenue = roomRevenueHTMLModels.Sum(item => item.TaxableRevenue),
                    Tax = roomRevenueHTMLModels.Sum(item => item.Tax),
                    MiscellaneousAmount = roomRevenueHTMLModels.Sum(item => item.MiscellaneousAmount),
                    Total = roomRevenueHTMLModels.Sum(item => item.Total),
                    OCC_Rooms = roomRevenueHTMLModels.Sum(item => item.OCC_Rooms),
                    OCC_Rate = Math.Round(roomRevenueHTMLModels.Average(item => item.OCC_Rate).GetValueOrDefault(), 2),
                    ADR = CalculateADR(roomRevenueHTMLModels.Sum(item => item.GrossRevenue), roomRevenueHTMLModels.Sum(item => item.OCC_Rooms) ?? 0),
                    Rev_Par = Math.Round(roomRevenueHTMLModels.Average(item => item.Rev_Par).GetValueOrDefault(), 2)
                };

                var roomRevenueReportHTMLModel = new RoomRevenueReportHTMLModel
                {
                    FromDate = fromDate,
                    ToDate = toDate,
                    hotelHTMLModel = dailyAuditReportHTMLModel.hotelHTMLModel,
                    roomRevenueHTMLModels = roomRevenueHTMLModels,
                    roomRevenueHTMLModel = roomRevenueHTMLModel,
                };

                var roomRevenueReportHTML = await _htmlGenerator.getRoomRevenueReportHTML(roomRevenueReportHTMLModel);

                byte[] PDF = ConvertHTMLToPDF(roomRevenueReportHTML);

                _logger.LogInformation("Repository: DownloadRoomRevenueReport method execution completed.");

                return Result.Success(PDF);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: DownloadRoomRevenueReport method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel report.");
            }
        }

        public async Task<Result<byte[]>> DownloadIncomeBreakdownReport(int hotelId, DateOnly fromDate, DateOnly toDate)
        {
            try
            {
                _logger.LogInformation("Repository: DownloadIncomeBreakdownReport method initiated.");

                var dailyAuditReportHTMLModel = await GetDailyAuditReportSummary(hotelId, fromDate, toDate);

                // Day-wise breakdown
                var incomeBreakdownHTMLModels = dailyAuditReportHTMLModel.dailyAuditReportBookingSummaries
                    .GroupBy(booking => booking.BookingDate)
                    .OrderBy(group => group.Key)
                    .Select(group =>
                    {

                        return new IncomeBreakdownHTMLModel
                        {
                            Date = group.Key,
                            Cash = group.Sum(item => item.Cash.GetValueOrDefault()),
                            MiscellaneousAmount = group.Sum(item => item.MiscellaneousAmount.GetValueOrDefault()),
                            NetCash = group.Sum(item => item.Cash.GetValueOrDefault()) + group.Sum(item => item.MiscellaneousAmount.GetValueOrDefault()),
                            Credit = group.Sum(item => item.Credit.GetValueOrDefault()),
                            Reward = group.Sum(item => item.Reward.GetValueOrDefault()),
                            Total = group.Sum(item => item.Payment.GetValueOrDefault()) + group.Sum(item => item.MiscellaneousAmount.GetValueOrDefault()),
                            hotelRoomBookingTaxRateHTMLModels = group.SelectMany(booking => booking.hotelRoomBookingTaxRateHTMLModels).ToList()
                        };
                    }).ToList();

                // Total Summary
                var incomeBreakdownHTMLModel = new IncomeBreakdownHTMLModel
                {
                    Cash = incomeBreakdownHTMLModels.Sum(i => i.Cash),
                    MiscellaneousAmount = incomeBreakdownHTMLModels.Sum(i => i.MiscellaneousAmount),
                    NetCash = incomeBreakdownHTMLModels.Sum(i => i.NetCash),
                    Credit = incomeBreakdownHTMLModels.Sum(i => i.Credit),
                    Reward = incomeBreakdownHTMLModels.Sum(i => i.Reward),
                    Total = incomeBreakdownHTMLModels.Sum(i => i.Total),
                    hotelRoomBookingTaxRateHTMLModels = incomeBreakdownHTMLModels
                        .SelectMany(i => i.hotelRoomBookingTaxRateHTMLModels)
                        .GroupBy(t => t.BookingTaxRateName)
                        .Select(group => new HotelRoomBookingTaxRateHTMLModel
                        {
                            BookingTaxRateName = group.Key,
                            BookingTaxRatePercentage = group.First().BookingTaxRatePercentage,
                            BookingTaxRate = group.Sum(t => t.BookingTaxRate)
                        }).ToList()
                };

                var incomeBreakdownReportHTMLModel = new IncomeBreakdownReportHTMLModel
                {
                    FromDate = fromDate,
                    ToDate = toDate,
                    hotelHTMLModel = dailyAuditReportHTMLModel.hotelHTMLModel,
                    incomeBreakdownHTMLModels = incomeBreakdownHTMLModels,
                    incomeBreakdownHTMLModel = incomeBreakdownHTMLModel
                };

                var incomeBreakdownReportHTML = await _htmlGenerator.getIncomeBreakdownReportHTML(incomeBreakdownReportHTMLModel);
                byte[] PDF = ConvertHTMLToPDF(incomeBreakdownReportHTML);

                _logger.LogInformation("Repository: DownloadIncomeBreakdownReport method execution completed.");
                return Result.Success(PDF);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: DownloadIncomeBreakdownReport method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel report.");
            }
        }

        public async Task<Result<byte[]>> DownloadShiftReport(int hotelId, HotelShiftModel hotelShiftData, DateOnly fromDate, DateOnly toDate)
        {
            try
            {
                _logger.LogInformation("Repository: DownloadShiftReport method initiated.");

                var shiftAuditData = await GetDailyShiftAuditReportAsync(hotelId, hotelShiftData, fromDate, toDate);
                var shiftHTMLModels = shiftAuditData.shiftHTMLModels
                    .OrderBy(item => item.ShiftStartDate)
                    .Select(booking => new ShiftHTMLModel
                    {
                        BookingCode = booking.BookingCode,
                        RoomNumber = booking.RoomNumber,
                        GuestName = booking.GuestName,
                        ScheduledCheckInDate = booking.ScheduledCheckInDate,
                        Duration = booking.Duration,
                        PaymentType = booking.PaymentType,
                        Cash = booking.Cash,
                        Credit = booking.Credit,
                        Reward = booking.Reward,
                        RefundAmount = booking.RefundAmount,
                    }).ToList();

                var shiftHTMLModel = new ShiftHTMLModel
                {
                    ShiftNo = hotelShiftData.ShiftNo,
                    ShiftStartDate = hotelShiftData.StartDate,
                    ShiftEndDate = hotelShiftData.EndDate,
                    ShiftOwnerName = hotelShiftData.ShiftOwnerName,
                    Cash = shiftHTMLModels.Sum(item => item.Cash),
                    Credit = shiftHTMLModels.Sum(item => item.Credit),
                    Reward = shiftHTMLModels.Sum(item => item.Reward),
                    RefundAmount = shiftHTMLModels.Sum(item => item.RefundAmount)
                };

                var shiftReportHTMLModel = new ShiftReportHTMLModel
                {
                    FromDate = shiftAuditData.FromDate,
                    ToDate = shiftAuditData.ToDate,
                    hotelHTMLModel = shiftAuditData.hotelHTMLModel,
                    shiftHTMLModels = shiftHTMLModels,
                    shiftHTMLModel = shiftHTMLModel,
                };

                // Generate the HTML report
                var shiftReportHTML = await _htmlGenerator.getShiftReportHTML(shiftReportHTMLModel);

                // Convert the HTML report to PDF
                byte[] PDF = ConvertHTMLToPDF(shiftReportHTML);

                _logger.LogInformation("Repository: DownloadShiftReport method execution completed.");

                return Result.Success(PDF);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: DownloadShiftReport method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel report.");
            }
        }

        public async Task<GetHotelOwnerDashboardModel> GetHotelDashboardDetails(int hotelID, DateOnly fromDate, DateOnly toDate, string metrixType)
        {

            _logger.LogInformation("Repository: GetHotelDashboardDetails method initiated.");

            var dailyAuditReportHTMLModel = await GetDailyAuditReportSummary(hotelID, fromDate, toDate);

            var roomRevenueHTMLModels = dailyAuditReportHTMLModel.dailyAuditReportBookingSummaries
                    .GroupBy(booking => booking.BookingDate)
                    .OrderBy(group => group.Key)
                    .Select(group => new RoomRevenueHTMLModel
                    {
                        Date = group.Key,
                        GrossRevenue = group.Sum(item => item.RoomChargeAmount.GetValueOrDefault()),
                        NonTaxableRevenue = group.Sum(item => item.NonTaxableRevenue.GetValueOrDefault()),
                        PartialTaxableRevenue = group.Sum(item => item.PartialTaxableRevenue.GetValueOrDefault()),
                        TaxableRevenue = group.Sum(item => item.TaxableRevenue.GetValueOrDefault()),
                        Tax = group.Sum(item => item.Tax.GetValueOrDefault()),
                        MiscellaneousAmount = group.Sum(item => item.MiscellaneousAmount.GetValueOrDefault()),
                        Total = group.Sum(item => item.Total.GetValueOrDefault()),
                        OCC_Rooms = group.Sum(item => item.Rented),
                        OCC_Rate = CalculateOccupancyPercentage(group.Sum(item => item.Rented), dailyAuditReportHTMLModel.dailyAuditReportTaxSummary.TotalRoom),
                        ADR = CalculateADR(group.Sum(item => item.RoomChargeAmount.GetValueOrDefault()), group.Sum(item => item.Rented)),
                        Rev_Par = Math.Round(CalculateRavPar((decimal)group.Sum(item => item.RoomChargeAmount.GetValueOrDefault()), dailyAuditReportHTMLModel.dailyAuditReportTaxSummary.TotalRoom ?? 0), 2)
                    }).ToList();

            var roomRevenueHTMLModel = new RoomRevenueHTMLModel
            {
                GrossRevenue = roomRevenueHTMLModels.Sum(item => item.GrossRevenue),
                NonTaxableRevenue = roomRevenueHTMLModels.Sum(item => item.NonTaxableRevenue),
                PartialTaxableRevenue = roomRevenueHTMLModels.Sum(item => item.PartialTaxableRevenue),
                TaxableRevenue = roomRevenueHTMLModels.Sum(item => item.TaxableRevenue),
                Tax = roomRevenueHTMLModels.Sum(item => item.Tax),
                MiscellaneousAmount = roomRevenueHTMLModels.Sum(item => item.MiscellaneousAmount),
                Total = roomRevenueHTMLModels.Sum(item => item.Total),
                OCC_Rooms = roomRevenueHTMLModels.Sum(item => item.OCC_Rooms),
                OCC_Rate = Math.Round(roomRevenueHTMLModels.Average(item => item.OCC_Rate).GetValueOrDefault(), 2),
                ADR = CalculateADR(roomRevenueHTMLModels.Sum(item => item.GrossRevenue), roomRevenueHTMLModels.Sum(item => item.OCC_Rooms) ?? 0),
                Rev_Par = Math.Round(roomRevenueHTMLModels.Average(item => item.Rev_Par).GetValueOrDefault(), 2)
            };

            _logger.LogInformation("Repository: GetHotelDashboardDetails method execution completed.");

            return new GetHotelOwnerDashboardModel
            {
                Metrictype = metrixType,
                Date = fromDate,
                RoomSold = roomRevenueHTMLModel.OCC_Rooms ?? 0,
                Occupancy = roomRevenueHTMLModel.OCC_Rate ?? 0,
                GrossRevenue = roomRevenueHTMLModel.GrossRevenue ?? 0,
                ADR = roomRevenueHTMLModel.ADR ?? 0,
                RevPAR = roomRevenueHTMLModel.Rev_Par ?? 0,
                TotalRevenue = roomRevenueHTMLModel.Total ?? 0,
                Cash = dailyAuditReportHTMLModel.dailyAuditReportSummary.TotalCash ?? 0,
                Credit = dailyAuditReportHTMLModel.dailyAuditReportSummary.TotalCreditCards ?? 0,
                TotalPayments = dailyAuditReportHTMLModel.dailyAuditReportSummary.Total ?? 0
            };
        }

        private static HotelHTMLModel BindHotelModel(tblHotel hotelData)
        {
            var hotelHTMLModel = new HotelHTMLModel
            {

                BusinessLLCName = hotelData.BusinessLLCName,
                HotelCode = hotelData.BusinessLLCName,
                Email = hotelData.Email,
                MobileNumber = hotelData.MobileNumber,
                Address1 = hotelData.Address1,
                Address2 = hotelData.Address2,
                Country = hotelData.State.Country.CountryName,
                State = hotelData.State.StateName,
                City = hotelData.City,
                ZipCode = hotelData.ZipCode,

            };

            return hotelHTMLModel;
        }

        private byte[] ConvertHTMLToPDF(string html)
        {
            using var memoryStream = new MemoryStream();
            var pdf = new PdfDocument(new PdfWriter(memoryStream));
            pdf.SetDefaultPageSize(PageSize.A4);
            pdf.SetTagged();

            string htmlWithMargins = @"
                                        <style>
                                            @page {
                                                size: A4;
                                                margin: 10pt 10pt 10pt 10pt; /* top right bottom left */
                                            }
                                        </style>" + html;

            HtmlConverter.ConvertToPdf(htmlWithMargins, pdf, new ConverterProperties());
            return memoryStream.ToArray();
        }

        private string ConvertToPdf(string html)
        {
            using var memoryStream = new MemoryStream();
            var pdf = new PdfDocument(new PdfWriter(memoryStream));
            pdf.SetDefaultPageSize(PageSize.A4);
            pdf.SetTagged();
            HtmlConverter.ConvertToPdf(html, pdf, new ConverterProperties());
            var pdfInBase64 = Convert.ToBase64String(memoryStream.ToArray());
            return pdfInBase64;
        }

        private async Task<tblHotel> GetDetailedHotelBookingData(int hotelID, DateTime fromDate, DateTime toDate)
        {

            return await _checkinProContext.tblHotels
                .AsNoTracking()
                .AsSplitQuery()
                .Include(s => s.State)
                    .ThenInclude(c => c.Country)
                .Include(hotelTaxRate => hotelTaxRate.tblHotelTaxRates.Where(item => item.IsTaxRateActive))
                .Include(roomType => roomType.tblHotelRoomTypes)
                    .ThenInclude(booking => booking.tblHotelRoomBookings.Where(item =>
                                item.IsIncludedInReport == true &&
                                item.HotelRoomID != null &&
                                item.BookingStatus != BookingStatusMessages.Cancelled &&
                                ((item.ScheduledCheckInDate >= fromDate && item.ScheduledCheckInDate <= toDate) ||
                                    (item.ScheduledCheckOutDate >= fromDate && item.ScheduledCheckOutDate <= toDate) ||
                                    (item.ScheduledCheckInDate <= fromDate && item.ScheduledCheckOutDate >= toDate)
                                )))
                        .ThenInclude(rateDetail => rateDetail.tblHotelRoomBookingRateDetails.Where(item => item.IsBookingActive))
                            .ThenInclude(bookingTaxRate => bookingTaxRate.tblHotelRoomBookingTaxRates.Where(item => item.IsBookingTaxRateActive))
                .Include(roomType => roomType.tblHotelRoomTypes)
                    .ThenInclude(booking => booking.tblHotelRoomBookings)
                        .ThenInclude(room => room.HotelRoom)
                .Include(roomType => roomType.tblHotelRoomTypes)
                    .ThenInclude(booking => booking.tblHotelRoomBookings)
                        .ThenInclude(misc => misc.tblHotelRoomBookingMiscDetails)
                .Include(roomType => roomType.tblHotelRoomTypes)
                    .ThenInclude(booking => booking.tblHotelRoomBookings)
                        .ThenInclude(p => p.tblPayments)
                .Include(roomType => roomType.tblHotelRoomTypes)
                    .ThenInclude(booking => booking.tblHotelRoomBookings)
                        .ThenInclude(bookingGuest => bookingGuest.tblHotelRoomBookingGuests.Where(item => item.IsPrimaryGuest))
                            .ThenInclude(g => g.Guest)
                .Where(item => item.HotelID == hotelID).FirstOrDefaultAsync();
        }
        private async Task<DailyAuditReportHTMLModel> GetDailyAuditReportSummary(int hotelId, DateOnly fromDate, DateOnly toDate)
        {
            var (startDateTime, endDateTime) = CommonConstants.GetAdjustedHotelDateRange(fromDate, toDate);

            var hotelBookingData = await GetDetailedHotelBookingData(hotelId, startDateTime, endDateTime);

            List<DailyAuditReportBookingSummary> dailyAuditReportBookingSummaries = new();

            foreach (var roomType in hotelBookingData.tblHotelRoomTypes)
            {
                foreach (var booking in roomType.tblHotelRoomBookings)
                {
                    // 🔹 Cache collections for performance
                    var rateDetails = booking.tblHotelRoomBookingRateDetails.ToList();
                    var payments = booking.tblPayments.ToList();
                    var miscDetails = booking.tblHotelRoomBookingMiscDetails.ToList();
                    var primaryGuest = booking.tblHotelRoomBookingGuests.FirstOrDefault()?.Guest;
                    var guestName = primaryGuest == null ? null : primaryGuest.FirstName + " " + primaryGuest.LastName;

                    var completedPayments = payments.Where(p => p.PaymentStatus == CommonConstants.PaymentStatusMessages.Completed).ToList();
                    var refundedPayments = payments.Where(p => p.IsRefunded).ToList();

                    var originalBooking = rateDetails.FirstOrDefault(r => !r.IsExtend);

                    if (booking.IsHourlyBooking)
                    {
                        if (booking.ScheduledCheckInDate >= startDateTime && booking.ScheduledCheckInDate <= endDateTime)
                        {
                            decimal perDayRoomRate = rateDetails.Sum(r => r.RoomChargeAmount ?? 0);
                            decimal perDayTax = rateDetails.SelectMany(r => r.tblHotelRoomBookingTaxRates).Sum(t => t.BookingTaxRate ?? 0);
                            decimal perDayTotal = rateDetails.Sum(r => r.TotalAmount ?? 0);
                            decimal dailyMisc = miscDetails.Sum(m => m.MiscellaneousAmount ?? 0);

                            DateTime? earliestCheckIn = rateDetails.Min(r => r.CheckInDate);
                            DateTime? latestCheckOut = rateDetails.Max(r => r.CheckOutDate);

                            var paymentData = completedPayments.Where(p => p.PaymentCompletedOn >= startDateTime && p.PaymentCompletedOn <= endDateTime).ToList();

                            decimal totalCashPaid = paymentData.Where(p => p.PaymentMode == PaymentModeOption.Cash).Sum(p => p.Amount ?? 0);
                            decimal totalCreditPaid = paymentData.Where(p => p.PaymentMode != PaymentModeOption.Cash && p.PaymentMode != PaymentModeOption.RewardPoint).Sum(p => p.Amount ?? 0);
                            decimal totalReward = paymentData.Where(p => p.PaymentMode == PaymentModeOption.RewardPoint).Sum(p => p.Amount ?? 0);
                            decimal totalPaid = totalCashPaid + totalCreditPaid;

                            decimal perDayTaxableRevenue = 0, perDayNonTaxableRevenue = 0, perDayPartialTaxableRevenue = 0;
                            if (originalBooking?.TaxStatus == TaxStatus.NonTaxable) perDayNonTaxableRevenue = perDayRoomRate;
                            else if (originalBooking?.TaxStatus == TaxStatus.Taxable) perDayTaxableRevenue = perDayRoomRate;
                            else if (originalBooking?.TaxStatus == TaxStatus.PartialTaxable) perDayPartialTaxableRevenue = perDayRoomRate;

                            // Main booking entry
                            dailyAuditReportBookingSummaries.Add(new DailyAuditReportBookingSummary
                            {
                                BookingDate = DateOnly.FromDateTime((earliestCheckIn ?? booking.ScheduledCheckInDate ?? DateTime.Now).Hour < 6
                            ? (earliestCheckIn ?? booking.ScheduledCheckInDate ?? DateTime.Now).AddDays(-1)
                            : (earliestCheckIn ?? booking.ScheduledCheckInDate ?? DateTime.Now)),

                                Rented = 1,
                                HourlyRented = 1,
                                BookingCode = booking.BookingCode,
                                RoomNumber = booking.HotelRoom?.RoomNumber,
                                GuestName = booking.tblHotelRoomBookingGuests.FirstOrDefault()?.Guest?.FirstName + " " + booking.tblHotelRoomBookingGuests.FirstOrDefault()?.Guest?.LastName,
                                ScheduledCheckInDate = earliestCheckIn,
                                ScheduledCheckOutDate = latestCheckOut,
                                Duration = $"{booking.Duration} Hour(s)",
                                RoomChargeAmount = Math.Round(perDayRoomRate, 2),
                                Tax = Math.Round(perDayTax, 2),
                                //MiscellaneousAmount = Math.Round(rateDetails.FirstOrDefault(item => item.IsExtend == false)?.MiscellaneousAmount ?? 0, 2),
                                MiscellaneousAmount = dailyMisc,
                                Total = Math.Round(perDayTotal + dailyMisc, 2),
                                Cash = Math.Round(totalCashPaid, 2),
                                Credit = Math.Round(totalCreditPaid, 2),
                                Reward = Math.Round(totalReward, 2),
                                Payment = Math.Round(totalPaid, 2),
                                //Balance = totalRefunded > 0 ? 0 : Math.Round(perDayTotal - totalPaid, 2),
                                Balance = originalBooking.Balance,
                                TaxableRevenue = Math.Round(perDayTaxableRevenue, 2),
                                NonTaxableRevenue = Math.Round(perDayNonTaxableRevenue, 2),
                                PartialTaxableRevenue = Math.Round(perDayPartialTaxableRevenue, 2),
                                TaxStatus = rateDetails.Where(item => !item.IsExtend).First().TaxStatus,
                                hotelRoomBookingTaxRateHTMLModels = rateDetails
                                .SelectMany(r => r.tblHotelRoomBookingTaxRates)
                                .GroupBy(t => t.BookingTaxRateName)
                                .Select(group => new HotelRoomBookingTaxRateHTMLModel
                                {
                                    BookingTaxRateName = group.Key,
                                    BookingTaxRatePercentage = group.First().BookingTaxRatePercentage,
                                    BookingTaxRate = Math.Round(group.Sum(t => t.BookingTaxRate ?? 0), 2),
                                }).ToList()
                            });

                            // Refund for Hourly Booking
                            var refundData = refundedPayments.Where(r => r.RefundDate >= startDateTime && r.RefundDate <= endDateTime).ToList();
                            if (refundData.Count > 0)
                            {
                                decimal totalCashRefunded = refundData.Where(p => p.PaymentMode == PaymentModeOption.Cash).Sum(p => p.RefundAmount ?? 0);
                                decimal totalCreditRefunded = refundData.Where(p => p.PaymentMode != PaymentModeOption.Cash && p.PaymentMode != PaymentModeOption.RewardPoint).Sum(p => p.RefundAmount ?? 0);
                                decimal totalRefunded = totalCashRefunded + totalCreditRefunded;

                                decimal totalRefundAmount = 0;
                                decimal totalRefundRoomRate = 0;
                                decimal totalRefundTax = 0;
                                decimal totalMISCRefund = 0;

                                decimal nonTaxableRevenue = 0;
                                decimal taxableRevenue = 0;
                                decimal partialTaxableRevenue = 0;

                                // Refund Amount Reverse Calculation
                                var bookingRefundData = refundData.Where(item => item.PaymentMode != CommonConstants.PaymentModeOption.RewardPoint && item.PaymentType != CommonConstants.PaymentTypeOption.MiscellaneousAmount).ToList();
                                if (bookingRefundData != null)
                                {
                                    totalRefundAmount = bookingRefundData.Sum(item => item.RefundAmount) ?? 0;
                                    totalRefundRoomRate = totalRefundAmount / (((rateDetails.Where(item => !item.IsExtend).SelectMany(item => item.tblHotelRoomBookingTaxRates).Sum(item => item.BookingTaxRatePercentage)) + 100) / 100) ?? 0;
                                    totalRefundTax = totalRefundAmount - totalRefundRoomRate;
                                }

                                var bookingMISCRefundData = refundData.Where(item => item.PaymentType == CommonConstants.PaymentTypeOption.MiscellaneousAmount).ToList();
                                totalMISCRefund = bookingMISCRefundData.Sum(item => item.RefundAmount) ?? 0;
                                decimal balance = perDayTotal - totalPaid - totalRefunded;

                                if (originalBooking?.TaxStatus == TaxStatus.NonTaxable)
                                {
                                    nonTaxableRevenue = totalRefundRoomRate;
                                }
                                else if (originalBooking?.TaxStatus == TaxStatus.Taxable)
                                {
                                    taxableRevenue = totalRefundRoomRate;
                                }
                                else if (originalBooking?.TaxStatus == TaxStatus.PartialTaxable)
                                {
                                    partialTaxableRevenue = totalRefundRoomRate;
                                }

                                dailyAuditReportBookingSummaries.Add(new DailyAuditReportBookingSummary
                                {
                                    BookingDate = DateOnly.FromDateTime((earliestCheckIn ?? booking.ScheduledCheckInDate ?? DateTime.Now).Hour < 6
                                    ? (earliestCheckIn ?? booking.ScheduledCheckInDate ?? DateTime.Now).AddDays(-1)
                                    : (earliestCheckIn ?? booking.ScheduledCheckInDate ?? DateTime.Now)),
                                    Rented = 0,
                                    BookingCode = booking.BookingCode,
                                    RoomNumber = booking.HotelRoom?.RoomNumber + " (Refund)",
                                    GuestName = booking.tblHotelRoomBookingGuests.FirstOrDefault()?.Guest?.FirstName + " " + booking.tblHotelRoomBookingGuests.FirstOrDefault()?.Guest?.LastName,
                                    IdentityNumber = booking.tblHotelRoomBookingGuests.FirstOrDefault()?.Guest?.IdentityNumber,
                                    ScheduledCheckInDate = booking.ActualCheckInDate,
                                    ScheduledCheckOutDate = booking.ScheduledCheckOutDate,
                                    Duration = $"{booking.Duration} Hour(s)",
                                    RoomChargeAmount = -Math.Round(totalRefundRoomRate, 2),
                                    Tax = -Math.Round(totalRefundTax, 2),
                                    MiscellaneousAmount = -Math.Round(totalMISCRefund, 2),
                                    Total = -Math.Round(totalRefundAmount, 2),
                                    Cash = -Math.Round(totalCashRefunded, 2),
                                    Credit = -Math.Round(totalCreditRefunded, 2),
                                    Payment = -Math.Round(totalRefunded, 2),
                                    Balance = -Math.Round(totalRefunded, 2),
                                    TaxableRevenue = -Math.Round(taxableRevenue, 2),
                                    NonTaxableRevenue = -Math.Round(nonTaxableRevenue, 2),
                                    PartialTaxableRevenue = -Math.Round(partialTaxableRevenue, 2),
                                    IsRefunded = true,
                                    hotelRoomBookingTaxRateHTMLModels = originalBooking?.tblHotelRoomBookingTaxRates
                                    .GroupBy(t => t.BookingTaxRateName)
                                    .Select(group => new HotelRoomBookingTaxRateHTMLModel
                                    {
                                        BookingTaxRateName = group.Key,
                                        BookingTaxRatePercentage = group.First().BookingTaxRatePercentage,
                                        BookingTaxRate = -Math.Round(totalRefundRoomRate * group.First().BookingTaxRatePercentage / 100 ?? 0, 2)
                                    }).ToList()
                                });
                            }
                        }
                    }
                    else
                    {
                        // Daily bookings logic (optimized)
                        foreach (var rateDetail in rateDetails)
                        {
                            int days = rateDetail.Duration ?? 0;
                            if (days <= 0) continue;

                            decimal perDayRoomRate = (rateDetail.RoomChargeAmount ?? 0) / days;
                            decimal perDayTax = (rateDetail.tblHotelRoomBookingTaxRates.Sum(t => t.BookingTaxRate) ?? 0) / days;
                            decimal perDayTotal = (rateDetail.TotalAmount ?? 0) / days;

                            DateTime current = rateDetail.CheckInDate.Value;
                            decimal cumulativeTotal = 0;
                            decimal dailyTotalPayment = 0;

                            for (int i = 0; i < days; i++)
                            {
                                var date = current.AddDays(i);
                                cumulativeTotal += perDayTotal;

                                if (date < startDateTime || date > endDateTime) continue;

                                DateTime checkStartDate = date.Date.AddHours(6);
                                DateTime checkEndDate = date.Date.AddDays(1).AddHours(6);

                                decimal dailyMisc = miscDetails.Where(m => m.MiscellaneousDate >= checkStartDate && m.MiscellaneousDate <= checkEndDate).Sum(m => m.MiscellaneousAmount ?? 0);

                                var dailyPayments = completedPayments.Where(p => p.PaymentCompletedOn >= checkStartDate && p.PaymentCompletedOn <= checkEndDate).ToList();
                                decimal dailyCash = dailyPayments.Where(p => p.PaymentMode == PaymentModeOption.Cash).Sum(p => p.Amount ?? 0);
                                decimal dailyCredit = dailyPayments.Where(p => p.PaymentMode != PaymentModeOption.Cash && p.PaymentMode != PaymentModeOption.RewardPoint).Sum(p => p.Amount ?? 0);
                                decimal dailyReward = dailyPayments.Where(p => p.PaymentMode == PaymentModeOption.RewardPoint).Sum(p => p.Amount ?? 0);
                                decimal dailyPayment = dailyCash + dailyCredit;

                                dailyTotalPayment += dailyPayment;

                                decimal perDayTaxableRevenue = 0, perDayNonTaxableRevenue = 0, perDayPartialTaxableRevenue = 0;
                                if (rateDetail.TaxStatus == TaxStatus.NonTaxable) perDayNonTaxableRevenue = perDayRoomRate;
                                else if (rateDetail.TaxStatus == TaxStatus.Taxable) perDayTaxableRevenue = perDayRoomRate;
                                else if (rateDetail.TaxStatus == TaxStatus.PartialTaxable) perDayPartialTaxableRevenue = perDayRoomRate;

                                // Main daily booking entry
                                dailyAuditReportBookingSummaries.Add(new DailyAuditReportBookingSummary
                                {
                                    BookingDate = DateOnly.FromDateTime(date.Hour < 6 ? date.AddDays(-1) : date),
                                    Rented = 1,
                                    BookingCode = booking.BookingCode,
                                    RoomNumber = booking.HotelRoom?.RoomNumber,
                                    GuestName = guestName,
                                    IdentityNumber = primaryGuest?.IdentityNumber,
                                    ScheduledCheckInDate = booking.ActualCheckInDate,
                                    ScheduledCheckOutDate = booking.ScheduledCheckOutDate,
                                    Duration = $"{booking.Duration} Day(s)",
                                    RoomChargeAmount = Math.Round(perDayRoomRate, 2),
                                    Tax = Math.Round(perDayTax, 2),
                                    MiscellaneousAmount = dailyMisc,
                                    Total = Math.Round(perDayTotal + dailyMisc, 2),
                                    Cash = Math.Round(dailyCash, 2),
                                    Credit = Math.Round(dailyCredit, 2),
                                    Reward = Math.Round(dailyReward, 2),
                                    Payment = Math.Round(dailyPayment, 2),
                                    Balance = rateDetail.FinalAmount - dailyTotalPayment,
                                    TaxableRevenue = Math.Round(perDayTaxableRevenue, 2),
                                    NonTaxableRevenue = Math.Round(perDayNonTaxableRevenue, 2),
                                    PartialTaxableRevenue = Math.Round(perDayPartialTaxableRevenue, 2),
                                    TaxStatus = rateDetail.TaxStatus,
                                    hotelRoomBookingTaxRateHTMLModels = rateDetail.tblHotelRoomBookingTaxRates
                                        .GroupBy(t => t.BookingTaxRateName)
                                        .Select(g => new HotelRoomBookingTaxRateHTMLModel
                                        {
                                            BookingTaxRateName = g.Key,
                                            BookingTaxRatePercentage = g.First().BookingTaxRatePercentage,
                                            BookingTaxRate = Math.Round(g.Sum(t => t.BookingTaxRate ?? 0) / days, 2)
                                        }).ToList()
                                });

                                // Refund for Day Booking
                                var refundData = refundedPayments.Where(r => r.RefundDate >= checkStartDate && r.RefundDate <= checkEndDate).ToList();
                                if (refundData.Count > 0)
                                {
                                    decimal totalCashRefunded = refundData.Where(p => p.PaymentMode == PaymentModeOption.Cash).Sum(p => p.RefundAmount ?? 0);
                                    decimal totalCreditRefunded = refundData.Where(p => p.PaymentMode != PaymentModeOption.Cash && p.PaymentMode != PaymentModeOption.RewardPoint).Sum(p => p.RefundAmount ?? 0);
                                    decimal totalRefunded = totalCashRefunded + totalCreditRefunded;

                                    decimal totalRefundAmount = 0;
                                    decimal totalRefundRoomRate = 0;
                                    decimal totalRefundTax = 0;
                                    decimal totalMISCRefund = 0;

                                    decimal nonTaxableRevenue = 0;
                                    decimal taxableRevenue = 0;
                                    decimal partialTaxableRevenue = 0;

                                    // Refund Amount Reverse Calculation
                                    var bookingRefundData = refundData.Where(item => item.PaymentMode != CommonConstants.PaymentModeOption.RewardPoint && item.PaymentType != CommonConstants.PaymentTypeOption.MiscellaneousAmount).ToList();
                                    if (bookingRefundData != null)
                                    {
                                        totalRefundAmount = bookingRefundData.Sum(item => item.RefundAmount) ?? 0;
                                        totalRefundRoomRate = totalRefundAmount / (((rateDetails.Where(item => !item.IsExtend).SelectMany(item => item.tblHotelRoomBookingTaxRates).Sum(item => item.BookingTaxRatePercentage)) + 100) / 100) ?? 0;
                                        totalRefundTax = totalRefundAmount - totalRefundRoomRate;
                                    }

                                    var bookingMISCRefundData = refundData.Where(item => item.PaymentType == CommonConstants.PaymentTypeOption.MiscellaneousAmount).ToList();
                                    totalMISCRefund = bookingMISCRefundData.Sum(item => item.RefundAmount) ?? 0;


                                    if (rateDetail.TaxStatus == TaxStatus.NonTaxable)
                                    {
                                        nonTaxableRevenue = totalRefundRoomRate;
                                    }
                                    else if (rateDetail.TaxStatus == TaxStatus.Taxable)
                                    {
                                        taxableRevenue = totalRefundRoomRate;
                                    }
                                    else if (rateDetail.TaxStatus == TaxStatus.PartialTaxable)
                                    {
                                        partialTaxableRevenue = totalRefundRoomRate;
                                    }

                                    dailyAuditReportBookingSummaries.Add(new DailyAuditReportBookingSummary
                                    {
                                        BookingDate = DateOnly.FromDateTime(date.Hour < 6 ? date.AddDays(-1) : date),
                                        Rented = 0,
                                        BookingCode = booking.BookingCode,
                                        RoomNumber = booking.HotelRoom?.RoomNumber + " (Refund)",
                                        GuestName = booking.tblHotelRoomBookingGuests.FirstOrDefault()?.Guest?.FirstName + " " + booking.tblHotelRoomBookingGuests.FirstOrDefault()?.Guest?.LastName,
                                        IdentityNumber = booking.tblHotelRoomBookingGuests.FirstOrDefault()?.Guest?.IdentityNumber,
                                        ScheduledCheckInDate = booking.ActualCheckInDate,
                                        ScheduledCheckOutDate = booking.ScheduledCheckOutDate,
                                        Duration = $"{booking.Duration} Day(s)",
                                        RoomChargeAmount = -Math.Round(totalRefundRoomRate, 2),
                                        Tax = -Math.Round(totalRefundTax, 2),
                                        MiscellaneousAmount = -Math.Round(totalMISCRefund, 2),
                                        Total = -Math.Round(totalRefundAmount, 2),
                                        Cash = -Math.Round(totalCashRefunded, 2),
                                        Credit = -Math.Round(totalCreditRefunded, 2),
                                        Payment = -Math.Round(totalRefunded, 2),
                                        Balance = -Math.Round(totalRefunded, 2),
                                        TaxableRevenue = -Math.Round(taxableRevenue, 2),
                                        NonTaxableRevenue = -Math.Round(nonTaxableRevenue, 2),
                                        PartialTaxableRevenue = -Math.Round(partialTaxableRevenue, 2),
                                        IsRefunded = true,
                                        hotelRoomBookingTaxRateHTMLModels = rateDetail.tblHotelRoomBookingTaxRates
                                        .GroupBy(t => t.BookingTaxRateName)
                                        .Select(group => new HotelRoomBookingTaxRateHTMLModel
                                        {
                                            BookingTaxRateName = group.Key,
                                            BookingTaxRatePercentage = group.First().BookingTaxRatePercentage,
                                            BookingTaxRate = -Math.Round(totalRefundRoomRate * group.First().BookingTaxRatePercentage / 100 ?? 0, 2)
                                        }).ToList()
                                    });
                                }
                            }
                        }
                    }
                }
            }

            _checkinProContext.ChangeTracker.AutoDetectChangesEnabled = true;

            // 🔹 Totals and summary (unchanged)
            var TotalCash = dailyAuditReportBookingSummaries.Sum(item => item.Cash);
            var TotalCreditCards = dailyAuditReportBookingSummaries.Sum(item => item.Credit);
            var TotalReward = dailyAuditReportBookingSummaries.Sum(item => item.Reward);
            var TotalRefunds = dailyAuditReportBookingSummaries.Where(item => item.IsRefunded).Sum(item => item.Payment);

            var dailyAuditReportTotalSummary = new DailyAuditReportTotalSummary
            {
                TotalRented = dailyAuditReportBookingSummaries.Sum(item => item.Rented),
                TotalHourlyRented = dailyAuditReportBookingSummaries.Sum(item => item.HourlyRented),
                TotalRoomCharge = dailyAuditReportBookingSummaries.Sum(item => item.RoomChargeAmount),
                TotalTax = dailyAuditReportBookingSummaries.Sum(item => item.Tax),
                TotalMiscellaneous = dailyAuditReportBookingSummaries.Sum(item => item.MiscellaneousAmount),
                Total = dailyAuditReportBookingSummaries.Sum(item => item.Total),
                TotalCash = TotalCash,
                TotalCreditCards = TotalCreditCards,
                TotalReward = TotalReward,
                TotalPayment = dailyAuditReportBookingSummaries.Sum(item => item.Payment),
                TotalBalance = dailyAuditReportBookingSummaries.Sum(item => item.Balance),
            };

            var TotalExpense = _checkinProContext.tblHotelExpenses
                .Where(item => item.ExpenseDate >= fromDate && item.ExpenseDate <= toDate && item.HotelID == hotelId)
                .Sum(he => he.ExpenseAmount);

            var dailyAuditReportSummary = new DailyAuditReportSummary
            {
                TotalCash = TotalCash,
                TotalCreditCards = TotalCreditCards,
                TotalRefunds = TotalRefunds,
                Total = (TotalCash + TotalCreditCards) - (TotalExpense)
            };

            var hotelRooms = _checkinProContext.tblHotelRooms.Count(item => item.HotelID == hotelId);
            var reportDays = (endDateTime - startDateTime).TotalDays;
            int totalRoom = (int)Math.Ceiling(hotelRooms * reportDays);

            var dailyAuditReportTaxSummary = new DailyAuditReportTaxSummary
            {
                TaxableRevenue = dailyAuditReportBookingSummaries.Sum(item => item.TaxableRevenue),
                NonTaxableRevenue = dailyAuditReportBookingSummaries.Sum(item => item.NonTaxableRevenue),
                PartialTaxableRevenue = dailyAuditReportBookingSummaries.Sum(item => item.PartialTaxableRevenue),
                ADR = CalculateADR(dailyAuditReportTotalSummary.TotalRoomCharge, dailyAuditReportTotalSummary.TotalRented),
                OCC = CalculateOccupancyPercentage(dailyAuditReportTotalSummary.TotalRented, totalRoom),
                Rented = dailyAuditReportTotalSummary.TotalRented,
                HourlyRented = dailyAuditReportTotalSummary.TotalHourlyRented,
                TotalRoom = hotelRooms,
                ExpenseAmount = TotalExpense,
                hotelRoomBookingTaxRateHTMLModels = dailyAuditReportBookingSummaries
                    .SelectMany(b => b.hotelRoomBookingTaxRateHTMLModels)
                    .GroupBy(tax => tax.BookingTaxRateName)
                    .Select(group => new HotelRoomBookingTaxRateHTMLModel
                    {
                        BookingTaxRateName = group.Key,
                        BookingTaxRatePercentage = group.First().BookingTaxRatePercentage,
                        BookingTaxRate = group.Sum(tax => tax.BookingTaxRate)
                    }).ToList()
            };

            var result = new DailyAuditReportHTMLModel
            {
                FromDate = fromDate,
                ToDate = toDate,
                hotelHTMLModel = BindHotelModel(hotelBookingData),
                dailyAuditReportBookingSummaries = dailyAuditReportBookingSummaries.OrderBy(key => key.ScheduledCheckInDate).ToList(),
                dailyAuditReportTotalSummary = dailyAuditReportTotalSummary,
                dailyAuditReportSummary = dailyAuditReportSummary,
                dailyAuditReportTaxSummary = dailyAuditReportTaxSummary,
            };

            return result;
        }
        private async Task<ShiftReportHTMLModel> GetDailyShiftAuditReportAsync(int hotelId, HotelShiftModel hotelShiftData, DateOnly fromDate, DateOnly toDate)
        {
            var (startDateTime, endDateTime) = CommonConstants.GetAdjustedHotelDateRange(fromDate, toDate);

            if (hotelShiftData.EndDate == null)
            {
                hotelShiftData.EndDate = DateTime.Now;
            }

            var hotelBookingData = await GetDetailedHotelBookingData(hotelId, startDateTime, endDateTime);

            List<ShiftHTMLModel> shiftHTMLModels = new();

            foreach (var roomType in hotelBookingData.tblHotelRoomTypes)
            {
                foreach (var booking in roomType.tblHotelRoomBookings)
                {
                    foreach (var payment in booking.tblPayments)
                    {
                        if (payment.PaymentStatus == CommonConstants.PaymentStatusMessages.Completed && (payment.PaymentCompletedOn >= hotelShiftData.StartDate && payment.PaymentCompletedOn <= hotelShiftData.EndDate))
                        {
                            shiftHTMLModels.Add(new ShiftHTMLModel
                            {
                                BookingCode = booking.BookingCode,
                                RoomNumber = booking.HotelRoom?.RoomNumber,
                                GuestName = booking.tblHotelRoomBookingGuests.FirstOrDefault()?.Guest.FirstName + " " + booking.tblHotelRoomBookingGuests.FirstOrDefault()?.Guest.LastName,
                                ScheduledCheckInDate = booking.ActualCheckInDate,
                                Duration = booking.Duration,
                                PaymentType = payment.PaymentType,
                                Cash = payment.PaymentMode == PaymentModeOption.Cash ? payment.Amount : 0,
                                Credit = payment.PaymentMode != PaymentModeOption.Cash && payment.PaymentMode != PaymentModeOption.RewardPoint ? payment.Amount : 0,
                                Reward = payment.PaymentMode == PaymentModeOption.RewardPoint ? payment.Amount : 0,
                                RefundAmount = payment.RefundAmount.GetValueOrDefault(),
                            });
                        }

                        //if (payment.IsRefunded && (payment.RefundDate >= hotelShiftData.StartDate && payment.RefundDate <= hotelShiftData.EndDate))
                        //{
                        //    shiftHTMLModels.Add(new ShiftHTMLModel
                        //    {
                        //        BookingCode = booking.BookingCode,
                        //        RoomNumber = booking.HotelRoom?.RoomNumber,
                        //        GuestName = booking.tblHotelRoomBookingGuests.FirstOrDefault()?.Guest.FirstName + " " + booking.tblHotelRoomBookingGuests.FirstOrDefault()?.Guest.LastName,
                        //        ScheduledCheckInDate = booking.ActualCheckInDate,
                        //        Duration = booking.Duration,
                        //        PaymentType = payment.PaymentType + " - Refunded",
                        //        Cash = payment.PaymentMode == "Cash" ? -payment.RefundAmount : 0,
                        //        Credit = payment.PaymentMode != "Cash" ? -payment.RefundAmount : 0,
                        //    });
                        //}
                    }
                }
            }

            var shiftReportHTMLModel = new ShiftReportHTMLModel
            {

                FromDate = DateOnly.FromDateTime(hotelShiftData.StartDate.Value.Hour < 6 ? hotelShiftData.StartDate.Value.AddDays(-1) : hotelShiftData.StartDate.Value),
                ToDate = DateOnly.FromDateTime(hotelShiftData.EndDate.Value.Hour < 6 ? hotelShiftData.EndDate.Value.AddDays(-1) : hotelShiftData.EndDate.Value),
                hotelHTMLModel = BindHotelModel(hotelBookingData),
                shiftHTMLModels = shiftHTMLModels.OrderBy(key => key.ScheduledCheckInDate).ToList()
            };

            return shiftReportHTMLModel;
        }
    }
}