﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Repositories.IRepository;
using CheckinPro.WebApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Repositories
{
    public class StateRepository : IStateRepository
    {
        private readonly ILogger _logger;
        private readonly CheckinProContext _checkinProContext;

        public StateRepository(ILogger<StateRepository> logger, CheckinProContext checkinProContext)
        {
            _logger = logger;
            _checkinProContext = checkinProContext;
        }

        /// <summary>
        /// Retrieves a list of states.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="StateModel"/> representing state data.</returns>
        public async Task<Result<List<StateModel>>> GetStates(int countryId)
        {
            try
            {
                _logger.LogInformation("Repository: GetStates method initiated.");
                // Transform the entities into StateModel instances
                var stateModels = await _checkinProContext.tblStates
                    .Where(t => t.CountryID == countryId)
                    .Select(item => new StateModel
                    {
                        StateID = item.StateID,
                        StateName = item.StateName,
                        IsStateActive = item.IsStateActive,
                        IsStateDeleted = item.IsStateDeleted,
                    }).ToListAsync();

                _logger.LogInformation("Repository: GetStates method execution completed.");
                _logger.LogInformation($"Repository: GetStates method execution completed. Total states retrieved: {stateModels.Count}.");


                // Return the list of stateModels
                return Result.Success(stateModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetStates method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching GetStates.");
            }
        }

        /// <summary>
        /// Retrieves a list of active states.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="StateModel"/> representing state data.</returns>
        public async Task<Result<List<StateModel>>> GetActiveStates(int countryId)
        {
            try
            {
                _logger.LogInformation("Repository: GetActiveStates method initiated.");
                // Transform the entities into StateModel instances
                var stateModels = await _checkinProContext.tblStates
                    .Where(t => t.CountryID == countryId && t.IsStateActive == true && t.IsStateDeleted == false)
                    .Select(item => new StateModel
                    {
                        StateID = item.StateID,
                        StateName = item.StateName,
                    }).ToListAsync();

                _logger.LogInformation("Repository: GetActiveStates method execution completed.");
                _logger.LogInformation($"Repository: GetActiveStates method execution completed. Total states retrieved: {stateModels.Count}.");


                // Return the list of stateModels
                return Result.Success(stateModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetActiveStates method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching active states.");
            }
        }

        /// <summary>
        /// Retrieves a state.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="StateModel"/> representing state data.</returns>
        public async Task<Result<StateModel>> GetStateByStateID(int stateId)
        {
            try
            {
                _logger.LogInformation("Repository: GetStateByStateID method initiated.");
                // Transform the entities into StateModel instances
                var stateModels = await _checkinProContext.tblStates
                    .Where(t => t.StateID == stateId)
                    .Select(item => new StateModel
                    {
                        StateName = item.StateName,
                        IsStateActive = item.IsStateActive,
                        IsStateDeleted = item.IsStateDeleted,
                    }).FirstOrDefaultAsync();

                _logger.LogInformation("Repository: GetStateByStateID method execution completed.");

                // Return the stateModels
                return Result.Success(stateModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetStateByStateID method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching GetStateByStateID.");
            }
        }

        /// <summary>
        /// Adds a new state record based on the provided stateRequestModel.
        /// </summary>
        /// <param name="stateRequestModel">The <see cref="StateModel"/> containing data for the new state.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the state addition operation.</returns>
        public async Task<Result> AddState(StateModel stateRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddState method initiated.");

                    // Validate the request model
                    if (stateRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddState called with a null stateRequestModel.");
                        return Result.NoContent();
                    }

                    // Create a new state entity dbState and add it to the database
                    tblState dbState = new tblState();
                    dbState.CountryID = stateRequestModel.CountryID;
                    dbState.StateName = stateRequestModel.StateName;
                    dbState.IsStateActive = stateRequestModel.IsStateActive;
                    dbState.CreatedBy = auditInfoModel.AuditUserID;
                    dbState.CreatedDate = DateTime.Now;

                    await _checkinProContext.tblStates.AddAsync(dbState);
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully added state with ID: {dbState.StateID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while adding state. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: AddState Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while adding the state.");
                }
            }
        }

        /// <summary>
        /// Updates an existing state record based on the provided stateID and stateRequestModel.
        /// </summary>
        /// <param name="stateID">The ID of the state to be updated.</param>
        /// <param name="stateRequestModel">The <see cref="StateModel"/> containing updated data for the state.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the state update operation.</returns>
        public async Task<Result> UpdateState(int stateID, StateModel stateRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: UpdateState method initiated for stateID: {stateID}.");

                    // Validate the request model
                    if (stateRequestModel == null)
                    {
                        _logger.LogWarning("Repository: UpdateState called with a null CountryModel.");
                        return Result.NoContent();
                    }

                    // Fetch the existing country entity
                    var dbState = await _checkinProContext.tblStates.FindAsync(stateID);
                    if (dbState == null)
                    {
                        _logger.LogWarning($"Repository: No state found with stateID: {stateID}.");
                        return Result.NoContent();
                    }

                    // Check the related country
                    var dbCountry = await _checkinProContext.tblCountries.FindAsync(dbState.CountryID);
                    if (dbCountry == null)
                    {
                        _logger.LogWarning($"Repository: No country found with countryID: {dbState.CountryID}.");
                        return Result.NoContent();
                    }
                    // Update the properties
                    dbState.StateName = stateRequestModel.StateName;
                    dbState.IsStateActive = stateRequestModel.IsStateActive;
                    dbState.UpdatedBy = stateRequestModel.UpdatedBy;
                    dbState.UpdatedDate = DateTime.Now;
                    if (stateRequestModel.IsStateActive == true)
                    {
                        // If IsStateActive is set to true, check if the country is inactive
                        if (!dbCountry.IsCountryActive)
                        {
                            dbCountry.IsCountryActive = true; // Activate the country
                            dbCountry.UpdatedBy = auditInfoModel.AuditUserID;
                            dbCountry.UpdatedDate = DateTime.Now; // Optionally update country timestamps
                        }
                    }

                    // Save changes to the database
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully updated country with ID: {stateID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while updating state. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: UpdateCountry Exception occurred for countryID: {stateID}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while updating the country.");
                }
            }
        }

        /// <summary>
        /// Deletes a state based on the provided stateID.
        /// </summary>
        /// <param name="stateID">The ID of the state to be deleted.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the delete operation.</returns>
        public async Task<Result> DeleteState(int stateID, StateModel stateRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: DeleteState method initiated for StateID: {stateID}.");

                    // Fetch the existing state entity
                    var dbState = await _checkinProContext.tblStates.FindAsync(stateID);
                    if (dbState == null)
                    {
                        _logger.LogWarning($"Repository: No state found with StateID: {stateID}.");
                        return Result.NoContent();
                    }

                    // Update the properties
                    dbState.IsStateDeleted = stateRequestModel.IsStateDeleted;
                    dbState.IsStateActive = stateRequestModel.IsStateActive;
                    dbState.DeletedDate = DateTime.Now;
                    dbState.DeletedBy = auditInfoModel.AuditUserID;
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully deleted state with ID: {stateID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while deleting state. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: DeleteState Exception occurred for StateID: {stateID}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while deleting the state.");
                }
            }
        }
    }
}
