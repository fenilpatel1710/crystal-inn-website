﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Repositories.IRepository;
using CheckinPro.WebApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Repositories
{
    public class CountryRepository : ICountryRepository
    {
        private readonly ILogger _logger;
        private readonly CheckinProContext _checkinProContext;

        public CountryRepository(ILogger<CountryRepository> logger, CheckinProContext checkinProContext)
        {
            _logger = logger;
            _checkinProContext = checkinProContext;
        }

        /// <summary>
        /// Retrieves a list of countries.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="CountryModel"/> representing country data.</returns>
        public async Task<Result<List<CountryModel>>> GetCountries()
        {
            try
            {
                _logger.LogInformation("Repository: GetCountries method initiated.");
                // Transform the entities into CountryModel instances
                var countryModels = await _checkinProContext.tblCountries.Select(item => new CountryModel
                {
                    CountryID = item.CountryID,
                    CountryName = item.CountryName,
                    IsCountryActive = item.IsCountryActive,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    UpdatedBy = item.UpdatedBy,
                    UpdatedDate = item.UpdatedDate,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                }).ToListAsync();

                _logger.LogInformation("Repository: GetCountries method execution completed.");
                _logger.LogInformation($"Repository: GetCountries method execution completed. Total countries retrieved: {countryModels.Count}.");


                // Return the list of CountryModel
                return Result.Success(countryModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetCountries method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching countries.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific country by its ID.
        /// </summary>
        /// <param name="countryID">The ID of the country to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="CountryModel"/> for the specified country, or an error if not found.</returns>
        public async Task<Result<CountryModel>> GetCountryById(int countryID)
        {
            try
            {
                _logger.LogInformation($"Repository: GetCountryById method initiated for CountryID: {countryID}.");

                // Fetch the country model based on the CountryID
                var countryModel = await _checkinProContext.tblCountries
                    .Where(item => item.CountryID == countryID)
                    .Select(item => new CountryModel
                    {
                        CountryID = item.CountryID,
                        CountryName = item.CountryName,
                        IsCountryActive = item.IsCountryActive,
                        CreatedBy = item.CreatedBy,
                        CreatedDate = item.CreatedDate,
                        UpdatedBy = item.UpdatedBy,
                        UpdatedDate = item.UpdatedDate,
                        DeletedBy = item.DeletedBy,
                        DeletedDate = item.DeletedDate,
                    })
                    .FirstOrDefaultAsync();

                // Return the CountryModel or null
                if (countryModel == null)
                {
                    _logger.LogWarning($"Repository: No country found with CountryID: {countryID}.");
                    return Result.NotFound($"No country found with CountryID: {countryID}.");
                }
                else
                {
                    _logger.LogInformation($"Repository: Successfully retrieved country for CountryID: {countryID}.");
                    return Result.Success(countryModel);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetCountryById Exception occurred for CountryID: {countryID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the country.");
            }
        }

        /// <summary>
        /// Adds a new country record based on the provided countryRequestModel.
        /// </summary>
        /// <param name="countryRequestModel">The <see cref="CountryModel"/> containing data for the new country.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the country addition operation.</returns>
        public async Task<Result> AddCountry(CountryModel countryRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddCountry method initiated.");

                    // Validate the request model
                    if (countryRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddCountry called with a null countryRequestModel.");
                        return Result.NoContent();
                    }

                    // Create a new country entity dbCountry and add it to the database
                    tblCountry dbCountry = new tblCountry();

                    dbCountry.CountryName = countryRequestModel.CountryName;
                    dbCountry.IsCountryActive = countryRequestModel.IsCountryActive;
                    dbCountry.CreatedBy = auditInfoModel.AuditUserID;
                    dbCountry.CreatedDate = DateTime.Now;

                    await _checkinProContext.tblCountries.AddAsync(dbCountry);
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully added country with ID: {dbCountry.CountryID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while adding country. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }

                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: AddCountry Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while adding the country.");
                }
            }
        }

        /// <summary>
        /// Updates an existing country record based on the provided countryID and countryRequestModel.
        /// </summary>
        /// <param name="countryID">The ID of the country to be updated.</param>
        /// <param name="countryRequestModel">The <see cref="CountryModel"/> containing updated data for the country.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the country update operation.</returns>
        public async Task<Result> UpdateCountry(int countryID, CountryModel countryRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: UpdateCountry method initiated for countryID: {countryID}.");

                    // Validate the request model
                    if (countryRequestModel == null)
                    {
                        _logger.LogWarning("Repository: UpdateCountry called with a null CountryModel.");
                        return Result.NoContent();
                    }

                    // Fetch the existing country entity
                    var dbCountry = await _checkinProContext.tblCountries.FindAsync(countryID);
                    if (dbCountry == null)
                    {
                        _logger.LogWarning($"Repository: No country found with countryID: {countryID}.");
                        return Result.NoContent();
                    }

                    // Update the properties
                    dbCountry.CountryName = countryRequestModel.CountryName;
                    dbCountry.IsCountryActive = countryRequestModel.IsCountryActive;
                    dbCountry.UpdatedBy = auditInfoModel.AuditUserID;
                    dbCountry.UpdatedDate = DateTime.Now;

                    // Fetch related states
                    var relatedStates = await _checkinProContext.tblStates
                        .Where(s => s.CountryID == countryID)
                        .ToListAsync();

                    // Update states based on the IsCountryActive status
                    foreach (var state in relatedStates)
                    {
                        state.IsStateActive = dbCountry.IsCountryActive; // Set to true/false based on country status
                        state.UpdatedBy = countryRequestModel.UpdatedBy;
                        state.UpdatedDate = DateTime.Now;
                    }

                    // Save changes to the database
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully updated country with ID: {countryID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while updating country. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }

                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: UpdateCountry Exception occurred for countryID: {countryID}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while updating the country.");
                }
            }
        }

        /// <summary>
        /// Deletes a country based on the provided countryID.
        /// </summary>
        /// <param name="countryID">The ID of the country to be deleted.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the delete operation.</returns>
        public async Task<Result> DeleteCountry(int countryID, CountryModel countryRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: DeleteCountry method initiated for CountryID: {countryID}.");

                    // Fetch the existing country entity
                    var dbCountry = await _checkinProContext.tblCountries.FindAsync(countryID);
                    if (dbCountry == null)
                    {
                        _logger.LogWarning($"Repository: No country found with CountryID: {countryID}.");
                        return Result.NoContent();
                    }

                    // Update the properties
                    dbCountry.IsCountryDeleted = countryRequestModel.IsCountryDeleted;
                    dbCountry.IsCountryActive = countryRequestModel.IsCountryActive;
                    dbCountry.DeletedDate = DateTime.Now;
                    dbCountry.DeletedBy = auditInfoModel.AuditUserID;
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully deleted country with ID: {countryID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while deleting country. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }

                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: DeleteCountry Exception occurred for CountryID: {countryID}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while deleting the country.");
                }
            }
        }
    }
}
