﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Repositories.IRepository;
using CheckinPro.WebApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Repositories
{
    public class HotelConfigurationRepository : IHotelConfigurationRepository
    {
        private readonly ILogger _logger;
        private readonly CheckinProContext _checkinProContext;

        public HotelConfigurationRepository(ILogger<HotelConfigurationRepository> logger, CheckinProContext checkinProContext)
        {
            _logger = logger;
            _checkinProContext = checkinProContext;
        }

        /// <summary>
        /// Retrieves a list of hotel tax rate.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="HotelTaxRateModel"/> representing all hotel tax rate data.</returns>
        public async Task<Result<List<HotelTaxRateModel>>> GetHotelTaxRate(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelTaxRate method initiated.");

                var dbHotelTaxRateData = await _checkinProContext.tblHotelTaxRates
                    .Where(item => item.HotelID == hotelID)
                    .Include(item => item.Hotel)
                    .Select(item => new HotelTaxRateModel
                    {
                        HotelTaxRateID = item.HotelTaxRateID,
                        HotelID = item.HotelID,
                        TaxName = item.TaxName,
                        TaxRate = item.TaxRate,
                        IsTaxRateActive = item.IsTaxRateActive,
                        Hotel = new GetHotelModel
                        {
                            BusinessLLCName = item.Hotel.BusinessLLCName,
                        },
                    }).ToListAsync();

                _logger.LogInformation("Repository: GetHotelTaxRate method execution completed.");
                _logger.LogInformation($"Repository: GetHotelTaxRate method execution completed. Total retrieved: {dbHotelTaxRateData.Count}.");


                // Return the list of GetHotelRoomModel
                return Result.Success(dbHotelTaxRateData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelTaxRate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching data.");
            }
        }

        /// <summary> 
        /// Adds a new hotel tax rate record based on the provided hotelTaxRateRequestModel.
        /// </summary>
        /// <param name="hotelTaxRateRequestModel">The <see cref="HotelTaxRateModel"/> containing data for the new hotel tax rate.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel tax rate creation operation.</returns>

        public async Task<Result> AddEditHotelTaxRate(HotelTaxRateModel hotelTaxRateRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddEditHotelTaxRate method initiated.");

                    // Validate the request model
                    if (hotelTaxRateRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddEditHotelTaxRate called with a null hotelTaxRateRequestModel.");
                        return Result.NoContent();
                    }
                    var dbHotelTaxRateData = await _checkinProContext.tblHotelTaxRates.FirstOrDefaultAsync(item => item.HotelTaxRateID == hotelTaxRateRequestModel.HotelTaxRateID);
                    if (dbHotelTaxRateData != null)
                    {
                        dbHotelTaxRateData.TaxName = hotelTaxRateRequestModel.TaxName;
                        dbHotelTaxRateData.TaxRate = hotelTaxRateRequestModel.TaxRate;
                        dbHotelTaxRateData.IsTaxRateActive = hotelTaxRateRequestModel.IsTaxRateActive;
                        dbHotelTaxRateData.UpdatedBy = auditInfoModel.AuditUserID;
                        dbHotelTaxRateData.UpdatedDate = DateTime.Now;

                        _checkinProContext.tblHotelTaxRates.Update(dbHotelTaxRateData);
                    }
                    else
                    {
                        var dbHotelTaxRateTaxName = await _checkinProContext.tblHotelTaxRates.FirstOrDefaultAsync(item => item.HotelID == hotelTaxRateRequestModel.HotelID && item.TaxName == hotelTaxRateRequestModel.TaxName);
                        if (dbHotelTaxRateTaxName != null)
                        {
                            _logger.LogWarning($"Repository: Tax Rate already exists for Date: {hotelTaxRateRequestModel.TaxName}.");
                            return Result.Error("Tax Rate Date already exists for the given TaxRateName.");
                        }

                        tblHotelTaxRate dbHotelTaxRate = new tblHotelTaxRate
                        {
                            HotelID = hotelTaxRateRequestModel.HotelID,
                            TaxName = hotelTaxRateRequestModel.TaxName,
                            TaxRate = hotelTaxRateRequestModel.TaxRate,
                            IsTaxRateActive = hotelTaxRateRequestModel.IsTaxRateActive,
                            CreatedBy = auditInfoModel.AuditUserID,
                            CreatedDate = DateTime.Now,
                        };
                        await _checkinProContext.tblHotelTaxRates.AddAsync(dbHotelTaxRate);
                    }

                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();
                    _logger.LogInformation($"Repository: Successfully added hotel tax rate.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while adding HotelTaxRate. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: AddEditHotelTaxRate Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while adding the hotel tax rate.");
                }
            }
        }

        public async Task<Result<HotelConfigurationModel>> GetHotelMasterConfiguration(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelMasterConfiguration method initiated.");

                var dbHotelMasterConfigurationsData = await _checkinProContext.tblHotelConfigurations
                    .Where(item => item.HotelID == hotelID)
                    .Include(item => item.Hotel)
                    .Select(item => new HotelConfigurationModel
                    {
                        HotelMasterConfigurationID = item.HotelMasterConfigurationID,
                        HotelID = item.HotelID,
                        BestAvailableRate = item.BestAvailableRate,
                    }).FirstOrDefaultAsync();

                _logger.LogInformation("Repository: GetHotelMasterConfiguration method execution completed.");

                // Return the list of GetHotelRoomModel
                return Result.Success(dbHotelMasterConfigurationsData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelMasterConfiguration method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching data.");
            }
        }
        public async Task<Result> AddEditHotelMasterConfiguration(HotelConfigurationModel hotelMasterConfigurationRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddHotelMasterConfiguration method initiated.");

                    // Validate the request model
                    if (hotelMasterConfigurationRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddHotelMasterConfiguration called with a null hotelMasterConfigurationRequestModel.");
                        return Result.NoContent();
                    }


                    // 1. Check if the room number and floor combination already exists for the given HotelID
                    var dbHotelMasterConfigurationsData = await _checkinProContext.tblHotelConfigurations.FirstOrDefaultAsync(r => r.HotelID == hotelMasterConfigurationRequestModel.HotelID);
                    if (dbHotelMasterConfigurationsData != null)
                    {
                        dbHotelMasterConfigurationsData.BestAvailableRate = hotelMasterConfigurationRequestModel?.BestAvailableRate;
                        dbHotelMasterConfigurationsData.UpdatedDate = DateTime.Now;
                        dbHotelMasterConfigurationsData.UpdatedBy = auditInfoModel.AuditUserID;
                        _checkinProContext.Update(dbHotelMasterConfigurationsData);
                    }
                    else
                    {

                        tblHotelConfiguration dbHotelMasterConfiguration = new tblHotelConfiguration
                        {
                            HotelID = hotelMasterConfigurationRequestModel.HotelID,
                            BestAvailableRate = hotelMasterConfigurationRequestModel.BestAvailableRate,
                            CreatedDate = DateTime.Now,
                            CreatedBy = auditInfoModel.AuditUserID,
                        };
                        await _checkinProContext.tblHotelConfigurations.AddAsync(dbHotelMasterConfiguration);
                    }
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();
                    _logger.LogInformation($"Repository: Successfully added hotel best available rate.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while adding HotelMasterConfiguration. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: AddHotelMasterConfiguration Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while adding the HotelMasterConfiguration.");
                }
            }
        }

        public async Task<Result<List<HotelDailyRateModel>>> GetHotelDailyRate(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelDailyRate method initiated.");

                var dbHotelDailyRateData = await _checkinProContext.tblHotelDailyRates
                    .Where(item => item.HotelID == hotelID)
                    .Include(item => item.Hotel)
                    .Select(item => new HotelDailyRateModel
                    {
                        HotelDailyRateID = item.HotelDailyRateID,
                        HotelID = item.HotelID,
                        DailyRateDate = item.DailyRateDate,
                        DailyBestAvailableRate = item.DailyBestAvailableRate,
                        IsDailyRateActive = item.IsDailyRateActive,
                    }).ToListAsync();

                _logger.LogInformation("Repository: GetHotelDailyRate method execution completed.");

                // Return the list of GetHotelRoomModel
                return Result.Success(dbHotelDailyRateData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelDailyRate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching data.");
            }
        }
        public async Task<Result> AddEditHotelDailyRate(HotelDailyRateModel hotelDailyRateRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddEditHotelDailyRate method initiated.");

                    // Validate the request model
                    if (hotelDailyRateRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddEditHotelDailyRate called with a null hotelDailyRateRequestModel.");
                        return Result.NoContent();
                    }


                    // 1. Check if the room number and floor combination already exists for the given HotelID
                    var dbHotelDailyRateData = await _checkinProContext.tblHotelDailyRates.FirstOrDefaultAsync(item => item.HotelDailyRateID == hotelDailyRateRequestModel.HotelDailyRateID);
                    if (dbHotelDailyRateData != null)
                    {
                        dbHotelDailyRateData.DailyBestAvailableRate = hotelDailyRateRequestModel.DailyBestAvailableRate;
                        dbHotelDailyRateData.IsDailyRateActive = hotelDailyRateRequestModel.IsDailyRateActive;
                        dbHotelDailyRateData.UpdatedDate = DateTime.Now;
                        dbHotelDailyRateData.UpdatedBy = auditInfoModel.AuditUserID;
                        _checkinProContext.Update(dbHotelDailyRateData);
                    }
                    else
                    {
                        var dbHotelDailyRateDate = await _checkinProContext.tblHotelDailyRates.FirstOrDefaultAsync(item => item.HotelID == hotelDailyRateRequestModel.HotelID && item.DailyRateDate == hotelDailyRateRequestModel.DailyRateDate);
                        if (dbHotelDailyRateDate != null)
                        {
                            _logger.LogWarning($"Repository: Daily Rate already exists for Date: {hotelDailyRateRequestModel.DailyRateDate}.");
                            return Result.Error("Daily Rate Date already exists for the given Date.");
                        }

                        if (hotelDailyRateRequestModel.StartDate.HasValue && hotelDailyRateRequestModel.EndDate.HasValue)
                        {
                            DateTime fromDate = hotelDailyRateRequestModel.StartDate.Value.ToDateTime(TimeOnly.MinValue);
                            DateTime toDate = hotelDailyRateRequestModel.EndDate.Value.ToDateTime(TimeOnly.MinValue);

                            for (DateTime date = fromDate; date <= toDate; date = date.AddDays(1))
                            {
                                tblHotelDailyRate dbHotelDailyRate = new tblHotelDailyRate
                                {
                                    HotelID = hotelDailyRateRequestModel.HotelID,
                                    DailyRateDate = DateOnly.FromDateTime(date),  // Convert DateTime to DateOnly
                                    DailyBestAvailableRate = hotelDailyRateRequestModel.DailyBestAvailableRate,
                                    IsDailyRateActive = hotelDailyRateRequestModel.IsDailyRateActive,
                                    CreatedDate = DateTime.Now,
                                    CreatedBy = auditInfoModel.AuditUserID,
                                };

                                await _checkinProContext.tblHotelDailyRates.AddAsync(dbHotelDailyRate);
                            }

                            await _checkinProContext.SaveChangesAsync();
                        }
                        else
                        {
                            throw new ArgumentException("From and To dates must be provided.");
                        }

                    }

                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();
                    _logger.LogInformation($"Repository: Successfully added hotel daily best available rate.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while adding HotelDailyRate. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: AddEditHotelDailyRate Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while adding the HotelDailyRate.");
                }
            }
        }

        public async Task<Result<List<HotelHourlyRateModel>>> GetHotelHourlyRate(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelHourlyRate method initiated.");

                var dbHotelHourlyRateData = await _checkinProContext.tblHotelHourlyRates
                    .Where(item => item.HotelID == hotelID)
                    .Include(item => item.Hotel)
                    .Select(item => new HotelHourlyRateModel
                    {
                        HotelHourlyRateID = item.HotelHourlyRateID,
                        HotelID = item.HotelID,
                        Hour = item.Hour,
                        HourlyRate = item.HourlyRate,
                        IsHotelHourlyRateActive = item.IsHotelHourlyRateActive,
                    }).ToListAsync();

                _logger.LogInformation("Repository: GetHotelHourlyRate method execution completed.");

                // Return the list of GetHotelRoomModel
                return Result.Success(dbHotelHourlyRateData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelHourlyRate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching data.");
            }
        }
        public async Task<Result> AddEditHotelHourlyRate(HotelHourlyRateModel hotelHourlyRateRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddEditHotelHourlyRate method initiated.");

                    // Validate the request model
                    if (hotelHourlyRateRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddEditHotelHourlyRate called with a null hotelHourlyRateRequestModel.");
                        return Result.NoContent();
                    }


                    // 1. Check if the room number and floor combination already exists for the given HotelID
                    var dbHotelHourlyRateData = await _checkinProContext.tblHotelHourlyRates.FirstOrDefaultAsync(item => item.HotelHourlyRateID == hotelHourlyRateRequestModel.HotelHourlyRateID);
                    if (dbHotelHourlyRateData != null)
                    {
                        dbHotelHourlyRateData.HourlyRate = hotelHourlyRateRequestModel.HourlyRate;
                        dbHotelHourlyRateData.IsHotelHourlyRateActive = hotelHourlyRateRequestModel.IsHotelHourlyRateActive;
                        dbHotelHourlyRateData.UpdatedDate = DateTime.Now;
                        dbHotelHourlyRateData.UpdatedBy = auditInfoModel.AuditUserID;
                        _checkinProContext.Update(dbHotelHourlyRateData);
                    }
                    else
                    {
                        var dbHotelHourlyRateHour = await _checkinProContext.tblHotelHourlyRates.FirstOrDefaultAsync(item => item.HotelID == hotelHourlyRateRequestModel.HotelID && item.Hour == hotelHourlyRateRequestModel.Hour);

                        if (dbHotelHourlyRateHour != null)
                        {
                            _logger.LogWarning($"Repository: Hourly Rate already exists for Hour: {hotelHourlyRateRequestModel.Hour}.");
                            return Result.Error("Hourly Rate already exists for the given Hour.");
                        }

                        tblHotelHourlyRate dbHotelHourlyRate = new tblHotelHourlyRate
                        {
                            HotelID = hotelHourlyRateRequestModel.HotelID,
                            Hour = hotelHourlyRateRequestModel.Hour,
                            HourlyRate = hotelHourlyRateRequestModel.HourlyRate,
                            IsHotelHourlyRateActive = hotelHourlyRateRequestModel.IsHotelHourlyRateActive,
                            CreatedDate = DateTime.Now,
                            CreatedBy = auditInfoModel.AuditUserID,
                        };
                        await _checkinProContext.tblHotelHourlyRates.AddAsync(dbHotelHourlyRate);
                    }

                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();
                    _logger.LogInformation($"Repository: Successfully added hotel hourly rate.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while adding HotelHourlyRate. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: AddEditHotelHourlyRate Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while adding the HotelHourlyRate.");
                }
            }
        }

        public async Task<Result<List<HotelRoomTypeModel>>> GetHotelRoomType(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelRoomType method initiated.");

                var dbHotelRoomTypeData = await _checkinProContext.tblHotelRoomTypes
                    .Where(item => item.HotelID == hotelID)
                    .Select(item => new HotelRoomTypeModel
                    {
                        HotelRoomTypeID = item.HotelRoomTypeID,
                        HotelID = item.HotelID,
                        RoomTypeName = item.RoomTypeName,
                        RoomTypeIcon = item.RoomTypeIcon,
                        Description = item.Description,
                        AdjustmentRate = item.AdjustmentRate,
                        IsHotelRoomTypeActive = item.IsHotelRoomTypeActive
                    }).ToListAsync();

                _logger.LogInformation("Repository: GetHotelRoomType method execution completed.");

                // Return the list of GetHotelRoomModel
                return Result.Success(dbHotelRoomTypeData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelRoomType method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching data.");
            }
        }

        public async Task<Result<HotelRoomTypeModel>> GetHotelRoomTypeById(int hotelRoomTypeID)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelRoomTypeById method initiated.");

                var dbHotelRoomTypeData = await _checkinProContext.tblHotelRoomTypes
                    .Where(item => item.HotelRoomTypeID == hotelRoomTypeID)
                    .Select(item => new HotelRoomTypeModel
                    {
                        HotelRoomTypeID = item.HotelRoomTypeID,
                        HotelID = item.HotelID,
                        RoomTypeName = item.RoomTypeName,
                        RoomTypeIcon = item.RoomTypeIcon,
                        Description = item.Description,
                        AdjustmentRate = item.AdjustmentRate,
                        IsHotelRoomTypeActive = item.IsHotelRoomTypeActive
                    }).FirstOrDefaultAsync();

                _logger.LogInformation("Repository: GetHotelRoomTypeById method execution completed.");

                // Return the list of GetHotelRoomModel
                return Result.Success(dbHotelRoomTypeData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelRoomTypeById method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching data.");
            }
        }
        public async Task<Result> AddEditHotelRoomType(HotelRoomTypeModel hotelRoomTypeRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddEditHotelRoomType method initiated.");

                    // Validate the request model
                    if (hotelRoomTypeRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddEditHotelRoomType called with a null hotelRoomTypeRequestModel.");
                        return Result.NoContent();
                    }


                    // 1. Check if the room number and floor combination already exists for the given HotelID
                    var dbHotelRoomTypeData = await _checkinProContext.tblHotelRoomTypes.FirstOrDefaultAsync(item => item.HotelRoomTypeID == hotelRoomTypeRequestModel.HotelRoomTypeID);
                    if (dbHotelRoomTypeData != null)
                    {
                        dbHotelRoomTypeData.RoomTypeName = hotelRoomTypeRequestModel.RoomTypeName;
                        dbHotelRoomTypeData.RoomTypeIcon = hotelRoomTypeRequestModel.RoomTypeIcon;
                        dbHotelRoomTypeData.Description = hotelRoomTypeRequestModel.Description;
                        dbHotelRoomTypeData.AdjustmentRate = hotelRoomTypeRequestModel.AdjustmentRate;
                        dbHotelRoomTypeData.IsHotelRoomTypeActive = hotelRoomTypeRequestModel.IsHotelRoomTypeActive;
                        dbHotelRoomTypeData.UpdatedDate = DateTime.Now;
                        dbHotelRoomTypeData.UpdatedBy = auditInfoModel.AuditUserID;
                        _checkinProContext.Update(dbHotelRoomTypeData);
                    }
                    else
                    {
                        var dbHotelRoomTypeName = await _checkinProContext.tblHotelRoomTypes.FirstOrDefaultAsync(item => item.HotelID == hotelRoomTypeRequestModel.HotelID && item.RoomTypeName == hotelRoomTypeRequestModel.RoomTypeName);
                        if (dbHotelRoomTypeName != null)
                        {
                            _logger.LogWarning($"Repository: Room Type already exists for Type: {hotelRoomTypeRequestModel.RoomTypeName}.");
                            return Result.Error("Room Type already exists for the given Type.");
                        }

                        tblHotelRoomType dbHotelRoomType = new tblHotelRoomType
                        {
                            HotelID = hotelRoomTypeRequestModel.HotelID,
                            RoomTypeName = hotelRoomTypeRequestModel.RoomTypeName,
                            RoomTypeIcon = hotelRoomTypeRequestModel.RoomTypeIcon,
                            Description = hotelRoomTypeRequestModel.Description,
                            AdjustmentRate = hotelRoomTypeRequestModel.AdjustmentRate,
                            IsHotelRoomTypeActive = hotelRoomTypeRequestModel.IsHotelRoomTypeActive,
                            CreatedDate = DateTime.Now,
                            CreatedBy = auditInfoModel.AuditUserID,
                        };
                        await _checkinProContext.tblHotelRoomTypes.AddAsync(dbHotelRoomType);
                    }

                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();
                    _logger.LogInformation($"Repository: Successfully added hotel room type.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while adding HotelRoomType. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: AddEditHotelRoomType Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while adding the HotelRoomType.");
                }
            }
        }


        public async Task<Result<List<HotelAdditionalRateModel>>> GetHotelAdditionalRate(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelAdditionalRate method initiated.");

                var dbHotelAdditionalRateData = await _checkinProContext.tblHotelAdditionalRates
                    .Where(item => item.HotelID == hotelID)
                    .Include(item => item.Hotel)
                    .Select(item => new HotelAdditionalRateModel
                    {
                        HotelAdditionalRateID = item.HotelAdditionalRateID,
                        HotelID = item.HotelID,
                        AdditionalRateName = item.AdditionalRateName,
                        AdditionalRate = item.AdditionalRate,
                        IsDiscountedRate = item.IsDiscountedRate,
                        IsAdditionalRateActive = item.IsAdditionalRateActive,
                    }).ToListAsync();

                _logger.LogInformation("Repository: GetHotelAdditionalRate method execution completed.");

                // Return the list of GetHotelRoomModel
                return Result.Success(dbHotelAdditionalRateData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelAdditionalRate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching data.");
            }
        }
        public async Task<Result> AddEditHotelAdditionalRate(HotelAdditionalRateModel hotelAdditionalRateRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddEditHotelAdditionalRate method initiated.");

                    // Validate the request model
                    if (hotelAdditionalRateRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddEditHotelAdditionalRate called with a null hotelAdditionalRateRequestModel.");
                        return Result.NoContent();
                    }


                    // 1. Check if the room number and floor combination already exists for the given HotelID
                    var dbHotelAdditionalRateData = await _checkinProContext.tblHotelAdditionalRates.FirstOrDefaultAsync(item => item.HotelAdditionalRateID == hotelAdditionalRateRequestModel.HotelAdditionalRateID);
                    if (dbHotelAdditionalRateData != null)
                    {
                        dbHotelAdditionalRateData.AdditionalRateName = hotelAdditionalRateRequestModel.AdditionalRateName;
                        dbHotelAdditionalRateData.AdditionalRate = hotelAdditionalRateRequestModel.AdditionalRate;
                        dbHotelAdditionalRateData.IsDiscountedRate = hotelAdditionalRateRequestModel.IsDiscountedRate;
                        dbHotelAdditionalRateData.IsAdditionalRateActive = hotelAdditionalRateRequestModel.IsAdditionalRateActive;
                        dbHotelAdditionalRateData.UpdatedDate = DateTime.Now;
                        dbHotelAdditionalRateData.UpdatedBy = auditInfoModel.AuditUserID;
                        _checkinProContext.Update(dbHotelAdditionalRateData);
                    }
                    else
                    {
                        var dbHotelAdditionalRateName = await _checkinProContext.tblHotelAdditionalRates.FirstOrDefaultAsync(item => item.HotelID == hotelAdditionalRateRequestModel.HotelID && item.AdditionalRateName == hotelAdditionalRateRequestModel.AdditionalRateName);
                        if (dbHotelAdditionalRateName != null)
                        {
                            _logger.LogWarning($"Repository: Additional Rate already exists for Hour: {hotelAdditionalRateRequestModel.AdditionalRateName}.");
                            return Result.Error("Additional Rate already exists for the given Name.");
                        }

                        tblHotelAdditionalRate dbHotelAdditionalRate = new tblHotelAdditionalRate
                        {
                            HotelID = hotelAdditionalRateRequestModel.HotelID,
                            AdditionalRateName = hotelAdditionalRateRequestModel.AdditionalRateName,
                            AdditionalRate = hotelAdditionalRateRequestModel.AdditionalRate,
                            IsDiscountedRate = hotelAdditionalRateRequestModel.IsDiscountedRate,
                            IsAdditionalRateActive = hotelAdditionalRateRequestModel.IsAdditionalRateActive,
                            CreatedDate = DateTime.Now,
                            CreatedBy = auditInfoModel.AuditUserID,
                        };
                        await _checkinProContext.tblHotelAdditionalRates.AddAsync(dbHotelAdditionalRate);
                    }

                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();
                    _logger.LogInformation($"Repository: Successfully added hotel additional rate.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while adding HotelAdditionalRate. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: AddEditHotelAdditionalRate Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while adding the HotelAdditionalRate.");
                }
            }
        }

        public async Task<Result> DeleteHotelDailyRate(int hotelDailyRateID)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: DeleteHotelDailyRate method initiated.");

                    var dbHotelDailyRateData = await _checkinProContext.tblHotelDailyRates.FindAsync(hotelDailyRateID);

                    if (dbHotelDailyRateData != null)
                    {
                        _checkinProContext.tblHotelDailyRates.Remove(dbHotelDailyRateData);
                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();
                        return Result.Success();
                    }
                    else
                    {
                        _logger.LogWarning($"Repository: No hotel daily rate found.");
                        return Result.NotFound($"No hotel daily rate found.");
                    }
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while deleting Hotel Daily Rate. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Repository: DeleteHotelDailyRate Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while deleting Hotel Daily Rate.");
                }
            }
        }


    }
}
