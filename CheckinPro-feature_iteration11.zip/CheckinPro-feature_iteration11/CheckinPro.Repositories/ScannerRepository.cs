﻿using Ardalis.Result;
using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Repositories.IRepository;
using CheckinPro.WebApi.Models;
using CheckinPro.WebApi.Models.GuestModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using System.Xml.Serialization;

namespace CheckinPro.Repositories
{
    public class ScannerRepository : IScannerRepository
    {

        private readonly ILogger _logger;
        private readonly CheckinProContext _checkinProContext;

        public ScannerRepository(ILogger<ScannerRepository> logger, CheckinProContext checkinProContext)
        {
            _logger = logger;
            _checkinProContext = checkinProContext;
        }


        //public async Task<Result<List<AddGuestModel>>> GetGuestScanDetail(int hotelID)
        //{
        //    try
        //    {
        //        _logger.LogInformation("Repository: AddGuestScanDetail method initiated.");

        //        var dbhotel = await _checkinProContext.tblHotels.Where(item => item.HotelID == hotelID).FirstOrDefaultAsync();

        //        var dbGuestScanDetail = await _checkinProContext.tblGuestIDScans.Where(item => item.HotelUniqueID == dbhotel.HotelUniqueID).ToListAsync();

        //        List<AddGuestModel> guestList = new();

        //        foreach (var guestScan in dbGuestScanDetail)
        //        {
        //            var root = DeserializeGuestXml(guestScan.Scanner_XML_File);
        //            //var obj = JsonConvert.DeserializeObject<ScanIDXMLDocumentModel>(guestScan.Scanner_XML_File);

        //            var guestModel = new AddGuestModel
        //            {
        //                FirstName = root.NewData.FrontDocumentType,
        //                LastName = root.NewData.OCREmulateLastName,
        //                Address1 = root.NewData.OCRAddress,
        //                City = root.NewData.OCRCity,
        //                //ZipCode = int.TryParse(root.NewData.OCRZip, out int zip) ? zip : (int?)null,
        //                IdentityType = root.NewData.FrontDocumentType,
        //                IdentityNumber = root.NewData.OCRDocumentNumber,
        //                FrontSideImage = !string.IsNullOrEmpty(root.NewData.FrontImage)
        //                                 ? root.NewData.FrontImage
        //                                 : null
        //            };

        //            guestList.Add(guestModel);
        //        }

        //        //  _logger.LogInformation($"Repository: Successfully updated hotel room booking with ID: {dbHotelRoomBooking.HotelRoomBookingID}.");
        //        return Result.Success(guestList);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError($"Repository: UpdateHotelRoomBooking Exception occurred. Stacktrace: {ex}");
        //        return Result.Error("An error occurred while updating the hotel room booking.");
        //    }
        //}


        //public async Task<Result<List<AddGuestModel>>> GetGuestScanDetail(int hotelID)
        //{
        //    try
        //    {
        //        _logger.LogInformation("Repository: GetGuestScanDetail method initiated.");

        //        var dbHotel = await _checkinProContext.tblHotels
        //            .FirstOrDefaultAsync(h => h.HotelID == hotelID);

        //        if (dbHotel == null)
        //            return Result.Error("Hotel not found.");

        //        var today = DateTime.Now.AddDays(-1);

        //        var dbGuestScanDetails = await _checkinProContext.tblGuestIDScans
        //                  .Where(g => g.HotelUniqueID == dbHotel.HotelUniqueID && g.Document_Scan_Date.Value.Date == today.Date)
        //                  .OrderByDescending(g => g.Document_Scan_Date)
        //                  .ToListAsync();

        //        List<AddGuestModel> guestList = new();
        //        foreach (var guestScan in dbGuestScanDetails)
        //        {
        //            AddGuestModel guestModel = new();
        //            var dbGuestPresent = await _checkinProContext.tblGuests.FirstOrDefaultAsync(item => item.IdentityNumber == guestScan.Document_Number);
        //            if (dbGuestPresent != null)
        //            {
        //                guestModel.GuestID = dbGuestPresent.GuestID;
        //                guestModel.GuestCode = dbGuestPresent.GuestCode;
        //                guestModel.FirstName = dbGuestPresent.FirstName;
        //                guestModel.LastName = dbGuestPresent.LastName;
        //                guestModel.IdentityType = dbGuestPresent.IdentityType;
        //                guestModel.IdentityNumber = dbGuestPresent.IdentityNumber;
        //                guestModel.FrontSideImage = Convert.ToBase64String(dbGuestPresent.FrontSideImage);
        //                guestModel.MobileNumber = dbGuestPresent.MobileNumber;
        //                guestModel.Email = dbGuestPresent.Email;
        //                guestModel.Address1 = dbGuestPresent.Address1;
        //                guestModel.Address2 = dbGuestPresent.Address2;
        //                guestModel.Country = dbGuestPresent.Country;
        //                guestModel.State = dbGuestPresent.State;
        //                guestModel.City = dbGuestPresent.City;
        //                guestModel.ZipCode = dbGuestPresent.ZipCode;
        //                guestModel.ScanID = guestScan.ScanID;
        //            }
        //            else
        //            {
        //                Guest_XML_JSON_DataModel? guestData = null;

        //                // Try JSON deserialization first
        //                if (!string.IsNullOrWhiteSpace(guestScan.Scanner_JSON_File))
        //                {
        //                    try
        //                    {
        //                        var jsonRoot = JsonSerializer.Deserialize<GuestIdScanDataModel>(
        //                            guestScan.Scanner_JSON_File,
        //                            new JsonSerializerOptions
        //                            {
        //                                PropertyNameCaseInsensitive = true
        //                            });

        //                        guestData = jsonRoot?.NewDatas.NewData;
        //                    }
        //                    catch (Exception ex)
        //                    {
        //                        _logger.LogWarning($"Failed to parse JSON for GuestScan ID {guestScan.ScanID}: {ex.Message}");
        //                    }
        //                }

        //                // If JSON fails or is empty, try XML
        //                if (guestData == null && !string.IsNullOrWhiteSpace(guestScan.Scanner_XML_File))
        //                {
        //                    try
        //                    {
        //                        var xmlRoot = DeserializeGuestXml(guestScan.Scanner_XML_File);
        //                        guestData = xmlRoot?.NewDatas.NewData;
        //                    }
        //                    catch (Exception ex)
        //                    {
        //                        _logger.LogWarning($"Failed to parse XML for GuestScan ID {guestScan.ScanID}: {ex.Message}");
        //                    }
        //                }

        //                if (guestData != null)
        //                {
        //                    guestModel.FirstName = guestData.FirstName;
        //                    guestModel.LastName = guestData.LastName;
        //                    guestModel.IdentityType = guestData.FrontDocumentType;
        //                    guestModel.IdentityNumber = guestData.DocumentNumber;
        //                    guestModel.Address1 = guestData.OCRAddress;
        //                    guestModel.Country = guestData.IssuingStateCode;
        //                    guestModel.State = guestData.OCRAddressState;
        //                    guestModel.City = guestData.OCRCity;
        //                    guestModel.ZipCode = guestData.OCRZip;
        //                    guestModel.ScanID = guestScan.ScanID;
        //                    guestModel.FrontSideImage = !string.IsNullOrEmpty(guestData.FrontImage)
        //                                        ? guestData.FrontImage
        //                                        : null;

        //                }

        //            }
        //            guestList.Add(guestModel);
        //        }

        //        return Result.Success(guestList);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError($"Repository: GetGuestScanDetail encountered an error. Stacktrace: {ex}");
        //        return Result.Error("An error occurred while retrieving guest scan details.");
        //    }
        //}

        public async Task<Result<List<AddGuestModel>>> GetGuestScanDetail(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetGuestScanDetail method initiated.");

                var dbHotel = await _checkinProContext.tblHotels
                    .AsNoTracking()
                    .Where(h => h.HotelID == hotelID)
                    .Select(h => new { h.HotelUniqueID })
                    .FirstOrDefaultAsync();

                if (dbHotel == null)
                    return Result.Error("Hotel not found.");

                // Fixed date
                var today = DateTime.Today;

                // 1️⃣ Load scans
                var guestScans = await _checkinProContext.tblGuestIDScans
                    .AsNoTracking()
                    .Where(g =>
                        g.HotelUniqueID == dbHotel.HotelUniqueID &&
                        g.Document_Scan_Date.Value.Date >= today.Date).OrderByDescending(g => g.Document_Scan_Date).Take(5).ToListAsync();

                if (!guestScans.Any())
                    return Result.Success(new List<AddGuestModel>());

                // 2️⃣ Collect valid document numbers
                var documentNumbers = guestScans
                    .Where(x => !string.IsNullOrWhiteSpace(x.Document_Number))
                    .Select(x => x.Document_Number!.Trim())
                    .Distinct()
                    .ToList();

                // 3️⃣ Load guests in one query
                var guests = await _checkinProContext.tblGuests
                    .AsNoTracking()
                    .Where(g => documentNumbers.Contains(g.IdentityNumber))
                    .ToDictionaryAsync(g => g.IdentityNumber);

                // 4️⃣ Build response
                var guestList = new List<AddGuestModel>(guestScans.Count);

                foreach (var guestScan in guestScans)
                {
                    var guestModel = new AddGuestModel
                    {
                        ScanID = guestScan.ScanID
                    };

                    var documentNumber = guestScan.Document_Number?.Trim();

                    if (!string.IsNullOrEmpty(documentNumber) &&
                        guests.TryGetValue(documentNumber, out var dbGuest))
                    {
                        guestModel.GuestID = dbGuest.GuestID;
                        guestModel.GuestCode = dbGuest.GuestCode;
                        guestModel.FirstName = dbGuest.FirstName;
                        guestModel.LastName = dbGuest.LastName;
                        guestModel.IdentityType = dbGuest.IdentityType;
                        guestModel.IdentityNumber = dbGuest.IdentityNumber;
                        guestModel.MobileNumber = dbGuest.MobileNumber;
                        guestModel.Email = dbGuest.Email;
                        guestModel.Address1 = dbGuest.Address1;
                        guestModel.Address2 = dbGuest.Address2;
                        guestModel.Country = dbGuest.Country;
                        guestModel.State = dbGuest.State;
                        guestModel.City = dbGuest.City;
                        guestModel.ZipCode = dbGuest.ZipCode;
                        guestModel.FrontSideImage = dbGuest.FrontSideImage != null
                            ? Convert.ToBase64String(dbGuest.FrontSideImage)
                            : null;
                    }
                    else
                    {
                        Guest_XML_JSON_DataModel? guestData = null;

                        if (!string.IsNullOrWhiteSpace(guestScan.Scanner_JSON_File))
                        {
                            try
                            {
                                var jsonRoot = JsonSerializer.Deserialize<GuestIdScanDataModel>(
                                    guestScan.Scanner_JSON_File,
                                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                                guestData = jsonRoot?.NewDatas?.NewData;
                            }
                            catch (Exception ex)
                            {
                                _logger.LogWarning($"JSON parse failed for ScanID {guestScan.ScanID}: {ex.Message}");
                            }
                        }

                        if (guestData == null &&
                            !string.IsNullOrWhiteSpace(guestScan.Scanner_XML_File))
                        {
                            try
                            {
                                var xmlRoot = DeserializeGuestXml(guestScan.Scanner_XML_File);
                                guestData = xmlRoot?.NewDatas?.NewData;
                            }
                            catch (Exception ex)
                            {
                                _logger.LogWarning($"XML parse failed for ScanID {guestScan.ScanID}: {ex.Message}");
                            }
                        }

                        if (guestData != null)
                        {
                            guestModel.FirstName = guestData.FirstName;
                            guestModel.LastName = guestData.LastName;
                            guestModel.IdentityType = guestData.FrontDocumentType;
                            guestModel.IdentityNumber = guestData.DocumentNumber;
                            guestModel.Address1 = guestData.OCRAddress;
                            guestModel.Country = guestData.IssuingStateCode;
                            guestModel.State = guestData.OCRAddressState;
                            guestModel.City = guestData.OCRCity;
                            guestModel.ZipCode = guestData.OCRZip;
                            guestModel.FrontSideImage = guestData.FrontImage;
                        }
                    }

                    guestList.Add(guestModel);
                }

                return Result.Success(guestList);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetGuestScanDetail error: {ex}");
                return Result.Error("An error occurred while retrieving guest scan details.");
            }
        }


        public async Task<Result> AddGuestScanDetail(GuestIDScan guestIDScan)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddGuestScanDetail method initiated.");

                    var deserializedJson = DeserializeGuestJson(guestIDScan.Scanner_JSON_File);
                    DateTime.TryParse(deserializedJson.NewDatas.NewData.DocumentScanDate, out DateTime parsedScanDate);


                    tblGuestIDScan dbGuestIDScan = new tblGuestIDScan
                    {
                        HotelUniqueID = guestIDScan.HotelUniqueID,
                        Document_Number = deserializedJson.NewDatas.NewData.DocumentNumber,
                        Document_Scan_Date = parsedScanDate != DateTime.MinValue ? parsedScanDate : DateTime.Now,
                        Scanner_XML_File = guestIDScan.Scanner_XML_File,
                        Scanner_JSON_File = guestIDScan.Scanner_JSON_File,
                        CreatedDate = DateTime.Now,
                    };

                    await _checkinProContext.tblGuestIDScans.AddAsync(dbGuestIDScan);

                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    //  _logger.LogInformation($"Repository: Successfully updated hotel room booking with ID: {dbHotelRoomBooking.HotelRoomBookingID}.");
                    return Result.Success();

                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while updating hotel room booking. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: UpdateHotelRoomBooking Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while updating the hotel room booking.");
                }
            }
        }

        private GuestIdScanDataModel DeserializeGuestJson(string jsonData)
        {
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            return JsonSerializer.Deserialize<GuestIdScanDataModel>(jsonData, options)!;
        }

        private GuestIdScanDataModel DeserializeGuestXml(string xmlData)
        {
            var serializer = new XmlSerializer(typeof(GuestIdScanDataModel));
            using var reader = new StringReader(xmlData);
            return (GuestIdScanDataModel)serializer.Deserialize(reader)!;
        }
    }
}
