﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.Common.Models.Constants;
using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Repositories.IRepository;
using CheckinPro.WebApi.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Data;
using static CheckinPro.Common.Models.Constants.CommonConstants;
using static iText.StyledXmlParser.Jsoup.Select.Evaluator;

namespace CheckinPro.Repositories
{
    public class HotelRoomBookingRepository : IHotelRoomBookingRepository
    {
        private readonly ILogger _logger;
        private readonly CheckinProContext _checkinProContext;

        public HotelRoomBookingRepository(ILogger<HotelRoomBookingRepository> logger, CheckinProContext checkinProContext)
        {
            _logger = logger;
            _checkinProContext = checkinProContext;
        }

        public async Task<Result<HotelDailyRateModel>> GetHotelDailyRateByDate(int hotelID, DateOnly checkInDate)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelDailyRateByDate method initiated.");

                var dbHotelDailyBestAvailableRateData = await _checkinProContext.tblHotelDailyRates
                    .Where(item => item.HotelID == hotelID &&
                        item.DailyRateDate == checkInDate &&
                        item.IsDailyRateActive)
                    .Select(item => new HotelDailyRateModel
                    {
                        HotelDailyRateID = item.HotelDailyRateID,
                        HotelID = item.HotelID,
                        DailyRateDate = item.DailyRateDate,
                        DailyBestAvailableRate = item.DailyBestAvailableRate,
                    }).FirstOrDefaultAsync();

                return Result.Success(dbHotelDailyBestAvailableRateData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelDailyRateByDate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel room list.");
            }
        }

        /// <summary>
        /// Retrieves the list of hotel rooms by check-in and check-out dates.
        /// </summary>
        /// <param name="dates">Check-in and check-out dates of the hotel rooms to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the list of <see cref="GetHotelRoomModel"/> for the specified dates.</returns>
        public async Task<Result<List<HotelRoomModel>>> GetHotelRoomByDates(int hotelID, DateTime checkInDate, DateTime checkOutDate)
        {
            try
            {
                _logger.LogInformation("Repository: GetHotelRoomByDates method initiated.");

                var dbHotelRoomData = await _checkinProContext.tblHotelRooms
                    .Where(item => item.HotelID == hotelID &&
                        !item.IsHotelRoomDeleted &&
                        item.IsHotelRoomActive &&
                        !_checkinProContext.tblHotelRoomBookings
                            .Any(booking =>
                                booking.HotelRoomID == item.HotelRoomID &&
                                ((checkInDate >= booking.ScheduledCheckInDate && checkInDate < booking.ScheduledCheckOutDate) ||
                                 (checkOutDate > booking.ScheduledCheckInDate && checkOutDate <= booking.ScheduledCheckOutDate) ||
                                 (checkInDate <= booking.ScheduledCheckInDate && checkOutDate >= booking.ScheduledCheckOutDate))
                            )
                    )
                    .Include(item => item.HotelRoomType)
                    .Select(item => new HotelRoomModel
                    {
                        HotelRoomID = item.HotelRoomID,
                        HotelRoomTypeID = item.HotelRoomTypeID,
                        RoomNumber = item.RoomNumber,
                        Floor = item.Floor,
                        MaxOccupancy = item.MaxOccupancy,
                        RoomStatus = item.RoomStatus,
                        Description = item.Description,
                        IsHotelRoomActive = item.IsHotelRoomActive,
                        HotelRoomType = new HotelRoomTypeModel
                        {
                            HotelID = item.HotelRoomType.HotelID,
                            HotelRoomTypeID = item.HotelRoomType.HotelRoomTypeID,
                            RoomTypeName = item.HotelRoomType.RoomTypeName,
                            RoomTypeIcon = item.HotelRoomType.RoomTypeIcon,
                            Description = item.HotelRoomType.Description,
                            AdjustmentRate = item.HotelRoomType.AdjustmentRate,
                            IsHotelRoomTypeActive = item.HotelRoomType.IsHotelRoomTypeActive
                        }
                    }).ToListAsync();

                return Result.Success(dbHotelRoomData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelRoomById method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel room list.");
            }
        }

        public async Task<Result<List<HotelRoomModel>>> GetAvailableRoomByDates(int hotelID, int hotelRoomTypeID, DateTime checkInDate, DateTime checkOutDate)
        {
            try
            {
                _logger.LogInformation("Repository: GetAvailableRoomRoomByDates method initiated.");

                var dbHotelRoomData = await _checkinProContext.tblHotelRooms
                    .Where(item => item.HotelID == hotelID && item.HotelRoomTypeID == hotelRoomTypeID && item.RoomStatus == CommonConstants.RoomStatusMessages.ReadyToCheckIn &&
                        !item.IsHotelRoomDeleted && item.IsHotelRoomActive && !_checkinProContext.tblHotelRoomBookings
                            .Any(booking =>
                                booking.HotelRoomID == item.HotelRoomID && booking.BookingStatus == BookingStatusMessages.CheckedIn &&
                                ((checkInDate >= booking.ScheduledCheckInDate && checkInDate < booking.ScheduledCheckOutDate) ||
                                 (checkOutDate > booking.ScheduledCheckInDate && checkOutDate <= booking.ScheduledCheckOutDate) ||
                                 (checkInDate <= booking.ScheduledCheckInDate && checkOutDate >= booking.ScheduledCheckOutDate))
                            )
                    )
                    .Include(item => item.HotelRoomType)
                    .Select(item => new HotelRoomModel
                    {
                        HotelRoomID = item.HotelRoomID,
                        HotelRoomTypeID = item.HotelRoomTypeID,
                        RoomNumber = item.RoomNumber,
                        Floor = item.Floor,
                        MaxOccupancy = item.MaxOccupancy,
                        RoomStatus = item.RoomStatus,
                    }).ToListAsync();

                return Result.Success(dbHotelRoomData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetAvailableRoomRoomByDates method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel room list.");
            }
        }


        /// <summary>
        /// Retrieves a list of mobile number.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of mobile numbers</returns>
        public async Task<Result<List<string>>> GetMobileNumbers(string searchTerm = null)
        {
            try
            {
                List<string> mobileNumbers = new List<string>();
                _logger.LogInformation("Repository: GetMobileNumbers method initiated.");
                if (string.IsNullOrWhiteSpace(searchTerm))
                {
                    mobileNumbers = await _checkinProContext.tblGuests
                    .Select(g => g.MobileNumber)
                    .Distinct()
                    .ToListAsync();
                }
                else
                {
                    string normalizedSearchTerm = new string(searchTerm.Where(char.IsDigit).ToArray());
                    mobileNumbers = await _checkinProContext.tblGuests
                .Where(g => EF.Functions.Like(g.MobileNumber, $"%{searchTerm}%") || // Match partial numbers with formatting
                            EF.Functions.Like(g.MobileNumber, $"%{normalizedSearchTerm}%")) // Match without formatting
                .Select(g => g.MobileNumber)
                .Distinct()
                .ToListAsync();
                }


                return Result.Success(mobileNumbers);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetMobileNumbers method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching mobile number list.");
            }
        }

        /// <summary>
        /// Retrieves a list of room types along with the number of available rooms for a given hotel.
        /// </summary>
        /// <param name="hotelID">The ID of the hotel.</param>
        /// <returns>A <see cref="Result"/> containing a list of room types with available room counts.</returns>
        public async Task<Result<List<HotelRoomTypeModel>>> GetAvailableRoomTypesByHotel(int hotelID, DateTime checkInDate, DateTime checkOutDate)
        {
            try
            {
                _logger.LogInformation("Repository: GetRoomTypeAvailabilityByDates method initiated.");

                var availableRoomTypes = await _checkinProContext.tblHotelRoomTypes
                    .Where(roomType => roomType.HotelID == hotelID && roomType.IsHotelRoomTypeActive && roomType.tblHotelRooms.Count > 0)
                    .Include(roomType => roomType.tblHotelRooms)
                    .Include(roomType => roomType.tblHotelRoomBookings)
                    .ToListAsync();

                // Now loop through each room type and calculate available room counts
                var roomTypeModels = new List<HotelRoomTypeModel>();

                foreach (var roomType in availableRoomTypes)
                {
                    var allocatedRoomsCount = _checkinProContext.tblHotelRoomBookings.Where(booking => booking.HotelRoomTypeID == roomType.HotelRoomTypeID &&
                                                                    ((checkInDate >= booking.ScheduledCheckInDate && checkInDate < booking.ScheduledCheckOutDate) ||
                                                                    (checkOutDate > booking.ScheduledCheckInDate && checkOutDate <= booking.ScheduledCheckOutDate) ||
                                                                    (checkInDate <= booking.ScheduledCheckInDate && checkOutDate >= booking.ScheduledCheckOutDate))).ToList();

                    var bookedRoomCount = allocatedRoomsCount.Count(item => item.BookingStatus == BookingStatusMessages.Booked);
                    var checkedInRoomCount = allocatedRoomsCount.Count(item => item.BookingStatus == BookingStatusMessages.CheckedIn);
                    var totalActiveRooms = roomType.tblHotelRooms.Count(room => room.IsHotelRoomActive && !room.IsHotelRoomDeleted && room.RoomStatus == RoomStatusMessages.ReadyToCheckIn);
                    var pendingRoomCleanCount = roomType.tblHotelRooms.Count(room => room.IsHotelRoomActive && !room.IsHotelRoomDeleted && room.RoomStatus == RoomStatusMessages.PendingCleaning);

                    // Ensure the available room count is never negative
                    //var availableRoomCount = Math.Max(0, totalActiveRooms - checkedInRoomCount - pendingRoomCleanCount);


                    roomTypeModels.Add(new HotelRoomTypeModel
                    {
                        HotelID = roomType.HotelID,
                        HotelRoomTypeID = roomType.HotelRoomTypeID,
                        RoomTypeName = roomType.RoomTypeName,
                        RoomTypeIcon = roomType.RoomTypeIcon,
                        Description = roomType.Description,
                        AdjustmentRate = roomType.AdjustmentRate,
                        IsHotelRoomTypeActive = roomType.IsHotelRoomTypeActive,
                        NumberOfRoomsAvailable = totalActiveRooms,
                        PendingRoomCleaning = pendingRoomCleanCount,
                        BookedRoom = bookedRoomCount
                    });
                }

                return Result.Success(roomTypeModels);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetRoomTypeAvailabilityByDates method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching room type availability.");
            }
        }

        /// <summary>
        /// Retrieves a list of booked hotel rooms having check-out today.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelRoomBookingModel"/> representing all hotel rooms data.</returns>
        public async Task<Result<List<GetHotelRoomBookingModel>>> GetTodaysCheckOutRoomsByHotelID(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetTodaysCheckOutRoomsByHotelID method initiated.");
                var today = DateTime.Today;
                var next24Hours = today.AddHours(24);
                var dbHotelRoomData = await _checkinProContext.tblHotelRoomBookings
                    .Include(booking => booking.HotelRoom) // Include HotelRoom data
                        .ThenInclude(room => room.HotelRoomType)
                    .Include(booking => booking.tblHotelRoomBookingGuests)    // Include Guest data
                        .ThenInclude(booking => booking.Guest)    // Include Guest data
                    .Where(booking => booking.HotelRoom.HotelID == hotelID
                       && booking.ScheduledCheckOutDate >= today
                       && booking.ScheduledCheckOutDate < next24Hours)  // Ensure only next24Hour's checkouts
                    .OrderBy(booking => booking.ScheduledCheckOutDate)
                    .Select(booking => new GetHotelRoomBookingModel
                    {
                        HotelRoomBookingID = booking.HotelRoomBookingID,
                        HotelRoomTypeID = booking.HotelRoomTypeID,
                        ScheduledCheckInDate = booking.ScheduledCheckInDate,
                        ScheduledCheckOutDate = booking.ScheduledCheckOutDate,
                        Duration = booking.Duration,
                        IsHourlyBooking = booking.IsHourlyBooking,
                        BookingStatus = booking.BookingStatus,
                        FinalAmount = booking.tblHotelRoomBookingRateDetails.Sum(item => item.FinalAmount),
                        HotelRoomType = new HotelRoomTypeModel
                        {
                            HotelRoomTypeID = booking.HotelRoomType.HotelRoomTypeID,
                            RoomTypeName = booking.HotelRoomType.RoomTypeName,
                            RoomTypeIcon = booking.HotelRoomType.RoomTypeIcon,
                            AdjustmentRate = booking.HotelRoomType.AdjustmentRate,
                            IsHotelRoomTypeActive = booking.HotelRoomType.IsHotelRoomTypeActive,
                        },
                        GetHotelRoom = new GetHotelRoomModel
                        {
                            RoomNumber = booking.HotelRoom.RoomNumber,
                            Floor = booking.HotelRoom.Floor,
                            RoomStatus = booking.HotelRoom.RoomStatus,
                        },
                        GetGuests = booking.tblHotelRoomBookingGuests.Select(guest => new GetGuestModel
                        {
                            IsPrimaryGuest = guest.IsPrimaryGuest,
                            FirstName = guest.Guest.FirstName,
                            LastName = guest.Guest.LastName
                        }).ToList(),
                    }).ToListAsync();

                return Result.Success(dbHotelRoomData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetTodaysCheckOutRoomsByHotelID method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching check out room list.");
            }
        }

        public async Task<Result<List<GetHotelRoomBookingModel>>> GetTodaysBookingsByHotelID(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetTodaysHotelRoomsByHotelID method initiated.");

                var dbHotelRoomData = await _checkinProContext.tblHotelRoomBookings
                    .Include(booking => booking.HotelRoomType)
                    .Include(booking => booking.HotelRoom)
                    .Include(booking => booking.tblPayments)
                    .Include(booking => booking.tblHotelRoomBookingGuests)
                        .ThenInclude(booking => booking.Guest)
                    .Where(booking => booking.HotelRoomType.HotelID == hotelID)
                    .Where(booking => booking.ScheduledCheckInDate.Value.Date == DateTime.Today || booking.ScheduledCheckOutDate.Value.Date == DateTime.Today || (booking.ScheduledCheckInDate.Value.Date <= DateTime.Today && booking.ScheduledCheckOutDate.Value.Date >= DateTime.Today))
                    .OrderByDescending(booking => booking.HotelRoomBookingID)
                    .Select(booking => new GetHotelRoomBookingModel
                    {
                        HotelRoomBookingID = booking.HotelRoomBookingID,
                        HotelRoomTypeID = booking.HotelRoomTypeID,
                        HotelRoomID = booking.HotelRoomID,
                        BookingCode = booking.BookingCode,
                        IsHourlyBooking = booking.IsHourlyBooking,
                        ScheduledCheckInDate = booking.ScheduledCheckInDate,
                        ScheduledCheckOutDate = booking.ScheduledCheckOutDate,
                        Duration = booking.Duration,
                        ActualCheckInDate = booking.ActualCheckInDate,
                        ActualCheckOutDate = booking.ActualCheckOutDate,
                        BookingStatus = booking.BookingStatus,
                        FinalAmount = booking.tblHotelRoomBookingRateDetails.Sum(item => item.FinalAmount),
                        TotalPaid = booking.tblPayments.Sum(item => item.Amount),
                        HotelRoomType = new HotelRoomTypeModel
                        {
                            HotelRoomTypeID = booking.HotelRoomType.HotelRoomTypeID,
                            RoomTypeName = booking.HotelRoomType.RoomTypeName,
                            RoomTypeIcon = booking.HotelRoomType.RoomTypeIcon,
                            AdjustmentRate = booking.HotelRoomType.AdjustmentRate,
                            IsHotelRoomTypeActive = booking.HotelRoomType.IsHotelRoomTypeActive,
                        },
                        GetHotelRoom = new GetHotelRoomModel
                        {
                            RoomNumber = booking.HotelRoom.RoomNumber,
                            Floor = booking.HotelRoom.Floor,
                            RoomStatus = booking.HotelRoom.RoomStatus,
                        },
                        GetGuests = booking.tblHotelRoomBookingGuests.Select(guest => new GetGuestModel
                        {
                            IsPrimaryGuest = guest.IsPrimaryGuest,
                            FirstName = guest.Guest.FirstName,
                            LastName = guest.Guest.LastName
                        }).ToList(),
                    }).ToListAsync();

                return Result.Success(dbHotelRoomData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetTodaysHotelRoomsByHotelID method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching today's booked hotel room list.");
            }
        }


        /// <summary>
        /// Retrieves a list of booked hotel rooms.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelRoomBookingModel"/> representing all hotel rooms data.</returns>
        public async Task<Result<List<GetHotelRoomBookingModel>>> GetBookedHotelRoomsByHotelID(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetBookedHotelRoomsByHotelID method initiated.");

                var dbHotelRoomData = await _checkinProContext.tblHotelRoomBookings
                    .Include(booking => booking.HotelRoomType)
                    .Include(booking => booking.HotelRoom)
                    .Include(booking => booking.tblPayments)
                    .Include(booking => booking.tblHotelRoomBookingGuests)
                        .ThenInclude(booking => booking.Guest)
                    .Where(booking => booking.HotelRoomType.HotelID == hotelID)
                    .OrderByDescending(booking => booking.HotelRoomBookingID)
                    .Select(booking => new GetHotelRoomBookingModel
                    {
                        HotelRoomBookingID = booking.HotelRoomBookingID,
                        HotelRoomTypeID = booking.HotelRoomTypeID,
                        HotelRoomID = booking.HotelRoomID,
                        BookingCode = booking.BookingCode,
                        IsHourlyBooking = booking.IsHourlyBooking,
                        ScheduledCheckInDate = booking.ScheduledCheckInDate,
                        ScheduledCheckOutDate = booking.ScheduledCheckOutDate,
                        Duration = booking.Duration,
                        ActualCheckInDate = booking.ActualCheckInDate,
                        ActualCheckOutDate = booking.ActualCheckOutDate,
                        BookingStatus = booking.BookingStatus,
                        FinalAmount = booking.tblHotelRoomBookingRateDetails.Sum(item => item.FinalAmount),
                        TotalPaid = booking.tblPayments.Sum(item => item.Amount),
                        HotelRoomType = new HotelRoomTypeModel
                        {
                            HotelRoomTypeID = booking.HotelRoomType.HotelRoomTypeID,
                            RoomTypeName = booking.HotelRoomType.RoomTypeName,
                            RoomTypeIcon = booking.HotelRoomType.RoomTypeIcon,
                            AdjustmentRate = booking.HotelRoomType.AdjustmentRate,
                            IsHotelRoomTypeActive = booking.HotelRoomType.IsHotelRoomTypeActive,
                        },
                        GetHotelRoom = new GetHotelRoomModel
                        {
                            RoomNumber = booking.HotelRoom.RoomNumber,
                            Floor = booking.HotelRoom.Floor,
                            RoomStatus = booking.HotelRoom.RoomStatus,
                        },
                        GetGuests = booking.tblHotelRoomBookingGuests.Select(guest => new GetGuestModel
                        {
                            IsPrimaryGuest = guest.IsPrimaryGuest,
                            FirstName = guest.Guest.FirstName,
                            LastName = guest.Guest.LastName
                        }).ToList(),
                    }).ToListAsync();

                return Result.Success(dbHotelRoomData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetBookedHotelRoomsByHotelID method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching booked hotel room list.");
            }
        }

        /// <summary>
        /// Retrieves a list of booked hotel rooms.
        /// </summary>
        /// <param name="hotelRoomBookingID">The ID of the hotel room to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing a details of <see cref="GetHotelRoomBookingModel"/> booked room.</returns>
        public async Task<Result<HotelRoomBookingModel>> GetRoomBookingDetailsByID(int hotelRoomBookingID)
        {
            try
            {
                _logger.LogInformation("Repository: GetRoomBookingDetailsByID method initiated.");

                var dbHotelRoomBookingData = await _checkinProContext.tblHotelRoomBookings
                    .Include(booking => booking.HotelRoomType)
                    .Include(booking => booking.HotelRoom)
                    .Include(booking => booking.tblHotelRoomBookingGuests)
                        .ThenInclude(booking => booking.Guest)
                    .Include(booking => booking.tblPayments)
                    .Include(booking => booking.tblHotelRoomBookingTaxRates)
                    .Include(booking => booking.tblHotelRoomBookingAudits)
                    .Where(booking => booking.HotelRoomBookingID == hotelRoomBookingID) // Filter by HotelRoomBookingID
                    .Select(booking => new HotelRoomBookingModel
                    {
                        HotelRoomBookingID = booking.HotelRoomBookingID,
                        HotelRoomTypeID = booking.HotelRoomTypeID,
                        HotelRoomID = booking.HotelRoomID,
                        BookingCode = booking.BookingCode,
                        ScheduledCheckInDate = booking.ScheduledCheckInDate,
                        ScheduledCheckOutDate = booking.ScheduledCheckOutDate,
                        Duration = booking.Duration,
                        ActualCheckInDate = booking.ActualCheckInDate,
                        ActualCheckOutDate = booking.ActualCheckOutDate,
                        NumberOfGuests = booking.NumberOfGuests,
                        IsHourlyBooking = booking.IsHourlyBooking,
                        //BestAvailableRate = booking.BestAvailableRate,
                        //AdjustmentRate = booking.AdjustmentRate,
                        //HourlyRate = booking.HourlyRate,
                        //SubTotalAmount = booking.SubTotalAmount,
                        //TotalAmount = booking.TotalAmount,
                        //IsDiscountedRate = booking.IsDiscountedRate,
                        //AdditionalRateType = booking.AdditionalRateType,
                        //AdditionalRateAmount = booking.AdditionalRateAmount,
                        //DiscountedAmount = booking.DiscountedAmount,
                        //MiscellaneousAmount = booking.MiscellaneousAmount,
                        //FinalAmount = booking.FinalAmount,
                        BookingStatus = booking.BookingStatus,
                        //PaymentStatus = booking.PaymentStatus,
                        GuestSpecialRequests = booking.GuestSpecialRequests,
                        GuestNoteType = booking.GuestNoteType,
                        GuestNotes = booking.GuestNotes,
                        IsBookingCancelled = booking.IsBookingCancelled,
                        CancellationReason = booking.CancellationReason,
                        IsIncludedInReport = booking.IsIncludedInReport,
                        //IsBookingExtend = booking.IsBookingExtend,
                        //IsExtended = booking.IsExtended,
                        //OriginalHotelRoomBookingID = booking.OriginalHotelRoomBookingID,
                        HotelRoomType = new HotelRoomTypeModel
                        {
                            RoomTypeName = booking.HotelRoomType.RoomTypeName,
                            RoomTypeIcon = booking.HotelRoomType.RoomTypeIcon,
                            AdjustmentRate = booking.HotelRoomType.AdjustmentRate,
                        },
                        HotelRoom = new AddEditHotelRoomModel
                        {
                            RoomNumber = booking.HotelRoom.RoomNumber,
                            Floor = booking.HotelRoom.Floor,
                            MaxOccupancy = booking.HotelRoom.MaxOccupancy,
                            RoomStatus = booking.HotelRoom.RoomStatus,
                            Description = booking.HotelRoom.Description,
                        },
                        Guests = booking.tblHotelRoomBookingGuests.Select(booking => new AddGuestModel
                        {
                            GuestID = booking.Guest.GuestID,
                            FirstName = booking.Guest.FirstName,
                            LastName = booking.Guest.LastName,
                            GuestCode = booking.Guest.GuestCode,
                            IdentityType = booking.Guest.IdentityType,
                            IdentityNumber = booking.Guest.IdentityNumber,
                            FrontSideImage = booking.Guest.FrontSideImage != null ? Convert.ToBase64String(booking.Guest.FrontSideImage) : null,
                            MobileNumber = booking.Guest.MobileNumber,
                            Email = booking.Guest.Email,
                            Address1 = booking.Guest.Address1,
                            Address2 = booking.Guest.Address2,
                            Country = booking.Guest.Country,
                            State = booking.Guest.State,
                            City = booking.Guest.City,
                            ZipCode = booking.Guest.ZipCode,
                            IsGuestScanned = booking.Guest.IsGuestScanned,
                            IsPrimaryGuest = booking.IsPrimaryGuest
                        }).ToList(),
                        HotelRoomBookingRateDetails = booking.tblHotelRoomBookingRateDetails.Select(item => new HotelRoomBookingRateDetailModel
                        {
                            HotelRoomBookingRateDetailID = item.HotelRoomBookingRateDetailID,
                            CheckInDate = item.CheckInDate,
                            CheckOutDate = item.CheckOutDate,
                            Duration = item.Duration,
                            BestAvailableRate = item.BestAvailableRate,
                            AdjustmentRate = item.AdjustmentRate,
                            HourlyRate = item.HourlyRate,
                            RoomChargeAmount = item.RoomChargeAmount,
                            TotalAmount = item.TotalAmount,
                            IsDiscountedRate = item.IsDiscountedRate,
                            AdditionalRateType = item.AdditionalRateType,
                            AdditionalRateAmount = item.AdditionalRateAmount,
                            DiscountedAmount = item.DiscountedAmount,
                            MiscellaneousAmount = item.MiscellaneousAmount,
                            FinalAmount = item.FinalAmount,
                            Balance = item.Balance,
                            IsExtend = item.IsExtend,
                            IsBookingActive = item.IsBookingActive,
                            CreatedDate = item.CreatedDate,
                            HotelRoomBookingTaxRates = booking.tblHotelRoomBookingTaxRates.Where(h => h.HotelRoomBookingRateDetailID == item.HotelRoomBookingRateDetailID).Select(item => new HotelRoomBookingTaxRateModel
                            {
                                HotelRoomBookingTaxRateID = item.HotelRoomBookingTaxRateID,
                                HotelTaxRateID = item.HotelTaxRateID,
                                BookingTaxRateName = item.BookingTaxRateName,
                                BookingTaxRatePercentage = item.BookingTaxRatePercentage,
                                BookingTaxRate = item.BookingTaxRate,
                                IsBookingTaxRateActive = item.IsBookingTaxRateActive
                            }).ToList(),
                        }).ToList(),
                        HotelRoomBookingTaxRates = booking.tblHotelRoomBookingTaxRates.Select(item => new HotelRoomBookingTaxRateModel
                        {
                            HotelRoomBookingTaxRateID = item.HotelRoomBookingTaxRateID,
                            HotelTaxRateID = item.HotelTaxRateID,
                            BookingTaxRateName = item.BookingTaxRateName,
                            BookingTaxRatePercentage = item.BookingTaxRatePercentage,
                            BookingTaxRate = item.BookingTaxRate,
                            IsBookingTaxRateActive = item.IsBookingTaxRateActive
                        }).ToList(),
                        HotelRoomBookingAudits = booking.tblHotelRoomBookingAudits.Select(item => new HotelRoomBookingAuditModel
                        {
                            ActionName = item.ActionName,
                            ActionDateTime = item.ActionDateTime,
                            ActionBy = item.ActionBy,
                            ActionComment = item.ActionComment
                        }).ToList(),
                        HotelRoomPayments = booking.tblPayments.Select(item => new AddPaymentModel
                        {
                            PaymentID = item.PaymentID,
                            PaymentDate = item.PaymentDate,
                            PaymentCompletedOn = item.PaymentCompletedOn,
                            Amount = item.Amount,
                            PaymentMode = item.PaymentMode,
                            PaymentType = item.PaymentType,
                            PaymentStatus = item.PaymentStatus,
                            PaymentGateway = item.PaymentGateway,
                            TransactionID = item.TransactionID,
                            //TransactionType = item.TransactionType,
                            PaymentNotes = item.PaymentNotes,
                            IsRefunded = item.IsRefunded,
                            RefundDate = item.RefundDate,
                            RefundAmount = item.RefundAmount,
                            RefundNotes = item.RefundNotes,
                        }).ToList(),
                    })
                    .FirstOrDefaultAsync(); // Get the first record or null
                return Result.Success(dbHotelRoomBookingData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetRoomBookingDetailsByID method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching booked room details.");
            }
        }

        /// <summary> 
        /// Adds a new hotel room booking record based on the provided hotelRoomBookingRequestModel.
        /// </summary>
        /// <param name="hotelRoomBookingRequestModel">The <see cref="HotelRoomBookingModel"/> containing data for the new hotel room booking.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel room booking creation operation.</returns>

        //public async Task<Result> AddHotelRoomBookings(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel)
        //{
        //    using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
        //    {
        //        try
        //        {
        //            _logger.LogInformation("Repository: AddEditHotelRoomBooking method initiated.");

        //            // Validate the request model
        //            if (hotelRoomBookingRequestModel == null)
        //            {
        //                _logger.LogWarning("Repository: AddEditHotelRoomBooking called with a null hotelRoomBookingRequestModel.");
        //                return Result.NoContent();
        //            }


        //            tblGuest dbGuest = new tblGuest
        //            {
        //                FirstName = hotelRoomBookingRequestModel.Guest.FirstName,
        //                LastName = hotelRoomBookingRequestModel.Guest.LastName,
        //                IdentityType = hotelRoomBookingRequestModel.Guest.IdentityType,
        //                IdentityNumber = hotelRoomBookingRequestModel.Guest.IdentityNumber,
        //                FrontSideImage = hotelRoomBookingRequestModel.Guest.FrontSideImage,
        //                MobileNumber = hotelRoomBookingRequestModel.Guest.MobileNumber,
        //                Email = hotelRoomBookingRequestModel.Guest.Email,
        //                Address1 = hotelRoomBookingRequestModel.Guest.Address1,
        //                Address2 = hotelRoomBookingRequestModel.Guest.Address2,
        //                StateID = hotelRoomBookingRequestModel.Guest.StateID,
        //                City = hotelRoomBookingRequestModel.Guest.City,
        //                ZipCode = hotelRoomBookingRequestModel.Guest.ZipCode,
        //                ProfilePicture = hotelRoomBookingRequestModel.Guest.ProfilePicture,
        //                CreatedBy = auditInfoModel.AuditUserID,
        //                CreatedDate = DateTime.Now,
        //            };
        //            // Check if the booking already exists in the database
        //            var dbHotelRoomBooking = await _checkinProContext.tblHotelRoomBookings
        //                .FirstOrDefaultAsync(br => br.HotelRoomBookingID == hotelRoomBookingRequestModel.HotelRoomBookingID);



        //            // Create a new hotel room booking entity and add it to the database
        //            dbHotelRoomBooking = new tblHotelRoomBooking
        //            {
        //                HotelRoomTypeID = hotelRoomBookingRequestModel.HotelRoomTypeID,
        //                ScheduledCheckInDate = hotelRoomBookingRequestModel.ScheduledCheckInDate,
        //                ScheduledCheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckOutDate,
        //                Duration = hotelRoomBookingRequestModel.Duration,
        //                ActualCheckInDate = hotelRoomBookingRequestModel.ActualCheckInDate,
        //                ActualCheckOutDate = hotelRoomBookingRequestModel.ActualCheckOutDate,
        //                NumberOfGuests = hotelRoomBookingRequestModel.NumberOfGuests,
        //                IsHourlyBooking = hotelRoomBookingRequestModel.IsHourlyBooking,
        //                BestAvailableRate = hotelRoomBookingRequestModel.BestAvailableRate,
        //                AdjustmentRate = hotelRoomBookingRequestModel.AdjustmentRate,
        //                HourlyRate = hotelRoomBookingRequestModel.HourlyRate,
        //                SubTotalAmount = hotelRoomBookingRequestModel.SubTotalAmount,
        //                TotalAmount = hotelRoomBookingRequestModel.TotalAmount,
        //                AdditionalRateType = hotelRoomBookingRequestModel.AdditionalRateType,
        //                AdditionalRateAmount = hotelRoomBookingRequestModel.AdditionalRateAmount,
        //                DiscountedAmount = hotelRoomBookingRequestModel.DiscountedAmount,
        //                FinalAmount = hotelRoomBookingRequestModel.FinalAmount,
        //                BookingStatus = hotelRoomBookingRequestModel.BookingStatus,
        //                PaymentStatus = hotelRoomBookingRequestModel.PaymentStatus,
        //                GuestSpecialRequests = hotelRoomBookingRequestModel.GuestSpecialRequests,
        //                GuestNoteType = hotelRoomBookingRequestModel.GuestNoteType,
        //                GuestNotes = hotelRoomBookingRequestModel.GuestNotes,
        //                CreatedBy = auditInfoModel.AuditUserID,
        //                CreatedDate = DateTime.Now,
        //                tblHotelRoomBookingTaxRates = hotelRoomBookingRequestModel.HotelRoomBookingTaxRates.Select(item => new tblHotelRoomBookingTaxRate
        //                {
        //                    HotelTaxRateID = item.HotelTaxRateID,
        //                    BookingTaxRateName = item.BookingTaxRateName,
        //                    BookingTaxRatePercentage = item.BookingTaxRatePercentage,
        //                    BookingTaxRate = item.BookingTaxRate,
        //                    CreatedBy = auditInfoModel.AuditUserID,
        //                    CreatedDate = DateTime.Now
        //                }).ToList(),
        //                tblPayments = hotelRoomBookingRequestModel.HotelRoomPayments.Select(item => new tblPayment
        //                {
        //                    PaymentDate = item.PaymentDate ?? DateTime.Now,
        //                    Amount = item.Amount,
        //                    PaymentMode = item.PaymentMode,
        //                    PaymentStatus = item.PaymentStatus,
        //                    PaymentGateway = item.PaymentGateway,
        //                    TransactionID = item.TransactionID,
        //                    TransactionType = item.TransactionType,
        //                    PaymentNotes = item.PaymentNotes,
        //                    CreatedBy = auditInfoModel.AuditUserID,
        //                    CreatedDate = DateTime.Now
        //                }).ToList(),
        //            };

        //            if (hotelRoomBookingRequestModel.HotelRoom.RoomStatus != null)
        //            {
        //                var hotelRoomEntity = await _checkinProContext.tblHotelRooms.FirstOrDefaultAsync(hr => hr.HotelRoomID == hotelRoomBookingRequestModel.HotelRoomID);
        //                if (hotelRoomEntity != null)
        //                {
        //                    hotelRoomEntity.RoomStatus = hotelRoomBookingRequestModel.HotelRoom.RoomStatus;
        //                }
        //                dbHotelRoomBooking.HotelRoom = hotelRoomEntity;
        //            }

        //            if (hotelRoomBookingRequestModel.BookingStatus == BookingStatusMessages.CheckedIn)
        //            {
        //                dbHotelRoomBooking.ActualCheckInDate = DateTime.Now;
        //                dbHotelRoomBooking.HotelRoomID = hotelRoomBookingRequestModel.HotelRoomID;
        //            }

        //            //if (hotelRoomBookingRequestModel.GuestID == 0)
        //            //{
        //            //    dbHotelRoomBooking.Guest = dbGuest;
        //            //}
        //            //else
        //            //{
        //            //    dbHotelRoomBooking.GuestID = hotelRoomBookingRequestModel.GuestID;
        //            //}

        //            await _checkinProContext.tblHotelRoomBookings.AddAsync(dbHotelRoomBooking);
        //            await _checkinProContext.SaveChangesAsync();
        //            await transaction.CommitAsync();

        //            _logger.LogInformation($"Repository: Successfully added hotel room booked.");
        //            return Result.Success();
        //        }
        //        catch (DbUpdateException dbEx)
        //        {
        //            await transaction.RollbackAsync();
        //            _logger.LogError($"Repository: Database error occurred while adding or updating hotel room booking. {dbEx.Message}");
        //            return Result.Error("A database error occurred. Please try again later.");
        //        }
        //        catch (Exception ex)
        //        {
        //            await transaction.RollbackAsync();
        //            _logger.LogError($"Repository: AddEditHotelRoomBooking Exception occurred. Stacktrace: {ex}");
        //            return Result.Error("An error occurred while adding or updating the hotel room booking.");
        //        }
        //    }
        //}

        //public async Task<Result<int>> AddHotelRoomBooking(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel)
        //{
        //    using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
        //    {
        //        try
        //        {
        //            _logger.LogInformation("Repository: AddHotelRoomBooking method initiated.");

        //            // Validate the request model
        //            if (hotelRoomBookingRequestModel == null || hotelRoomBookingRequestModel.Guests == null || !hotelRoomBookingRequestModel.Guests.Any())
        //            {
        //                _logger.LogWarning("Repository: AddHotelRoomBooking called with invalid request.");
        //                return Result.NoContent();
        //            }

        //            // Create a new hotel room booking entity             

        //            tblHotelRoomBooking dbHotelRoomBooking = new tblHotelRoomBooking
        //            {
        //                HotelRoomTypeID = hotelRoomBookingRequestModel.HotelRoomTypeID,
        //                ScheduledCheckInDate = hotelRoomBookingRequestModel.ScheduledCheckInDate,
        //                ScheduledCheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckOutDate,
        //                Duration = hotelRoomBookingRequestModel.Duration,
        //                //ActualCheckInDate = hotelRoomBookingRequestModel.ActualCheckInDate,
        //                //ActualCheckOutDate = hotelRoomBookingRequestModel.ActualCheckOutDate,
        //                NumberOfGuests = hotelRoomBookingRequestModel.NumberOfGuests,
        //                IsHourlyBooking = hotelRoomBookingRequestModel.IsHourlyBooking,
        //                //BestAvailableRate = hotelRoomBookingRequestModel.BestAvailableRate,
        //                //AdjustmentRate = hotelRoomBookingRequestModel.AdjustmentRate,
        //                //HourlyRate = hotelRoomBookingRequestModel.HourlyRate,
        //                //SubTotalAmount = hotelRoomBookingRequestModel.SubTotalAmount,
        //                //TotalAmount = hotelRoomBookingRequestModel.TotalAmount,
        //                //IsDiscountedRate = hotelRoomBookingRequestModel.IsDiscountedRate,
        //                //AdditionalRateType = hotelRoomBookingRequestModel.AdditionalRateType,
        //                //AdditionalRateAmount = hotelRoomBookingRequestModel.AdditionalRateAmount,
        //                //DiscountedAmount = hotelRoomBookingRequestModel.DiscountedAmount,
        //                //FinalAmount = hotelRoomBookingRequestModel.FinalAmount,
        //                BookingStatus = BookingStatusMessages.Booked,
        //                //PaymentStatus = hotelRoomBookingRequestModel.PaymentStatus,
        //                GuestSpecialRequests = hotelRoomBookingRequestModel.GuestSpecialRequests,
        //                GuestNoteType = hotelRoomBookingRequestModel.GuestNoteType,
        //                GuestNotes = hotelRoomBookingRequestModel.GuestNotes,
        //                CreatedBy = auditInfoModel.AuditUserID,
        //                CreatedDate = DateTime.Now,
        //                tblHotelRoomBookingRateDetails = hotelRoomBookingRequestModel.HotelRoomBookingRateDetails.Select(item => new tblHotelRoomBookingRateDetail
        //                {
        //                    CheckInDate = hotelRoomBookingRequestModel.ScheduledCheckInDate,
        //                    CheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckOutDate,
        //                    Duration = hotelRoomBookingRequestModel.Duration,
        //                    BestAvailableRate = item.BestAvailableRate,
        //                    AdjustmentRate = item.AdjustmentRate,
        //                    HourlyRate = item.HourlyRate,
        //                    RoomChargeAmount = item.RoomChargeAmount,
        //                    TotalAmount = item.TotalAmount,
        //                    IsDiscountedRate = item.IsDiscountedRate,
        //                    AdditionalRateType = item.AdditionalRateType,
        //                    AdditionalRateAmount = item.AdditionalRateAmount,
        //                    DiscountedAmount = item.DiscountedAmount,
        //                    FinalAmount = item.FinalAmount,
        //                    CreatedBy = auditInfoModel.AuditUserID,
        //                    CreatedDate = DateTime.Now
        //                }).ToList(),
        //                //tblHotelRoomBookingTaxRates = hotelRoomBookingRequestModel.HotelRoomBookingTaxRates.Select(item => new tblHotelRoomBookingTaxRate
        //                //{
        //                //    HotelTaxRateID = item.HotelTaxRateID,
        //                //    BookingTaxRateName = item.BookingTaxRateName,
        //                //    BookingTaxRatePercentage = item.BookingTaxRatePercentage,
        //                //    BookingTaxRate = item.BookingTaxRate,
        //                //    CreatedBy = auditInfoModel.AuditUserID,
        //                //    CreatedDate = DateTime.Now
        //                //}).ToList(),
        //                //tblPayments = hotelRoomBookingRequestModel.HotelRoomPayments.Select(item => new tblPayment
        //                //{
        //                //    PaymentDate = item.PaymentDate ?? DateTime.Now,
        //                //    Amount = item.Amount,
        //                //    PaymentMode = item.PaymentMode,
        //                //    PaymentType = item.PaymentType,
        //                //    PaymentStatus = item.PaymentStatus,
        //                //    PaymentGateway = item.PaymentGateway,
        //                //    TransactionID = item.TransactionID,
        //                //    //TransactionType = item.TransactionType,
        //                //    PaymentNotes = item.PaymentNotes,
        //                //    CreatedBy = auditInfoModel.AuditUserID,
        //                //    CreatedDate = DateTime.Now,
        //                //    PaymentCompletedOn = item.PaymentStatus == "Completed" ? DateTime.Now : (DateTime?)null
        //                //}).ToList(),
        //            };



        //            //if (hotelRoomBookingRequestModel.IsBookingExtend)
        //            //{
        //            //    dbHotelRoomBooking.HotelRoomID = hotelRoomBookingRequestModel.HotelRoomID;
        //            //    dbHotelRoomBooking.IsExtended = hotelRoomBookingRequestModel.IsBookingExtend;
        //            //    dbHotelRoomBooking.OriginalHotelRoomBookingID = hotelRoomBookingRequestModel.OriginalHotelRoomBookingID;

        //            //    var oldBookingData = _checkinProContext.tblHotelRoomBookings.FirstOrDefault(item => item.HotelRoomBookingID == hotelRoomBookingRequestModel.OriginalHotelRoomBookingID);
        //            //    if (oldBookingData != null)
        //            //    {
        //            //        oldBookingData.IsBookingExtend = hotelRoomBookingRequestModel.IsBookingExtend;
        //            //    }
        //            //}

        //            // Link the hotel room booking to a hotel room, if provided
        //            if (hotelRoomBookingRequestModel.HotelRoomID.HasValue)
        //            {
        //                var hotelRoomEntity = await _checkinProContext.tblHotelRooms.FirstOrDefaultAsync(hr => hr.HotelRoomID == hotelRoomBookingRequestModel.HotelRoomID);
        //                if (hotelRoomEntity != null)
        //                {
        //                    dbHotelRoomBooking.HotelRoom = hotelRoomEntity;
        //                }
        //            }

        //            await _checkinProContext.tblHotelRoomBookings.AddAsync(dbHotelRoomBooking);
        //            await _checkinProContext.SaveChangesAsync();


        //            //var rateDetails = hotelRoomBookingRequestModel.HotelRoomBookingRateDetails.Select(item => new tblHotelRoomBookingRateDetail
        //            //{
        //            //    CheckInDate = hotelRoomBookingRequestModel.ScheduledCheckInDate,
        //            //    CheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckOutDate,
        //            //    Duration = hotelRoomBookingRequestModel.Duration,
        //            //    BestAvailableRate = item.BestAvailableRate,
        //            //    AdjustmentRate = item.AdjustmentRate,
        //            //    HourlyRate = item.HourlyRate,
        //            //    RoomChargeAmount = item.RoomChargeAmount,
        //            //    TotalAmount = item.TotalAmount,
        //            //    IsDiscountedRate = item.IsDiscountedRate,
        //            //    AdditionalRateType = item.AdditionalRateType,
        //            //    AdditionalRateAmount = item.AdditionalRateAmount,
        //            //    DiscountedAmount = item.DiscountedAmount,
        //            //    FinalAmount = item.FinalAmount,
        //            //    CreatedBy = auditInfoModel.AuditUserID,
        //            //    CreatedDate = DateTime.Now
        //            //}).ToList();

        //            var rateDetails = dbHotelRoomBooking.tblHotelRoomBookingRateDetails.ToList();
        //            var taxRates = hotelRoomBookingRequestModel.HotelRoomBookingTaxRates.Select((item, index) => new tblHotelRoomBookingTaxRate
        //            {
        //                HotelRoomBookingID = dbHotelRoomBooking.HotelRoomBookingID,
        //                HotelRoomBookingRateDetailID = rateDetails.ElementAtOrDefault(index)?.HotelRoomBookingRateDetailID ?? 0,
        //                HotelTaxRateID = item.HotelTaxRateID,
        //                BookingTaxRateName = item.BookingTaxRateName,
        //                BookingTaxRatePercentage = item.BookingTaxRatePercentage,
        //                BookingTaxRate = item.BookingTaxRate,
        //                CreatedBy = auditInfoModel.AuditUserID,
        //                CreatedDate = DateTime.Now,
        //            }).ToList();

        //            await _checkinProContext.tblHotelRoomBookingTaxRates.AddRangeAsync(taxRates);

        //            var payments = hotelRoomBookingRequestModel.HotelRoomPayments.Select((item, index) => new tblPayment
        //            {
        //                HotelRoomBookingID = dbHotelRoomBooking.HotelRoomBookingID,
        //                HotelRoomBookingRateDetailID = rateDetails.ElementAtOrDefault(index)?.HotelRoomBookingRateDetailID ?? 0,
        //                PaymentDate = item.PaymentDate ?? DateTime.Now,
        //                Amount = item.Amount,
        //                PaymentMode = item.PaymentMode,
        //                PaymentType = item.PaymentType,
        //                PaymentStatus = item.PaymentStatus,
        //                PaymentGateway = item.PaymentGateway,
        //                TransactionID = item.TransactionID,
        //                //TransactionType = item.TransactionType,
        //                PaymentNotes = item.PaymentNotes,
        //                CreatedBy = auditInfoModel.AuditUserID,
        //                CreatedDate = DateTime.Now,
        //                PaymentCompletedOn = item.PaymentStatus == "Completed" ? DateTime.Now : (DateTime?)null
        //            }).ToList();

        //            await _checkinProContext.tblPayments.AddRangeAsync(payments);

        //            // Link guests to the booking (this is the new part for adding multiple guests)
        //            foreach (var guestModel in hotelRoomBookingRequestModel.Guests)
        //            {
        //                // Check if a guest with the same IdentityNumber and MobileNumber already exists for this booking
        //                var existingGuest = await _checkinProContext.tblGuests
        //                    .Where(g => g.IdentityNumber == guestModel.IdentityNumber)
        //                    .FirstOrDefaultAsync();

        //                tblGuest dbGuest = null;

        //                // If the guest does not exist, create a new guest and add it
        //                if (existingGuest == null)
        //                {
        //                    dbGuest = new tblGuest
        //                    {
        //                        FirstName = guestModel.FirstName,
        //                        LastName = guestModel.LastName,
        //                        IdentityType = guestModel.IdentityType,
        //                        IdentityNumber = guestModel.IdentityNumber,
        //                        //FrontSideImage = ConvertFrontSideImageToByte(guestModel.FrontSideImage),
        //                        MobileNumber = guestModel.MobileNumber,
        //                        Email = guestModel.Email,
        //                        Address1 = guestModel.Address1,
        //                        Address2 = guestModel.Address2,
        //                        Country = guestModel.Country,
        //                        State = guestModel.State,
        //                        City = guestModel.City,
        //                        ZipCode = guestModel.ZipCode,
        //                        ScanID = guestModel.ScanID,
        //                        IsGuestScanned = guestModel.IsGuestScanned,
        //                        ProfilePicture = guestModel.ProfilePicture,
        //                        CreatedBy = auditInfoModel.AuditUserID,
        //                        CreatedDate = DateTime.Now
        //                    };
        //                    if (guestModel.FrontSideImage != null)
        //                    {
        //                        dbGuest.FrontSideImage = ConvertFrontSideImageToByte(guestModel.FrontSideImage);
        //                    }
        //                }
        //                else
        //                {
        //                    dbGuest = existingGuest;
        //                }

        //                tblHotelRoomBookingGuest dbHotelRoomBookingGuests = new tblHotelRoomBookingGuest()
        //                {
        //                    HotelRoomBookingID = dbHotelRoomBooking.HotelRoomBookingID,
        //                    IsPrimaryGuest = guestModel.IsPrimaryGuest,
        //                    CreatedBy = auditInfoModel.AuditUserID,
        //                    CreatedDate = DateTime.Now,
        //                    Guest = dbGuest,
        //                    HotelRoomBooking = dbHotelRoomBooking,
        //                };
        //                await _checkinProContext.tblHotelRoomBookingGuests.AddAsync(dbHotelRoomBookingGuests);
        //            }

        //            // Add the hotel room booking record to the context
        //            //await _checkinProContext.tblHotelRoomBookings.AddAsync(dbHotelRoomBooking);
        //            //await _checkinProContext.tblHotelRoomBookingGuests.AddAsync(dbHotelRoomBooking);

        //            // Commit changes
        //            await _checkinProContext.SaveChangesAsync();
        //            await transaction.CommitAsync();

        //            if (dbHotelRoomBooking.HotelRoomBookingID != 0 && hotelRoomBookingRequestModel.HotelRoomID > 0 && hotelRoomBookingRequestModel.ScheduledCheckInDate.Value.Date == GetCheckInMinDate(hotelRoomBookingRequestModel.IsHourlyBooking).Date)
        //            {
        //                await RoomCheckIn(dbHotelRoomBooking.HotelRoomBookingID, hotelRoomBookingRequestModel.HotelRoomID ?? 0, auditInfoModel);
        //            }
        //            _logger.LogInformation($"Repository: Successfully added hotel room booking with multiple guests.");


        //            //if (hotelRoomBookingRequestModel.IsBookingExtend)
        //            //{
        //            //    return Result<int>.Success(hotelRoomBookingRequestModel.OriginalHotelRoomBookingID ?? 0);
        //            //}
        //            //else
        //            //{
        //            return Result<int>.Success(dbHotelRoomBooking.HotelRoomBookingID);
        //            //}

        //        }
        //        catch (DbUpdateException dbEx)
        //        {
        //            await transaction.RollbackAsync();
        //            _logger.LogError($"Repository: Database error occurred while adding or updating hotel room booking. {dbEx.Message}");
        //            return Result.Error("A database error occurred. Please try again later.");
        //        }
        //        catch (Exception ex)
        //        {
        //            await transaction.RollbackAsync();
        //            _logger.LogError($"Repository: AddHotelRoomBooking Exception occurred. Stacktrace: {ex}");
        //            return Result.Error("An error occurred while adding the hotel room booking.");
        //        }
        //    }
        //}


        public async Task<Result<int>> AddHotelRoomBooking(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddHotelRoomBooking method initiated.");

                    // Validate the request model
                    if (hotelRoomBookingRequestModel == null || hotelRoomBookingRequestModel.Guests == null || !hotelRoomBookingRequestModel.Guests.Any())
                    {
                        _logger.LogWarning("Repository: AddHotelRoomBooking called with invalid request.");
                        return Result.NoContent();
                    }

                    var outputParam = new SqlParameter
                    {
                        ParameterName = "@BookingNumber",
                        SqlDbType = SqlDbType.NVarChar,
                        Direction = ParameterDirection.Output,
                        Size = 50
                    };

                    await _checkinProContext.Database.ExecuteSqlRawAsync("EXEC sp_GenerateUniqueBookingNumber @BookingNumber OUTPUT", outputParam);

                    // Create the main hotel room booking entity
                    tblHotelRoomBooking dbHotelRoomBooking = new tblHotelRoomBooking
                    {
                        HotelRoomTypeID = hotelRoomBookingRequestModel.HotelRoomTypeID,
                        BookingCode = outputParam.Value.ToString(),
                        ScheduledCheckInDate = hotelRoomBookingRequestModel.ScheduledCheckInDate,
                        ScheduledCheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckOutDate,
                        Duration = hotelRoomBookingRequestModel.Duration,
                        NumberOfGuests = hotelRoomBookingRequestModel.NumberOfGuests,
                        IsHourlyBooking = hotelRoomBookingRequestModel.IsHourlyBooking,
                        BookingStatus = BookingStatusMessages.Booked,
                        GuestSpecialRequests = hotelRoomBookingRequestModel.GuestSpecialRequests,
                        GuestNoteType = hotelRoomBookingRequestModel.GuestNoteType,
                        GuestNotes = hotelRoomBookingRequestModel.GuestNotes,
                        IsIncludedInReport = true,
                        CreatedBy = auditInfoModel.AuditUserID,
                        CreatedDate = DateTime.Now,
                    };

                    // Link the hotel room booking to a hotel room, if provided
                    if (hotelRoomBookingRequestModel.HotelRoomID.HasValue)
                    {
                        var hotelRoomEntity = await _checkinProContext.tblHotelRooms.FirstOrDefaultAsync(hr => hr.HotelRoomID == hotelRoomBookingRequestModel.HotelRoomID);
                        if (hotelRoomEntity != null)
                        {
                            dbHotelRoomBooking.HotelRoom = hotelRoomEntity;
                        }
                    }

                    await _checkinProContext.tblHotelRoomBookings.AddAsync(dbHotelRoomBooking);
                    await _checkinProContext.SaveChangesAsync();  // Commit the booking first

                    // Create rate details and save the tax rates and payments for the booking
                    var dbHotelRoomBookingRateDetails = hotelRoomBookingRequestModel.HotelRoomBookingRateDetails.Select(item => new tblHotelRoomBookingRateDetail
                    {
                        HotelRoomBookingID = dbHotelRoomBooking.HotelRoomBookingID,
                        CheckInDate = hotelRoomBookingRequestModel.ScheduledCheckInDate,
                        CheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckOutDate,
                        Duration = item.Duration,
                        BestAvailableRate = item.BestAvailableRate,
                        AdjustmentRate = item.AdjustmentRate,
                        HourlyRate = item.HourlyRate,
                        RoomChargeAmount = item.RoomChargeAmount,
                        TotalAmount = item.TotalAmount,
                        IsDiscountedRate = item.IsDiscountedRate,
                        AdditionalRateType = item.AdditionalRateType,
                        AdditionalRateAmount = item.AdditionalRateAmount,
                        DiscountedAmount = item.DiscountedAmount,
                        FinalAmount = item.FinalAmount,
                        Balance = item.Balance,
                        TaxStatus = item.TaxStatus,
                        IsBookingActive = true,
                        CreatedBy = auditInfoModel.AuditUserID,
                        CreatedDate = DateTime.Now,
                    }).ToList();

                    // Save the rate details to the database first
                    await _checkinProContext.tblHotelRoomBookingRateDetails.AddRangeAsync(dbHotelRoomBookingRateDetails);
                    await _checkinProContext.SaveChangesAsync();


                    // Explicitly save tax rates and payments
                    foreach (var rateDetail in dbHotelRoomBookingRateDetails)
                    {
                        // Create and assign tax rates for this rate detail
                        var taxRates = hotelRoomBookingRequestModel.HotelRoomBookingTaxRates.Select(item => new tblHotelRoomBookingTaxRate
                        {
                            HotelRoomBookingID = dbHotelRoomBooking.HotelRoomBookingID,
                            HotelRoomBookingRateDetailID = rateDetail.HotelRoomBookingRateDetailID,
                            HotelTaxRateID = item.HotelTaxRateID,
                            BookingTaxRateName = item.BookingTaxRateName,
                            BookingTaxRatePercentage = item.BookingTaxRatePercentage,
                            BookingTaxRate = item.BookingTaxRate,
                            IsBookingTaxRateActive = true,
                            CreatedBy = auditInfoModel.AuditUserID,
                            CreatedDate = DateTime.Now
                        }).ToList();

                        // Add tax rates to context
                        await _checkinProContext.tblHotelRoomBookingTaxRates.AddRangeAsync(taxRates);

                        // Create and assign payments for this rate detail
                        var payments = hotelRoomBookingRequestModel.HotelRoomPayments.Select(item => new tblPayment
                        {
                            HotelRoomBookingID = dbHotelRoomBooking.HotelRoomBookingID,
                            PaymentDate = item.PaymentDate ?? DateTime.Now,
                            Amount = item.Amount,
                            UsedRewardPoint = item.UsedRewardPoint,
                            PaymentMode = item.PaymentMode,
                            PaymentType = item.PaymentType,
                            PaymentStatus = item.PaymentStatus,
                            PaymentGateway = item.PaymentGateway,
                            TransactionID = item.TransactionID,
                            PaymentNotes = item.PaymentNotes,
                            CreatedBy = auditInfoModel.AuditUserID,
                            CreatedDate = DateTime.Now,
                            PaymentCompletedOn = item.PaymentStatus == "Completed" ? item.PaymentCompletedOn : (DateTime?)null
                        }).ToList();

                        // Add payments to context
                        await _checkinProContext.tblPayments.AddRangeAsync(payments);
                    }

                    // Link guests to the booking (this is the new part for adding multiple guests)
                    foreach (var guestModel in hotelRoomBookingRequestModel.Guests)
                    {
                        // Check if a guest with the same IdentityNumber and MobileNumber already exists for this booking
                        var existingGuest = await _checkinProContext.tblGuests
                            .Where(g => g.IdentityNumber == guestModel.IdentityNumber)
                            .FirstOrDefaultAsync();

                        tblGuest dbGuest = null;

                        // If the guest does not exist, create a new guest and add it
                        if (existingGuest == null)
                        {
                            dbGuest = new tblGuest
                            {
                                FirstName = guestModel.FirstName,
                                LastName = guestModel.LastName,
                                IdentityType = guestModel.IdentityType,
                                IdentityNumber = guestModel.IdentityNumber,
                                //FrontSideImage = ConvertFrontSideImageToByte(guestModel.FrontSideImage),
                                MobileNumber = guestModel.MobileNumber,
                                Email = guestModel.Email,
                                Address1 = guestModel.Address1,
                                Address2 = guestModel.Address2,
                                Country = guestModel.Country,
                                State = guestModel.State,
                                City = guestModel.City,
                                ZipCode = guestModel.ZipCode,
                                ScanID = guestModel.ScanID,
                                IsGuestScanned = guestModel.IsGuestScanned,
                                ProfilePicture = guestModel.ProfilePicture,
                                CreatedBy = auditInfoModel.AuditUserID,
                                CreatedDate = DateTime.Now
                            };
                            if (guestModel.FrontSideImage != null)
                            {
                                dbGuest.FrontSideImage = ConvertFrontSideImageToByte(guestModel.FrontSideImage);
                            }
                        }
                        else
                        {

                            existingGuest.FirstName = guestModel.FirstName;
                            existingGuest.LastName = guestModel.LastName;
                            existingGuest.IdentityType = guestModel.IdentityType;
                            existingGuest.IdentityNumber = guestModel.IdentityNumber;
                            existingGuest.MobileNumber = guestModel.MobileNumber;
                            existingGuest.Email = guestModel.Email;
                            existingGuest.Address1 = guestModel.Address1;
                            existingGuest.Address2 = guestModel.Address2;
                            existingGuest.Country = guestModel.Country;
                            existingGuest.State = guestModel.State;
                            existingGuest.City = guestModel.City;
                            existingGuest.ZipCode = guestModel.ZipCode;
                            existingGuest.ScanID = guestModel.ScanID;
                            existingGuest.IsGuestScanned = guestModel.IsGuestScanned;
                            existingGuest.ProfilePicture = guestModel.ProfilePicture;

                            if (guestModel.FrontSideImage != null)
                            {
                                existingGuest.FrontSideImage = ConvertFrontSideImageToByte(guestModel.FrontSideImage);
                            }

                            dbGuest = existingGuest;
                        }

                        tblHotelRoomBookingGuest dbHotelRoomBookingGuests = new tblHotelRoomBookingGuest()
                        {
                            IsPrimaryGuest = guestModel.IsPrimaryGuest,
                            CreatedBy = auditInfoModel.AuditUserID,
                            CreatedDate = DateTime.Now,
                            Guest = dbGuest,
                            HotelRoomBooking = dbHotelRoomBooking,
                        };
                        await _checkinProContext.tblHotelRoomBookingGuests.AddAsync(dbHotelRoomBookingGuests);
                    }
                    var guestID = hotelRoomBookingRequestModel.Guests.Where(item => item.IsPrimaryGuest).FirstOrDefault().GuestID;
                    if (guestID > 0 && hotelRoomBookingRequestModel.HotelRoomPayments.Count(item => item.PaymentMode == PaymentModeOption.RewardPoint) > 0)
                    {
                        var guestRewardPoint = _checkinProContext.tblGuestRewards.Where(item => item.HotelID == dbHotelRoomBooking.HotelRoom.HotelID && item.GuestID == guestID).FirstOrDefault();
                        if (guestRewardPoint != null)
                        {
                            var usedRewardPoint = hotelRoomBookingRequestModel.HotelRoomPayments.Where(item => item.PaymentMode == "Reward Point").FirstOrDefault().UsedRewardPoint ?? 0;
                            guestRewardPoint.TotalRewardPoint = guestRewardPoint.TotalRewardPoint - usedRewardPoint;
                        }
                    }
                    if (dbHotelRoomBooking.HotelRoomBookingID != 0 && hotelRoomBookingRequestModel.HotelRoomID == 0)
                    {
                        tblHotelRoomBookingAudit dbHotelRoomBookingAudit = new tblHotelRoomBookingAudit()
                        {
                            HotelRoomBookingID = dbHotelRoomBooking.HotelRoomBookingID,
                            ActionName = "Booked",
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = "Room Booked successfully.",
                        };
                        await _checkinProContext.tblHotelRoomBookingAudits.AddRangeAsync(dbHotelRoomBookingAudit);
                    }

                    // Commit changes
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    if (dbHotelRoomBooking.HotelRoomBookingID != 0 && hotelRoomBookingRequestModel.HotelRoomID > 0 && hotelRoomBookingRequestModel.ScheduledCheckInDate.Value.Date == GetCheckInMinDate(hotelRoomBookingRequestModel.IsHourlyBooking).Date)
                    {
                        await RoomCheckIn(dbHotelRoomBooking.HotelRoomBookingID, hotelRoomBookingRequestModel.HotelRoomID ?? 0, auditInfoModel);
                    }
                    _logger.LogInformation($"Repository: Successfully added hotel room booking with multiple guests.");

                    return Result<int>.Success(dbHotelRoomBooking.HotelRoomBookingID);
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while adding or updating hotel room booking. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: AddHotelRoomBooking Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while adding the hotel room booking.");
                }
            }
        }


        private DateTime GetCheckInMinDate(bool IsHourlyBooking)
        {
            if (IsHourlyBooking)
            {
                return DateTime.Now; // Always allow current time
            }

            // For daily bookings
            var now = DateTime.Now;
            if (now.Hour < 6)
            {
                return now.AddDays(-1).Date.AddHours(11);
            }
            return now.Date.AddHours(11);
        }

        private byte[] ConvertFrontSideImageToByte(string frontSideImage)
        {
            string base64String = frontSideImage;

            if (base64String.StartsWith("data:image/jpeg;base64,"))
            {
                base64String = base64String.Substring("data:image/jpeg;base64,".Length);
            }

            // Convert the base64 string to byte array
            return Convert.FromBase64String(base64String);
        }

        //public async Task<Result> UpdateHotelRoomBooking(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel)
        //{
        //    using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
        //    {
        //        try
        //        {
        //            _logger.LogInformation("Repository: UpdateHotelRoomBooking method initiated.");

        //            // Validate the request model
        //            if (hotelRoomBookingRequestModel == null)
        //            {
        //                _logger.LogWarning("Repository: UpdateHotelRoomBooking called with a null hotelRoomBookingRequestModel.");
        //                return Result.NoContent();
        //            }


        //            tblGuest dbGuest = new tblGuest
        //            {
        //                //FirstName = hotelRoomBookingRequestModel.Guest.FirstName,
        //                //LastName = hotelRoomBookingRequestModel.Guest.LastName,
        //                //IdentityType = hotelRoomBookingRequestModel.Guest.IdentityType,
        //                //IdentityNumber = hotelRoomBookingRequestModel.Guest.IdentityNumber,
        //                //FrontSideImage = hotelRoomBookingRequestModel.Guest.FrontSideImage,
        //                //MobileNumber = hotelRoomBookingRequestModel.Guest.MobileNumber,
        //                //Email = hotelRoomBookingRequestModel.Guest.Email,
        //                //Address1 = hotelRoomBookingRequestModel.Guest.Address1,
        //                //Address2 = hotelRoomBookingRequestModel.Guest.Address2,
        //                //StateID = hotelRoomBookingRequestModel.Guest.StateID,
        //                //City = hotelRoomBookingRequestModel.Guest.City,
        //                //ZipCode = hotelRoomBookingRequestModel.Guest.ZipCode,
        //                //ProfilePicture = hotelRoomBookingRequestModel.Guest.ProfilePicture,
        //                //UpdatedBy = auditInfoModel.AuditUserID,
        //                //UpdatedDate = DateTime.Now,

        //            };
        //            // Check if the booking already exists in the database
        //            var dbHotelRoomBooking = await _checkinProContext.tblHotelRoomBookings
        //                .FirstOrDefaultAsync(br => br.HotelRoomBookingID == hotelRoomBookingRequestModel.HotelRoomBookingID);

        //            if (dbHotelRoomBooking != null)
        //            {
        //                // Update the existing booking details
        //                dbHotelRoomBooking.HotelRoomTypeID = hotelRoomBookingRequestModel.HotelRoomTypeID;
        //                dbHotelRoomBooking.HotelRoomID = hotelRoomBookingRequestModel.HotelRoomID;
        //                dbHotelRoomBooking.ScheduledCheckInDate = hotelRoomBookingRequestModel.ScheduledCheckInDate;
        //                dbHotelRoomBooking.ScheduledCheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckOutDate;
        //                dbHotelRoomBooking.Duration = hotelRoomBookingRequestModel.Duration;
        //                dbHotelRoomBooking.ActualCheckInDate = hotelRoomBookingRequestModel.ActualCheckInDate;
        //                dbHotelRoomBooking.ActualCheckOutDate = hotelRoomBookingRequestModel.ActualCheckOutDate;
        //                dbHotelRoomBooking.NumberOfGuests = hotelRoomBookingRequestModel.NumberOfGuests;
        //                dbHotelRoomBooking.IsHourlyBooking = hotelRoomBookingRequestModel.IsHourlyBooking;
        //                dbHotelRoomBooking.BestAvailableRate = hotelRoomBookingRequestModel.BestAvailableRate;
        //                dbHotelRoomBooking.AdjustmentRate = hotelRoomBookingRequestModel.AdjustmentRate;
        //                dbHotelRoomBooking.HourlyRate = hotelRoomBookingRequestModel.HourlyRate;
        //                dbHotelRoomBooking.SubTotalAmount = hotelRoomBookingRequestModel.SubTotalAmount;
        //                dbHotelRoomBooking.TotalAmount = hotelRoomBookingRequestModel.TotalAmount;
        //                dbHotelRoomBooking.AdditionalRateType = hotelRoomBookingRequestModel.AdditionalRateType;
        //                dbHotelRoomBooking.AdditionalRateAmount = hotelRoomBookingRequestModel.AdditionalRateAmount;
        //                dbHotelRoomBooking.DiscountedAmount = hotelRoomBookingRequestModel.DiscountedAmount;
        //                dbHotelRoomBooking.FinalAmount = hotelRoomBookingRequestModel.FinalAmount;
        //                dbHotelRoomBooking.BookingStatus = hotelRoomBookingRequestModel.BookingStatus;
        //                dbHotelRoomBooking.PaymentStatus = hotelRoomBookingRequestModel.PaymentStatus;
        //                dbHotelRoomBooking.GuestSpecialRequests = hotelRoomBookingRequestModel.GuestSpecialRequests;
        //                dbHotelRoomBooking.GuestNoteType = hotelRoomBookingRequestModel.GuestNoteType;
        //                dbHotelRoomBooking.GuestNotes = hotelRoomBookingRequestModel.GuestNotes;
        //                dbHotelRoomBooking.UpdatedBy = auditInfoModel.AuditUserID;
        //                dbHotelRoomBooking.UpdatedDate = DateTime.Now;
        //                // Update the associated hotel room and payments
        //                dbHotelRoomBooking.tblHotelRoomBookingTaxRates = hotelRoomBookingRequestModel.HotelRoomBookingTaxRates
        //                    .Select(item => new tblHotelRoomBookingTaxRate
        //                    {
        //                        HotelTaxRateID = item.HotelTaxRateID,
        //                        BookingTaxRateName = item.BookingTaxRateName,
        //                        BookingTaxRatePercentage = item.BookingTaxRatePercentage,
        //                        BookingTaxRate = item.BookingTaxRate,
        //                        UpdatedBy = auditInfoModel.AuditUserID,
        //                        UpdatedDate = DateTime.Now
        //                    }).ToList();

        //                dbHotelRoomBooking.tblPayments = hotelRoomBookingRequestModel.HotelRoomPayments
        //                    .Select(item => new tblPayment
        //                    {
        //                        PaymentDate = item.PaymentDate ?? DateTime.Now,
        //                        Amount = item.Amount,
        //                        PaymentMode = item.PaymentMode,
        //                        PaymentStatus = item.PaymentStatus,
        //                        PaymentGateway = item.PaymentGateway,
        //                        TransactionID = item.TransactionID,
        //                        TransactionType = item.TransactionType,
        //                        PaymentNotes = item.PaymentNotes,
        //                        UpdatedBy = auditInfoModel.AuditUserID,
        //                        UpdatedDate = DateTime.Now
        //                    }).ToList();

        //                //dbHotelRoomBooking.Guest = dbGuest;

        //                //if (dbHotelRoomBooking.Guest.MobileNumber == hotelRoomBookingRequestModel.Guest.MobileNumber)
        //                //{
        //                //    dbHotelRoomBooking.GuestID = hotelRoomBookingRequestModel.GuestID;
        //                //    dbHotelRoomBooking.Guest = dbGuest;
        //                //}

        //                if (hotelRoomBookingRequestModel.HotelRoom.RoomStatus != null)
        //                {
        //                    var hotelRoomEntity = await _checkinProContext.tblHotelRooms.FirstOrDefaultAsync(hr => hr.HotelRoomID == hotelRoomBookingRequestModel.HotelRoomID);
        //                    if (hotelRoomEntity != null)
        //                    {
        //                        hotelRoomEntity.RoomStatus = hotelRoomBookingRequestModel.HotelRoom.RoomStatus;
        //                    }
        //                    dbHotelRoomBooking.HotelRoom = hotelRoomEntity;
        //                }

        //                _checkinProContext.Update(dbHotelRoomBooking);
        //            }
        //            await _checkinProContext.SaveChangesAsync();
        //            await transaction.CommitAsync();

        //            _logger.LogInformation($"Repository: Successfully {(dbHotelRoomBooking.HotelRoomBookingID == 0 ? "added" : "updated")} hotel room booking with ID: {dbHotelRoomBooking.HotelRoomBookingID}.");
        //            return Result.Success();
        //        }
        //        catch (DbUpdateException dbEx)
        //        {
        //            await transaction.RollbackAsync();
        //            _logger.LogError($"Repository: Database error occurred while adding or updating hotel room booking. {dbEx.Message}");
        //            return Result.Error("A database error occurred. Please try again later.");
        //        }
        //        catch (Exception ex)
        //        {
        //            await transaction.RollbackAsync();
        //            _logger.LogError($"Repository: UpdateHotelRoomBooking Exception occurred. Stacktrace: {ex}");
        //            return Result.Error("An error occurred while adding or updating the hotel room booking.");
        //        }
        //    }
        //}

        public async Task<Result> UpdateHotelRoomBooking(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: UpdateHotelRoomBooking method initiated.");

                    // Validate the request model
                    if (hotelRoomBookingRequestModel == null)
                    {
                        _logger.LogWarning("Repository: UpdateHotelRoomBooking called with a null hotelRoomBookingRequestModel.");
                        return Result.NoContent();
                    }

                    // Check if the booking already exists in the database
                    var dbHotelRoomBooking = await _checkinProContext.tblHotelRoomBookings
                        .FirstOrDefaultAsync(br => br.HotelRoomBookingID == hotelRoomBookingRequestModel.HotelRoomBookingID);

                    if (dbHotelRoomBooking != null)
                    {
                        // Update the booking details
                        dbHotelRoomBooking.HotelRoomTypeID = hotelRoomBookingRequestModel.HotelRoomTypeID;
                        dbHotelRoomBooking.HotelRoomID = hotelRoomBookingRequestModel.HotelRoomID;
                        dbHotelRoomBooking.ScheduledCheckInDate = hotelRoomBookingRequestModel.ScheduledCheckInDate;
                        dbHotelRoomBooking.ScheduledCheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckOutDate;
                        dbHotelRoomBooking.Duration = hotelRoomBookingRequestModel.Duration;
                        dbHotelRoomBooking.ActualCheckInDate = hotelRoomBookingRequestModel.ActualCheckInDate;
                        dbHotelRoomBooking.ActualCheckOutDate = hotelRoomBookingRequestModel.ActualCheckOutDate;
                        dbHotelRoomBooking.NumberOfGuests = hotelRoomBookingRequestModel.NumberOfGuests;
                        dbHotelRoomBooking.IsHourlyBooking = hotelRoomBookingRequestModel.IsHourlyBooking;
                        //dbHotelRoomBooking.BestAvailableRate = hotelRoomBookingRequestModel.BestAvailableRate;
                        //dbHotelRoomBooking.AdjustmentRate = hotelRoomBookingRequestModel.AdjustmentRate;
                        //dbHotelRoomBooking.HourlyRate = hotelRoomBookingRequestModel.HourlyRate;
                        //dbHotelRoomBooking.SubTotalAmount = hotelRoomBookingRequestModel.SubTotalAmount;
                        //dbHotelRoomBooking.TotalAmount = hotelRoomBookingRequestModel.TotalAmount;
                        //dbHotelRoomBooking.AdditionalRateType = hotelRoomBookingRequestModel.AdditionalRateType;
                        //dbHotelRoomBooking.AdditionalRateAmount = hotelRoomBookingRequestModel.AdditionalRateAmount;
                        //dbHotelRoomBooking.DiscountedAmount = hotelRoomBookingRequestModel.DiscountedAmount;
                        //dbHotelRoomBooking.MiscellaneousAmount = hotelRoomBookingRequestModel.MiscellaneousAmount;
                        //dbHotelRoomBooking.FinalAmount = hotelRoomBookingRequestModel.FinalAmount;
                        dbHotelRoomBooking.BookingStatus = hotelRoomBookingRequestModel.BookingStatus;
                        //dbHotelRoomBooking.PaymentStatus = hotelRoomBookingRequestModel.PaymentStatus;
                        dbHotelRoomBooking.GuestSpecialRequests = hotelRoomBookingRequestModel.GuestSpecialRequests;
                        dbHotelRoomBooking.GuestNoteType = hotelRoomBookingRequestModel.GuestNoteType;
                        dbHotelRoomBooking.GuestNotes = hotelRoomBookingRequestModel.GuestNotes;
                        dbHotelRoomBooking.UpdatedBy = auditInfoModel.AuditUserID;
                        dbHotelRoomBooking.UpdatedDate = DateTime.Now;

                        foreach (var taxRateModel in hotelRoomBookingRequestModel.HotelRoomBookingTaxRates)
                        {

                            var existingTaxRate = await _checkinProContext.tblHotelRoomBookingTaxRates.FirstOrDefaultAsync(tr => tr.HotelRoomBookingID == dbHotelRoomBooking.HotelRoomBookingID && tr.HotelTaxRateID == taxRateModel.HotelTaxRateID);
                            if (existingTaxRate != null)
                            {
                                existingTaxRate.BookingTaxRateName = taxRateModel.BookingTaxRateName;
                                existingTaxRate.BookingTaxRatePercentage = taxRateModel.BookingTaxRatePercentage;
                                existingTaxRate.BookingTaxRate = taxRateModel.BookingTaxRate;
                                existingTaxRate.UpdatedBy = auditInfoModel.AuditUserID;
                                existingTaxRate.UpdatedDate = DateTime.Now;
                            }
                            else
                            {
                                var dbTaxRate = new tblHotelRoomBookingTaxRate
                                {
                                    HotelRoomBookingID = dbHotelRoomBooking.HotelRoomBookingID,
                                    HotelTaxRateID = taxRateModel.HotelTaxRateID,
                                    BookingTaxRateName = taxRateModel.BookingTaxRateName,
                                    BookingTaxRatePercentage = taxRateModel.BookingTaxRatePercentage,
                                    BookingTaxRate = taxRateModel.BookingTaxRate,
                                    CreatedBy = auditInfoModel.AuditUserID,
                                    CreatedDate = DateTime.Now
                                };
                                await _checkinProContext.tblHotelRoomBookingTaxRates.AddAsync(dbTaxRate);
                            }
                        }

                        foreach (var guestModel in hotelRoomBookingRequestModel.Guests)
                        {
                            // Check if the guest already exists in the database
                            var existingGuest = await _checkinProContext.tblGuests
                                .FirstOrDefaultAsync(g => g.GuestID == guestModel.GuestID);

                            if (existingGuest != null)
                            {
                                // Update the existing guest
                                existingGuest.FirstName = guestModel.FirstName;
                                existingGuest.LastName = guestModel.LastName;
                                existingGuest.IdentityType = guestModel.IdentityType;
                                existingGuest.IdentityNumber = guestModel.IdentityNumber;
                                if (guestModel.FrontSideImage != null)
                                {
                                    existingGuest.FrontSideImage = ConvertFrontSideImageToByte(guestModel.FrontSideImage);
                                }
                                existingGuest.MobileNumber = guestModel.MobileNumber;
                                existingGuest.Email = guestModel.Email;
                                existingGuest.Address1 = guestModel.Address1;
                                existingGuest.Address2 = guestModel.Address2;
                                existingGuest.Country = guestModel.Country;
                                existingGuest.State = guestModel.State;
                                existingGuest.City = guestModel.City;
                                existingGuest.ZipCode = guestModel.ZipCode;
                                existingGuest.ProfilePicture = guestModel.ProfilePicture;
                                existingGuest.UpdatedBy = auditInfoModel.AuditUserID;
                                existingGuest.UpdatedDate = DateTime.Now;
                            }
                            else
                            {
                                // Add a new guest if it doesn't exist
                                var dbGuest = new tblGuest
                                {
                                    FirstName = guestModel.FirstName,
                                    LastName = guestModel.LastName,
                                    IdentityType = guestModel.IdentityType,
                                    IdentityNumber = guestModel.IdentityNumber,
                                    MobileNumber = guestModel.MobileNumber,
                                    Email = guestModel.Email,
                                    Address1 = guestModel.Address1,
                                    Address2 = guestModel.Address2,
                                    Country = guestModel.Country,
                                    State = guestModel.State,
                                    City = guestModel.City,
                                    ZipCode = guestModel.ZipCode,
                                    ScanID = guestModel.ScanID,
                                    IsGuestScanned = guestModel.IsGuestScanned,
                                    ProfilePicture = guestModel.ProfilePicture,
                                    CreatedBy = auditInfoModel.AuditUserID,
                                    CreatedDate = DateTime.Now
                                };

                                if (guestModel.FrontSideImage != null)
                                {
                                    dbGuest.FrontSideImage = ConvertFrontSideImageToByte(guestModel.FrontSideImage);
                                }

                                await _checkinProContext.tblGuests.AddAsync(dbGuest);
                                existingGuest = dbGuest;
                            }

                            var existingBookingGuest = await _checkinProContext.tblHotelRoomBookingGuests
                                .FirstOrDefaultAsync(bg => bg.HotelRoomBookingID == dbHotelRoomBooking.HotelRoomBookingID && bg.GuestID == existingGuest.GuestID);

                            if (existingBookingGuest == null)
                            {
                                // Add the relationship if it doesn't exist
                                dbHotelRoomBooking.tblHotelRoomBookingGuests.Add(new tblHotelRoomBookingGuest
                                {
                                    Guest = existingGuest,
                                    HotelRoomBooking = dbHotelRoomBooking,
                                    IsPrimaryGuest = guestModel.IsPrimaryGuest,
                                    CreatedBy = auditInfoModel.AuditUserID,
                                    CreatedDate = DateTime.Now
                                });
                            }
                        }

                        foreach (var paymentModel in hotelRoomBookingRequestModel.HotelRoomPayments)
                        {
                            // Check if the payment already exists for the booking (by PaymentID)
                            var existingBookingPayment = await _checkinProContext.tblPayments
                                .FirstOrDefaultAsync(py => py.PaymentID == paymentModel.PaymentID && py.HotelRoomBookingID == dbHotelRoomBooking.HotelRoomBookingID);

                            if (existingBookingPayment != null)
                            {
                                // Update the existing payment details if it exists
                                existingBookingPayment.PaymentDate = paymentModel.PaymentDate ?? DateTime.Now;
                                existingBookingPayment.Amount = paymentModel.Amount;
                                existingBookingPayment.PaymentMode = paymentModel.PaymentMode;
                                existingBookingPayment.PaymentType = paymentModel.PaymentType;
                                existingBookingPayment.PaymentStatus = paymentModel.PaymentStatus;
                                existingBookingPayment.PaymentGateway = paymentModel.PaymentGateway;
                                existingBookingPayment.TransactionID = paymentModel.TransactionID;
                                existingBookingPayment.PaymentNotes = paymentModel.PaymentNotes;
                                existingBookingPayment.UpdatedBy = auditInfoModel.AuditUserID;
                                existingBookingPayment.UpdatedDate = DateTime.Now;
                                existingBookingPayment.PaymentCompletedOn = (existingBookingPayment.PaymentCompletedOn == null && paymentModel.PaymentStatus == "Completed") ? GetSystemMinDate() : existingBookingPayment.PaymentCompletedOn;
                            }
                            else
                            {
                                // If payment doesn't exist, add a new payment record
                                var dbPayment = new tblPayment
                                {
                                    PaymentDate = paymentModel.PaymentDate ?? DateTime.Now,
                                    Amount = paymentModel.Amount,
                                    PaymentMode = paymentModel.PaymentMode,
                                    PaymentType = paymentModel.PaymentType,
                                    PaymentStatus = paymentModel.PaymentStatus,
                                    PaymentGateway = paymentModel.PaymentGateway,
                                    TransactionID = paymentModel.TransactionID,
                                    PaymentNotes = paymentModel.PaymentNotes,
                                    HotelRoomBookingID = dbHotelRoomBooking.HotelRoomBookingID, // Link to the booking
                                    CreatedBy = auditInfoModel.AuditUserID,
                                    CreatedDate = DateTime.Now,
                                    PaymentCompletedOn = paymentModel.PaymentStatus == "Completed" ? GetSystemMinDate() : (DateTime?)null
                                };

                                await _checkinProContext.tblPayments.AddAsync(dbPayment);
                            }
                        }

                        // Commit updates to the booking entity
                        _checkinProContext.Update(dbHotelRoomBooking);
                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();

                        _logger.LogInformation($"Repository: Successfully updated hotel room booking with ID: {dbHotelRoomBooking.HotelRoomBookingID}.");
                        return Result.Success();
                    }
                    else
                    {
                        _logger.LogWarning($"Repository: UpdateHotelRoomBooking hotel room booking with ID:{dbHotelRoomBooking.HotelRoomBookingID} Not Found.");
                        return Result.NoContent();
                    }
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while updating hotel room booking. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: UpdateHotelRoomBooking Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while updating the hotel room booking.");
                }
            }
        }

        public async Task<Result> UpdateHotelRoomBookingTotalAmount(HotelRoomBookingRateDetailModel hotelRoomBookingRateDetailRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: UpdateHotelRoomBookingTotalAmount method initiated.");

                    // Validate the request model
                    if (hotelRoomBookingRateDetailRequestModel == null)
                    {
                        _logger.LogWarning("Repository: UpdateHotelRoomBookingTotalAmount called with a null hotelRoomBookingRequestModel.");
                        return Result.NoContent();
                    }

                    // Check if the booking already exists in the database
                    var dbHotelRoomBookingRateDetail = await _checkinProContext.tblHotelRoomBookingRateDetails
                        .FirstOrDefaultAsync(br => br.HotelRoomBookingRateDetailID == hotelRoomBookingRateDetailRequestModel.HotelRoomBookingRateDetailID);

                    if (dbHotelRoomBookingRateDetail != null)
                    {
                        tblHotelRoomBookingAudit dbHotelRoomBookingAudit = new tblHotelRoomBookingAudit()
                        {
                            HotelRoomBookingID = dbHotelRoomBookingRateDetail.HotelRoomBookingID,
                            ActionName = "Total Amount",
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = "Total Amount updated from $" + dbHotelRoomBookingRateDetail.TotalAmount + " to $" + hotelRoomBookingRateDetailRequestModel.TotalAmount + " (" + dbHotelRoomBookingRateDetail.CheckInDate + " -- " + dbHotelRoomBookingRateDetail.CheckOutDate + ")"
                        };
                        await _checkinProContext.tblHotelRoomBookingAudits.AddRangeAsync(dbHotelRoomBookingAudit);

                        // Update the booking details
                        dbHotelRoomBookingRateDetail.RoomChargeAmount = hotelRoomBookingRateDetailRequestModel.RoomChargeAmount;
                        dbHotelRoomBookingRateDetail.TotalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount;
                        dbHotelRoomBookingRateDetail.FinalAmount = hotelRoomBookingRateDetailRequestModel.FinalAmount;
                        dbHotelRoomBookingRateDetail.UpdatedBy = auditInfoModel.AuditUserID;
                        dbHotelRoomBookingRateDetail.UpdatedDate = DateTime.Now;

                        foreach (var taxRateModel in hotelRoomBookingRateDetailRequestModel.HotelRoomBookingTaxRates)
                        {

                            var existingTaxRate = await _checkinProContext.tblHotelRoomBookingTaxRates.FirstOrDefaultAsync(tr => tr.HotelRoomBookingRateDetailID == dbHotelRoomBookingRateDetail.HotelRoomBookingRateDetailID && tr.HotelTaxRateID == taxRateModel.HotelTaxRateID);
                            if (existingTaxRate != null)
                            {
                                existingTaxRate.BookingTaxRate = taxRateModel.BookingTaxRate;
                                existingTaxRate.UpdatedBy = auditInfoModel.AuditUserID;
                                existingTaxRate.UpdatedDate = DateTime.Now;
                            }
                            else
                            {
                                _logger.LogWarning($"Repository: UpdateHotelRoomBookingTotalAmount HotelRoomBookingRateDetailID:{dbHotelRoomBookingRateDetail.HotelRoomBookingRateDetailID},HotelTaxRateID:{taxRateModel.HotelTaxRateID} Not Found.");
                                return Result.NoContent();
                            }
                        }

                        // Commit updates to the booking entity
                        _checkinProContext.Update(dbHotelRoomBookingRateDetail);
                        await _checkinProContext.SaveChangesAsync();
                        var dbHotelRoomBookingRateDetailData = await _checkinProContext.tblHotelRoomBookingRateDetails.Where(item => item.HotelRoomBookingID == dbHotelRoomBookingRateDetail.HotelRoomBookingID && item.IsExtend == false).FirstOrDefaultAsync();
                        if (dbHotelRoomBookingRateDetailData != null)
                        {
                            dbHotelRoomBookingRateDetailData.Balance = await GetBookingBalance(dbHotelRoomBookingRateDetail.HotelRoomBookingID);

                            _checkinProContext.tblHotelRoomBookingRateDetails.Update(dbHotelRoomBookingRateDetailData);
                        }

                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();

                        _logger.LogInformation($"Repository: Successfully updated hotel room booking TotalAmount.");
                        return Result.Success();
                    }
                    else
                    {
                        _logger.LogWarning($"Repository: UpdateHotelRoomBookingTotalAmount HotelRoomBookingRateDetailID:{hotelRoomBookingRateDetailRequestModel.HotelRoomBookingRateDetailID} Not Found.");
                        return Result.NoContent();
                    }
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while updating hotel room booking TotalAmount. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: UpdateHotelRoomBookingTotalAmount Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while updating the hotel room booking TotalAmount.");
                }
            }
        }

        public async Task<Result> RoomCheckIn(int hotelRoomBookingID, int hotelRoomID, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: RoomCheckIn method initiated.");

                    // Validate the request model
                    if (hotelRoomBookingID == 0)
                    {
                        _logger.LogWarning("Repository: RoomCheckIn called with a null hotelRoomBookingID.");
                        return Result.NoContent();
                    }

                    var dbBookingdData = await _checkinProContext.tblHotelRoomBookings
                        .Include(b => b.tblHotelRoomBookingGuests)
                        .Where(item => item.HotelRoomBookingID == hotelRoomBookingID && item.BookingStatus == BookingStatusMessages.Booked).FirstOrDefaultAsync();
                    if (dbBookingdData != null)
                    {
                        dbBookingdData.HotelRoomID = hotelRoomID;
                        dbBookingdData.BookingStatus = BookingStatusMessages.CheckedIn;
                        dbBookingdData.ActualCheckInDate = DateTime.Now;
                        dbBookingdData.UpdatedBy = auditInfoModel.AuditUserID;
                        dbBookingdData.UpdatedDate = DateTime.Now;

                        var hotelRoomEntity = await _checkinProContext.tblHotelRooms.FirstOrDefaultAsync(hr => hr.HotelRoomID == dbBookingdData.HotelRoomID);
                        if (hotelRoomEntity != null)
                        {
                            hotelRoomEntity.RoomStatus = RoomStatusMessages.Booked;
                        }
                        dbBookingdData.HotelRoom = hotelRoomEntity;

                        dbBookingdData.tblHotelRoomBookingAudits.Add(new tblHotelRoomBookingAudit
                        {
                            ActionName = "CheckedIn",
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = "Room CheckedIn to : " + hotelRoomEntity.RoomNumber,
                        });

                        var rewardPointData = await _checkinProContext.tblPayments.Where(item => item.HotelRoomBookingID == hotelRoomBookingID && item.PaymentMode == PaymentModeOption.RewardPoint).FirstOrDefaultAsync();
                        if (rewardPointData != null)
                        {
                            var GuestID = dbBookingdData.tblHotelRoomBookingGuests.Where(item => item.IsPrimaryGuest).Select(item => item.GuestID).FirstOrDefault();
                            var guestData = await _checkinProContext.tblGuests.Where(item => item.GuestID == GuestID).FirstOrDefaultAsync();
                            var fullName = guestData.FirstName + " " + guestData.LastName;
                            dbBookingdData.tblHotelRoomBookingAudits.Add(new tblHotelRoomBookingAudit
                            {
                                ActionName = "Used Reward Point",
                                ActionDateTime = DateTime.Now,
                                ActionBy = auditInfoModel.AuditUserName,
                                ActionComment = "Used Reward Point : " + rewardPointData.UsedRewardPoint + " (" + fullName + ")",
                            });
                        }
                        _checkinProContext.tblHotelRoomBookings.Update(dbBookingdData);
                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();

                        _logger.LogInformation($"Repository: User successfully checkIn to hotel room booking with ID: {dbBookingdData.HotelRoomBookingID}.");
                    }

                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while CheckIn. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: RoomCheckIn Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while checkIn.");
                }
            }
        }

        public async Task<Result> RoomChange(RoomChangeModel roomChangeRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: RoomChange method initiated.");

                    // Validate the request model
                    if (roomChangeRequestModel.HotelRoomBookingID == 0)
                    {
                        _logger.LogWarning("Repository: RoomChange called with a null hotelRoomBookingID.");
                        return Result.NoContent();
                    }

                    var dbBookingData = await _checkinProContext.tblHotelRoomBookings.Where(item => item.HotelRoomBookingID == roomChangeRequestModel.HotelRoomBookingID).FirstOrDefaultAsync();
                    if (dbBookingData != null && dbBookingData.BookingStatus == BookingStatusMessages.CheckedIn)
                    {
                        dbBookingData.HotelRoomTypeID = roomChangeRequestModel.HotelRoomTypeID;
                        dbBookingData.HotelRoomID = roomChangeRequestModel.HotelRoomID;
                        dbBookingData.BookingStatus = BookingStatusMessages.CheckedIn;
                        dbBookingData.UpdatedBy = auditInfoModel.AuditUserID;
                        dbBookingData.UpdatedDate = DateTime.Now;

                        var hotelRoomEntity = await _checkinProContext.tblHotelRooms.FirstOrDefaultAsync(hr => hr.HotelRoomID == dbBookingData.HotelRoomID);
                        if (hotelRoomEntity != null)
                        {
                            hotelRoomEntity.RoomStatus = RoomStatusMessages.Booked;
                        }
                        dbBookingData.HotelRoom = hotelRoomEntity;

                        var dbOldRoomStatusUpdate = await _checkinProContext.tblHotelRooms.FirstOrDefaultAsync(hr => hr.HotelRoomID == roomChangeRequestModel.OldHotelRoomID);
                        if (dbOldRoomStatusUpdate != null)
                        {
                            dbOldRoomStatusUpdate.RoomStatus = RoomStatusMessages.PendingCleaning;
                        }

                        dbBookingData.tblHotelRoomCleaningAudits.Add(new tblHotelRoomCleaningAudit
                        {
                            HotelRoomBookingID = roomChangeRequestModel.HotelRoomBookingID,
                            HotelRoomID = roomChangeRequestModel.OldHotelRoomID,
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = "RoomChange from Room:" + dbOldRoomStatusUpdate.RoomNumber + " to Room:" + hotelRoomEntity.RoomNumber,
                        });

                        dbBookingData.tblHotelRoomBookingAudits.Add(new tblHotelRoomBookingAudit
                        {
                            ActionName = "Room",
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = "Room Changed from room : " + dbOldRoomStatusUpdate.RoomNumber + " to " + hotelRoomEntity.RoomNumber,
                        });

                        _checkinProContext.tblHotelRoomBookings.Update(dbBookingData);
                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();

                        _logger.LogInformation($"Repository: User successfully change room to hotel room booking with ID: {dbBookingData.HotelRoomBookingID}.");
                    }
                    else if (dbBookingData.BookingStatus == BookingStatusMessages.Booked)
                    {
                        dbBookingData.HotelRoomTypeID = roomChangeRequestModel.HotelRoomTypeID;
                        dbBookingData.HotelRoomID = roomChangeRequestModel.HotelRoomID;
                        dbBookingData.UpdatedBy = auditInfoModel.AuditUserID;
                        dbBookingData.UpdatedDate = DateTime.Now;

                        _checkinProContext.tblHotelRoomBookings.Update(dbBookingData);

                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();

                        _logger.LogInformation($"Repository: User successfully change room and checked in to hotel room booking with ID: {dbBookingData.HotelRoomBookingID}.");

                        if (dbBookingData.HotelRoomBookingID != 0 && roomChangeRequestModel.HotelRoomID > 0 && dbBookingData.ScheduledCheckInDate.Value.Date == GetCheckInMinDate(dbBookingData.IsHourlyBooking).Date)
                        {
                            await RoomCheckIn(dbBookingData.HotelRoomBookingID, dbBookingData.HotelRoomID ?? 0, auditInfoModel);
                        }
                    }

                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while CheckIn. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: RoomChange Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while changing room.");
                }
            }
        }

        public async Task<Result> RoomCheckOut(UpdateHotelRoomCleaningAuditModel hotelRoomCleaningAuditRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: RoomCheckOut method initiated.");

                    // Validate the request model
                    if (hotelRoomCleaningAuditRequestModel.HotelRoomBookingID == 0)
                    {
                        _logger.LogWarning("Repository: RoomCheckOut called with a null hotelRoomBookingID.");
                        return Result.NoContent();
                    }

                    var dbBookingdData = await _checkinProContext.tblHotelRoomBookings
                        .Include(b => b.tblHotelRoomBookingGuests)
                        .Where(item => item.HotelRoomBookingID == hotelRoomCleaningAuditRequestModel.HotelRoomBookingID && item.BookingStatus == BookingStatusMessages.CheckedIn).FirstOrDefaultAsync();
                    if (dbBookingdData != null)
                    {
                        dbBookingdData.BookingStatus = BookingStatusMessages.CheckedOut;
                        dbBookingdData.ActualCheckOutDate = DateTime.Now;
                        dbBookingdData.UpdatedBy = auditInfoModel.AuditUserID;
                        dbBookingdData.UpdatedDate = DateTime.Now;

                        var hotelRoomEntity = await _checkinProContext.tblHotelRooms.FirstOrDefaultAsync(hr => hr.HotelRoomID == dbBookingdData.HotelRoomID);
                        if (hotelRoomEntity != null)
                        {
                            hotelRoomEntity.RoomStatus = RoomStatusMessages.PendingCleaning;
                        }
                        dbBookingdData.HotelRoom = hotelRoomEntity;

                        dbBookingdData.tblHotelRoomCleaningAudits.Add(new tblHotelRoomCleaningAudit
                        {
                            HotelRoomBookingID = hotelRoomCleaningAuditRequestModel.HotelRoomBookingID,
                            HotelRoomID = hotelRoomCleaningAuditRequestModel.HotelRoomID,
                            CheckOutComment = hotelRoomCleaningAuditRequestModel.CheckOutComment
                        });

                        dbBookingdData.tblHotelRoomBookingAudits.Add(new tblHotelRoomBookingAudit
                        {
                            ActionName = "CheckedOut",
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = "Room CheckedOut from : " + hotelRoomEntity.RoomNumber,
                        });

                        if (hotelRoomCleaningAuditRequestModel.IsRewardPointGiven && hotelRoomCleaningAuditRequestModel.EarnedRewardPoint > 0)
                        {
                            var primaryGuest = dbBookingdData.tblHotelRoomBookingGuests
                                .Where(item => item.IsPrimaryGuest)
                                .FirstOrDefault();

                            if (primaryGuest == null)
                            {
                                _logger.LogWarning("Repository: RoomCheckOut - no primary guest found for BookingID: {BookingID}, skipping reward.", hotelRoomCleaningAuditRequestModel.HotelRoomBookingID);
                            }
                            else
                            {
                                var DBGuestRewardPoint = new tblGuestRewardHistory
                                {
                                    HotelRoomBookingGuestID = primaryGuest.HotelRoomBookingGuestID,
                                    EarnedRewardPoint = hotelRoomCleaningAuditRequestModel.EarnedRewardPoint,
                                    CreatedBy = auditInfoModel.AuditUserID,
                                    CreatedDate = DateTime.Now
                                };

                                _checkinProContext.tblGuestRewardHistories.Add(DBGuestRewardPoint);

                                var DBGuestRewardEntity = await _checkinProContext.tblGuestRewards.Where(item => item.GuestID == primaryGuest.GuestID && item.HotelID == hotelRoomEntity.HotelID).FirstOrDefaultAsync();
                                if (DBGuestRewardEntity is not null)
                                {
                                    DBGuestRewardEntity.TotalRewardPoint = (DBGuestRewardEntity.TotalRewardPoint ?? 0m) + (hotelRoomCleaningAuditRequestModel.EarnedRewardPoint ?? 0m);
                                    DBGuestRewardEntity.UpdatedBy = auditInfoModel.AuditUserID;
                                    DBGuestRewardEntity.UpdatedDate = DateTime.Now;
                                    _checkinProContext.tblGuestRewards.Update(DBGuestRewardEntity);
                                }
                                else
                                {
                                    _checkinProContext.tblGuestRewards.Add(new tblGuestReward
                                    {
                                        GuestID = primaryGuest.GuestID,
                                        HotelID = hotelRoomEntity.HotelID,
                                        TotalRewardPoint = hotelRoomCleaningAuditRequestModel.EarnedRewardPoint,
                                        CreatedBy = auditInfoModel.AuditUserID,
                                        CreatedDate = DateTime.Now
                                    });
                                }

                                var guestData = await _checkinProContext.tblGuests.Where(item => item.GuestID == primaryGuest.GuestID).FirstOrDefaultAsync();
                                var fullName = guestData.FirstName + " " + guestData.LastName;
                                dbBookingdData.tblHotelRoomBookingAudits.Add(new tblHotelRoomBookingAudit
                                {
                                    ActionName = "Earned Reward Point",
                                    ActionDateTime = DateTime.Now,
                                    ActionBy = auditInfoModel.AuditUserName,
                                    ActionComment = "Earned Reward Point : " + hotelRoomCleaningAuditRequestModel.EarnedRewardPoint + " (" + fullName + ")"
                                });
                            }
                        }

                        _checkinProContext.tblHotelRoomBookings.Update(dbBookingdData);
                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();

                        _logger.LogInformation($"Repository: User successfully checkOut to hotel room booking with ID: {dbBookingdData.HotelRoomBookingID}.");
                    }

                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while CheckOut. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: RoomCheckInOut Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while checkIn.");
                }
            }
        }

        public async Task<Result> RoomCheckOutDateChange(HotelRoomBookingRateDetailModel hotelRoomBookingRateDetailRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: UpdateHotelRoomBookingOnCheckout method initiated.");

                    // Validate the request model
                    if (hotelRoomBookingRateDetailRequestModel == null)
                    {
                        _logger.LogWarning("Repository: UpdateHotelRoomBookingOnCheckout called with a null hotelRoomBookingRequestModel.");
                        return Result.NoContent();
                    }

                    // Check if the booking already exists in the database
                    var dbHotelRoomBookingRateDetail = await _checkinProContext.tblHotelRoomBookingRateDetails
                        .Include(item => item.HotelRoomBooking)
                        .FirstOrDefaultAsync(br => br.HotelRoomBookingRateDetailID == hotelRoomBookingRateDetailRequestModel.HotelRoomBookingRateDetailID);

                    if (dbHotelRoomBookingRateDetail != null)
                    {
                        tblHotelRoomBookingAudit dbHotelRoomBookingAudit = new tblHotelRoomBookingAudit()
                        {
                            HotelRoomBookingID = dbHotelRoomBookingRateDetail.HotelRoomBookingID,
                            ActionName = "Early CheckOut",
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = "CheckOut date changed from " + dbHotelRoomBookingRateDetail.CheckOutDate + " to " + hotelRoomBookingRateDetailRequestModel.CheckOutDate
                        };
                        await _checkinProContext.tblHotelRoomBookingAudits.AddRangeAsync(dbHotelRoomBookingAudit);

                        // Update the booking details
                        dbHotelRoomBookingRateDetail.CheckOutDate = hotelRoomBookingRateDetailRequestModel.CheckOutDate;
                        dbHotelRoomBookingRateDetail.Duration = hotelRoomBookingRateDetailRequestModel.Duration;
                        dbHotelRoomBookingRateDetail.RoomChargeAmount = hotelRoomBookingRateDetailRequestModel.RoomChargeAmount;
                        dbHotelRoomBookingRateDetail.TotalAmount = hotelRoomBookingRateDetailRequestModel.TotalAmount;
                        dbHotelRoomBookingRateDetail.FinalAmount = hotelRoomBookingRateDetailRequestModel.FinalAmount;
                        dbHotelRoomBookingRateDetail.UpdatedBy = auditInfoModel.AuditUserID;
                        dbHotelRoomBookingRateDetail.UpdatedDate = DateTime.Now;

                        foreach (var taxRateModel in hotelRoomBookingRateDetailRequestModel.HotelRoomBookingTaxRates)
                        {

                            var existingTaxRate = await _checkinProContext.tblHotelRoomBookingTaxRates.FirstOrDefaultAsync(tr => tr.HotelRoomBookingRateDetailID == dbHotelRoomBookingRateDetail.HotelRoomBookingRateDetailID && tr.HotelTaxRateID == taxRateModel.HotelTaxRateID);
                            if (existingTaxRate != null)
                            {
                                existingTaxRate.BookingTaxRate = taxRateModel.BookingTaxRate;
                                existingTaxRate.UpdatedBy = auditInfoModel.AuditUserID;
                                existingTaxRate.UpdatedDate = DateTime.Now;
                            }
                            else
                            {
                                _logger.LogWarning($"Repository: UpdateHotelRoomBookingOnCheckout HotelRoomBookingRateDetailID:{dbHotelRoomBookingRateDetail.HotelRoomBookingRateDetailID},HotelTaxRateID:{taxRateModel.HotelTaxRateID} Not Found.");
                                return Result.NoContent();
                            }
                        }

                        dbHotelRoomBookingRateDetail.HotelRoomBooking.ScheduledCheckOutDate = hotelRoomBookingRateDetailRequestModel.CheckOutDate;
                        var duration = dbHotelRoomBookingRateDetail.HotelRoomBooking.ScheduledCheckOutDate.Value.Date - dbHotelRoomBookingRateDetail.HotelRoomBooking.ScheduledCheckInDate.Value.Date;
                        if (duration.TotalDays >= 1)
                        {
                            dbHotelRoomBookingRateDetail.HotelRoomBooking.Duration = Convert.ToInt32(Math.Floor(duration.TotalDays));
                        }


                        var bookingsToUpdate = _checkinProContext.tblHotelRoomBookingRateDetails.Include(b => b.tblHotelRoomBookingTaxRates).Where(b => b.HotelRoomBookingID == dbHotelRoomBookingRateDetail.HotelRoomBookingID && b.CreatedDate > dbHotelRoomBookingRateDetail.CreatedDate).ToList();
                        bookingsToUpdate.ForEach(b =>
                        {
                            b.IsBookingActive = false;
                            b.tblHotelRoomBookingTaxRates.ToList().ForEach(t => t.IsBookingTaxRateActive = false);
                        });

                        _checkinProContext.UpdateRange(bookingsToUpdate);

                        // Commit updates to the booking entity
                        _checkinProContext.Update(dbHotelRoomBookingRateDetail);
                        await _checkinProContext.SaveChangesAsync();
                        var dbHotelRoomBookingRateDetailData = await _checkinProContext.tblHotelRoomBookingRateDetails.Where(item => item.HotelRoomBookingID == dbHotelRoomBookingRateDetail.HotelRoomBookingID && item.IsExtend == false).FirstOrDefaultAsync();
                        if (dbHotelRoomBookingRateDetailData != null)
                        {
                            dbHotelRoomBookingRateDetailData.Balance = await GetBookingBalance(dbHotelRoomBookingRateDetail.HotelRoomBookingID);

                            _checkinProContext.tblHotelRoomBookingRateDetails.Update(dbHotelRoomBookingRateDetailData);
                        }
                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();

                        _logger.LogInformation($"Repository: Successfully updated hotel room booking TotalAmount.");
                        return Result.Success();
                    }
                    else
                    {
                        _logger.LogWarning($"Repository: UpdateHotelRoomBookingOnCheckout HotelRoomBookingRateDetailID:{hotelRoomBookingRateDetailRequestModel.HotelRoomBookingRateDetailID} Not Found.");
                        return Result.NoContent();
                    }
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while updating hotel room booking TotalAmount. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: UpdateHotelRoomBookingTotalAmount Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while updating the hotel room booking TotalAmount.");
                }
            }
        }

        public async Task<Result> RoomExtend(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: RoomExtend method initiated.");

                    // Validate the request model
                    // Validate the request model
                    if (hotelRoomBookingRequestModel == null)
                    {
                        _logger.LogWarning("Repository: RoomExtend called with a null hotelRoomBookingRequestModel.");
                        return Result.NoContent();
                    }

                    var dbBookingData = await _checkinProContext.tblHotelRoomBookings.Where(item => item.HotelRoomBookingID == hotelRoomBookingRequestModel.HotelRoomBookingID).FirstOrDefaultAsync();
                    if (dbBookingData != null)
                    {
                        dbBookingData.tblHotelRoomBookingAudits.Add(new tblHotelRoomBookingAudit
                        {
                            ActionName = "Extend",
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = "Room Booking Extended from : " + dbBookingData.ScheduledCheckOutDate + " to : " + hotelRoomBookingRequestModel.ScheduledCheckOutDate,
                        });

                        dbBookingData.ScheduledCheckOutDate = hotelRoomBookingRequestModel.ScheduledCheckOutDate;
                        dbBookingData.Duration = hotelRoomBookingRequestModel.Duration;
                        dbBookingData.UpdatedBy = auditInfoModel.AuditUserID;
                        dbBookingData.UpdatedDate = DateTime.Now;

                        _checkinProContext.tblHotelRoomBookings.Update(dbBookingData);

                        // Create rate details and save the tax rates and payments for the booking
                        var dbHotelRoomBookingRateDetails = hotelRoomBookingRequestModel.HotelRoomBookingRateDetails.Select(item => new tblHotelRoomBookingRateDetail
                        {
                            HotelRoomBookingID = hotelRoomBookingRequestModel.HotelRoomBookingID,
                            CheckInDate = item.CheckInDate,
                            CheckOutDate = item.CheckOutDate,
                            Duration = item.Duration,
                            BestAvailableRate = item.BestAvailableRate,
                            AdjustmentRate = item.AdjustmentRate,
                            HourlyRate = item.HourlyRate,
                            RoomChargeAmount = item.RoomChargeAmount,
                            TotalAmount = item.TotalAmount,
                            IsDiscountedRate = item.IsDiscountedRate,
                            AdditionalRateType = item.AdditionalRateType,
                            AdditionalRateAmount = item.AdditionalRateAmount,
                            DiscountedAmount = item.DiscountedAmount,
                            FinalAmount = item.FinalAmount,
                            IsExtend = true,
                            IsBookingActive = true,
                            CreatedBy = auditInfoModel.AuditUserID,
                            CreatedDate = DateTime.Now,
                        }).ToList();

                        // Save the rate details to the database first
                        await _checkinProContext.tblHotelRoomBookingRateDetails.AddRangeAsync(dbHotelRoomBookingRateDetails);
                        await _checkinProContext.SaveChangesAsync();


                        // Explicitly save tax rates and payments
                        foreach (var rateDetail in dbHotelRoomBookingRateDetails)
                        {
                            // Create and assign tax rates for this rate detail
                            var taxRates = hotelRoomBookingRequestModel.HotelRoomBookingTaxRates.Select(item => new tblHotelRoomBookingTaxRate
                            {
                                HotelRoomBookingID = hotelRoomBookingRequestModel.HotelRoomBookingID,
                                HotelRoomBookingRateDetailID = rateDetail.HotelRoomBookingRateDetailID,
                                HotelTaxRateID = item.HotelTaxRateID,
                                BookingTaxRateName = item.BookingTaxRateName,
                                BookingTaxRatePercentage = item.BookingTaxRatePercentage,
                                BookingTaxRate = item.BookingTaxRate,
                                IsBookingTaxRateActive = true,
                                CreatedBy = auditInfoModel.AuditUserID,
                                CreatedDate = DateTime.Now
                            }).ToList();

                            // Add tax rates to context
                            await _checkinProContext.tblHotelRoomBookingTaxRates.AddRangeAsync(taxRates);
                        }
                        var dbHotelRoomBookingRateDetail = await _checkinProContext.tblHotelRoomBookingRateDetails.Where(item => item.HotelRoomBookingID == hotelRoomBookingRequestModel.HotelRoomBookingID && item.IsExtend == false).FirstOrDefaultAsync();
                        if (dbHotelRoomBookingRateDetail != null)
                        {
                            dbHotelRoomBookingRateDetail.Balance = await GetBookingBalance(hotelRoomBookingRequestModel.HotelRoomBookingID);

                            _checkinProContext.tblHotelRoomBookingRateDetails.Update(dbHotelRoomBookingRateDetail);
                        }
                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();

                        _logger.LogInformation($"Repository: User Room Extend successfully done for hotel room booking with ID: {dbBookingData.HotelRoomBookingID}.");
                    }

                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while Room Extend. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: RoomExtend Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while Room Extend.");
                }
            }
        }

        public async Task<Result> RoomCancel(int hotelRoomBookingID, string? cancellationReason, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: RoomCancel method initiated.");

                    // Validate the request model
                    if (hotelRoomBookingID == 0)
                    {
                        _logger.LogWarning("Repository: RoomCancel called with a null hotelRoomBookingRequestModel.");
                        return Result.NoContent();
                    }

                    var dbBookingdData = await _checkinProContext.tblHotelRoomBookings.Where(item => item.HotelRoomBookingID == hotelRoomBookingID).FirstOrDefaultAsync();
                    if (dbBookingdData != null)
                    {
                        dbBookingdData.BookingStatus = BookingStatusMessages.Cancelled;
                        dbBookingdData.IsBookingCancelled = true;
                        dbBookingdData.CancellationReason = cancellationReason;
                        dbBookingdData.UpdatedBy = auditInfoModel.AuditUserID;
                        dbBookingdData.UpdatedDate = DateTime.Now;

                        var hotelRoomEntity = await _checkinProContext.tblHotelRooms.FirstOrDefaultAsync(hr => hr.HotelRoomID == dbBookingdData.HotelRoomID);
                        if (hotelRoomEntity != null)
                        {
                            hotelRoomEntity.RoomStatus = RoomStatusMessages.PendingCleaning;
                        }
                        dbBookingdData.HotelRoom = hotelRoomEntity;

                        dbBookingdData.tblHotelRoomCleaningAudits.Add(new tblHotelRoomCleaningAudit
                        {
                            HotelRoomBookingID = hotelRoomBookingID,
                            HotelRoomID = dbBookingdData.HotelRoomID,
                        });

                        dbBookingdData.tblHotelRoomBookingAudits.Add(new tblHotelRoomBookingAudit
                        {
                            ActionName = "Cancelled",
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = dbBookingdData.BookingCode + " Cancelled successfully.",
                        });

                        _checkinProContext.tblHotelRoomBookings.Update(dbBookingdData);
                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();

                        _logger.LogInformation($"Repository: User Room Cancel successfully for hotel room booking with ID: {dbBookingdData.HotelRoomBookingID}.");

                    }

                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while Room Cancel. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Room Cancel Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while Room Cancel.");
                }
            }
        }

        public async Task<Result> RoomRefund(AddPaymentModel bookingPaymentRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: RoomRefund method initiated.");

                    // Validate the request model
                    if (bookingPaymentRequestModel == null)
                    {
                        _logger.LogWarning("Repository: RoomRefund called with a null bookingPaymentRequestModel.");
                        return Result.NoContent();
                    }

                    var dbBookingPaymentData = await _checkinProContext.tblPayments.Where(item => item.PaymentID == bookingPaymentRequestModel.PaymentID).FirstOrDefaultAsync();
                    if (dbBookingPaymentData != null)
                    {

                        if (bookingPaymentRequestModel.RefundAmount > 0)
                        {
                            tblHotelRoomBookingAudit dbHotelRoomBookingAudit = new tblHotelRoomBookingAudit()
                            {
                                HotelRoomBookingID = bookingPaymentRequestModel.HotelRoomBookingID,
                                ActionName = "Refund",
                                ActionDateTime = DateTime.Now,
                                ActionBy = auditInfoModel.AuditUserName,
                                ActionComment = dbBookingPaymentData.RefundAmount == null ? "Refund added successfully : $" + bookingPaymentRequestModel.RefundAmount : "Refund updated successfully from $" + dbBookingPaymentData.RefundAmount + " to $" + bookingPaymentRequestModel.RefundAmount
                            };
                            await _checkinProContext.tblHotelRoomBookingAudits.AddRangeAsync(dbHotelRoomBookingAudit);

                            dbBookingPaymentData.IsRefunded = true;
                            dbBookingPaymentData.RefundDate = bookingPaymentRequestModel.RefundDate;
                            dbBookingPaymentData.RefundAmount = bookingPaymentRequestModel.RefundAmount;

                        }
                        else
                        {
                            tblHotelRoomBookingAudit dbHotelRoomBookingAudit = new tblHotelRoomBookingAudit()
                            {
                                HotelRoomBookingID = bookingPaymentRequestModel.HotelRoomBookingID,
                                ActionName = "Refund",
                                ActionDateTime = DateTime.Now,
                                ActionBy = auditInfoModel.AuditUserName,
                                ActionComment = "Refund removed successfully."
                            };
                            await _checkinProContext.tblHotelRoomBookingAudits.AddRangeAsync(dbHotelRoomBookingAudit);

                            dbBookingPaymentData.IsRefunded = false;
                            dbBookingPaymentData.RefundDate = bookingPaymentRequestModel.RefundDate;
                            dbBookingPaymentData.RefundAmount = null;
                        }

                        dbBookingPaymentData.RefundNotes = bookingPaymentRequestModel.RefundNotes;
                        dbBookingPaymentData.UpdatedBy = auditInfoModel.AuditUserID;
                        dbBookingPaymentData.UpdatedDate = DateTime.Now;

                        _checkinProContext.tblPayments.Update(dbBookingPaymentData);
                        await _checkinProContext.SaveChangesAsync();
                        var dbHotelRoomBookingRateDetailData = await _checkinProContext.tblHotelRoomBookingRateDetails.Where(item => item.HotelRoomBookingID == bookingPaymentRequestModel.HotelRoomBookingID && item.IsExtend == false).FirstOrDefaultAsync();
                        if (dbHotelRoomBookingRateDetailData != null)
                        {
                            dbHotelRoomBookingRateDetailData.Balance = await GetBookingBalance(bookingPaymentRequestModel.HotelRoomBookingID);

                            _checkinProContext.tblHotelRoomBookingRateDetails.Update(dbHotelRoomBookingRateDetailData);
                        }

                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();

                        _logger.LogInformation($"Repository: User Room Refund successfully for hotel room booking with ID: {dbBookingPaymentData.HotelRoomBookingID}.");

                        if (dbBookingPaymentData.Amount != bookingPaymentRequestModel.Amount || dbBookingPaymentData.PaymentMode != bookingPaymentRequestModel.PaymentMode)
                        {
                            await AddUpdateBookingPayment(bookingPaymentRequestModel, auditInfoModel);
                        }
                    }

                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while Room Refund. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Room Refund Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while Room Refund.");
                }
            }
        }

        public async Task<Result> RoomCleaning(UpdateHotelRoomCleaningAuditModel hotelRoomCleaningAuditRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: RoomCleaning method initiated.");

                    // Validate the request model
                    if (hotelRoomCleaningAuditRequestModel.HotelRoomBookingID == 0)
                    {
                        _logger.LogWarning("Repository: RoomCleaning called with a null hotelRoomBookingID.");
                        return Result.NoContent();
                    }

                    var dbHotelRoomCleaningData = await _checkinProContext.tblHotelRoomCleaningAudits.Where(item => item.HotelRoomCleaningAuditID == hotelRoomCleaningAuditRequestModel.HotelRoomCleaningAuditID && !item.IsRoomClean).FirstOrDefaultAsync();
                    if (dbHotelRoomCleaningData != null)
                    {
                        dbHotelRoomCleaningData.IsRoomClean = true;
                        dbHotelRoomCleaningData.ActionDateTime = DateTime.Now;
                        dbHotelRoomCleaningData.ActionBy = auditInfoModel.AuditUserName;
                        dbHotelRoomCleaningData.ActionComment = hotelRoomCleaningAuditRequestModel.ActionComment;

                        var hotelRoomEntity = await _checkinProContext.tblHotelRooms.FirstOrDefaultAsync(hr => hr.HotelRoomID == dbHotelRoomCleaningData.HotelRoomID && hr.RoomStatus != RoomStatusMessages.OutOfService);
                        if (hotelRoomEntity != null)
                        {
                            hotelRoomEntity.RoomStatus = RoomStatusMessages.ReadyToCheckIn;
                        }


                        var hotelRoomBookingEntity = await _checkinProContext.tblHotelRoomBookings.FirstOrDefaultAsync(hr => hr.HotelRoomBookingID == dbHotelRoomCleaningData.HotelRoomBookingID);
                        if (hotelRoomBookingEntity != null)
                        {
                            hotelRoomBookingEntity.GuestNoteType = hotelRoomCleaningAuditRequestModel.GuestNoteType;
                            hotelRoomBookingEntity.GuestNotes = hotelRoomCleaningAuditRequestModel.GuestNotes;
                        }

                        dbHotelRoomCleaningData.HotelRoomBooking = hotelRoomBookingEntity;

                        _checkinProContext.tblHotelRoomCleaningAudits.Update(dbHotelRoomCleaningData);
                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();

                        _logger.LogInformation($"Repository: User successfully clean hotel room.");
                    }

                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while CheckOut. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: RoomCheckInOut Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while checkIn.");
                }
            }
        }

        public async Task<Result<List<HotelRoomCleaningAuditModel>>> GetPendingRoomCleaningList(int hotelID)
        {
            try
            {
                _logger.LogInformation("Repository: GetPendingRoomCleaningList method initiated.");

                var dbPendingCleaningData = await _checkinProContext.tblHotelRoomCleaningAudits
                    .Where(item => item.HotelRoom.HotelID == hotelID && item.IsRoomClean == false)
                    .Include(item => item.HotelRoom)
                    .ThenInclude(room => room.HotelRoomType)
                    .Select(item => new HotelRoomCleaningAuditModel
                    {
                        HotelRoomCleaningAuditID = item.HotelRoomCleaningAuditID,
                        HotelRoomBookingID = item.HotelRoomBookingID,
                        HotelRoomID = item.HotelRoomID,
                        IsRoomClean = item.IsRoomClean,
                        CheckOutComment = item.CheckOutComment,
                        Floor = item.HotelRoom.Floor,
                        RoomNumber = item.HotelRoom.RoomNumber,
                        MaxOccupancy = item.HotelRoom.MaxOccupancy,
                        RoomStatus = item.HotelRoom.RoomStatus,
                        RoomTypeName = item.HotelRoom.HotelRoomType.RoomTypeName
                    }).OrderBy(item => item.Floor).ThenBy(item => item.RoomNumber).ToListAsync();

                _logger.LogInformation("Repository: GetPendingRoomCleaningList method execution completed.");
                _logger.LogInformation($"Repository: GetPendingRoomCleaningList method execution completed. Total Pending Cleaning Rooms retrieved: {dbPendingCleaningData.Count}.");

                // Return the list of HotelRoomCleaningAuditModel
                return Result.Success(dbPendingCleaningData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetPendingRoomCleaningList method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching pending room cleaning list.");
            }
        }

        public async Task<Result> UpdateHotelRoomBookingStatus(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddHotelRoomBooking method initiated.");

                    var dbBookingdData = await _checkinProContext.tblHotelRoomBookings.Where(item => item.HotelRoomBookingID == hotelRoomBookingRequestModel.HotelRoomBookingID).FirstOrDefaultAsync();

                    if (dbBookingdData != null)
                    {

                        dbBookingdData.BookingStatus = hotelRoomBookingRequestModel.BookingStatus;

                        if (hotelRoomBookingRequestModel.BookingStatus == BookingStatusMessages.Cancelled)
                        {
                            dbBookingdData.IsBookingCancelled = hotelRoomBookingRequestModel.IsBookingCancelled;
                            dbBookingdData.CancellationReason = hotelRoomBookingRequestModel.CancellationReason;

                        }
                        else if (hotelRoomBookingRequestModel.BookingStatus == BookingStatusMessages.CheckedIn)
                        {
                            dbBookingdData.HotelRoomID = hotelRoomBookingRequestModel.HotelRoomID;
                            dbBookingdData.ActualCheckInDate = DateTime.Now;
                        }
                        else if (hotelRoomBookingRequestModel.BookingStatus == BookingStatusMessages.CheckedOut)
                        {
                            dbBookingdData.ActualCheckOutDate = DateTime.Now;
                        }

                        dbBookingdData.UpdatedBy = auditInfoModel.AuditUserID;
                        dbBookingdData.UpdatedDate = DateTime.Now;

                        var hotelRoomEntity = await _checkinProContext.tblHotelRooms.FirstOrDefaultAsync(hr => hr.HotelRoomID == dbBookingdData.HotelRoomID);
                        if (hotelRoomEntity != null)
                        {
                            hotelRoomEntity.RoomStatus = hotelRoomBookingRequestModel.HotelRoom.RoomStatus;
                        }
                        dbBookingdData.HotelRoom = hotelRoomEntity;

                        _checkinProContext.tblHotelRoomBookings.Update(dbBookingdData);
                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();

                        _logger.LogInformation($"Repository: Successfully added hotel room booking with ID: {dbBookingdData.HotelRoomBookingID}.");
                    }

                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while adding hotelRoomBooking. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: AddHotelRoomBooking Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while adding the hotel room booking.");
                }
            }
        }

        public async Task<Result> AddEditMiscAmount(AddEditMiscAmountModel addEditMiscAmountRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddEditMiscAmount method initiated.");

                    // Validate the request model
                    if (addEditMiscAmountRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddEditMiscAmount called with invalid request.");
                        return Result.NoContent();
                    }
                    var existingBookingMiscData = await _checkinProContext.tblHotelRoomBookingMiscDetails.Where(item => item.HotelRoomBookingMiscellaneousID == addEditMiscAmountRequestModel.HotelRoomBookingMiscellaneousID).FirstOrDefaultAsync();
                    if (existingBookingMiscData != null)
                    {
                        tblHotelRoomBookingAudit dbHotelRoomBookingAudit = new tblHotelRoomBookingAudit()
                        {
                            HotelRoomBookingID = existingBookingMiscData.HotelRoomBookingID,
                            ActionName = "Miscellaneous",
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = "Misc updated successfully from " + existingBookingMiscData.MiscellaneousDate + " - $" + existingBookingMiscData.MiscellaneousAmount + " to " + addEditMiscAmountRequestModel.MiscellaneousDate + " - $" + addEditMiscAmountRequestModel.MiscellaneousAmount,
                        };
                        await _checkinProContext.tblHotelRoomBookingAudits.AddRangeAsync(dbHotelRoomBookingAudit);

                        existingBookingMiscData.MiscellaneousDate = addEditMiscAmountRequestModel.MiscellaneousDate;
                        existingBookingMiscData.MiscellaneousAmount = addEditMiscAmountRequestModel.MiscellaneousAmount;
                        existingBookingMiscData.UpdatedBy = auditInfoModel.AuditUserID;
                        existingBookingMiscData.UpdatedDate = DateTime.Now;

                        _checkinProContext.Update(existingBookingMiscData);
                        await _checkinProContext.SaveChangesAsync();
                        _logger.LogInformation($"Repository: Successfully updated Misc Amount.");
                    }
                    else
                    {
                        var dbBookingMiscDetail = new tblHotelRoomBookingMiscDetail
                        {
                            HotelRoomBookingID = addEditMiscAmountRequestModel.HotelRoomBookingID,
                            MiscellaneousDate = addEditMiscAmountRequestModel.MiscellaneousDate,
                            MiscellaneousAmount = addEditMiscAmountRequestModel.MiscellaneousAmount,
                            CreatedBy = auditInfoModel.AuditUserID,
                            CreatedDate = DateTime.Now
                        };
                        await _checkinProContext.tblHotelRoomBookingMiscDetails.AddAsync(dbBookingMiscDetail);
                        tblHotelRoomBookingAudit dbHotelRoomBookingAudit = new tblHotelRoomBookingAudit()
                        {
                            HotelRoomBookingID = addEditMiscAmountRequestModel.HotelRoomBookingID,
                            ActionName = "Miscellaneous",
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = "Misc added successfully : " + addEditMiscAmountRequestModel.MiscellaneousDate + " - $" + addEditMiscAmountRequestModel.MiscellaneousAmount,
                        };
                        await _checkinProContext.tblHotelRoomBookingAudits.AddRangeAsync(dbHotelRoomBookingAudit);
                        await _checkinProContext.SaveChangesAsync();
                        _logger.LogInformation($"Repository: Successfully saved Misc Amount.");
                    }
                    var dbBookingData = await _checkinProContext.tblHotelRoomBookingRateDetails.Where(item => item.HotelRoomBookingID == addEditMiscAmountRequestModel.HotelRoomBookingID && item.IsExtend == false).FirstOrDefaultAsync();
                    if (dbBookingData != null)
                    {
                        var totalMiscAmount = _checkinProContext.tblHotelRoomBookingMiscDetails.Where(item => item.HotelRoomBookingID == addEditMiscAmountRequestModel.HotelRoomBookingID).Sum(item => item.MiscellaneousAmount) ?? 0;
                        dbBookingData.MiscellaneousAmount = totalMiscAmount;
                        dbBookingData.FinalAmount = dbBookingData.TotalAmount + totalMiscAmount;

                        await _checkinProContext.SaveChangesAsync();
                        dbBookingData.Balance = await GetBookingBalance(addEditMiscAmountRequestModel.HotelRoomBookingID);
                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();

                        _logger.LogInformation($"Repository: Misc Amount Added or Edited successfully for hotel room booking with ID: {addEditMiscAmountRequestModel.HotelRoomBookingID}.");
                        return Result.Success();
                    }
                    else
                    {
                        _logger.LogWarning($"Repository: AddEditMiscAmount hotel room booking with ID:{addEditMiscAmountRequestModel.HotelRoomBookingID} Not Found.");
                        return Result.NoContent();
                    }

                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();

                    _logger.LogError($"Repository: Database error occurred while Add or Edit Misc Amount. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository:Add or Edit Misc Amount Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while Add or Edit Misc Amount.");
                }
            }
        }

        public async Task<Result> AddUpdateBookingPayment(AddPaymentModel bookingPaymentRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddUpdateBookingPayment method initiated.");

                    // Validate the request model
                    if (bookingPaymentRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddUpdateBookingPayment called with invalid request.");
                        return Result.NoContent();
                    }

                    var existingBookingPayment = await _checkinProContext.tblPayments.Where(item => item.PaymentID == bookingPaymentRequestModel.PaymentID && item.HotelRoomBookingID == bookingPaymentRequestModel.HotelRoomBookingID).FirstOrDefaultAsync();
                    if (existingBookingPayment != null)
                    {
                        var existingBookingPaymentDetail = "Date : " + existingBookingPayment.PaymentCompletedOn + " | Mode : " + existingBookingPayment.PaymentMode + " | Type : " + existingBookingPayment.PaymentType + " | Amount : " + existingBookingPayment.Amount + " | Status : " + existingBookingPayment.PaymentStatus;
                        var updatedBookingPaymentDetail = "Date : " + bookingPaymentRequestModel.PaymentCompletedOn + " | Mode : " + bookingPaymentRequestModel.PaymentMode + " | Type : " + bookingPaymentRequestModel.PaymentType + " | Amount : " + bookingPaymentRequestModel.Amount + " | Status : " + bookingPaymentRequestModel.PaymentStatus;

                        tblHotelRoomBookingAudit dbHotelRoomBookingAudit = new tblHotelRoomBookingAudit()
                        {
                            HotelRoomBookingID = bookingPaymentRequestModel.HotelRoomBookingID,
                            ActionName = "Payment",
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = "Existing Detail : " + existingBookingPaymentDetail + " ==> Updated Detail : " + updatedBookingPaymentDetail
                        };
                        await _checkinProContext.tblHotelRoomBookingAudits.AddRangeAsync(dbHotelRoomBookingAudit);

                        existingBookingPayment.PaymentDate = bookingPaymentRequestModel.PaymentDate ?? DateTime.Now;
                        existingBookingPayment.Amount = bookingPaymentRequestModel.Amount;
                        existingBookingPayment.UsedRewardPoint = bookingPaymentRequestModel.UsedRewardPoint;
                        existingBookingPayment.PaymentMode = bookingPaymentRequestModel.PaymentMode;
                        existingBookingPayment.PaymentType = bookingPaymentRequestModel.PaymentType;
                        existingBookingPayment.PaymentStatus = bookingPaymentRequestModel.PaymentStatus;
                        existingBookingPayment.PaymentGateway = bookingPaymentRequestModel.PaymentGateway;
                        existingBookingPayment.TransactionID = bookingPaymentRequestModel.TransactionID;
                        existingBookingPayment.PaymentNotes = bookingPaymentRequestModel.PaymentNotes;
                        existingBookingPayment.UpdatedBy = auditInfoModel.AuditUserID;
                        existingBookingPayment.UpdatedDate = DateTime.Now;
                        existingBookingPayment.PaymentCompletedOn = bookingPaymentRequestModel.PaymentStatus == "Completed" ? bookingPaymentRequestModel.PaymentCompletedOn : (DateTime?)null;
                        if (bookingPaymentRequestModel.PaymentMode == "Cash")
                        {
                            existingBookingPayment.PaymentGateway = null;
                            existingBookingPayment.TransactionID = null;
                        }


                        _checkinProContext.tblPayments.Update(existingBookingPayment);
                        _logger.LogInformation($"Repository: Successfully updated room payment.");

                    }
                    else
                    {
                        var dbPayment = new tblPayment
                        {
                            HotelRoomBookingID = bookingPaymentRequestModel.HotelRoomBookingID,
                            PaymentDate = bookingPaymentRequestModel.PaymentDate ?? DateTime.Now,
                            Amount = bookingPaymentRequestModel.Amount,
                            UsedRewardPoint = bookingPaymentRequestModel.UsedRewardPoint,
                            PaymentMode = bookingPaymentRequestModel.PaymentMode,
                            PaymentType = bookingPaymentRequestModel.PaymentType,
                            PaymentStatus = bookingPaymentRequestModel.PaymentStatus,
                            PaymentGateway = bookingPaymentRequestModel.PaymentGateway,
                            TransactionID = bookingPaymentRequestModel.TransactionID,
                            PaymentNotes = bookingPaymentRequestModel.PaymentNotes,
                            CreatedBy = auditInfoModel.AuditUserID,
                            CreatedDate = DateTime.Now,
                            PaymentCompletedOn = bookingPaymentRequestModel.PaymentStatus == "Completed" ? bookingPaymentRequestModel.PaymentCompletedOn : (DateTime?)null
                        };
                        await _checkinProContext.tblPayments.AddAsync(dbPayment);

                        tblHotelRoomBookingAudit dbHotelRoomBookingAudit = new tblHotelRoomBookingAudit()
                        {
                            HotelRoomBookingID = bookingPaymentRequestModel.HotelRoomBookingID,
                            ActionName = "Payment",
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = "Payment collected (" + bookingPaymentRequestModel.PaymentStatus + ") : $" + dbPayment.Amount
                        };
                        await _checkinProContext.tblHotelRoomBookingAudits.AddRangeAsync(dbHotelRoomBookingAudit);
                        _logger.LogInformation($"Repository: Successfully added room payment.");
                    }
                    await _checkinProContext.SaveChangesAsync();

                    var dbHotelRoomBookingRateDetail = await _checkinProContext.tblHotelRoomBookingRateDetails.Where(item => item.HotelRoomBookingID == bookingPaymentRequestModel.HotelRoomBookingID && item.IsExtend == false).FirstOrDefaultAsync();
                    if (dbHotelRoomBookingRateDetail != null)
                    {
                        dbHotelRoomBookingRateDetail.Balance = await GetBookingBalance(bookingPaymentRequestModel.HotelRoomBookingID);

                        _checkinProContext.tblHotelRoomBookingRateDetails.Update(dbHotelRoomBookingRateDetail);
                    }
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully added or updated room payment.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();

                    _logger.LogError($"Repository: Database error occurred while AddUpdateBookingPayment. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository:AddUpdateBookingPayment Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while AddUpdateBookingPayment.");
                }
            }
        }

        /// <summary> 
        /// Retrieves booked hotel room details based on the provided hotelRoomBookingID and checkOutDate.
        /// </summary>
        /// <param name="hotelRoomBookingID">The unique identifier of the hotel room booking to exclude from the search.</param>
        /// <param name="checkOutDate">The <see cref="DateTime"/> representing the check-out date to filter bookings.</param>
        /// <returns>
        /// A <see cref="Task{Result{List{GetBookedRoomDetailsModel}}}"/> containing a list of booked rooms, including check-in date, 
        /// check-out date, guest name, room type, and room number.
        /// </returns>
        public async Task<Result<List<GetBookedRoomDetailsModel>>> GetBookedRoomDetailsByCheckOutDate(int hotelRoomBookingID, DateTime checkOutDate)
        {
            try
            {
                _logger.LogInformation("Repository: GetBookedRoomDetailsByCheckOutDate method initiated.");

                var bookedRooms = await _checkinProContext.tblHotelRoomBookings
                    .Where(booking => booking.HotelRoomBookingID != hotelRoomBookingID &&
                      (booking.BookingStatus == BookingStatusMessages.Booked ||
                       booking.BookingStatus == BookingStatusMessages.CheckedIn) &&
                      (
                          (booking.ScheduledCheckInDate.HasValue && booking.ScheduledCheckInDate.Value.Date == checkOutDate.Date) ||
                          (booking.ScheduledCheckOutDate.HasValue && booking.ScheduledCheckOutDate.Value.Date == checkOutDate.Date) ||
                          (booking.ScheduledCheckInDate.HasValue && booking.ScheduledCheckOutDate.HasValue &&
                           checkOutDate > booking.ScheduledCheckInDate.Value && checkOutDate < booking.ScheduledCheckOutDate.Value)
                                  )
                )
                .Include(booking => booking.tblHotelRoomBookingGuests)
                    .ThenInclude(booking => booking.Guest)
                .Include(booking => booking.HotelRoomType)
                .Include(booking => booking.HotelRoom)
                .Select(booking => new GetBookedRoomDetailsModel
                {
                    RoomNumber = booking.HotelRoom != null ? booking.HotelRoom.RoomNumber : "N/A",
                    RoomType = booking.HotelRoomType != null ? booking.HotelRoomType.RoomTypeName : "N/A",
                    //GuestName = booking.Guest != null ? (booking.Guest.FirstName + " " + booking.Guest.LastName) : "N/A",
                    IsHourlyBooking = booking.IsHourlyBooking,
                    ScheduledCheckInDate = booking.ScheduledCheckInDate,
                    ScheduledCheckOutDate = booking.ScheduledCheckOutDate,
                    Duration = booking.Duration,
                    BookingStatus = booking.BookingStatus,
                })
                .ToListAsync();

                return Result.Success(bookedRooms);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetBookedRoomDetailsByCheckOutDate method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching booked room details.");
            }
        }


        //public async Task<Result<List<GetHotelRoomBookingSPModel>>> SearchHotelRoomBooking(FindHotelRoomBooking findHotelRoomBookingRequestModel)
        //{
        //    try
        //    {
        //        _logger.LogInformation("Repository: SearchHotelRoomBooking method initiated.");


        //        var spParams = new SqlParameter[] {
        //              new SqlParameter(){ ParameterName="@HotelID", Value = findHotelRoomBookingRequestModel.HotelId },
        //              new SqlParameter(){ ParameterName="@FirstName", Value = findHotelRoomBookingRequestModel.FirstName },
        //              new SqlParameter(){ ParameterName="@LastName", Value = findHotelRoomBookingRequestModel.LastName },
        //              new SqlParameter(){ ParameterName="@CheckIn", Value = findHotelRoomBookingRequestModel.CheckIn },
        //              new SqlParameter(){ ParameterName="@CheckOut", Value = findHotelRoomBookingRequestModel.CheckOut },
        //        };

        //        List<GetHotelRoomBookingSPModel> dbHotelRoomData = new List<GetHotelRoomBookingSPModel>();


        //        dbHotelRoomData = await _checkinProContext.sp_FindHotelRoomBooking.FromSqlRaw("EXEC sp_FindHotelRoomBooking", spParams).ToListAsync();


        //        return Result.Success(dbHotelRoomData);
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError($"Repository: GetTodaysHotelRoomsByHotelID method encountered an exception. Stacktrace: {ex}");
        //        return Result.Error("An error occurred while fetching today's booked hotel room list.");
        //    }
        //}

        public async Task<Result<List<GetHotelRoomBookingSearchListModel>>> SearchHotelRoomBooking(FindHotelRoomBookingModel findHotelRoomBookingRequestModel)
        {
            try
            {
                _logger.LogInformation("Repository: SearchHotelRoomBooking method initiated.");

                var spParams = new SqlParameter[]
                {
                    new SqlParameter("@HotelID", SqlDbType.Int) { Value = findHotelRoomBookingRequestModel.HotelId },
                    new SqlParameter("@BookingCode", SqlDbType.NVarChar) { Value = findHotelRoomBookingRequestModel.BookingCode ?? (object)DBNull.Value },
                    new SqlParameter("@BookingStatus", SqlDbType.NVarChar) { Value = findHotelRoomBookingRequestModel.BookingStatus ?? (object)DBNull.Value },
                    new SqlParameter("@HotelRoomTypeID", SqlDbType.Int) { Value = findHotelRoomBookingRequestModel.HotelRoomTypeID ?? (object)DBNull.Value},
                    new SqlParameter("@RoomNumber", SqlDbType.NVarChar) { Value = findHotelRoomBookingRequestModel.RoomNumber ?? (object)DBNull.Value },
                    new SqlParameter("@GuestCode", SqlDbType.NVarChar) { Value = findHotelRoomBookingRequestModel.GuestCode ?? (object)DBNull.Value },
                    new SqlParameter("@FirstName", SqlDbType.NVarChar) { Value = findHotelRoomBookingRequestModel.FirstName ?? (object)DBNull.Value },
                    new SqlParameter("@LastName", SqlDbType.NVarChar) { Value = findHotelRoomBookingRequestModel.LastName ?? (object)DBNull.Value },
                    new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = findHotelRoomBookingRequestModel.StartDate ?? (object)DBNull.Value},
                    new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = findHotelRoomBookingRequestModel.EndDate ??(object) DBNull.Value },
                };

                List<GetHotelRoomBookingSearchListModel> dbHotelRoomData = await _checkinProContext.sp_FindHotelRoomBooking
               .FromSqlRaw("EXEC sp_FindHotelRoomBooking @HotelID, @BookingCode, @BookingStatus, @HotelRoomTypeID, @RoomNumber, @GuestCode, @FirstName, @LastName, @StartDate, @EndDate", spParams)
               .ToListAsync();


                // Call the stored procedure and map the result
                //var reportData = await _checkinProContext.sp_FindHotelRoomBooking
                //    .FromSqlRaw("EXEC sp_FindHotelRoomBooking @HotelId, @FirstName, @LastName, @CheckIn, @CheckOut",
                //        new SqlParameter("@HotelId", findHotelRoomBookingRequestModel.HotelId),
                //        new SqlParameter("@FirstName", findHotelRoomBookingRequestModel.FirstName),
                //        new SqlParameter("@LastName", findHotelRoomBookingRequestModel.LastName),
                //        new SqlParameter("@CheckIn", findHotelRoomBookingRequestModel.CheckIn),
                //        new SqlParameter("@CheckOut", findHotelRoomBookingRequestModel.CheckOut)
                //    ).ToListAsync();


                //List<GetHotelRoomBookingSPModel> dbHotelRoomData = await _checkinProContext
                //    .Set<GetHotelRoomBookingSPModel>()
                //    .FromSqlRaw("EXEC sp_FindHotelRoomBooking @HotelID, @FirstName, @LastName, @CheckIn, @CheckOut", spParams)
                //    .ToListAsync();





                return Result.Success(dbHotelRoomData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: SearchHotelRoomBooking method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel room booking details.");
            }
        }

        public async Task<Result> AddUpdateGuest(int hotelRoomBookingID, AddGuestModel guestRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddUpdateGuest method initiated.");

                    // Validate the request model
                    if (guestRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddUpdateGuest called with invalid request.");
                        return Result.NoContent();
                    }

                    var existingGuestData = await _checkinProContext.tblGuests.Where(item => item.GuestID == guestRequestModel.GuestID).FirstOrDefaultAsync();
                    if (existingGuestData != null)
                    {
                        if (existingGuestData.IsGuestScanned.HasValue && guestRequestModel.IsGuestScanned == false)
                        {
                            existingGuestData.FirstName = guestRequestModel.FirstName;
                            existingGuestData.LastName = guestRequestModel.LastName;
                            existingGuestData.IdentityType = guestRequestModel.IdentityType;
                            existingGuestData.IdentityNumber = guestRequestModel.IdentityNumber;

                            if (guestRequestModel.FrontSideImage != null)
                            {
                                existingGuestData.FrontSideImage = ConvertFrontSideImageToByte(guestRequestModel.FrontSideImage);
                            }
                        }

                        existingGuestData.MobileNumber = guestRequestModel.MobileNumber;
                        existingGuestData.Email = guestRequestModel.Email;
                        existingGuestData.Address1 = guestRequestModel.Address1;
                        existingGuestData.Address2 = guestRequestModel.Address2;
                        existingGuestData.Country = guestRequestModel.Country;
                        existingGuestData.State = guestRequestModel.State;
                        existingGuestData.City = guestRequestModel.City;
                        existingGuestData.ZipCode = guestRequestModel.ZipCode;
                        existingGuestData.UpdatedBy = auditInfoModel.AuditUserID;
                        existingGuestData.UpdatedDate = DateTime.Now;
                        var existingHotelRoomBookingGuestData = await _checkinProContext.tblHotelRoomBookingGuests.Where(item => item.HotelRoomBookingID == hotelRoomBookingID).ToListAsync();
                        if (existingHotelRoomBookingGuestData.Count < 2 && existingHotelRoomBookingGuestData.Any(item => item.GuestID != existingGuestData.GuestID))
                        {
                            existingGuestData.tblHotelRoomBookingGuests.Add(new tblHotelRoomBookingGuest
                            {
                                HotelRoomBookingID = hotelRoomBookingID,
                                IsPrimaryGuest = false,
                                CreatedBy = auditInfoModel.AuditUserID,
                                CreatedDate = DateTime.Now
                            });
                        }
                        _checkinProContext.Update(existingGuestData);
                        tblHotelRoomBookingAudit dbHotelRoomBookingAudit = new tblHotelRoomBookingAudit()
                        {
                            HotelRoomBookingID = hotelRoomBookingID,
                            ActionName = "Guest",
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = "Existing Guest updated : " + guestRequestModel.FirstName + " " + guestRequestModel.LastName
                        };
                        await _checkinProContext.tblHotelRoomBookingAudits.AddRangeAsync(dbHotelRoomBookingAudit);
                        _logger.LogInformation($"Repository: Successfully updated Guest Data.");
                    }
                    else
                    {
                        var dbGuest = new tblGuest
                        {
                            FirstName = guestRequestModel.FirstName,
                            LastName = guestRequestModel.LastName,
                            IdentityType = guestRequestModel.IdentityType,
                            IdentityNumber = guestRequestModel.IdentityNumber,
                            MobileNumber = guestRequestModel.MobileNumber,
                            Email = guestRequestModel.Email,
                            Address1 = guestRequestModel.Address1,
                            Address2 = guestRequestModel.Address2,
                            Country = guestRequestModel.Country,
                            State = guestRequestModel.State,
                            City = guestRequestModel.City,
                            ZipCode = guestRequestModel.ZipCode,
                            ScanID = guestRequestModel.ScanID,
                            IsGuestScanned = guestRequestModel.IsGuestScanned,
                            ProfilePicture = guestRequestModel.ProfilePicture,
                            CreatedBy = auditInfoModel.AuditUserID,
                            CreatedDate = DateTime.Now,
                        };

                        if (guestRequestModel.FrontSideImage != null)
                        {
                            dbGuest.FrontSideImage = ConvertFrontSideImageToByte(guestRequestModel.FrontSideImage);
                        }

                        dbGuest.tblHotelRoomBookingGuests.Add(new tblHotelRoomBookingGuest
                        {
                            HotelRoomBookingID = hotelRoomBookingID,
                            IsPrimaryGuest = false,
                            CreatedBy = auditInfoModel.AuditUserID,
                            CreatedDate = DateTime.Now
                        });

                        await _checkinProContext.tblGuests.AddAsync(dbGuest);

                        tblHotelRoomBookingAudit dbHotelRoomBookingAudit = new tblHotelRoomBookingAudit()
                        {
                            HotelRoomBookingID = hotelRoomBookingID,
                            ActionName = "Guest",
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = "New Guest added : " + guestRequestModel.FirstName + " " + guestRequestModel.LastName
                        };
                        await _checkinProContext.tblHotelRoomBookingAudits.AddRangeAsync(dbHotelRoomBookingAudit);
                        _logger.LogInformation($"Repository: Successfully added Guest Data.");
                    }

                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully added or updated Guest Data.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();

                    _logger.LogError($"Repository: Database error occurred while AddUpdateGuest. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository:AddUpdateGuest Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while AddUpdateGuest.");
                }
            }
        }

        public async Task<Result> UpdateGuestRequest(UpdateGuestRequestModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: UpdateGuestRequest method initiated.");

                    // Validate the request model
                    if (hotelRoomBookingRequestModel == null)
                    {
                        _logger.LogWarning("Repository: UpdateGuestRequest called with a null hotelRoomBookingRequestModel.");
                        return Result.NoContent();
                    }

                    // Check if the booking already exists in the database
                    var dbHotelRoomBooking = await _checkinProContext.tblHotelRoomBookings
                        .FirstOrDefaultAsync(br => br.HotelRoomBookingID == hotelRoomBookingRequestModel.HotelRoomBookingID);

                    if (dbHotelRoomBooking != null)
                    {

                        dbHotelRoomBooking.GuestSpecialRequests = hotelRoomBookingRequestModel.GuestSpecialRequests;
                        dbHotelRoomBooking.GuestNoteType = hotelRoomBookingRequestModel.GuestNoteType;
                        dbHotelRoomBooking.GuestNotes = hotelRoomBookingRequestModel.GuestNotes;
                        dbHotelRoomBooking.UpdatedBy = auditInfoModel.AuditUserID;
                        dbHotelRoomBooking.UpdatedDate = DateTime.Now;

                        dbHotelRoomBooking.tblHotelRoomBookingAudits.Add(new tblHotelRoomBookingAudit
                        {
                            ActionName = "Guest Note",
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = "Guest Note updated successfully.",
                        });

                        // Commit updates to the booking entity
                        _checkinProContext.Update(dbHotelRoomBooking);
                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();

                        _logger.LogInformation($"Repository: Successfully updated hotel room booking with ID: {dbHotelRoomBooking.HotelRoomBookingID}.");
                        return Result.Success();
                    }
                    else
                    {
                        _logger.LogWarning($"Repository: UpdateGuestRequest hotel room booking with ID:{dbHotelRoomBooking.HotelRoomBookingID} Not Found.");
                        return Result.NoContent();
                    }
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while updating hotel room booking. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: UpdateGuestRequest Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while updating the hotel room booking.");
                }
            }
        }

        public async Task<Result> UpdateBookingReportFlag(int hotelRoomBookingID, bool isIncludedInReport, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: UpdateBookingReportFlag method initiated.");

                    // Validate the request model
                    if (hotelRoomBookingID <= 0)
                    {
                        _logger.LogWarning("Repository: UpdateBookingReportFlag called with invalid request.");
                        return Result.NoContent();
                    }
                    var dbHotelRoomBooking = await _checkinProContext.tblHotelRoomBookings.Where(item => item.HotelRoomBookingID == hotelRoomBookingID).FirstOrDefaultAsync();
                    if (dbHotelRoomBooking != null)
                    {
                        dbHotelRoomBooking.IsIncludedInReport = isIncludedInReport;
                        dbHotelRoomBooking.UpdatedBy = auditInfoModel.AuditUserID;
                        dbHotelRoomBooking.UpdatedDate = DateTime.Now;

                        dbHotelRoomBooking.tblHotelRoomBookingAudits.Add(new tblHotelRoomBookingAudit
                        {
                            ActionName = "Report",
                            ActionDateTime = DateTime.Now,
                            ActionBy = auditInfoModel.AuditUserName,
                            ActionComment = "Booking " + (isIncludedInReport ? "Included in Daily Report." : "Excluded from Daily Report."),
                        });

                        _checkinProContext.Update(dbHotelRoomBooking);
                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();

                        _logger.LogInformation($"Repository: Successfully updated hotel booking Data.");
                        return Result.Success();
                    }
                    else
                    {
                        _logger.LogWarning($"Repository: UpdateBookingReportFlag hotel room booking with ID:{hotelRoomBookingID} Not Found.");
                        return Result.NoContent();
                    }
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();

                    _logger.LogError($"Repository: Database error occurred while UpdateBookingReportFlag. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository:UpdateBookingReportFlag Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while UpdateBookingReportFlag.");
                }
            }
        }

        public async Task<Result<List<AddEditMiscAmountModel>>> GetRoomBookingMiscAmount(int hotelRoomBookingID)
        {
            try
            {
                _logger.LogInformation("Repository: GetRoomBookingMiscAmount method initiated.");

                var dbMiscAmountData = await _checkinProContext.tblHotelRoomBookingMiscDetails.Where(item => item.HotelRoomBookingID == hotelRoomBookingID).OrderByDescending(item => item.CreatedDate)
                    .Select(item => new AddEditMiscAmountModel
                    {
                        HotelRoomBookingMiscellaneousID = item.HotelRoomBookingMiscellaneousID,
                        MiscellaneousDate = item.MiscellaneousDate,
                        MiscellaneousAmount = item.MiscellaneousAmount
                    }).ToListAsync();

                return Result.Success(dbMiscAmountData);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetRoomBookingMiscAmount method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching Misc Amount list.");
            }
        }

        public async Task<Result> DeleteMiscAmount(int hotelRoomBookingMiscellaneousID)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: DeleteMiscAmount method initiated.");

                    var dbMiscData = await _checkinProContext.tblHotelRoomBookingMiscDetails.FindAsync(hotelRoomBookingMiscellaneousID);

                    if (dbMiscData != null)
                    {
                        _checkinProContext.tblHotelRoomBookingMiscDetails.Remove(dbMiscData);
                        await _checkinProContext.SaveChangesAsync();

                        var dbBookingData = await _checkinProContext.tblHotelRoomBookingRateDetails.Where(item => item.HotelRoomBookingID == dbMiscData.HotelRoomBookingID && item.IsExtend == false).FirstOrDefaultAsync();
                        if (dbBookingData != null)
                        {
                            var totalMiscAmount = _checkinProContext.tblHotelRoomBookingMiscDetails.Where(item => item.HotelRoomBookingID == dbMiscData.HotelRoomBookingID).Sum(item => item.MiscellaneousAmount) ?? 0;
                            dbBookingData.MiscellaneousAmount = totalMiscAmount;
                            dbBookingData.FinalAmount = dbBookingData.TotalAmount + totalMiscAmount;

                            await _checkinProContext.SaveChangesAsync();
                            dbBookingData.Balance = await GetBookingBalance(dbMiscData.HotelRoomBookingID);
                            await _checkinProContext.SaveChangesAsync();
                            await transaction.CommitAsync();

                            _logger.LogInformation($"Repository: Misc Amount Updated successfully for hotel room booking with ID: {dbMiscData.HotelRoomBookingID}.");
                            _logger.LogInformation($"Repository: Misc Amount Deleted successfully");
                            return Result.Success();
                        }
                        else
                        {
                            _logger.LogWarning($"Repository: DeleteMiscAmount hotel room booking with ID:{dbMiscData.HotelRoomBookingID} Not Found.");
                            return Result.NoContent();
                        }
                    }
                    else
                    {
                        _logger.LogWarning($"Repository: Misc Amount not found.");
                        return Result.NotFound($"Misc Amount not found.");
                    }
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while deleting Misc Amount. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Repository: DeleteMiscAmount Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while deleting Misc Amount.");
                }
            }
        }

        private async Task<decimal> GetBookingBalance(int? hotelRoomBookingID)
        {
            try
            {
                _logger.LogInformation("Repository: GetBookingBalance method initiated.");
                decimal Balance = 0;
                decimal finalAmount = _checkinProContext.tblHotelRoomBookingRateDetails.Where(item => item.HotelRoomBookingID == hotelRoomBookingID && item.IsBookingActive).Sum(item => item.FinalAmount) ?? 0;
                decimal totalPaid = _checkinProContext.tblPayments.Where(item => item.HotelRoomBookingID == hotelRoomBookingID && item.PaymentStatus == CommonConstants.PaymentStatusMessages.Completed).Sum(item => item.Amount) ?? 0;
                decimal refundAmount = _checkinProContext.tblPayments.Where(item => item.HotelRoomBookingID == hotelRoomBookingID && item.IsRefunded).Sum(item => item.RefundAmount) ?? 0;

                return Balance = finalAmount - (totalPaid - refundAmount);
                //return Balance = finalAmount - totalPaid;

            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository:GetBookingBalance Exception occurred. Stacktrace: {ex}");
                return 0;
            }

        }


    }
}
