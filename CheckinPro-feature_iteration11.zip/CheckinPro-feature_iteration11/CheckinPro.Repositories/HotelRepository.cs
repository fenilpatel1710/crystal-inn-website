﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.Common.Models.Constants;
using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Repositories.IRepository;
using CheckinPro.WebApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Net.Mail;
using System.Text;

namespace CheckinPro.Repositories
{
    public class HotelRepository : IHotelRepository
    {
        private readonly ILogger _logger;
        private readonly CheckinProContext _checkinProContext;
        private readonly IEmailRepository _emailService;

        public HotelRepository(ILogger<HotelRepository> logger, CheckinProContext checkinProContext, IEmailRepository emailService)
        {
            _logger = logger;
            _checkinProContext = checkinProContext;
            _emailService = emailService;
        }

        /// <summary>
        /// Checks if records exist for the given HotelID across multiple tables.
        /// </summary>
        /// <param name="hotelId">The ID of the hotel to check.</param>
        /// <returns>A <see cref="Result"/> containing a dictionary with presence status of each table.</returns>
        public async Task<Result<HotelProfileStatusModel>> GetHotelProfileCompletionStatus(int hotelId)
        {
            try
            {
                var response = new HotelProfileStatusModel
                {
                    IsHotelTaxRatePresent = await _checkinProContext.tblHotelTaxRates.AnyAsync(u => u.HotelID == hotelId),
                    IsHotelConfigurationPresent = await _checkinProContext.tblHotelConfigurations.AnyAsync(h => h.HotelID == hotelId),
                    IsHotelDailyPresent = await _checkinProContext.tblHotelDailyRates.AnyAsync(u => u.HotelID == hotelId),
                    IsHotelHourlyPresent = await _checkinProContext.tblHotelHourlyRates.AnyAsync(h => h.HotelID == hotelId),
                    IsHotelRoomTypePresent = await _checkinProContext.tblHotelRoomTypes.AnyAsync(h => h.HotelID == hotelId),
                    IsHotelAdditionalRatePresent = await _checkinProContext.tblHotelAdditionalRates.AnyAsync(u => u.HotelID == hotelId),
                    IsHotelRoomPresent = await _checkinProContext.tblHotelRooms.AnyAsync(u => u.HotelID == hotelId),
                    IsHotelStaffPresent = await _checkinProContext.tblHotelUsers.AnyAsync(hu => hu.HotelID == hotelId && hu.User != null && hu.User.Role != null && (hu.User.Role.RoleName == CommonConstants.ApplicationUserRole.HotelManager || hu.User.Role.RoleName == CommonConstants.ApplicationUserRole.HotelStaff)),
                };

                _logger.LogInformation($"Repository: GetHotelProfileCompletionStatus executed successfully for HotelID {hotelId}.");
                return Result.Success(response);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: Exception in GetHotelProfileCompletionStatus for HotelID {hotelId}. Error: {ex}");
                return Result.Error("An error occurred while checking hotel records.");
            }
        }


        /// <summary>
        /// Retrieves a list of Hotels.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelModel"/> representing the hotel data.</returns>
        public async Task<Result<List<GetHotelModel>>> GetHotels()
        {
            try
            {
                var dbhotelUserData = await _checkinProContext.tblHotelUsers
                    .Where(hu => hu.IsHotelUserActive && !hu.IsHotelUserBlocked && !hu.IsHotelUserDeleted && hu.User.RoleID == 2)
                    .Include(hu => hu.Hotel)
                    .Include(hu => hu.User)
                    .ToListAsync();
                if (dbhotelUserData.Any())
                {
                    var hotelList = dbhotelUserData.Select(hu => new GetHotelModel
                    {
                        HotelID = hu.Hotel.HotelID,
                        BusinessLLCName = hu.Hotel.BusinessLLCName,
                        HotelCode = hu.Hotel.HotelCode,
                        Email = hu.Hotel.Email,
                        MobileNumber = hu.Hotel.MobileNumber,
                        Address1 = hu.Hotel.Address1,
                        Address2 = hu.Hotel.Address2,
                        StateID = hu.Hotel.StateID,
                        City = hu.Hotel.City,
                        ZipCode = hu.Hotel.ZipCode,
                        Website = hu.Hotel.Website,
                        Description = hu.Hotel.Description,
                        IsOwnerDashboardVisible = hu.Hotel.IsOwnerDashboardVisible,
                        IsHotelActive = hu.Hotel.IsHotelActive,
                        hotelOwner = new HotelOwnerModel
                        {
                            FullName = hu.User.FirstName + " " + hu.User.LastName,
                            EmailID = hu.User.EmailID,
                            MobileNumber = hu.User.MobileNumber
                        }
                    }).ToList();

                    _logger.LogInformation("Repository: GetHotels method execution completed.");
                    _logger.LogInformation($"Repository: GetHotels method execution completed. Total Hotels retrieved: {dbhotelUserData.Count}.");
                    return hotelList;
                }
                else
                {
                    _logger.LogWarning($"Repository: No hotel found.");
                    return Result.NotFound($"Repository: No hotel found.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotels method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotels.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific hotel by its ID.
        /// </summary>
        /// <param name="hotelID">The ID of the hotel to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetHotelModel"/> for the specified hotel.</returns>
        public async Task<Result<GetHotelModel>> GetHotelById(int hotelID)
        {
            try
            {
                _logger.LogInformation($"Repository: GeHotelById method initiated for HotelID: {hotelID}.");

                var dbhotelUserData = await _checkinProContext.tblHotelUsers
                    .Where(hu => hu.HotelID == hotelID && hu.IsHotelUserActive && !hu.IsHotelUserBlocked && !hu.IsHotelUserDeleted)
                    .Include(hu => hu.Hotel)
                    .Include(hu => hu.User)
                    .FirstOrDefaultAsync();

                if (dbhotelUserData != null)
                {
                    var hotelModel = new GetHotelModel
                    {
                        HotelID = dbhotelUserData.Hotel.HotelID,
                        HotelCode = dbhotelUserData.Hotel.HotelCode,
                        HotelUniqueID = dbhotelUserData.Hotel.HotelUniqueID,
                        BusinessLLCName = dbhotelUserData.Hotel.BusinessLLCName,
                        Email = dbhotelUserData.Hotel.Email,
                        MobileNumber = dbhotelUserData.Hotel.MobileNumber,
                        Address1 = dbhotelUserData.Hotel.Address1,
                        Address2 = dbhotelUserData.Hotel.Address2,
                        StateID = dbhotelUserData.Hotel.StateID,
                        City = dbhotelUserData.Hotel.City,
                        ZipCode = dbhotelUserData.Hotel.ZipCode,
                        Website = dbhotelUserData.Hotel.Website,
                        Description = dbhotelUserData.Hotel.Description,
                        hotelOwner = new HotelOwnerModel
                        {
                            FullName = dbhotelUserData.User.FirstName + " " + dbhotelUserData.User.LastName,
                            EmailID = dbhotelUserData.User.EmailID,
                            MobileNumber = dbhotelUserData.User.MobileNumber
                        }
                    };
                    _logger.LogInformation($"Repository: Successfully retrieved hotel for HotelID: {hotelID}.");
                    return Result.Success(hotelModel);

                }
                else
                {
                    _logger.LogWarning($"Repository: No hotel found with HotelID: {hotelID}.");
                    return Result.NotFound($"No hotel found with HotelID: {hotelID}.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GeHotelById Exception occurred for HotelID: {hotelID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the Hotel.");
            }
        }

        /// <summary>
        /// Adds a new hotel record based on the provided hotelRequestModel.
        /// </summary>
        /// <param name="hotelRequestModel">The <see cref="AddHotelModel"/> containing data for the new hotel.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel creation operation.</returns>
        public async Task<Result> AddHotel(AddHotelModel hotelRequestModel, string randomPassword, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddHotel method initiated.");

                    // Validate the request model
                    if (hotelRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddHotel called with a null hotelRequestModel.");
                        return Result.NoContent();
                    }

                    var existingHotel = await _checkinProContext.tblHotels.FirstOrDefaultAsync(item => item.BusinessLLCName == hotelRequestModel.BusinessLLCName || item.Email == hotelRequestModel.Email);
                    if (existingHotel != null)
                    {
                        _logger.LogWarning("Repository: A hotel with the same email or business name already exists.");
                        return Result.Error("A hotel with the same business name or email already exists.");
                    }

                    // Check if the owner already exists
                    var checkOwnerAlreadyExists = await _checkinProContext.tblUsers.FirstOrDefaultAsync(item => item.EmailID == hotelRequestModel.Userinfo.EmailID);

                    if (checkOwnerAlreadyExists != null)
                    {
                        _logger.LogWarning("Repository: This Owner already exists.");
                        return Result.Error("Owner already exists.");
                    }

                    // Create and add the new hotel
                    tblHotel dbHotel = new tblHotel()
                    {
                        BusinessLLCName = hotelRequestModel.BusinessLLCName,
                        Email = hotelRequestModel.Email,
                        MobileNumber = hotelRequestModel.MobileNumber,
                        Address1 = hotelRequestModel.Address1,
                        Address2 = hotelRequestModel.Address2,
                        StateID = hotelRequestModel.StateID,
                        City = hotelRequestModel.City,
                        ZipCode = hotelRequestModel.ZipCode,
                        Website = hotelRequestModel.Website,
                        Description = hotelRequestModel.Description,
                        IsHotelVerified = true,
                        IsHotelActive = true,
                        IsOwnerDashboardVisible = hotelRequestModel.IsOwnerDashboardVisible,
                        IsHotelBlocked = false,
                        IsHotelDeleted = false,
                        CreatedBy = auditInfoModel.AuditUserID,
                        CreatedDate = DateTime.Now
                    };

                    // Create and add the new user
                    tblUser dbUser = new tblUser()
                    {
                        RoleID = 2,
                        FirstName = hotelRequestModel.Userinfo.FirstName,
                        LastName = hotelRequestModel.Userinfo.LastName,
                        EmailID = hotelRequestModel.Userinfo.EmailID,
                        MobileNumber = hotelRequestModel.Userinfo.MobileNumber,
                        StateID = hotelRequestModel.StateID,
                        IsProfileActive = true,
                        Password = hotelRequestModel.Userinfo.Password,
                        CreatedBy = 1,
                        CreatedDate = DateTime.Now
                    };

                    tblHotelUser dbHotelUser = new tblHotelUser()
                    {
                        IsHotelUserActive = true,
                        CreatedBy = 1,
                        CreatedDate = DateTime.Now,
                        User = dbUser,
                        Hotel = dbHotel,
                    };

                    // Add & save the hotel user record to the context
                    await _checkinProContext.tblHotelUsers.AddAsync(dbHotelUser);
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Adding new hotel with Email: {hotelRequestModel.Email}");
                    _logger.LogInformation($"Repository: Creating user for hotel owner: {hotelRequestModel.Userinfo.EmailID}");
                    _logger.LogInformation($"Repository: Successfully added hotel info with UserID: {dbUser.UserID} and HotelID: {dbHotel.HotelID}.");

                    //Sending invite mail with password to the owner
                    var emailTemplate = await _checkinProContext.tblEmailTemplates.Where(item => item.EmailTemplateName == "NewAccount").FirstOrDefaultAsync();
                    if (emailTemplate != null && !string.IsNullOrEmpty(emailTemplate.EmailTemplateDesign))
                    {
                        var messageBody = emailTemplate.EmailTemplateDesign;
                        StringBuilder strmsg = new StringBuilder(messageBody);
                        strmsg.Replace("[Recipient_Name]", hotelRequestModel.Userinfo.FirstName + " " + hotelRequestModel.Userinfo.LastName);
                        strmsg.Replace("[HoteL_Name]", hotelRequestModel.BusinessLLCName);
                        strmsg.Replace("[HoteL_Code]", dbHotel.HotelCode);
                        strmsg.Replace("[Email]", hotelRequestModel.Userinfo.EmailID);
                        strmsg.Replace("[Generated_Password]", randomPassword);
                        strmsg.Replace("[SignIn_URL]", "https://localhost:7020/signin");
                        await _emailService.SendEmailAsync(hotelRequestModel.Userinfo.EmailID, emailTemplate.EmailTemplateSubject, strmsg.ToString());
                    }
                    else
                    {
                        _logger.LogWarning("Repository: Email template is missing or incomplete.");
                        return Result.Error("Email template is missing or incomplete.");
                    }

                    _logger.LogInformation($"Repository: Invitation mail with password is sent to EmailID: {hotelRequestModel.Userinfo.EmailID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while adding hotel info. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: AddHotel Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while adding the hotel info.");
                }
            }
        }

        public async Task<Result> ActiveInactiveOwnerDashboard(int hotelID, bool isActive, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: ActiveInactiveOwnerDashboard method initiated");

                    // Fetch the existing entity
                    var dbHotelData = await _checkinProContext.tblHotels.FindAsync(hotelID);
                    if (dbHotelData == null)
                    {
                        _logger.LogWarning($"Repository: No hotel found with hotelID: {hotelID}.");
                        return Result.NoContent();
                    }

                    if (dbHotelData.IsHotelDeleted)
                    {
                        _logger.LogWarning("Repository: hotel is already deleted.");
                        return Result.Error("hotel is already deleted.");
                    }

                    //updating the flag
                    dbHotelData.IsOwnerDashboardVisible = isActive;
                    dbHotelData.UpdatedBy = auditInfoModel.AuditUserID;
                    dbHotelData.UpdatedDate = DateTime.Now;

                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully activated/inactivated hotel with ID: {hotelID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while activating hotel. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: ActiveInactiveOwnerDashboard Exception occurred for hotelID: {hotelID}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while ActiveInactiveOwnerDashboard.");
                }
            }
        }

        public async Task<Result> ActiveInactiveHotel(int hotelID, bool isActive, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: ActiveInactiveHotel method initiated");

                    // Fetch the existing entity
                    var dbHotelData = await _checkinProContext.tblHotels.Include(item => item.tblHotelUsers).ThenInclude(item => item.User).Where(item => item.HotelID == hotelID).FirstOrDefaultAsync();
                    if (dbHotelData == null)
                    {
                        _logger.LogWarning($"Repository: No hotel found with hotelID: {hotelID}.");
                        return Result.NoContent();
                    }

                    if (dbHotelData.IsHotelDeleted)
                    {
                        _logger.LogWarning("Repository: hotel is already deleted.");
                        return Result.Error("hotel is already deleted.");
                    }

                    //updating the flag
                    dbHotelData.IsHotelActive = isActive;
                    dbHotelData.UpdatedBy = auditInfoModel.AuditUserID;
                    dbHotelData.UpdatedDate = DateTime.Now;

                    foreach (var item in dbHotelData.tblHotelUsers)
                    {
                        item.User.IsProfileActive = isActive;
                        item.User.UpdatedBy = auditInfoModel.AuditUserID;
                        item.User.UpdatedDate = DateTime.Now;
                    }

                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully activated/inactivated hotel with ID: {hotelID}.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while activating hotel. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: ActiveInactiveHotel Exception occurred for hotelID: {hotelID}. Stacktrace: {ex}");
                    return Result.Error("An error occurred while ActiveInactiveHotel.");
                }
            }
        }

        public async Task<Result> AddHotelExpense(HotelExpenseModel hotelExpenseRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddHotelExpense method initiated.");

                    // Validate the request model
                    if (hotelExpenseRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddHotelExpense called with a null hotelExpenseRequestModel.");
                        return Result.NoContent();
                    }
                    tblHotelExpense dbHotelExpense = new tblHotelExpense()
                    {
                        HotelID = hotelExpenseRequestModel.HotelID,
                        ExpenseDate = hotelExpenseRequestModel.ExpenseDate,
                        ExpenseType = hotelExpenseRequestModel.ExpenseType,
                        ExpenseAmount = hotelExpenseRequestModel.ExpenseAmount,
                        ExpenseDescription = hotelExpenseRequestModel.ExpenseDescription,
                        Attachment = hotelExpenseRequestModel.Attachment,
                        CreatedBy = auditInfoModel.AuditUserID,
                        CreatedDate = DateTime.Now
                    };

                    // Add & save the hotel expense to the context
                    await _checkinProContext.tblHotelExpenses.AddAsync(dbHotelExpense);
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully added Hotel Expense.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while adding hotel expense. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: AddHotelExpense Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while adding the hotel expense.");
                }
            }
        }

        public async Task<Result<List<HotelExpenseModel>>> GetHotelExpense(int hotelID)
        {
            try
            {
                _logger.LogInformation($"Repository: GetHotelExpense method initiated.");

                var dbHotelExpenseData = await _checkinProContext.tblHotelExpenses
                    .Where(hu => hu.HotelID == hotelID)
                    .ToListAsync();

                if (dbHotelExpenseData != null)
                {
                    var hotelList = dbHotelExpenseData.Select(he => new HotelExpenseModel
                    {
                        HotelID = he.HotelID,
                        HotelExpenseID = he.HotelExpenseID,
                        ExpenseDate = he.ExpenseDate,
                        ExpenseType = he.ExpenseType,
                        ExpenseAmount = he.ExpenseAmount,
                        ExpenseDescription = he.ExpenseDescription,
                        Attachment = he.Attachment
                    }).ToList();
                    _logger.LogInformation($"Repository: Successfully retrieved expense for HotelID: {hotelID}.");
                    return Result.Success(hotelList);

                }
                else
                {
                    _logger.LogWarning($"Repository: No hotel expense found with HotelID: {hotelID}.");
                    return Result.NotFound($"No hotel expense found with HotelID: {hotelID}.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelExpense Exception occurred for HotelID: {hotelID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the Hotel Expense.");
            }
        }

        public async Task<Result> UpdateHotelExpense(HotelExpenseModel hotelExpenseRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: UpdateHotelExpense method initiated.");

                    // Validate the request model
                    if (hotelExpenseRequestModel == null)
                    {
                        _logger.LogWarning("Repository: UpdateHotelExpense called with a null hotelExpenseRequestModel.");
                        return Result.NoContent();
                    }

                    // Fetch Hotel Expense Data
                    var dbHotelExpenseData = await _checkinProContext.tblHotelExpenses.FindAsync(hotelExpenseRequestModel.HotelExpenseID);
                    if (dbHotelExpenseData == null)
                    {
                        _logger.LogWarning($"Repository: No Hotel Expense Found.");
                        return Result.NoContent();
                    }

                    // Update the properties
                    dbHotelExpenseData.ExpenseDate = hotelExpenseRequestModel.ExpenseDate;
                    dbHotelExpenseData.ExpenseType = hotelExpenseRequestModel.ExpenseType;
                    dbHotelExpenseData.ExpenseAmount = hotelExpenseRequestModel.ExpenseAmount;
                    dbHotelExpenseData.ExpenseDescription = hotelExpenseRequestModel.ExpenseDescription;
                    dbHotelExpenseData.Attachment = hotelExpenseRequestModel.Attachment;
                    dbHotelExpenseData.UpdatedBy = auditInfoModel.AuditUserID;
                    dbHotelExpenseData.UpdatedDate = DateTime.Now;

                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully updated Hotel Expense.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while updating Hotel Expense. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: UpdateHotelExpense Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while updating Hotel Expense.");
                }
            }
        }

        public async Task<Result> DeleteHotelExpense(int hotelExpenseID)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation($"Repository: DeleteHotelExpense method initiated.");

                    var dbHotelExpenseData = await _checkinProContext.tblHotelExpenses.FindAsync(hotelExpenseID);

                    if (dbHotelExpenseData != null)
                    {
                        _checkinProContext.tblHotelExpenses.Remove(dbHotelExpenseData);
                        await _checkinProContext.SaveChangesAsync();
                        await transaction.CommitAsync();
                        return Result.Success();
                    }
                    else
                    {
                        _logger.LogWarning($"Repository: No hotel expense found.");
                        return Result.NotFound($"No hotel expense found.");
                    }
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository: Database error occurred while deleting Hotel Expense. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Repository: DeleteHotelExpense Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while deleting Hotel Expense.");
                }
            }
        }

        public async Task<Result<List<DirectBillingCompanyModel>>> GetDirectBillingCompany(int hotelID)
        {
            try
            {
                _logger.LogInformation($"Repository: GetDirectBillingCompany method initiated.");

                var dbDirectBillingCompanyData = await _checkinProContext.tblHotelDirectBillingCompanies
                    .Where(hu => hu.HotelID == hotelID)
                    .ToListAsync();

                if (dbDirectBillingCompanyData != null)
                {
                    var directBillingCompanyList = dbDirectBillingCompanyData.Select(dbc => new DirectBillingCompanyModel
                    {
                        CompanyID = dbc.CompanyID,
                        HotelID = dbc.HotelID,
                        CompanyName = dbc.CompanyName,
                        BillingAddress = dbc.BillingAddress,
                        MobileNumber = dbc.MobileNumber,
                        Email = dbc.Email,
                        ManagerFirstName = dbc.ManagerFirstName,
                        ManagerLastName = dbc.ManagerLastName,
                        ManagerAddress = dbc.ManagerAddress,
                        NameOnCreditCard = dbc.NameOnCreditCard,
                        CreditCardNumber = dbc.CreditCardNumber,
                        ExpirationDate = dbc.ExpirationDate,
                        SecurityCode = dbc.SecurityCode,
                        AccountNumber = dbc.AccountNumber,
                        RoutingNumber = dbc.RoutingNumber,
                        Notes = dbc.Notes,
                    }).ToList();

                    _logger.LogInformation($"Repository: Successfully retrieved direct billing company list for HotelID: {hotelID}.");
                    return Result.Success(directBillingCompanyList);

                }
                else
                {
                    _logger.LogWarning($"Repository: No direct billing company found with HotelID: {hotelID}.");
                    return Result.NotFound($"No direct billing company found with HotelID: {hotelID}.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetDirectBillingCompany Exception occurred for HotelID: {hotelID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the GetDirectBillingCompany.");
            }
        }


        public async Task<Result> AddUpdateDirectBillingCompany(DirectBillingCompanyModel directBillingCompanyRequestModel, AuditInfoModel auditInfoModel)
        {
            using (var transaction = await _checkinProContext.Database.BeginTransactionAsync())
            {
                try
                {
                    _logger.LogInformation("Repository: AddUpdateDirectBillingCompany method initiated.");

                    // Validate the request model
                    if (directBillingCompanyRequestModel == null)
                    {
                        _logger.LogWarning("Repository: AddUpdateDirectBillingCompany called with invalid request.");
                        return Result.NoContent();
                    }

                    var existingCompanyData = await _checkinProContext.tblHotelDirectBillingCompanies.Where(item => item.CompanyID == directBillingCompanyRequestModel.CompanyID).FirstOrDefaultAsync();
                    if (existingCompanyData != null)
                    {

                        existingCompanyData.CompanyName = directBillingCompanyRequestModel.CompanyName;
                        existingCompanyData.BillingAddress = directBillingCompanyRequestModel.BillingAddress;
                        existingCompanyData.MobileNumber = directBillingCompanyRequestModel.MobileNumber;
                        existingCompanyData.Email = directBillingCompanyRequestModel.Email;
                        existingCompanyData.ManagerFirstName = directBillingCompanyRequestModel.ManagerFirstName;
                        existingCompanyData.ManagerLastName = directBillingCompanyRequestModel.ManagerLastName;
                        existingCompanyData.ManagerAddress = directBillingCompanyRequestModel.ManagerAddress;
                        existingCompanyData.NameOnCreditCard = directBillingCompanyRequestModel.NameOnCreditCard;
                        existingCompanyData.CreditCardNumber = directBillingCompanyRequestModel.CreditCardNumber;
                        existingCompanyData.ExpirationDate = directBillingCompanyRequestModel.ExpirationDate;
                        existingCompanyData.SecurityCode = directBillingCompanyRequestModel.SecurityCode;
                        existingCompanyData.AccountNumber = directBillingCompanyRequestModel.AccountNumber;
                        existingCompanyData.RoutingNumber = directBillingCompanyRequestModel.RoutingNumber;
                        existingCompanyData.Notes = directBillingCompanyRequestModel.Notes;
                        existingCompanyData.UpdatedBy = auditInfoModel.AuditUserID;
                        existingCompanyData.UpdatedDate = DateTime.Now;

                        _checkinProContext.Update(existingCompanyData);
                        _logger.LogInformation($"Repository: Successfully updated company data.");
                    }
                    else
                    {
                        var dbDirectBillingCompany = new tblHotelDirectBillingCompany
                        {

                            HotelID = directBillingCompanyRequestModel.HotelID,
                            CompanyName = directBillingCompanyRequestModel.CompanyName,
                            BillingAddress = directBillingCompanyRequestModel.BillingAddress,
                            MobileNumber = directBillingCompanyRequestModel.MobileNumber,
                            Email = directBillingCompanyRequestModel.Email,
                            ManagerFirstName = directBillingCompanyRequestModel.ManagerFirstName,
                            ManagerLastName = directBillingCompanyRequestModel.ManagerLastName,
                            ManagerAddress = directBillingCompanyRequestModel.ManagerAddress,
                            NameOnCreditCard = directBillingCompanyRequestModel.NameOnCreditCard,
                            CreditCardNumber = directBillingCompanyRequestModel.CreditCardNumber,
                            ExpirationDate = directBillingCompanyRequestModel.ExpirationDate,
                            SecurityCode = directBillingCompanyRequestModel.SecurityCode,
                            AccountNumber = directBillingCompanyRequestModel.AccountNumber,
                            RoutingNumber = directBillingCompanyRequestModel.RoutingNumber,
                            Notes = directBillingCompanyRequestModel.Notes,
                            CreatedBy = auditInfoModel.AuditUserID,
                            CreatedDate = DateTime.Now,
                        };

                        await _checkinProContext.tblHotelDirectBillingCompanies.AddAsync(dbDirectBillingCompany);
                        _logger.LogInformation($"Repository: Successfully added company data.");
                    }
                    await _checkinProContext.SaveChangesAsync();
                    await transaction.CommitAsync();

                    _logger.LogInformation($"Repository: Successfully added or updated company data.");
                    return Result.Success();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();

                    _logger.LogError($"Repository: Database error occurred while AddUpdateDirectBillingCompany. {dbEx.Message}");
                    return Result.Error("A database error occurred. Please try again later.");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    _logger.LogError($"Repository:AddUpdateDirectBillingCompany Exception occurred. Stacktrace: {ex}");
                    return Result.Error("An error occurred while AddUpdateDirectBillingCompany.");
                }
            }
        }

    }
}


