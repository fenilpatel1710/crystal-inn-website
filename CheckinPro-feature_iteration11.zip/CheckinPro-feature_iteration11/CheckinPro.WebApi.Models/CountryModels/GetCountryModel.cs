﻿namespace CheckinPro.WebApi.Models
{
    public class GetCountryModel
    {
        public int CountryID { get; set; }

        public string CountryName { get; set; }

        public string? ISO2 { get; set; }

        public string? ISO3 { get; set; }

        public string? PhoneCode { get; set; }

        public string? Capital { get; set; }

        public string? Currency { get; set; }

        public bool IsCountryActive { get; set; }

        public virtual ICollection<GetStateModel> States { get; set; } = new List<GetStateModel>();
    }
}
