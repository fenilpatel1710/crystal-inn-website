﻿
namespace CheckinPro.WebApi.Models
{
    public partial class UpdateUserModel
    {
        public string EmailID { get; set; }

        public string MobileNumber { get; set; }

        public string? Address1 { get; set; }

        public string? Address2 { get; set; }

        public int StateID { get; set; }

        public string? City { get; set; }

        public string? ZipCode { get; set; }

        public string? ProfilePicture { get; set; }
    }
}
