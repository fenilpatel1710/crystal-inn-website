﻿using CheckinPro.Common.Models.Constants;
using System.ComponentModel.DataAnnotations;

namespace CheckinPro.WebApi.Models
{
    public partial class AddUserModel
    {
        public int HotelID { get; set; }

        public int RoleID { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        [RegularExpression(CommonConstants.CheckRegularExpression.EmailRegEx, ErrorMessage = CommonConstants.DataAnnotationsErrorMessages.Invalid_Email_Format_Error_Message)]
        public string EmailID { get; set; }

        //length for mobile number should be updated in the DB
        // [RegularExpression(CommonConstants.CheckRegularExpression.MobileNumberRegEx, ErrorMessage = CommonConstants.DataAnnotationsErrorMessages.Invalid_MobileNumber_Format_Error_Message)] 
        public string MobileNumber { get; set; }

        public string? Address1 { get; set; }

        public string? Address2 { get; set; }

        public int StateID { get; set; }

        public string? City { get; set; }

        public string? ZipCode { get; set; }

        public string? Password { get; set; }
    }
}
