﻿namespace CheckinPro.WebApi.Models
{
    public class GetRoomStatusModel
    {
        public int RoomStatusID { get; set; }

        public string? RoomStatusName { get; set; }

        public string? Description { get; set; }

        public string? RoomStatusIcon { get; set; }

        public bool IsActive { get; set; }

        public bool IsDeleted { get; set; }
    }
}
