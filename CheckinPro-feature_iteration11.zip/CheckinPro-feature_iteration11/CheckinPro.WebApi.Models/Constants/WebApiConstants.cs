﻿
namespace CheckinPro.WebApi.Models
{
    internal class WebApiConstants
    {
    }
}
