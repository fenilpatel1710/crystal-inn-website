﻿namespace CheckinPro.WebApi.Models
{
    public class AddGuestModel
    {
        public int GuestID { get; set; }

        public string? GuestCode { get; set; }

        public string FirstName { get; set; } = null!;

        public string LastName { get; set; } = null!;

        public string? MobileNumber { get; set; }

        public string? IdentityType { get; set; }

        public string? IdentityNumber { get; set; }

        public string? FrontSideImage { get; set; }

        public string? Email { get; set; }

        public string? Address1 { get; set; }

        public string? Address2 { get; set; }

        public string? Country { get; set; }

        public string? State { get; set; }

        public string? City { get; set; }

        public string? ZipCode { get; set; }

        public int? ScanID { get; set; }

        public bool? IsGuestScanned { get; set; }

        public string? ProfilePicture { get; set; }

        public bool IsPrimaryGuest { get; set; }
    }
}
