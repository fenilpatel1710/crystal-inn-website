﻿using System.Text.Json.Serialization;
using System.Xml.Serialization;

namespace CheckinPro.WebApi.Models.GuestModels
{
    [XmlRoot("Root")]
    public class GuestIdScanDataModel
    {
        [XmlElement("NewData")]
        [JsonPropertyName("AllResults")]
        public NewDatas NewDatas { get; set; }
    }

    public class NewDatas
    {
        [XmlElement("NewData")]
        [JsonPropertyName("Scan#1")]
        public Guest_XML_JSON_DataModel NewData { get; set; }
    }

    public class Guest_XML_JSON_DataModel
    {
        [XmlElement("Document_Scan_Date")]
        [JsonPropertyName("Document_Scan_Date")]
        public string? DocumentScanDate { get; set; }


        [XmlElement("OCR_Given_Name")]
        [JsonPropertyName("OCR Given Name")]
        public string? OCRGivenName { get; set; }

        [XmlElement("MRZ_Given_Name")]
        [JsonPropertyName("MRZ Given Name")]
        public string? MRZGivenName { get; set; }

        [JsonIgnore]
        public string? FirstName => !string.IsNullOrWhiteSpace(OCRGivenName) ? OCRGivenName : MRZGivenName;



        [XmlElement("OCR_Surname")]
        [JsonPropertyName("OCR Surname")]
        public string? OCRSurname { get; set; }

        [XmlElement("MRZ_Surname")]
        [JsonPropertyName("MRZ Surname")]
        public string? MRZSurname { get; set; }

        [JsonIgnore]
        public string? LastName => !string.IsNullOrWhiteSpace(OCRSurname) ? OCRSurname : MRZSurname;



        [XmlElement("Front_Document_Type")]
        [JsonPropertyName("Front Document Type")]
        public string? FrontDocumentType { get; set; }

        [XmlElement("OCR_Document_Number")]
        [JsonPropertyName("OCR Document Number")]
        public string? OCRDocumentNumber { get; set; }

        [XmlElement("MRZ_Document_Number")]
        [JsonPropertyName("MRZ Document Number")]
        public string? MRZDocumentNumber { get; set; }

        [JsonIgnore]
        public string? DocumentNumber => !string.IsNullOrWhiteSpace(OCRDocumentNumber) ? OCRDocumentNumber : MRZDocumentNumber;




        [XmlElement("OCR_Address")]
        [JsonPropertyName("OCR Address")]
        public string? OCRAddress { get; set; }

        [XmlElement("OCR_Issuing_State_Code")]
        [JsonPropertyName("OCR Issuing State Code")]
        public string? OCRIssuingStateCode { get; set; }

        [XmlElement("MRZ_Issuing_State_Code")]
        [JsonPropertyName("MRZ Issuing State Code")]
        public string? MRZIssuingStateCode { get; set; }

        [JsonIgnore]
        public string? IssuingStateCode => !string.IsNullOrWhiteSpace(OCRIssuingStateCode) ? OCRIssuingStateCode : MRZIssuingStateCode;


        [XmlElement("OCR_addressState")]
        [JsonPropertyName("OCR addressState")]
        public string? OCRAddressState { get; set; }

        [XmlElement("OCR_State")]
        [JsonPropertyName("OCR State")]
        public string? OCRState { get; set; }

        [XmlElement("OCR_City")]
        [JsonPropertyName("OCR City")]
        public string? OCRCity { get; set; }

        [XmlElement("OCR_Zip")]
        [JsonPropertyName("OCR Zip")]
        public string? OCRZip { get; set; }

        [XmlElement("Front_Image")]
        [JsonPropertyName("Front Image")]
        public string? FrontImage { get; set; }
    }
}
