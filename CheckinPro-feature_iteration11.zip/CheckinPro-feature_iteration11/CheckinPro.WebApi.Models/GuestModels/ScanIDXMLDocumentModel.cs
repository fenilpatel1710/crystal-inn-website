﻿using System.Text.Json.Serialization;
using System.Xml.Serialization;

namespace CheckinPro.WebApi.Models
{
    [XmlRoot("Root")]
    public class ScanIDXMLDocumentModel
    {
        [XmlElement("NewData")]
        [JsonPropertyName("NewData")]
        public Scanner_XML_JSON_Data NewData { get; set; }
    }
    public class Scanner_XML_JSON_Data
    {
        [XmlElement("Front_Document_Classification")]
        [JsonPropertyName("Front Document Classification")]
        public string? FrontDocumentClassification { get; set; }

        [XmlElement("Front_Document_Region")]
        [JsonPropertyName("Front Document Region")]
        public string? FrontDocumentRegion { get; set; }

        [XmlElement("Front_Document_Country")]
        [JsonPropertyName("Front Document Country")]
        public string? FrontDocumentCountry { get; set; }

        [XmlElement("Front_Document_Type")]
        [JsonPropertyName("Front Document Type")]
        public string? FrontDocumentType { get; set; }

        [XmlElement("Front_Document_Side")]
        [JsonPropertyName("Front Document Side")]
        public string? FrontDocumentSide { get; set; }

        [XmlElement("Front_Document_Country_Code")]
        [JsonPropertyName("Front Document Country Code")]
        public string? FrontDocumentCountryCode { get; set; }

        [XmlElement("Front_Document_Country_ISOCode2")]
        [JsonPropertyName("Front Document Country ISOCode2")]
        public string? FrontDocumentCountryISOCode2 { get; set; }

        [XmlElement("Front_Document_Country_ISOCode3")]
        [JsonPropertyName("Front Document Country ISOCode3")]
        public string? FrontDocumentCountryISOCode3 { get; set; }

        [XmlElement("OCR_Date_Of_Expiry")]
        [JsonPropertyName("OCR Date Of Expiry")]
        public string? OCRDateOfExpiry { get; set; }

        [XmlElement("OCR_Date_Of_Expiry_Original")]
        [JsonPropertyName("OCR Date Of Expiry_Original")]
        public string? OCRDateOfExpiryOriginal { get; set; }

        [XmlElement("OCR_Given_Name")]
        [JsonPropertyName("OCR Given Name")]
        public string? OCRGivenName { get; set; }

        [XmlElement("OCR_Document_Number")]
        [JsonPropertyName("OCR Document Number")]
        public string? OCRDocumentNumber { get; set; }

        [XmlElement("OCR_Date_Of_Issue")]
        [JsonPropertyName("OCR Date Of Issue")]
        public string? OCRDateOfIssue { get; set; }

        [XmlElement("OCR_Date_Of_Issue_Original")]
        [JsonPropertyName("OCR Date Of Issue_Original")]
        public string? OCRDateOfIssueOriginal { get; set; }

        [XmlElement("OCR_DL_Class")]
        [JsonPropertyName("OCR DL Class")]
        public string? OCRDLClass { get; set; }

        [XmlElement("OCR_Date_Of_Birth")]
        [JsonPropertyName("OCR Date Of Birth")]
        public string? OCRDateOfBirth { get; set; }

        [XmlElement("OCR_Date_Of_Birth_Original")]
        [JsonPropertyName("OCR Date Of Birth_Original")]
        public string? OCRDateOfBirthOriginal { get; set; }

        [XmlElement("OCR_Race_Ethnicity")]
        [JsonPropertyName("OCR Race Ethnicity")]
        public string? OCRRaceEthnicity { get; set; }

        [XmlElement("OCR_Hair_Color")]
        [JsonPropertyName("OCR Hair Color")]
        public string? OCRHairColor { get; set; }

        [XmlElement("OCR_Hair_Color_Original")]
        [JsonPropertyName("OCR Hair Color_Original")]
        public string? OCRHairColorOriginal { get; set; }

        [XmlElement("OCR_Eyes_Color")]
        [JsonPropertyName("OCR Eyes Color")]
        public string? OCREyesColor { get; set; }

        [XmlElement("OCR_Eyes_Color_Original")]
        [JsonPropertyName("OCR Eyes Color_Original")]
        public string? OCREyesColorOriginal { get; set; }

        [XmlElement("OCR_Weight")]
        [JsonPropertyName("OCR Weight")]
        public string? OCRWeight { get; set; }

        [XmlElement("OCR_Weight_Original")]
        [JsonPropertyName("OCR Weight_Original")]
        public string? OCRWeightOriginal { get; set; }


        [XmlElement("OCR_Height")]
        [JsonPropertyName("OCR Height")]
        public string? OCRHeight { get; set; }

        [XmlElement("OCR_Height_Original")]
        [JsonPropertyName("OCR Height_Original")]
        public string? OCRHeightOriginal { get; set; }

        [XmlElement("OCR_Full_Address")]
        [JsonPropertyName("OCR Full Address")]
        public string? OCRFullAddress { get; set; }

        [XmlElement("OCR_Address")]
        [JsonPropertyName("OCR Address")]
        public string? OCRAddress { get; set; }

        [XmlElement("OCR_City")]
        [JsonPropertyName("OCR City")]
        public string? OCRCity { get; set; }

        [XmlElement("OCR_State")]
        [JsonPropertyName("OCR State")]
        public string? OCRState { get; set; }

        [XmlElement("OCR_Zip")]
        [JsonPropertyName("OCR Zip")]
        public string? OCRZip { get; set; }

        [XmlElement("OCR_Issuing_State_Code")]
        [JsonPropertyName("OCR Issuing State Code")]
        public string? OCRIssuingStateCode { get; set; }

        [XmlElement("OCR_addressState")]
        [JsonPropertyName("OCR addressState")]
        public string? OCRAddressState { get; set; }

        [XmlElement("OCR_Full_Name")]
        [JsonPropertyName("OCR Full Name")]
        public string? OCRFullName { get; set; }

        [XmlElement("OCR_Emulate_Full_Name")]
        [JsonPropertyName("OCR Emulate Full Name")]
        public string? OCREmulateFullName { get; set; }

        [XmlElement("OCR_Emulate_First_Name")]
        [JsonPropertyName("OCR Emulate First Name")]
        public string? OCREmulateFirstName { get; set; }

        [XmlElement("OCR_Emulate_Last_Name")]
        [JsonPropertyName("OCR Emulate Last Name")]
        public string? OCREmulateLastName { get; set; }

        [XmlElement("Front_Image")]
        [JsonPropertyName("Front Image")]
        public string? FrontImage { get; set; }
    }
}
