﻿namespace CheckinPro.WebApi.Models
{
    public class GuestRewardModel
    {
        public int GuestRewardID { get; set; }

        public int? GuestID { get; set; }

        public int? HotelID { get; set; }

        public decimal? TotalRewardPoint { get; set; }
    }
}
