﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.WebApi.Models
{
    public class GuestIDScan
    {
        public int ScanID { get; set; }

        public Guid? HotelUniqueID { get; set; }

        public string? Document_Number { get; set; }

        public DateTime? Document_Scan_Date { get; set; }

        public string? Scanner_JSON_File { get; set; }

        public string? Scanner_XML_File { get; set; }

        public DateTime? CreatedDate { get; set; }
    }
}
