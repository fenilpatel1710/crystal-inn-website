﻿using CheckinPro.Common.Models.Constants;
using System.ComponentModel.DataAnnotations;

namespace CheckinPro.WebApi.Models
{
    public partial class SignInRequestModel
    {
        [RegularExpression(CommonConstants.CheckRegularExpression.EmailRegEx, ErrorMessage = CommonConstants.DataAnnotationsErrorMessages.Invalid_Email_Format_Error_Message)]
        public string EmailID { get; set; }

        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
