﻿using CheckinPro.Common.Models.Constants;
using System.ComponentModel.DataAnnotations;

namespace CheckinPro.WebApi.Models
{
    public partial class ChangePasswordModel
    {
        [RegularExpression(CommonConstants.CheckRegularExpression.EmailRegEx, ErrorMessage = CommonConstants.DataAnnotationsErrorMessages.Invalid_Email_Format_Error_Message)]
        public string EmailID { get; set; }

        [DataType(DataType.Password)]
        public string OldPassword { get; set; }

        [DataType(DataType.Password)]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,}", ErrorMessage = "Password must contain: Minimum 8 atleast 1 UpperCase Alphabet, 1 LowerCase Alphabet, 1 Number and 1 Special Character.")]
        public string NewPassword { get; set; }

        [DataType(DataType.Password)]
        [Compare("NewPassword", ErrorMessage = "New Password and Confirm New Password dose not match")]
        public string ConfirmNewPassword { get; set; }
    }
}
