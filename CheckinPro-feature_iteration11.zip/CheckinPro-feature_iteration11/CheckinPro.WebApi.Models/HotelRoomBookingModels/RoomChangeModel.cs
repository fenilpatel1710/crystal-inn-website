﻿
namespace CheckinPro.WebApi.Models
{
    public class RoomChangeModel
    {
        public int HotelRoomBookingID { get; set; }

        public int HotelRoomTypeID { get; set; }

        public int? HotelRoomID { get; set; }

        public int? OldHotelRoomID { get; set; }
    }
}
