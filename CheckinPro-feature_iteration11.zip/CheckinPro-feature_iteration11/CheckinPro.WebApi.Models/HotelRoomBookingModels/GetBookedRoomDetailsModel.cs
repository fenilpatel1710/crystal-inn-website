﻿namespace CheckinPro.WebApi.Models
{
    public class GetBookedRoomDetailsModel
    {
        public DateTime? ScheduledCheckInDate { get; set; }

        public DateTime? ScheduledCheckOutDate { get; set; }

        public string? RoomType { get; set; }

        public string? GuestName { get; set; }

        public string? RoomNumber { get; set; }

        public int? Duration { get; set; }

        public bool IsHourlyBooking { get; set; }

        public string? BookingStatus { get; set; }
    }
}
