﻿
namespace CheckinPro.WebApi.Models
{
    public class FindHotelRoomBookingModel
    {
        public int? HotelId { get; set; }
        public string? BookingCode { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string? RoomNumber { get; set; }
        public string? GuestCode { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? BookingStatus { get; set; }
        public int? HotelRoomTypeID { get; set; }
    }
}
