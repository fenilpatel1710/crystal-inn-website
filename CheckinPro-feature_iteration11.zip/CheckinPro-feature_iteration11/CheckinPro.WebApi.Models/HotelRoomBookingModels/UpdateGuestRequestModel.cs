﻿

namespace CheckinPro.WebApi.Models
{
    public class UpdateGuestRequestModel
    {
        public int HotelRoomBookingID { get; set; }

        public string? GuestSpecialRequests { get; set; }

        public string? GuestNoteType { get; set; }

        public string? GuestNotes { get; set; }

    }
}
