﻿namespace CheckinPro.WebApi.Models
{
    public class AddEditMiscAmountModel
    {
        public int HotelRoomBookingMiscellaneousID { get; set; }
        public int HotelRoomBookingID { get; set; }
        public DateTime? MiscellaneousDate { get; set; }
        public decimal? MiscellaneousAmount { get; set; }
        public decimal? FinalAmount { get; set; }
    }
}
