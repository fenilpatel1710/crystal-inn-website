﻿namespace CheckinPro.WebApi.Models
{
    public class HotelRoomBookingModel
    {
        public int HotelRoomBookingID { get; set; }

        public int HotelRoomTypeID { get; set; }

        public int? HotelRoomID { get; set; }

        public string? BookingCode { get; set; }

        public DateTime? ScheduledCheckInDate { get; set; }

        public DateTime? ScheduledCheckOutDate { get; set; }

        public int? Duration { get; set; }

        public DateTime? ActualCheckInDate { get; set; }

        public DateTime? ActualCheckOutDate { get; set; }

        public int? NumberOfGuests { get; set; }

        public bool IsHourlyBooking { get; set; }

        public string? BookingStatus { get; set; }

        public string? GuestSpecialRequests { get; set; }

        public string? GuestNoteType { get; set; }

        public string? GuestNotes { get; set; }

        public bool IsBookingCancelled { get; set; }

        public string? CancellationReason { get; set; }

        public bool IsIncludedInReport { get; set; }


        public virtual List<AddGuestModel> Guests { get; set; } = new List<AddGuestModel>();

        public virtual AddEditHotelRoomModel HotelRoom { get; set; } = new AddEditHotelRoomModel();

        public virtual HotelRoomTypeModel HotelRoomType { get; set; } = new HotelRoomTypeModel();

        public virtual ICollection<HotelRoomBookingAuditModel> HotelRoomBookingAudits { get; set; } = new List<HotelRoomBookingAuditModel>();

        public virtual ICollection<HotelRoomBookingRateDetailModel> HotelRoomBookingRateDetails { get; set; } = new List<HotelRoomBookingRateDetailModel>();

        public virtual ICollection<HotelRoomBookingTaxRateModel> HotelRoomBookingTaxRates { get; set; } = new List<HotelRoomBookingTaxRateModel>();

        public virtual ICollection<AddPaymentModel> HotelRoomPayments { get; set; } = new List<AddPaymentModel>();
    }
}
