﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.WebApi.Models
{
    public class HotelRoomBookingAuditModel
    {
        public string? ActionName { get; set; }

        public DateTime? ActionDateTime { get; set; }
        
        public string? ActionBy { get; set; }
        
        public string? ActionComment { get; set; }   
    }
}
