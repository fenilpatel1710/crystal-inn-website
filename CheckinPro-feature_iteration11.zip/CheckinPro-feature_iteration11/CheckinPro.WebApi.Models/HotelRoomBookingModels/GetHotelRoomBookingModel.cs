﻿namespace CheckinPro.WebApi.Models
{
    public partial class GetHotelRoomBookingModel
    {
        public int HotelRoomBookingID { get; set; }

        public int HotelRoomTypeID { get; set; }

        public int? HotelRoomID { get; set; }

        public string? BookingCode { get; set; }

        public DateTime? ScheduledCheckInDate { get; set; }

        public DateTime? ScheduledCheckOutDate { get; set; }

        public int? Duration { get; set; }

        public DateTime? ActualCheckInDate { get; set; }

        public DateTime? ActualCheckOutDate { get; set; }

        public int? NumberOfGuests { get; set; }

        public bool IsHourlyBooking { get; set; }

        public decimal? BestAvailableRate { get; set; }

        public decimal? AdjustmentRate { get; set; }

        public decimal? HourlyRate { get; set; }

        public decimal? SubTotalAmount { get; set; }

        public decimal? TotalAmount { get; set; }

        public string? AdditionalRateType { get; set; }

        public decimal? AdditionalRateAmount { get; set; }

        public decimal? DiscountedAmount { get; set; }

        public decimal? FinalAmount { get; set; }

        public decimal? TotalPaid { get; set; }

        public string? BookingStatus { get; set; }

        public string? PaymentStatus { get; set; }

        public string? GuestSpecialRequests { get; set; }

        public string? GuestNoteType { get; set; }

        public string? GuestNotes { get; set; }

        public bool IsBookingCancelled { get; set; }

        public string? CancellationReason { get; set; }
        
        public bool IsBookingExtend { get; set; }

        public bool IsExtended { get; set; }

        public int? OriginalHotelRoomBookingID { get; set; }

        public bool IsIncludedInReport { get; set; }

        public virtual HotelRoomTypeModel HotelRoomType { get; set; } = new HotelRoomTypeModel();

        public virtual List<GetGuestModel> GetGuests { get; set; } = new List<GetGuestModel>();

        public virtual GetHotelRoomModel GetHotelRoom { get; set; } = new GetHotelRoomModel();

        public virtual ICollection<GetPaymentModel> GetPayments { get; set; } = new List<GetPaymentModel>();
    }
}
