﻿namespace CheckinPro.WebApi.Models
{
    public class GetStateModel
    {
        public int StateID { get; set; }

        public int CountryID { get; set; }

        public string StateName { get; set; }

        public bool IsStateActive { get; set; }

        public virtual GetCountryModel Country { get; set; }

        public virtual ICollection<GetGuestModel> Guests { get; set; } = new List<GetGuestModel>();

        public virtual ICollection<GetHotelModel> Hotels { get; set; } = new List<GetHotelModel>();

        public virtual ICollection<GetUserModel> Users { get; set; } = new List<GetUserModel>();

    }
}
