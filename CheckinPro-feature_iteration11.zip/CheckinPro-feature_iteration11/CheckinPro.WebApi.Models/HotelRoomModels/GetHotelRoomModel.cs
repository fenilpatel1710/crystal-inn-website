﻿namespace CheckinPro.WebApi.Models
{
    public partial class GetHotelRoomModel
    {
        public int HotelRoomID { get; set; }

        public string? RoomNumber { get; set; }

        public int? Floor { get; set; }

        public int? MaxOccupancy { get; set; }

        public decimal? BestAvailableRate { get; set; }

        public decimal? HourlyRate { get; set; }

        public string? RoomStatus { get; set; }

        public string? Description { get; set; }

        public bool IsHotelRoomActive { get; set; }

        public virtual GetHotelModel GetHotel { get; set; } = new GetHotelModel();
        public virtual HotelRoomTypeModel HotelRoomType { get; set; } = new HotelRoomTypeModel();

    }
}
