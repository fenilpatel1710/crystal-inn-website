﻿namespace CheckinPro.WebApi.Models
{
    public class HotelRoomModel
    {
        public int HotelRoomID { get; set; }

        public int HotelID { get; set; }

        public int HotelRoomTypeID { get; set; }

        public string? RoomNumber { get; set; }

        public int? Floor { get; set; }

        public int? MaxOccupancy { get; set; }

        public string? RoomStatus { get; set; }

        public string? Description { get; set; }

        public bool IsHotelRoomActive { get; set; }

        public bool IsHotelRoomDeleted { get; set; }

        public virtual GetHotelModel Hotel { get; set; } = new GetHotelModel();

        public virtual HotelRoomTypeModel HotelRoomType { get; set; } = new HotelRoomTypeModel();

        public virtual ICollection<GetHotelRoomBookingModel> HotelRoomBookings { get; set; } = new List<GetHotelRoomBookingModel>();

    }
}
