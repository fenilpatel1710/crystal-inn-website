﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.WebApi.Models.HotelRoomModels
{
    public class HotelRoomDetailModel
    {
        public int? HotelRoomBookingID { get; set; }

        public int? HotelRoomTypeID { get; set; }

        public int? HotelRoomID { get; set; }

        public string? RoomNumber { get; set; }

        public int? Floor { get; set; }

        public string? RoomTypeName { get; set; }
        
        public string? RoomTypeIcon { get; set; }
                
        public string? RoomStatus { get; set; }

        public bool IsHourlyBooking { get; set; }

        public DateTime? ScheduledCheckInDate { get; set; }
        
        public DateTime? ScheduledCheckOutDate { get; set; }

        public DateTime? ActualCheckInDate { get; set; }

        public DateTime? ActualCheckOutDate { get; set; }

        public string? GuestName { get; set; }

        public decimal? FinalAmount { get; set; }

        public string? BookingStatus { get; set; }

        public string? TimeLeftToCheckOut { get; set; }
    }
}
