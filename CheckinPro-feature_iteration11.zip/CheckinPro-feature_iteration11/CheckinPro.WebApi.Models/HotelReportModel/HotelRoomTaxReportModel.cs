﻿
namespace CheckinPro.WebApi.Models
{
    public class HotelRoomTaxReportModel
    {
        public DateTime ScheduledCheckInDate { get; set; }
        public string RoomNumber { get; set; }
        public string GuestName { get; set; }
        public decimal RoomCharge { get; set; }
        public decimal CountyTax { get; set; }
        public decimal StateTax { get; set; }
        public decimal CityTax { get; set; }
        public decimal TotalAmount { get; set; }
    }

    public class HotelInfoModel
    {
        public string BusinessLLCName { get; set; } // Hotel Name
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string? ZipCode { get; set; }
    }

    public class HotelTaxReportModel
    {
        public HotelInfoModel HotelInfo { get; set; }
        public List<HotelRoomTaxReportModel> TaxReport { get; set; }
    }
}
