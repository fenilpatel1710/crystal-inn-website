﻿namespace CheckinPro.WebApi.Models
{
    public class GetHotelRoomRevenueModel
    {
        public string? MonthName { get; set; }

        public decimal? TotalRevenue { get; set; }
    }
}
