﻿using CheckinPro.Common.Models.Constants;
using System.ComponentModel.DataAnnotations;

namespace CheckinPro.WebApi.Models
{
    public class AddHotelModel
    {
        public string BusinessLLCName { get; set; }

        [RegularExpression(CommonConstants.CheckRegularExpression.EmailRegEx, ErrorMessage = CommonConstants.DataAnnotationsErrorMessages.Invalid_Email_Format_Error_Message)]

        public string Email { get; set; }

        public string MobileNumber { get; set; }

        public string? Address1 { get; set; }

        public string? Address2 { get; set; }

        public int StateID { get; set; }

        public string? City { get; set; }

        public string? ZipCode { get; set; }

        public string? Website { get; set; }

        public decimal? TaxRate { get; set; }

        public string? Description { get; set; }

        public bool IsOwnerDashboardVisible { get; set; }

        public UserinfoWebAppModel? Userinfo { get; set; }
    }
    public partial class UserinfoWebAppModel
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        [RegularExpression(CommonConstants.CheckRegularExpression.EmailRegEx, ErrorMessage = CommonConstants.DataAnnotationsErrorMessages.Invalid_Email_Format_Error_Message)]
        public string EmailID { get; set; }

        public string MobileNumber { get; set; }

        public string? Password { get; set; }
    }
}
