﻿
namespace CheckinPro.WebApi.Models
{
    public class GetHotelModel
    {
        public int HotelID { get; set; }

        public string? HotelCode { get; set; }

        public Guid? HotelUniqueID { get; set; }

        public string? BusinessLLCName { get; set; }

        public string? Email { get; set; }

        public string? MobileNumber { get; set; }

        public string? Address1 { get; set; }

        public string? Address2 { get; set; }

        public int? StateID { get; set; }

        public string? City { get; set; }

        public string? ZipCode { get; set; }

        public string? Website { get; set; }

        public decimal? TaxRate { get; set; }

        public string? Description { get; set; }

        public bool IsOwnerDashboardVisible { get; set; }

        public bool IsHotelActive { get; set; }

        public HotelOwnerModel? hotelOwner { get; set; }
    }

    public partial class HotelOwnerModel
    {
        public string? FullName { get; set; }

        public string? EmailID { get; set; }

        public string? MobileNumber { get; set; }

    }
}
