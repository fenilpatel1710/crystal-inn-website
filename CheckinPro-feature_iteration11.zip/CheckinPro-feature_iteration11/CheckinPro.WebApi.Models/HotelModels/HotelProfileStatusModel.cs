﻿namespace CheckinPro.WebApi.Models
{
    public class HotelProfileStatusModel
    {
        public bool IsHotelTaxRatePresent { get; set; }
        public bool IsHotelConfigurationPresent { get; set; }
        public bool IsHotelDailyPresent { get; set; }
        public bool IsHotelHourlyPresent { get; set; }
        public bool IsHotelRoomTypePresent { get; set; }
        public bool IsHotelAdditionalRatePresent { get; set; }
        public bool IsHotelRoomPresent { get; set; }
        public bool IsHotelStaffPresent { get; set; }
    }
}
