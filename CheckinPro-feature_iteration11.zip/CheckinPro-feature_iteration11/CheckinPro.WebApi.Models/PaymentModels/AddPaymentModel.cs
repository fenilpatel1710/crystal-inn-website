﻿namespace CheckinPro.WebApi.Models
{
    public class AddPaymentModel
    {
        public int PaymentID { get; set; }

        public int HotelRoomBookingID { get; set; }

        public DateTime? PaymentDate { get; set; }

        public DateTime? PaymentCompletedOn { get; set; }

        public decimal? Amount { get; set; }

        public decimal? UsedRewardPoint { get; set; }

        public string? PaymentMode { get; set; }

        public string? PaymentType { get; set; }

        public string? PaymentStatus { get; set; }

        public string? PaymentGateway { get; set; }

        public string? TransactionID { get; set; }

        //public string? TransactionType { get; set; }

        public bool IsRefunded { get; set; }

        public decimal? RefundAmount { get; set; }

        public DateTime? RefundDate { get; set; }

        public string? PaymentNotes { get; set; }
        
        public string? RefundNotes { get; set; }

        //public virtual HotelRoomBookingModel HotelRoomBooking { get; set; } = new HotelRoomBookingModel();
    }
}
