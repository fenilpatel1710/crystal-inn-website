﻿
namespace CheckinPro.WebApi.Models
{
    public class GetPaymentModel
    {
        public int PaymentID { get; set; }

        public int HotelRoomBookingID { get; set; }

        public DateTime? PaymentDate { get; set; }

        public decimal? Amount { get; set; }

        public decimal? UsedRewardPoint { get; set; }

        public string? PaymentMode { get; set; }

        public string PaymentStatus { get; set; }

        public string? PaymentGateway { get; set; }

        public string? TransactionID { get; set; }

        public string? TransactionType { get; set; }

        public bool IsRefunded { get; set; }

        public decimal? RefundAmount { get; set; }

        public DateTime? RefundDate { get; set; }

        public string? PaymentNotes { get; set; }

        public virtual GetHotelRoomBookingModel HotelRoomBooking { get; set; }
    }
}
