﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.WebApi.Models
{
    public class HotelExpenseModel
    {
        public int HotelExpenseID { get; set; }

        public int HotelID { get; set; }

        public DateOnly? ExpenseDate { get; set; }

        public string? ExpenseType { get; set; }

        public decimal? ExpenseAmount { get; set; }

        public string? ExpenseDescription { get; set; }

        public byte[]? Attachment { get; set; } = null;
    }
}
