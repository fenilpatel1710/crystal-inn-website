﻿namespace CheckinPro.WebApi.Models
{
    public class HotelTaxRateModel
    {
        public int HotelTaxRateID { get; set; }

        public int HotelID { get; set; }

        public string? TaxName { get; set; }

        public decimal? TaxRate { get; set; }

        public bool IsTaxRateActive { get; set; }

        public virtual GetHotelModel Hotel { get; set; }
    }
}
