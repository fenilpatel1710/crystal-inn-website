﻿namespace CheckinPro.WebApi.Models
{
    public class HotelRoomTypeModel
    {
        public int HotelRoomTypeID { get; set; }

        public int HotelID { get; set; }

        public string? RoomTypeName { get; set; }

        public string? Description { get; set; }

        public string? RoomTypeIcon { get; set; }

        public decimal? AdjustmentRate { get; set; }

        public bool IsHotelRoomTypeActive { get; set; }

        public int NumberOfRoomsAvailable { get; set; }

        public int PendingRoomCleaning { get; set; }

        public int BookedRoom { get; set; }

        public virtual GetHotelModel Hotel { get; set; } = new GetHotelModel();
    }
}
