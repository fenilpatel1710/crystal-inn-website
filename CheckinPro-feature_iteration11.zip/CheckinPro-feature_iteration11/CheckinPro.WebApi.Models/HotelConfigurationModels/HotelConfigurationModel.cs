﻿
namespace CheckinPro.WebApi.Models
{
    public class HotelConfigurationModel
    {
        public int HotelMasterConfigurationID { get; set; }

        public int HotelID { get; set; }

        public decimal? BestAvailableRate { get; set; }

        public decimal? CashDrawerAmount { get; set; }

    }
}
