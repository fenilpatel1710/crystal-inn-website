﻿namespace CheckinPro.WebApi.Models
{
    public class HotelHourlyRateModel
    {
        public int HotelHourlyRateID { get; set; }

        public int HotelID { get; set; }

        public int? Hour { get; set; }

        public decimal? HourlyRate { get; set; }

        public bool IsHotelHourlyRateActive { get; set; } = true;

        public virtual GetHotelModel Hotel { get; set; } = new GetHotelModel();
    }
}
