﻿namespace CheckinPro.WebApi.Models
{
    public class HotelAdditionalRateModel
    {
        public int HotelAdditionalRateID { get; set; }

        public int HotelID { get; set; }

        public string? AdditionalRateName { get; set; }

        public decimal? AdditionalRate { get; set; }

        public bool IsDiscountedRate { get; set; }

        public bool IsAdditionalRateActive { get; set; }

        public virtual GetHotelModel Hotel { get; set; } = new GetHotelModel();
    }
}
