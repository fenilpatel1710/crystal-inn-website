﻿namespace CheckinPro.WebApi.Models
{
    public class HotelDailyRateModel
    {
        public int HotelDailyRateID { get; set; }

        public int HotelID { get; set; }

        public DateOnly? DailyRateDate { get; set; }

        public DateOnly? StartDate { get; set; }

        public DateOnly? EndDate { get; set; }

        public decimal? DailyBestAvailableRate { get; set; }

        public bool IsDailyRateActive { get; set; } = true;

        public virtual GetHotelModel Hotel { get; set; } = new GetHotelModel();

    }
}
