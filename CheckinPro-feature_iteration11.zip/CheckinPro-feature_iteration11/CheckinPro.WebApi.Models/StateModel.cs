﻿namespace CheckinPro.WebApi.Models
{
    public partial class StateModel
    {
        public int StateID { get; set; }

        public int CountryID { get; set; }

        public string StateName { get; set; }

        public bool IsStateActive { get; set; }

        public bool IsStateDeleted { get; set; }

        public int CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public int? UpdatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public int? DeletedBy { get; set; }

        public DateTime? DeletedDate { get; set; }
    }
}
