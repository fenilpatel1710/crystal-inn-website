﻿namespace CheckinPro.WebApi.Models
{
    public class GetHotelHourlyRateModel
    {
        public int HotelHourlyRateID { get; set; }

        public int HotelID { get; set; }

        public string? Hour { get; set; }

        public decimal? HourlyRate { get; set; }

        public bool? IsHotelHourlyRateActive { get; set; }
    }
}
