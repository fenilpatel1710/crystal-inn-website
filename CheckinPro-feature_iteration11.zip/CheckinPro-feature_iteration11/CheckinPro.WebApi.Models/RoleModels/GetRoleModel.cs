﻿
namespace CheckinPro.WebApi.Models
{
    public class GetRoleModel
    {
        public int RoleID { get; set; }

        public string RoleName { get; set; }

        public string Description { get; set; }

        public bool IsRoleActive { get; set; }

        public virtual ICollection<GetUserModel> Users { get; set; } = new List<GetUserModel>();
    }
}
