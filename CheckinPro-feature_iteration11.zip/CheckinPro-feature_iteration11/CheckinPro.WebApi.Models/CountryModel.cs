﻿
namespace CheckinPro.WebApi.Models
{
    public partial class CountryModel
    {
        public int CountryID { get; set; }

        public string CountryName { get; set; }

        public bool IsCountryActive { get; set; }

        public bool IsCountryDeleted { get; set; }

        public int? CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public int? UpdatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public int? DeletedBy { get; set; }

        public DateTime? DeletedDate { get; set; }
    }
}
