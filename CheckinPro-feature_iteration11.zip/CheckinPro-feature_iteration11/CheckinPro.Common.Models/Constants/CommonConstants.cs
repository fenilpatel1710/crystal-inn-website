﻿namespace CheckinPro.Common.Models.Constants
{
    public static class CommonConstants
    {
        public static class ApplicationUserRole
        {
            public const string SuperAdmin = "SuperAdmin";
            public const string HotelOwner = "HotelOwner";
            public const string HotelManager = "HotelManager";
            public const string HotelStaff = "HotelStaff";
        }

        public static class CheckRegularExpression
        {
            public const string EmailRegEx = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            public const string MobileNumberRegEx = @"^\+1\s\(\d{3}\)\s\d{3}-\d{4}$"; //Expected format: +1 (941) 875-1311
        }
        public static class DataAnnotationsErrorMessages
        {
            public const string Invalid_Email_Format_Error_Message = "Invalid Email Address Format.";
            public const string Invalid_MobileNumber_Format_Error_Message = "Invalid Mobile Number Format.";
        }

        public static class TaxStatus
        {
            public const int NonTaxable = 0;                //Represents No Tax applied
            public const int Taxable = 1;                   //Represents All Tax applied
            public const int PartialTaxable = 2;            //Represents Any one of Tax applied
        }

        public static class RoomStatusMessages
        {
            public const string ReadyToCheckIn = "Ready to CheckIn";    //Represents rooms that are ready for guests to check in.
            public const string PendingCleaning = "Pending Cleaning";    //Represents rooms that need to be cleaned.
            public const string OutOfService = "Out of Service";         //Represents rooms that are not available for booking due to some issue.
            public const string Booked = "Booked";                       //Represents rooms that are already reserved.
            public const string InProgress = "In Progress";              //Represents rooms in the process of some activity (e.g., being cleaned, inspected, etc.).
            public const string Maintenance = "Maintenance";             //Represents rooms that are under maintenance and unavailable for booking.
        }

        public static class BookingStatusMessages
        {
            public const string Booked = "Booked";           // Booking is confirmed and guaranteed. 
            public const string Cancelled = "Cancelled";     // Booking was cancelled by guest or admin.
            public const string CheckedIn = "CheckedIn";    // Guest has checked into the hotel.
            public const string CheckedOut = "CheckedOut";  // Guest has checked out of the hotel.
            public const string NoShow = "No Show";          // Guest didn't show up for their booking.
            public const string OverDue = "OverDue";          // Guest has checked out time Over due.
            public const string Extend = "Extend";          // Guest extend booking.
        }

        public static class PaymentStatusMessages
        {
            public const string Completed = "Completed";               // Payment is yet to be made or authorized.
            public const string Pending = "Pending";               // Payment is yet to be made or authorized.
            public const string Paid = "Paid";                     // Payment has been received.
            public const string Failed = "Failed";                 // Payment attempt failed.
            public const string Refunded = "Refunded";             // Payment was refunded to the guest.
            public const string PartiallyPaid = "Partially Paid";  // Partial payment has been made.
        }

        public static class PaymentTypeMessages
        {
            public const string Payment = "Payment";
            public const string Refund = "Refund";
        }

        public static class ReportFileName
        {
            public const string DailyAuditReport = "DailyAuditReport.pdf";
            public const string RoomTaxCollectedReport = "RoomTaxCollectedReport.pdf";
            public const string SummaryIncomeReport = "SummaryIncomeReport.pdf";
            public const string RoomRevenueReport = "RoomRevenueReport.pdf";
            public const string IncomeBreakdownReport = "IncomeBreakdownReport.pdf";
            public const string ShiftReport = "ShiftReport.pdf";
        }

        public static class PaymentModeOption
        {
            public const string CreditCard = "Credit Card";
            public const string DebitCard = "Debit Card";
            public const string Cash = "Cash";
            public const string BankTransfer = "Bank Transfer";
            public const string Check = "Check";
            public const string OnlinePay = "Online Pay";
            public const string HospitalityAdjustment = "Hospitality Adjustment";
            public const string CashApp = "CashApp";
            public const string Zelle = "Zelle";
            public const string Venmo = "Venmo";
            public const string RewardPoint = "Reward Point";
        }

        public static class PaymentTypeOption
        {
            public const string BookingPayment = "Booking Payment";
            public const string MiscellaneousAmount = "Miscellaneous Amount";
        }

        public static List<SelectionItemModel> BookingStatus = new List<SelectionItemModel>
        {
            new SelectionItemModel { ItemID=1, ItemName = "Booked" ,ItemIcon = "check_circle"},
            new SelectionItemModel { ItemID=2, ItemName = "Cancelled",ItemIcon = "cancel" },
            new SelectionItemModel { ItemID=3, ItemName = "CheckedIn" , ItemIcon = "keyboard_tab"},
            new SelectionItemModel { ItemID=4, ItemName = "CheckedOut" , ItemIcon = "keyboard_tab_rtl"},
        };

        public static List<SelectionItemModel> IdentityTypes = new List<SelectionItemModel>
        {
            new SelectionItemModel { ItemID=1, ItemName = "Passport" ,ItemIcon = "id_card"},
            new SelectionItemModel { ItemID=2, ItemName = "Driver's License",ItemIcon = "id_card" },
            new SelectionItemModel { ItemID=3, ItemName = "State ID" , ItemIcon = "id_card"},
            new SelectionItemModel { ItemID=4, ItemName = "Mexican ID" , ItemIcon = "id_card"},
            //new SelectionItemModel { ItemID=5, ItemName = "Permanent Resident Card" , ItemIcon = "id_card"},
            //new SelectionItemModel { ItemID=6, ItemName = "Travel Visa" , ItemIcon = "id_card"}
        };

        public static List<SelectionItemModel> PaymentMode = new List<SelectionItemModel>
        {
            new SelectionItemModel { ItemID = 1, ItemName = "Credit Card", ItemIcon = "credit_card" },
            new SelectionItemModel { ItemID = 2, ItemName = "Debit Card", ItemIcon = "credit_card" },
            new SelectionItemModel { ItemID = 3, ItemName = "Cash", ItemIcon = "payment" },
            new SelectionItemModel { ItemID = 4, ItemName = "Bank Transfer", ItemIcon = "account_balance" },
            new SelectionItemModel { ItemID = 5, ItemName = "Check", ItemIcon = "receipt" },
            new SelectionItemModel { ItemID = 6, ItemName = "Online Pay", ItemIcon = "payment" },
            new SelectionItemModel { ItemID = 7, ItemName = "Hospitality Adjustment", ItemIcon = "payment" },
            new SelectionItemModel { ItemID = 8, ItemName = "CashApp", ItemIcon = "attach_money" },
            new SelectionItemModel { ItemID = 9, ItemName = "Zelle", ItemIcon = "universal_currency_alt" },
            new SelectionItemModel { ItemID = 10, ItemName = "Venmo", ItemIcon = "payment" },
            new SelectionItemModel { ItemID = 11, ItemName = "Reward Point", ItemIcon = "stars" },
        };

        public static List<SelectionItemModel> PaymentType = new List<SelectionItemModel>
        {
            new SelectionItemModel { ItemID = 1, ItemName = "Booking Payment", ItemIcon = "payment" },
            new SelectionItemModel { ItemID = 2, ItemName = "Miscellaneous Amount", ItemIcon = "payment" },
        };

        public static List<SelectionItemModel> PaymentGateway = new List<SelectionItemModel>
        {
            new SelectionItemModel { ItemID = 1, ItemName = "Visa", ItemIcon = "credit_card" },
            new SelectionItemModel { ItemID = 2, ItemName = "MasterCard", ItemIcon = "credit_card" },
            new SelectionItemModel { ItemID = 3, ItemName = "American Express", ItemIcon = "credit_card" },
            new SelectionItemModel { ItemID = 4, ItemName = "PayPal", ItemIcon = "payment" },
            new SelectionItemModel { ItemID = 5, ItemName = "Apple Pay", ItemIcon = "apple" },
            new SelectionItemModel { ItemID = 6, ItemName = "Google Pay", ItemIcon = "android" },
            new SelectionItemModel { ItemID = 7, ItemName = "Discover ", ItemIcon = "credit_card" },
        };
             
        public static List<SelectionItemModel> PaymentStatus = new List<SelectionItemModel>
        {
            new SelectionItemModel { ItemID = 1, ItemName = "Completed", ItemIcon = "check_circle" },
            new SelectionItemModel { ItemID = 2, ItemName = "Pending", ItemIcon = "hourglass_empty" },
            new SelectionItemModel { ItemID = 3, ItemName = "Failed", ItemIcon = "cancel" },
            new SelectionItemModel { ItemID = 7, ItemName = "Declined", ItemIcon = "block" }
        };

        public static decimal CalculateADR(decimal? totalRoomCharge, int rented)
        {
            return Math.Round(rented > 0 && totalRoomCharge.HasValue ? totalRoomCharge.Value / rented : 0, 2);
        }

        public static decimal CalculateOccupancyPercentage(int rented, int? totalRooms)
        {
            return Math.Round(totalRooms > 0 ? ((decimal)rented / totalRooms ?? 0) * 100 : 0, 2);
        }

        public static decimal CalculateRavPar(decimal? totalRoomRevenue, int availableRooms)
        {
            return Math.Round(availableRooms > 0 && totalRoomRevenue.HasValue ? totalRoomRevenue.Value / availableRooms : 0, 2);
        }

        public static DateTime GetSystemMinDate()
        {
            var now = DateTime.Now;

            // If current time is before 6 AM, treat as previous hotel day starting at 6 AM
            if (now.Hour < 6)
            {
                return now.AddDays(-1).Date.AddHours(6); // Yesterday at 6 AM
            }

            // Otherwise, today at 6 AM
            return now.Date.AddHours(6);
        }

        public static DateTime GetSystemMaxDate()
        {
            return GetSystemMinDate().AddDays(1); // 6 AM next day
        }

        public static (DateTime StartDateTime, DateTime EndDateTime) GetAdjustedHotelDateRange(DateOnly uiStartDate, DateOnly uiEndDate)
        {
            var systemHotelDate = DateOnly.FromDateTime(GetSystemMinDate());

            // If both selected dates match today's hotel day, adjust to 6AM-6AM
            if (uiStartDate == systemHotelDate && uiEndDate == systemHotelDate)
            {
                var start = GetSystemMinDate(); // e.g., 3 May 2025 6:00 AM
                var end = start.AddDays(1);     // e.g., 4 May 2025 6:00 AM
                return (start, end);
            }

            // If not today's hotel day, treat each date as hotel days starting at 6AM
            var adjustedStart = uiStartDate.ToDateTime(TimeOnly.MinValue).AddHours(6);
            var adjustedEnd = uiEndDate.ToDateTime(TimeOnly.MinValue).AddHours(6).AddDays(1);
            return (adjustedStart, adjustedEnd);
        }

        public static class ApplicationURLs
        {
            public const string ScannerURL = "https://lumenpms.com/GuestScanDetail/";
        }
    }
}
