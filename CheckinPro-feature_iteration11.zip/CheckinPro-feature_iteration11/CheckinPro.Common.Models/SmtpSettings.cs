public partial class SmtpSettings
{
    public string SMTPHost { get; set; } = string.Empty;
    public int SMTPPort { get; set; } = 0;
    public string SMTPUsername { get; set; } = string.Empty;
    public string SMTPPassword { get; set; } = string.Empty;
    public bool SMTPEnableSsl { get; set; } = false;
}