﻿namespace CheckinPro.Common.Models
{
    public class AuditInfoModel
    {
        public int AuditUserID { get; set; }
        public string? AuditUserName { get; set; }
        public string? AuditUserRole { get; set; }
    }
}
