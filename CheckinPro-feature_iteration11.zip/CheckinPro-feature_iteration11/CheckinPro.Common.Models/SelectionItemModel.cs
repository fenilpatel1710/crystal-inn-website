﻿namespace CheckinPro.Common.Models
{
    public class SelectionItemModel
    {
        public int ItemID { get; set; }
        public string? ItemName { get; set; }
        public string? ItemIcon { get; set; }
    }
}
