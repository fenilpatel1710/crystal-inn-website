﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.Repositories.IRepository;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using Microsoft.Extensions.Logging;
public class CountryService : ICountryService
{
    private readonly ILogger _logger;
    private readonly ICountryRepository _countryRepository;
    public CountryService(ILogger<CountryService> logger, ICountryRepository countryRepository)
    {
        _logger = logger;
        _countryRepository = countryRepository;
    }

    /// <summary>
    /// Retrieves a list of countries.
    /// </summary>
    /// <returns>A <see cref="Result"/> containing a list of <see cref="CountryModel"/> representing the country data.</returns>
    public async Task<Result<List<CountryModel>>> GetCountriesAsync()
    {
        try
        {
            _logger.LogInformation("Service: GetCountriesAsync method initiated.");

            var result = await _countryRepository.GetCountries();

            _logger.LogInformation("Service: GetCountriesAsync method execution completed.");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Service: Error fetching countries: {ex.Message}");
            return Result.Error("An error occurred while fetching countries.");
        }
    }

    /// <summary>
    /// Retrieves details of a specific country by its ID.
    /// </summary>
    /// <param name="countryID">The ID of the country to retrieve.</param>
    /// <returns>A <see cref="Result"/> containing the <see cref="CountryModel"/> for the specified country.</returns>
    public async Task<Result<CountryModel>> GetCountryByIdAsync(int countryId)
    {
        try
        {
            _logger.LogInformation($"Service: GetCountryByIdAsync method initiated for CountryID: {countryId}.");
            var result = await _countryRepository.GetCountryById(countryId);
            if (result.Status == ResultStatus.NotFound)
            {
                _logger.LogWarning($"Service: No country found with CountryID: {countryId}.");
            }
            else
            {
                _logger.LogInformation($"Service: Successfully retrieved country for CountryID: {countryId}.");
            }
            _logger.LogInformation("Service: GetCountryByIdAsync method execution completed.");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Service: Error fetching country with ID {countryId}: {ex.Message}");
            return Result.Error("An error occurred while fetching the country.");
        }
    }

    /// <summary>
    /// Adds a new country record based on the provided countryRequestModel.
    /// </summary>
    /// <param name="countryRequestModel">The <see cref="CountryModel"/> containing data for the new country.</param>
    /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
    /// <returns>A <see cref="Result"/> representing the outcome of the country addition operation.</returns>
    public async Task<Result> AddCountryAsync(CountryModel countryRequestModel, AuditInfoModel auditInfoModel)
    {
        try
        {
            _logger.LogInformation("Service: AddCountryAsync method initiated.");

            var result = await _countryRepository.AddCountry(countryRequestModel, auditInfoModel);
            _logger.LogInformation("Service: AddCountryAsync method execution completed.");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Service: Error adding country: {ex.Message}");
            return Result.Error("An error occurred while adding the country.");
        }
    }

    /// <summary>
    /// Updates an existing country record based on the provided countryID and countryRequestModel.
    /// </summary>
    /// <param name="countryID">The ID of the country to be updated.</param>
    /// <param name="countryRequestModel">The <see cref="CountryModel"/> containing updated data for the country.</param>
    /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
    /// <returns>A <see cref="Result"/> representing the outcome of the country update operation.</returns>
    public async Task<Result> UpdateCountryAsync(int countryId, CountryModel countryRequestModel, AuditInfoModel auditInfoModel)
    {
        try
        {
            _logger.LogInformation($"Service: UpdateCountryAsync method initiated for CountryID: {countryId}.");

            var result = await _countryRepository.UpdateCountry(countryId, countryRequestModel, auditInfoModel);
            _logger.LogInformation("Service: UpdateCountryAsync method execution completed.");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Service: Error updating country with ID {countryId}: {ex.Message}");
            return Result.Error("An error occurred while updating the country.");
        }
    }

    /// <summary>
    /// Deletes a country based on the provided countryID.
    /// </summary>
    /// <param name="countryID">The ID of the country to be deleted.</param>
    /// <param name="countryRequestModel">The <see cref="CountryModel"/> containing updated data for the country.</param>
    /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
    /// <returns>A <see cref="Result"/> representing the outcome of the delete operation.</returns>
    public async Task<Result> DeleteCountryAsync(int countryId, CountryModel countryRequestModel, AuditInfoModel auditInfoModel)
    {
        try
        {
            _logger.LogInformation($"Service: DeleteCountryAsync method initiated for CountryID: {countryId}.");

            var result = await _countryRepository.DeleteCountry(countryId, countryRequestModel, auditInfoModel);
            _logger.LogInformation("Service: DeleteCountryAsync method execution completed.");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Service: Error deleting country with ID {countryId}: {ex.Message}");
            return Result.Error("An error occurred while deleting the country.");
        }
    }
}


