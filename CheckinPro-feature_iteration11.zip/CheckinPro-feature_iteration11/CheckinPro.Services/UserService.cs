﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.Repositories.IRepository;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Services
{
    public class UserService : IUserService
    {
        private readonly ILogger _logger;
        private readonly IUserRepository _userRepository;

        public UserService(ILogger<UserService> logger, IUserRepository userRepository)
        {
            _logger = logger;
            _userRepository = userRepository;
        }

        /// <summary>
        /// Retrieves list of all users.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetUserModel"/> representing the user data.</returns>
        public async Task<Result<List<GetUserModel>>> GetUsersAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation("Service: GetUsersAsync method initiated.");

                var result = await _userRepository.GetUsers(hotelID);

                _logger.LogInformation("Service: GetUsersAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error fetching users: {ex.Message}");
                return Result.Error("An error occurred while fetching users.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific user by its ID.
        /// </summary>
        /// <param name="userID">The ID of the user to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetUserModel"/> for the specified user Id.</returns>
        public async Task<Result<GetUserModel>> GetUserByIdAsync(int userID)
        {
            try
            {
                _logger.LogInformation($"Service: GetUserByIdAsync method initiated for UserID: {userID}.");
                var result = await _userRepository.GetUserById(userID);
                if (result.Status == ResultStatus.NotFound)
                {
                    _logger.LogWarning($"Service: No user found with UserID: {userID}.");
                }
                else
                {
                    _logger.LogInformation($"Service: Successfully retrieved user for UserID: {userID}.");
                }
                _logger.LogInformation("Service: GetUserByIdAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error fetching user with ID {userID}: {ex.Message}");
                return Result.Error("An error occurred while fetching the user.");
            }
        }

        /// <summary>
        /// Adds a new user record based on the provided addUserRequestModel.
        /// </summary>
        /// <param name="addUserRequestModel">The <see cref="AddUserModel"/> containing data for the new user.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the user creation operation.</returns>
        public async Task<Result> AddUserAsync(AddUserModel addUserRequestModel, string randomPassword, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: AddUserAsync method initiated.");

                var result = await _userRepository.AddUser(addUserRequestModel, randomPassword, auditInfoModel);
                _logger.LogInformation("Service: AddUserAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error adding user: {ex.Message}");
                return Result.Error("An error occurred while adding the user.");
            }
        }

        /// <summary>
        /// Updates an existing user record based on the provided userID and updateUserRequestModel.
        /// </summary>
        /// <param name="userID">The ID of the user to be updated.</param>
        /// <param name="updateUserRequestModel">The <see cref="UpdateUserModel"/> containing updated data for the user.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the user update operation.</returns>
        public async Task<Result> UpdateUserAsync(int userID, UpdateUserModel updateUserRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation($"Service: UpdateUserAsync method initiated for UserID: {userID}.");

                var result = await _userRepository.UpdateUser(userID, updateUserRequestModel, auditInfoModel);
                _logger.LogInformation("Service: UpdateUserAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error updating user with ID {userID}: {ex.Message}");
                return Result.Error("An error occurred while updating the user.");
            }
        }

        /// <summary>
        /// Deletes an user based on the provided userID.
        /// </summary>
        /// <param name="userID">The ID of the user to be deleted.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the delete operation.</returns>
        public async Task<Result> DeleteUserAsync(int userId, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation($"Service: DeleteUserAsync method initiated for UserID: {userId}.");

                var result = await _userRepository.DeleteUser(userId, auditInfoModel);
                _logger.LogInformation("Service: DeleteUserAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error deleting user with ID {userId}: {ex.Message}");
                return Result.Error("An error occurred while deleting the user.");
            }
        }

        // <summary>
        /// Blocks an user based on the provided userID.
        /// </summary>
        /// <param name="userID">The ID of the user to be blocked.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the block operation.</returns>
        public async Task<Result> BlockUserAsync(int userId, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation($"Service: BlockUserAsync method initiated for UserID: {userId}.");

                var result = await _userRepository.BlockUser(userId, auditInfoModel);
                _logger.LogInformation("Service: BlockUserAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error blocking user with ID {userId}: {ex.Message}");
                return Result.Error("An error occurred while blocking the user.");
            }
        }

        /// <summary>
        /// Activates the user based on the provided userID.
        /// </summary>
        /// <param name="userID">The ID of the user to be activated.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the profile activation operation.</returns>
        public async Task<Result> ActivateUserAsync(int userId, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation($"Service: ActivateUserAsync method initiated for UserID: {userId}.");

                var result = await _userRepository.ActivateUser(userId, auditInfoModel);
                _logger.LogInformation("Service: ActivateUserAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error activating user with ID {userId}: {ex.Message}");
                return Result.Error("An error occurred while activating the user.");
            }
        }
    }
}
