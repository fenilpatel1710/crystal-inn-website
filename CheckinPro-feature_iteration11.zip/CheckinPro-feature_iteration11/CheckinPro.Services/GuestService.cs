﻿using Ardalis.Result;
using CheckinPro.Repositories.IRepository;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Services
{
    public class GuestService : IGuestService
    {
        private readonly ILogger _logger;
        private readonly IGuestRepository _guestRepository;

        public GuestService(ILogger<GuestService> logger, IGuestRepository guestRepository)
        {
            _logger = logger;
            _guestRepository = guestRepository;
        }

        /// <summary>
        /// Retrieves a list of guests.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetGuestModel"/> representing all guests data.</returns>
        public async Task<Result<List<GetGuestModel>>> GetGuestByHotelIDAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation("Service: GetGuestByHotelIDAsync method initiated.");

                var result = await _guestRepository.GetGuestByHotelID(hotelID);

                _logger.LogInformation("Service: GetGuestByHotelIDAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetGuestByHotelIDAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching guest.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific Guest by its ID.
        /// </summary>
        /// <param name="guestId">The ID of the Guest to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetGuestModel"/> for the specified Guest Id.</returns>
        public async Task<Result<GetGuestModel>> GetGuestByCodeOrIdentityNumberOrMobileAsync(string? guestCode = null, string? identityNumber = null, string? mobileNumber = null)
        {
            try
            {
                _logger.LogInformation($"Service: GetGuestByCodeOrIdentityNumberOrMobileAsync method initiated.");

                var result = await _guestRepository.GetGuestByCodeOrIdentityNumberOrMobile(guestCode, identityNumber, mobileNumber);
                if (result.Status == ResultStatus.NotFound)
                {
                    _logger.LogWarning($"Service: No guest found with GuestID: {guestCode}, MobileNumber: {mobileNumber}, IdentityNumber: {identityNumber}.");
                }
                else
                {
                    _logger.LogInformation($"Service: Successfully retrieved guest for GuestID: {guestCode}, MobileNumber: {mobileNumber}, IdentityNumber: {identityNumber}.");
                }
                _logger.LogInformation("Service: GetGuestByCodeOrIdentityNumberOrMobileAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error fetching guest with  GuestID: {guestCode}, MobileNumber: {mobileNumber}, IdentityNumber: {identityNumber}: {ex.Message}");
                return Result.Error("An error occurred while fetching the user.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific Guest by its mobileNumber.
        /// </summary>
        /// <param name="mobileNumber">The mobileNumber of the Guest to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetGuestModel"/> for the specified Guest mobileNumber.</returns>
        public async Task<Result<GetGuestModel>> GetGuestByMobileAsync(string mobileNumber = null)
        {
            try
            {
                _logger.LogInformation($"Service: GetGuestByMobileAsync method initiated for MobileNumber: {mobileNumber}.");

                var result = await _guestRepository.GetGuestByMobile(mobileNumber);
                if (result.Status == ResultStatus.NotFound)
                {
                    _logger.LogWarning($"Service: No guest found with MobileNumber: {mobileNumber}.");
                }
                else
                {
                    _logger.LogInformation($"Service: Successfully retrieved guest forMobileNumber: {mobileNumber}.");
                }
                _logger.LogInformation("Service: GetGuestByIdOrEmailOrMobileAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error fetching guest with MobileNumber: {mobileNumber}: {ex.Message}");
                return Result.Error("An error occurred while fetching the user.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific guest by its ID.
        /// </summary>
        /// <param name="guestID">The ID of the guest to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetGuestModel"/> for the specified guest.</returns>
        public async Task<Result<List<GetGuestModel>>> GetGuestByIdAsyn(int guestID)
        {
            try
            {
                _logger.LogInformation($"Service: GetGuestByIdAsyn method initiated for GuestID: {guestID}.");
                var result = await _guestRepository.GetGuestById(guestID);
                if (result.Status == ResultStatus.NotFound)
                {
                    _logger.LogWarning($"Service: No guest found with GuestID: {guestID}.");
                }
                else
                {
                    _logger.LogInformation($"Service: Successfully retrieved guest for GuestID: {guestID}.");
                }
                _logger.LogInformation("Service: GetGuestByIdAsyn method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetGuestByIdAsyn Exception occurred for GuestID: {guestID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the guest.");
            }
        }

        public async Task<Result<List<GetGuestModel>>> GetGuestByNameAsync(string? firstName = null, string? lastName = null)
        {
            try
            {
                _logger.LogInformation($"Service: GetGuestByNameAsync method initiated.");

                var result = await _guestRepository.GetGuestByName(firstName, lastName);
                if (result.Status == ResultStatus.NotFound)
                {
                    _logger.LogWarning($"Service: No guest found.");
                }
                else
                {
                    _logger.LogInformation($"Service: Successfully retrieved guest.");
                }
                _logger.LogInformation("Service: GetGuestByNameAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error fetching guest data: {ex.Message}");
                return Result.Error("An error occurred while fetching the user.");
            }
        }

        public async Task<Result<GuestRewardModel>> GetGuestRewardPointAsync(int hotelID, int guestID)
        {
            try
            {
                _logger.LogInformation($"Service: GetGuestRewardPointAsync method initiated");

                var result = await _guestRepository.GetGuestRewardPoint(hotelID, guestID);

                if (result.Status == ResultStatus.NotFound)
                {
                    _logger.LogWarning($"Service: No Reward Point found.");
                }
                else
                {
                    _logger.LogInformation($"Service: Successfully retrieved data.");
                }
                _logger.LogInformation("Service: GetGuestRewardPointAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error fetching Reward Point");
                return Result.Error("An error occurred while fetching the data.");
            }


        }
    }
}
