﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.Repositories;
using CheckinPro.Repositories.IRepository;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.Services
{
    public class ScannerService :IScannerService
    {
        private readonly ILogger _logger;
        private readonly IScannerRepository _scannerRepository;
        public ScannerService(ILogger<ScannerService> logger, IScannerRepository scannerRepository)
        {
            _logger = logger;
            _scannerRepository = scannerRepository;
        }

        public async Task<Result<List<AddGuestModel>>> GetGuestScanDetailAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation("Service: GetGuestScanDetailAsync method initiated.");

                var result = await _scannerRepository.GetGuestScanDetail(hotelID);
                _logger.LogInformation("Service: GetGuestScanDetailAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetGuestScanDetailAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the scanner detail.");
            }
        }

        public async Task<Result> AddGuestScanDetailAsync(GuestIDScan guestIDScan)
        {
            try
            {
                _logger.LogInformation("Service: AddGuestScanDetailAsync method initiated.");

                var result = await _scannerRepository.AddGuestScanDetail(guestIDScan);
                _logger.LogInformation("Service: AddGuestScanDetailAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: AddGuestScanDetailAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the scanner detail.");
            }
        }



    }
}
