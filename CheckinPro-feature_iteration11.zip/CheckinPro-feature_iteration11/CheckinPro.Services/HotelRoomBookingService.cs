﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.Repositories.IRepository;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Services
{
    public class HotelRoomBookingService : IHotelRoomBookingService
    {
        private readonly ILogger _logger;
        private readonly IHotelRoomBookingRepository _hotelRoomBookingRepository;

        public HotelRoomBookingService(ILogger<HotelRoomBookingService> logger, IHotelRoomBookingRepository hotelRoomBookingRepository)
        {
            _logger = logger;
            _hotelRoomBookingRepository = hotelRoomBookingRepository;
        }

        public async Task<Result<List<GetHotelRoomBookingSearchListModel>>> SearchHotelRoomBookingAsync(FindHotelRoomBookingModel findHotelRoomBookingRequestModel)
        {
            try
            {
                _logger.LogInformation($"Service: SearchHotelRoomBookingAsync method initiated to get the room list");
                var result = await _hotelRoomBookingRepository.SearchHotelRoomBooking(findHotelRoomBookingRequestModel);
                if (result.Status == ResultStatus.NotFound)
                {
                    _logger.LogWarning($"Service: No hotel rate found within date {findHotelRoomBookingRequestModel}.");
                }
                else
                {
                    _logger.LogInformation($"Service: Successfully retrieved hotel rate with date {findHotelRoomBookingRequestModel}.");
                }
                _logger.LogInformation("Service: SearchHotelRoomBookingAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: SearchHotelRoomBookingAsync Exception occurred to get the rate with date {findHotelRoomBookingRequestModel}. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel Rate.");
            }
        }

        public async Task<Result<HotelDailyRateModel>> GetHotelDailyRateByDateAsync(int hotelID, DateOnly checkInDate)
        {
            try
            {
                _logger.LogInformation($"Service: GetHotelDailyRateByDateAsync method initiated to get the room list");
                var result = await _hotelRoomBookingRepository.GetHotelDailyRateByDate(hotelID, checkInDate);
                if (result.Status == ResultStatus.NotFound)
                {
                    _logger.LogWarning($"Service: No hotel rate found within date {checkInDate}.");
                }
                else
                {
                    _logger.LogInformation($"Service: Successfully retrieved hotel rate with date {checkInDate}.");
                }
                _logger.LogInformation("Service: GetHotelDailyRateByDateAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelDailyRateByDateAsync Exception occurred to get the rate with date {checkInDate}. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel Rate.");
            }
        }

        /// <summary>
        /// Retrieves a list of mobile numbers.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of mobile numbers</returns>
        public async Task<Result<List<string>>> GetMobileNumbersAsync(string searchTerm = null)
        {
            try
            {
                _logger.LogInformation("Service: GetMobileNumbersAsync method initiated.");

                var result = await _hotelRoomBookingRepository.GetMobileNumbers(searchTerm);

                _logger.LogInformation("Service: GetMobileNumbersAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetMobileNumbersAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching mobile numbers");
            }
        }


        /// <summary>
        /// Retrieves the list of hotel rooms by dates.
        /// </summary>
        /// <param name="dates">Check-in and check-out dates of the hotel rooms to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the list of <see cref="GetHotelRoomModel"/> for the specified dates.</returns>
        public async Task<Result<List<HotelRoomModel>>> GetHotelRoomByDatesAsync(int hotelID, DateTime checkInDate, DateTime checkOutDate)
        {
            try
            {
                _logger.LogInformation($"Service: GetHotelRoomByDatesAsync method initiated to get the room list");
                var result = await _hotelRoomBookingRepository.GetHotelRoomByDates(hotelID, checkInDate, checkOutDate);
                if (result.Status == ResultStatus.NotFound)
                {
                    _logger.LogWarning($"Service: No hotel room found within date rage {checkInDate} and {checkOutDate}.");
                }
                else
                {
                    _logger.LogInformation($"Service: Successfully retrieved hotel rooms within date rage {checkInDate} and {checkOutDate}.");
                }
                _logger.LogInformation("Service: GetHotelRoomByDatesAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelRoomByDatesAsync Exception occurred to get the rooms within date rage {checkInDate} and {checkOutDate}. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel Room.");
            }
        }

        public async Task<Result<List<HotelRoomModel>>> GetAvailableRoomByDatesAsync(int hotelID, int hotelRoomTypeID, DateTime checkInDate, DateTime checkOutDate)
        {
            try
            {
                _logger.LogInformation($"Service: GetAvailableRoomByDatesAsync method initiated to get the room list");
                var result = await _hotelRoomBookingRepository.GetAvailableRoomByDates(hotelID, hotelRoomTypeID, checkInDate, checkOutDate);
                if (result.Status == ResultStatus.NotFound)
                {
                    _logger.LogWarning($"Service: No hotel room found within date rage {checkInDate} and {checkOutDate}.");
                }
                else
                {
                    _logger.LogInformation($"Service: Successfully retrieved hotel rooms within date rage {checkInDate} and {checkOutDate}.");
                }
                _logger.LogInformation("Service: GetAvailableRoomByDatesAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetAvailableRoomByDatesAsync Exception occurred to get the rooms within date rage {checkInDate} and {checkOutDate}. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel Room.");
            }
        }

        /// <summary>
        /// Retrieves a list of available room types along with the number of available rooms for a given hotel.
        /// </summary>
        /// <param name="hotelID">The ID of the hotel.</param>
        /// <returns>A <see cref="Result"/> containing a list of room types with available room counts.</returns>
        public async Task<Result<List<HotelRoomTypeModel>>> GetAvailableRoomTypesAsync(int hotelID, DateTime checkInDate, DateTime checkOutDate)
        {
            try
            {
                _logger.LogInformation("Service: GetAvailableRoomTypesAsync method initiated for HotelID: {HotelID}", hotelID);
                var result = await _hotelRoomBookingRepository.GetAvailableRoomTypesByHotel(hotelID, checkInDate, checkOutDate);
                _logger.LogInformation("Service: GetAvailableRoomTypesAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: GetAvailableRoomTypesAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching available room types.");
            }
        }

        /// <summary>
        /// Retrieves a list of booked hotel rooms having check out today.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelRoomBookingModel"/> representing all check-out hotel rooms data.</returns>
        public async Task<Result<List<GetHotelRoomBookingModel>>> GetTodaysCheckOutRoomsByHotelIDAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation("Service: GetTodaysCheckOutRoomsByHotelIDAsync method initiated.");

                var result = await _hotelRoomBookingRepository.GetTodaysCheckOutRoomsByHotelID(hotelID);

                _logger.LogInformation("Service: GetTodaysCheckOutRoomsByHotelIDAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetTodaysCheckOutRoomsByHotelIDAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching check-out Hotel Room.");
            }
        }

        public async Task<Result<List<GetHotelRoomBookingModel>>> GetTodaysBookingsByHotelIDAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation("Service: GetTodaysBookingsByHotelIDAsync method initiated.");

                var result = await _hotelRoomBookingRepository.GetTodaysBookingsByHotelID(hotelID);

                _logger.LogInformation("Service: GetTodaysBookingsByHotelIDAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetTodaysBookingsByHotelIDAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching check-out Hotel Room.");
            }
        }


        /// <summary>
        /// Retrieves a list of booked hotel rooms.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelRoomBookingModel"/> representing all booked hotel rooms data.</returns>
        public async Task<Result<List<GetHotelRoomBookingModel>>> GetBookedHotelRoomsAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation("Service: GetBookedHotelRoomsAsync method initiated.");

                var result = await _hotelRoomBookingRepository.GetBookedHotelRoomsByHotelID(hotelID);

                _logger.LogInformation("Service: GetBookedHotelRoomsAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetBookedHotelRoomsAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching Booked Hotel Room.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific hotel room details by its booking ID.
        /// </summary>
        /// <param name="hotelRoomBookingID">The ID of the hotel room to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetHotelRoomModel"/> for the specified hotel room Id.</returns>
        public async Task<Result<HotelRoomBookingModel>> GetRoomBookingDetailsByIDAsync(int hotelRoomBookingID)
        {
            try
            {
                _logger.LogInformation($"Service: GetRoomBookingDetailsByIDAsync method initiated for hotelRoomID: {hotelRoomBookingID}.");
                var result = await _hotelRoomBookingRepository.GetRoomBookingDetailsByID(hotelRoomBookingID);
                if (result.Status == ResultStatus.NotFound)
                {
                    _logger.LogWarning($"Service: No hotel room found with hotelRoomID: {hotelRoomBookingID}.");
                }
                else
                {
                    _logger.LogInformation($"Service: Successfully retrieved hotel room for hotelRoomID: {hotelRoomBookingID}.");
                }
                _logger.LogInformation("Service: GetRoomBookingDetailsByIDAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetRoomBookingDetailsByIDAsync Exception occurred for hotelRoomID: {hotelRoomBookingID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel room details.");
            }
        }

        /// <summary> 
        /// Adds a new hotel room booking record based on the provided hotelRoomBookingRequestModel.
        /// </summary>
        /// <param name="hotelRoomBookingRequestModel">The <see cref="HotelRoomBookingModel"/> containing data for the new hotel room booking.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel room booking creation operation.</returns>
        public async Task<Result<int>> AddHotelRoomBookingAsync(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: AddHotelRoomBookingAsync method initiated.");

                var result = await _hotelRoomBookingRepository.AddHotelRoomBooking(hotelRoomBookingRequestModel, auditInfoModel);
                _logger.LogInformation("Service: AddHotelRoomBookingAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: AddHotelRoomBookingAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking.");
            }
        }

        public async Task<Result> UpdateHotelRoomBookingAsync(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: UpdateHotelRoomBookingAsync method initiated.");

                var result = await _hotelRoomBookingRepository.UpdateHotelRoomBooking(hotelRoomBookingRequestModel, auditInfoModel);
                _logger.LogInformation("Service: UpdateHotelRoomBookingAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: UpdateHotelRoomBookingAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking.");
            }
        }
        public async Task<Result> UpdateHotelRoomBookingTotalAmountAsync(HotelRoomBookingRateDetailModel hotelRoomBookingRateDetailRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: UpdateHotelRoomBookingTotalAmountAsync method initiated.");

                var result = await _hotelRoomBookingRepository.UpdateHotelRoomBookingTotalAmount(hotelRoomBookingRateDetailRequestModel, auditInfoModel);
                _logger.LogInformation("Service: UpdateHotelRoomBookingTotalAmountAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: UpdateHotelRoomBookingTotalAmountAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while updating the hotel room booking TotalAmount.");
            }
        }

        public async Task<Result> RoomCheckInAsync(int hotelRoomBookingID, int hotelRoomID, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: RoomCheckInAsync method initiated.");

                var result = await _hotelRoomBookingRepository.RoomCheckIn(hotelRoomBookingID, hotelRoomID, auditInfoModel);
                _logger.LogInformation("Service: RoomCheckInAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: RoomCheckInAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking.");
            }
        }

        public async Task<Result> RoomChangeAsync(RoomChangeModel roomChangeRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: RoomChangeAsync method initiated.");

                var result = await _hotelRoomBookingRepository.RoomChange(roomChangeRequestModel, auditInfoModel);
                _logger.LogInformation("Service: RoomChangeAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: RoomChangeAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while changing room.");
            }
        }
        public async Task<Result> RoomCheckOutAsync(UpdateHotelRoomCleaningAuditModel hotelRoomCleaningAuditRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: RoomCheckOutAsync method initiated.");

                var result = await _hotelRoomBookingRepository.RoomCheckOut(hotelRoomCleaningAuditRequestModel, auditInfoModel);
                _logger.LogInformation("Service: RoomCheckOutAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: RoomCheckOutAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking.");
            }
        }

        public async Task<Result> RoomCheckOutDateChangeAsync(HotelRoomBookingRateDetailModel hotelRoomBookingRateDetailRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: RoomCheckOutDateChangeAsync method initiated.");

                var result = await _hotelRoomBookingRepository.RoomCheckOutDateChange(hotelRoomBookingRateDetailRequestModel, auditInfoModel);
                _logger.LogInformation("Service: RoomCheckOutDateChangeAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: RoomCheckOutDateChangeAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking.");
            }
        }


        public async Task<Result> RoomExtendAsync(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: RoomExtendAsync method initiated.");

                var result = await _hotelRoomBookingRepository.RoomExtend(hotelRoomBookingRequestModel, auditInfoModel);
                _logger.LogInformation("Service: RoomExtendAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: RoomExtendAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking.");
            }
        }

        public async Task<Result> RoomCancelAsync(int hotelRoomBookingID, string? cancellationReason, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: RoomCancelAsync method initiated.");

                var result = await _hotelRoomBookingRepository.RoomCancel(hotelRoomBookingID, cancellationReason, auditInfoModel);
                _logger.LogInformation("Service: RoomCancelAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: RoomCancelAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking.");
            }
        }
        public async Task<Result> RoomRefundAsync(AddPaymentModel bookingPaymentRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: RoomRefundAsync method initiated.");

                var result = await _hotelRoomBookingRepository.RoomRefund(bookingPaymentRequestModel, auditInfoModel);
                _logger.LogInformation("Service: RoomRefundAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: RoomRefundAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking.");
            }
        }

        public async Task<Result> RoomCleaningAsync(UpdateHotelRoomCleaningAuditModel hotelRoomCleaningAuditRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: RoomCleaningAsync method initiated.");

                var result = await _hotelRoomBookingRepository.RoomCleaning(hotelRoomCleaningAuditRequestModel, auditInfoModel);
                _logger.LogInformation("Service: RoomCleaningAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: RoomCleaningAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while saving the hotel room booking.");
            }
        }

        public async Task<Result<List<HotelRoomCleaningAuditModel>>> GetPendingRoomCleaningListAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation("Service: GetPendingRoomCleaningListAsync method initiated.");

                var result = await _hotelRoomBookingRepository.GetPendingRoomCleaningList(hotelID);
                _logger.LogInformation("Service: GetPendingRoomCleaningListAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetPendingRoomCleaningListAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while getting data.");
            }
        }



        public async Task<Result> UpdateHotelRoomBookingStatusAsync(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: UpdateHotelRoomBookingStatusAsync method initiated.");

                var result = await _hotelRoomBookingRepository.UpdateHotelRoomBookingStatus(hotelRoomBookingRequestModel, auditInfoModel);
                _logger.LogInformation("Service: UpdateHotelRoomBookingStatusAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: UpdateHotelRoomBookingStatusAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking.");
            }
        }

        public async Task<Result> AddEditMiscAmountAsync(AddEditMiscAmountModel addEditMiscAmountRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: AddEditMiscAmountAsync method initiated.");

                var result = await _hotelRoomBookingRepository.AddEditMiscAmount(addEditMiscAmountRequestModel, auditInfoModel);
                _logger.LogInformation("Service: AddEditMiscAmountAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: AddEditMiscAmountAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding or editing Misc Amount.");
            }
        }

        public async Task<Result> AddUpdateBookingPaymentAsync(AddPaymentModel bookingPaymentRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: AddUpdateBookingPaymentAsync method initiated.");

                var result = await _hotelRoomBookingRepository.AddUpdateBookingPayment(bookingPaymentRequestModel, auditInfoModel);
                _logger.LogInformation("Service: AddUpdateBookingPaymentAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: AddUpdateBookingPaymentAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding or updating booking payment.");
            }
        }

        /// <summary>
        /// Retrieves a list of booked rooms based on the provided booking ID and check-out date.
        /// </summary>
        /// <param name="hotelRoomBookingID">The ID of the hotel room booking to exclude from the search.</param>
        /// <param name="checkOutDate">The <see cref="DateTime"/> representing the check-out date to filter bookings.</param>
        /// <returns>
        /// A <see cref="Result{List{GetBookedRoomDetailsModel}}"/> containing a list of booked rooms, including 
        /// check-in date, check-out date, guest name, room type, and room number.
        /// </returns>
        public async Task<Result<List<GetBookedRoomDetailsModel>>> GetBookedRoomsByCheckOutDate(int hotelRoomBookingID, DateTime checkOutDate)
        {
            try
            {
                _logger.LogInformation("Service: GetBookedRoomsByCheckOutDate method initiated for HotelRoomBookingID: {HotelRoomBookingID}", hotelRoomBookingID);
                var result = await _hotelRoomBookingRepository.GetBookedRoomDetailsByCheckOutDate(hotelRoomBookingID, checkOutDate);
                _logger.LogInformation("Service: GetBookedRoomsByCheckOutDate method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: GetBookedRoomsByCheckOutDates method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching booked room details.");
            }
        }

        public async Task<Result> AddUpdateGuestAsync(int hotelRoomBookingID, AddGuestModel guestRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: AddUpdateGuestAsync method initiated.");

                var result = await _hotelRoomBookingRepository.AddUpdateGuest(hotelRoomBookingID, guestRequestModel, auditInfoModel);
                _logger.LogInformation("Service: AddUpdateGuestAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: AddUpdateGuestAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding or updating Guest Data.");
            }
        }

        public async Task<Result> UpdateGuestRequestAsync(UpdateGuestRequestModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: UpdateGuestRequestAsync method initiated.");

                var result = await _hotelRoomBookingRepository.UpdateGuestRequest(hotelRoomBookingRequestModel, auditInfoModel);
                _logger.LogInformation("Service: UpdateGuestRequestAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: UpdateGuestRequestAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room booking.");
            }
        }

        public async Task<Result> UpdateBookingReportFlagAsync(int hotelRoomBookingID, bool isIncludedInReport, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: UpdateBookingReportFlagAsync method initiated.");

                var result = await _hotelRoomBookingRepository.UpdateBookingReportFlag(hotelRoomBookingID, isIncludedInReport, auditInfoModel);
                _logger.LogInformation("Service: UpdateBookingReportFlagAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: UpdateBookingReportFlagAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while Updating Booking Report Flag.");
            }
        }

        public async Task<Result<List<AddEditMiscAmountModel>>> GetRoomBookingMiscAmountAsync(int hotelRoomBookingID)
        {
            try
            {
                _logger.LogInformation("Service: GetRoomBookingMiscAmountAsync method initiated.");

                var result = await _hotelRoomBookingRepository.GetRoomBookingMiscAmount(hotelRoomBookingID);

                _logger.LogInformation("Service: GetRoomBookingMiscAmountAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetRoomBookingMiscAmountAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching Misc Amount list.");
            }
        }

        public async Task<Result> DeleteMiscAmountAsync(int hotelRoomBookingMiscellaneousID)
        {
            try
            {
                _logger.LogInformation($"Service: DeleteMiscAmountAsync method initiated.");

                var result = await _hotelRoomBookingRepository.DeleteMiscAmount(hotelRoomBookingMiscellaneousID);
                _logger.LogInformation("Service: DeleteMiscAmountAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error deleting Misc Amount: {ex.Message}");
                return Result.Error("An error occurred while deleting Misc Amount.");
            }
        }
    }
}
