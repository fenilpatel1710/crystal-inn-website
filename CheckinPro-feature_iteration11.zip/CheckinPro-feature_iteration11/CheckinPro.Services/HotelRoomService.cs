﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.Repositories.IRepository;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using CheckinPro.WebApi.Models.HotelRoomModels;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Services
{
    public class HotelRoomService : IHotelRoomService
    {
        private readonly ILogger _logger;
        private readonly IHotelRoomRepository _hotelRoomRepository;
        public HotelRoomService(ILogger<HotelRoomService> logger, IHotelRoomRepository hotelRoomRepository)
        {
            _logger = logger;
            _hotelRoomRepository = hotelRoomRepository;
        }

        /// <summary>
        /// Retrieves a list of hotel rooms.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelRoomModel"/> representing all hotel rooms data.</returns>
        public async Task<Result<List<HotelRoomModel>>> GetHotelRoomAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation("Service: GetHotelRoomAsync method initiated.");

                var result = await _hotelRoomRepository.GetHotelRoom(hotelID);

                _logger.LogInformation("Service: GetHotelRoomAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelRoomAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching Hotel Room.");
            }
        }

        /// <summary>
        /// Retrieves a list of hotel rooms with booking details, including TimeLeftToCheckOut.
        /// </summary>
        /// <param name="hotelID">The ID of the hotel.</param>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="HotelRoomModel"/> with booking details.</returns>
        public async Task<Result<List<HotelRoomDetailModel>>> GetHotelRoomAllDetailsAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation("Service: GetHotelRoomAllDetailsAsync method initiated.");

                var result = await _hotelRoomRepository.GetHotelRoomAllDetails(hotelID);

                _logger.LogInformation("Service: GetHotelRoomAllDetailsAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: GetHotelRoomAllDetailsAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel room details.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific hotel room by its ID.
        /// </summary>
        /// <param name="hotelRoomID">The ID of the hotel room to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetHotelRoomModel"/> for the specified hotel room Id.</returns>
        public async Task<Result<HotelRoomModel>> GetHotelRoomByIdAsync(int hotelRoomID)
        {
            try
            {
                _logger.LogInformation($"Service: GetHotelRoomByIdAsync method initiated for hotelRoomID: {hotelRoomID}.");
                var result = await _hotelRoomRepository.GetHotelRoomById(hotelRoomID);
                if (result.Status == ResultStatus.NotFound)
                {
                    _logger.LogWarning($"Service: No hotel room found with hotelRoomID: {hotelRoomID}.");
                }
                else
                {
                    _logger.LogInformation($"Service: Successfully retrieved hotel room for hotelRoomID: {hotelRoomID}.");
                }
                _logger.LogInformation("Service: GetHotelRoomByIdAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelRoomByIdAsync Exception occurred for hotelRoomID: {hotelRoomID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel Room.");
            }
        }

        /// <summary> 
        /// Adds a new hotel room record based on the provided hotelRoomRequestModel.
        /// </summary>
        /// <param name="hotelRoomRequestModel">The <see cref="AddEditHotelRoomModel"/> containing data for the new hotel room.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel room creation operation.</returns>
        public async Task<Result> AddEditHotelRoomAsync(AddEditHotelRoomModel hotelRoomRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: AddEditHotelRoomAsync method initiated.");

                var result = await _hotelRoomRepository.AddEditHotelRoom(hotelRoomRequestModel, auditInfoModel);
                _logger.LogInformation("Service: AddEditHotelRoomAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: AddEditHotelRoomAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the hotel room.");
            }
        }

        /// <summary>
        /// Updates an existing hotel room record based on the provided hotelRoomID and hotelRoomRequestModel.
        /// </summary>
        /// <param name="hotelRoomID">The ID of the hotel room to be updated.</param>
        /// <param name="hotelRoomRequestModel">The <see cref="AddEditHotelRoomModel"/> containing updated data for the hotel room.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel room update operation.</returns>
        public async Task<Result> UpdateHotelRoomStatusAsync(int hotelRoomID, string RoomStatus, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation($"Service: UpdateHotelRoomStatusAsync method initiated for hotelRoomID: {hotelRoomID}.");

                var result = await _hotelRoomRepository.UpdateHotelRoomStatus(hotelRoomID, RoomStatus, auditInfoModel);
                _logger.LogInformation("Service: UpdateHotelRoomStatusAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: UpdateHotelRoomStatusAsync Exception occurred for hotelRoomID: {hotelRoomID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while updating the hotel room.");
            }
        }

        /// <summary>
        /// Deletes a hotel room based on the provided hotelRoomID.
        /// </summary>
        /// <param name="hotelRoomID">The ID of the hotel room to be deleted.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the delete operation.</returns>
        public async Task<Result> DeleteHotelRoomAsync(int hotelRoomID, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation($"Service: DeleteHotelRoomAsync method initiated for hotelRoomID: {hotelRoomID}.");

                var result = await _hotelRoomRepository.DeleteHotelRoom(hotelRoomID, auditInfoModel);
                _logger.LogInformation("Service: DeleteHotelRoomAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: DeleteHotelRoomAsync Exception occurred for hotelRoomID: {hotelRoomID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while deleting the hotel room.");
            }
        }
    }
}
