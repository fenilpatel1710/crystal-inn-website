﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.Repositories;
using CheckinPro.Repositories.IRepository;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Services
{
    public class HotelConfigurationService : IHotelConfigurationService
    {
        private readonly ILogger _logger;
        private readonly IHotelConfigurationRepository _hotelConfigurationRepository;
        public HotelConfigurationService(ILogger<HotelConfigurationService> logger, IHotelConfigurationRepository hotelConfigurationRepository)
        {
            _logger = logger;
            _hotelConfigurationRepository = hotelConfigurationRepository;
        }

        /// <summary>
        /// Retrieves a list of hotel tax rate.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="HotelTaxRateModel"/> representing all hotel tax rate data.</returns>
        public async Task<Result<List<HotelTaxRateModel>>> GetHotelTaxRateAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation("Service: GetHotelTaxRateAsync method initiated.");

                var result = await _hotelConfigurationRepository.GetHotelTaxRate(hotelID);

                _logger.LogInformation("Service: GetHotelTaxRateAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelTaxRateAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching Data.");
            }
        }


        /// <summary> 
        /// Adds a new hotel tax rate record based on the provided hotelTaxRateRequestModel.
        /// </summary>
        /// <param name="hotelTaxRateRequestModel">The <see cref="HotelTaxRateModel"/> containing data for the new hotel tax rate.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        public async Task<Result> AddEditHotelTaxRateAsync(HotelTaxRateModel hotelTaxRateRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: AddEditHotelTaxRateAsync method initiated.");

                var result = await _hotelConfigurationRepository.AddEditHotelTaxRate(hotelTaxRateRequestModel, auditInfoModel);
                _logger.LogInformation("Service: AddEditHotelTaxRateAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: AddEditHotelTaxRateAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the data.");
            }
        }

        public async Task<Result<HotelConfigurationModel>> GetHotelMasterConfigurationAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation("Service: GetHotelMasterConfigurationAsync method initiated.");

                var result = await _hotelConfigurationRepository.GetHotelMasterConfiguration(hotelID);

                _logger.LogInformation("Service: GetHotelMasterConfigurationAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelTaxRateAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching Data.");
            }
        }

        public async Task<Result> AddEditHotelMasterConfigurationAsync(HotelConfigurationModel hotelMasterConfigurationRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: AddEditHotelMasterConfigurationAsync method initiated.");

                var result = await _hotelConfigurationRepository.AddEditHotelMasterConfiguration(hotelMasterConfigurationRequestModel, auditInfoModel);
                _logger.LogInformation("Service: AddEditHotelMasterConfigurationAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: AddEditHotelMasterConfigurationAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the data.");
            }
        }


        public async Task<Result<List<HotelDailyRateModel>>> GetHotelDailyRateAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation("Service: GetHotelDailyRateAsync method initiated.");

                var result = await _hotelConfigurationRepository.GetHotelDailyRate(hotelID);

                _logger.LogInformation("Service: GetHotelDailyRateAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelDailyRateAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching Data.");
            }
        }

        public async Task<Result> AddEditHotelDailyRateAsync(HotelDailyRateModel hotelDailyRateRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: AddEditHotelDailyRateAsync method initiated.");

                var result = await _hotelConfigurationRepository.AddEditHotelDailyRate(hotelDailyRateRequestModel, auditInfoModel);
                _logger.LogInformation("Service: AddEditHotelDailyRateAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: AddEditHotelDailyRateAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the data.");
            }
        }

        public async Task<Result<List<HotelHourlyRateModel>>> GetHotelHourlyRateAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation("Service: GetHotelHourlyRateAsync method initiated.");

                var result = await _hotelConfigurationRepository.GetHotelHourlyRate(hotelID);

                _logger.LogInformation("Service: GetHotelHourlyRateAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelHourlyRateAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching Data.");
            }
        }

        public async Task<Result<HotelRoomTypeModel>> GetHotelRoomTypeByIdAsync(int hotelRoomTypeID)
        {
            try
            {
                _logger.LogInformation("Service: GetHotelRoomTypeByIdAsync method initiated.");

                var result = await _hotelConfigurationRepository.GetHotelRoomTypeById(hotelRoomTypeID);

                _logger.LogInformation("Service: GetHotelRoomTypeByIdAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelRoomTypeByIdAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching Data.");
            }
        }


        public async Task<Result> AddEditHotelHourlyRateAsync(HotelHourlyRateModel hotelHourlyRateRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: AddEditHotelHourlyRateAsync method initiated.");

                var result = await _hotelConfigurationRepository.AddEditHotelHourlyRate(hotelHourlyRateRequestModel, auditInfoModel);
                _logger.LogInformation("Service: AddEditHotelHourlyRateAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: AddEditHotelHourlyRateAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the data.");
            }
        }


        public async Task<Result<List<HotelRoomTypeModel>>> GetHotelRoomTypeAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation("Service: GetHotelRoomTypeAsync method initiated.");

                var result = await _hotelConfigurationRepository.GetHotelRoomType(hotelID);

                _logger.LogInformation("Service: GetHotelRoomTypeAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelRoomTypeAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching Data.");
            }
        }

        public async Task<Result> AddEditHotelRoomTypeAsync(HotelRoomTypeModel hotelRoomTypeRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: AddEditHotelRoomTypeAsync method initiated.");

                var result = await _hotelConfigurationRepository.AddEditHotelRoomType(hotelRoomTypeRequestModel, auditInfoModel);
                _logger.LogInformation("Service: AddEditHotelRoomTypeAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: AddEditHotelRoomTypeAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the data.");
            }
        }



        public async Task<Result<List<HotelAdditionalRateModel>>> GetHotelAdditionalRateAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation("Service: GetHotelAdditionalRateAsync method initiated.");

                var result = await _hotelConfigurationRepository.GetHotelAdditionalRate(hotelID);

                _logger.LogInformation("Service: GetHotelAdditionalRateAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelAdditionalRateAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching Data.");
            }
        }

        public async Task<Result> AddEditHotelAdditionalRateAsync(HotelAdditionalRateModel hotelAdditionalRateRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: AddEditHotelAdditionalRateAsync method initiated.");

                var result = await _hotelConfigurationRepository.AddEditHotelAdditionalRate(hotelAdditionalRateRequestModel, auditInfoModel);
                _logger.LogInformation("Service: AddEditHotelAdditionalRateAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: AddEditHotelAdditionalRateAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the data.");
            }
        }


        public async Task<Result> DeleteHotelDailyRateAsync(int hotelDailyRateID)
        {
            try
            {
                _logger.LogInformation($"Service: DeleteHotelDailyRateAsync method initiated.");
                var result = await _hotelConfigurationRepository.DeleteHotelDailyRate(hotelDailyRateID);
                _logger.LogInformation("Service: DeleteHotelDailyRateAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error deleting Hotel Daily Rate: {ex.Message}");
                return Result.Error("An error occurred while deleting Hotel Daily Rate.");
            }
        }
    }
}
