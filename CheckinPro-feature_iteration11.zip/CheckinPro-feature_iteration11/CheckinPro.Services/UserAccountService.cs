﻿using Ardalis.Result;
using CheckinPro.Repositories.IRepository;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Services
{
    public class UserAccountService : IUserAccountService
    {
        private readonly ILogger _logger;
        private readonly IUserAccountRepository _userAccountRepository;

        public UserAccountService(ILogger<UserAccountService> logger, IUserAccountRepository userAccountRepository)
        {
            _logger = logger;
            _userAccountRepository = userAccountRepository;
        }

        /// <summary>
        /// Retrieves details of a specific user by its emailID.
        /// </summary>
        /// <param name="emailID">The emailID of the user to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="SignInUserResponseModel"/> for the specified emailID.</returns>       
        public async Task<Result<SignInUserResponseModel>> GetSignInUserDetailAsync(string emailID)
        {
            try
            {
                _logger.LogInformation("Service: SignInAsync method initiated.");

                var result = await _userAccountRepository.GetSignInUserDetail(emailID);
                _logger.LogInformation("Service: SignInAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error while user signin: {ex.Message}");
                return Result.Error("An error occurred while user signin.");
            }
        }

        /// <summary>
        /// Initiates a password change for the user identified by the specified email address.
        /// </summary>
        /// <param name="changePasswordModel">The model containing the user's email address, current password, and new password.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the change password operation.</returns>
        public async Task<Result> ChangePasswordAsync(ChangePasswordModel changePasswordModel)
        {
            try
            {
                _logger.LogInformation("Service: ChangePasswordAsync method initiated.");

                var result = await _userAccountRepository.ChangePassword(changePasswordModel);
                _logger.LogInformation("Service: ChangePasswordAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error  while change password.: {ex.Message}");
                return Result.Error("An error occurred  while change password..");
            }
        }

        // <summary>
        /// Initiates a password reset process for the user identified by the provided EmailID.
        /// </summary>
        /// <param name="EmailID">The user's email address for which forgot password process should be initiated</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the forgot password operation.</returns>
        public async Task<Result> ForgotPasswordAsync(string EmailID)
        {
            try
            {
                _logger.LogInformation("Service: ForgotPasswordAsync method initiated.");

                var result = await _userAccountRepository.ForgotPassword(EmailID);
                _logger.LogInformation("Service: ForgotPasswordAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error while forgot password: {ex.Message}");
                return Result.Error("An error occurred while forgot password.");
            }
        }

        /// <summary>
        /// Verifies whether the provided input OTP matches the stored OTP.
        /// </summary>
        /// <param name="ValidateOTPModel">The <see cref="ValidateOTPModel"/> containing the user's email and OTP for verification.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the OTP verification operation.</returns>
        public async Task<Result> ValidateOTPAsync(ValidateOTPModel validateOTPModel)
        {
            try
            {
                _logger.LogInformation("Service: ValidateOTPAsync method initiated.");

                var result = await _userAccountRepository.ValidateOTP(validateOTPModel);
                _logger.LogInformation("Service: ValidateOTPAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error while validating OTP: {ex.Message}");
                return Result.Error("An error occurred while validating OTP.");
            }
        }

        /// <summary>
        /// For password reset.
        /// </summary>
        /// <param name="resetPasswordModel">The <see cref="ResetPasswordModel"/> containing the user's email and new password for reset.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the password reset operation.</returns>
        public async Task<Result> ResetPasswordAsync(ResetPasswordModel resetPasswordModel)
        {
            try
            {
                _logger.LogInformation("Service: ResetPasswordAsync method initiated.");

                var result = await _userAccountRepository.ResetPassword(resetPasswordModel);
                _logger.LogInformation("Service: ResetPasswordAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error while password reset: {ex.Message}");
                return Result.Error("An error occurred while password reset.");
            }
        }

        /// <summary>
        /// Initiates to get password for the user identified by the provided EmailID.
        /// </summary>
        /// <param name="EmailID">The user's email address for which password process should be initiated</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the password operation.</returns>

        public async Task<Result<string>> GetPasswordToVerify(string EmailID)
        {
            try
            {
                _logger.LogInformation("Service: GetPasswordToVerify method initiated.");

                var result = await _userAccountRepository.GetPasswordToVerify(EmailID);
                _logger.LogInformation("Service: GetPasswordToVerify method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetPasswordToVerify Exception occurred for EmailID: {EmailID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while featching password.");
            }
        }
    }
}
