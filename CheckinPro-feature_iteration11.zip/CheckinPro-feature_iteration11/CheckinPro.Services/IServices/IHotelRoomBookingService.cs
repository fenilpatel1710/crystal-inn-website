﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.WebApi.Models;
namespace CheckinPro.Services.IServices
{
    public interface IHotelRoomBookingService
    {
        Task<Result<HotelDailyRateModel>> GetHotelDailyRateByDateAsync(int hotelID, DateOnly checkInDate);
        Task<Result<List<GetHotelRoomBookingSearchListModel>>> SearchHotelRoomBookingAsync(FindHotelRoomBookingModel findHotelRoomBookingRequestModel);
        /// <summary>
        /// Retrieves the list of hotel rooms by dates.
        /// </summary>
        /// <param name="dates">Check-in and check-out dates of the hotel rooms to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the list of <see cref="GetHotelRoomModel"/> for the specified dates.</returns>
        Task<Result<List<HotelRoomModel>>> GetHotelRoomByDatesAsync(int hotelID, DateTime checkInDate, DateTime checkOutDate);
        Task<Result<List<HotelRoomModel>>> GetAvailableRoomByDatesAsync(int hotelID, int hotelRoomTypeID, DateTime checkInDate, DateTime checkOutDate);

        /// <summary>
        /// Retrieves a list of available room types along with the number of available rooms for a given hotel.
        /// </summary>
        /// <param name="hotelID">The ID of the hotel.</param>
        /// <returns>A <see cref="Result"/> containing a list of room types with available room counts.</returns>
        Task<Result<List<HotelRoomTypeModel>>> GetAvailableRoomTypesAsync(int hotelID, DateTime checkInDate, DateTime checkOutDate);

        /// <summary>
        /// Retrieves a list of mobile numbers.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of mobile numbers</returns>
        Task<Result<List<string>>> GetMobileNumbersAsync(string searchTerm = null);


        /// <summary>
        /// Retrieves a list of booked hotel rooms having check out today.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelRoomBookingModel"/> representing all check-out hotel rooms data.</returns>
        Task<Result<List<GetHotelRoomBookingModel>>> GetTodaysCheckOutRoomsByHotelIDAsync(int hotelID);
        Task<Result<List<GetHotelRoomBookingModel>>> GetTodaysBookingsByHotelIDAsync(int hotelID);

        /// <summary>
        /// Retrieves a list of booked hotel rooms.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelRoomBookingModel"/> representing all booked hotel rooms data.</returns>
        Task<Result<List<GetHotelRoomBookingModel>>> GetBookedHotelRoomsAsync(int hotelID);

        /// <summary>
        /// Retrieves details of a specific hotel room details by its booking ID.
        /// </summary>
        /// <param name="hotelRoomBookingID">The ID of the hotel room to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetHotelRoomModel"/> for the specified hotel room Id.</returns>
        Task<Result<HotelRoomBookingModel>> GetRoomBookingDetailsByIDAsync(int hotelRoomBookingID);

        /// <summary> 
        /// Adds a new hotel room booking record based on the provided hotelRoomBookingRequestModel.
        /// </summary>
        /// <param name="hotelRoomBookingRequestModel">The <see cref="HotelRoomBookingModel"/> containing data for the new hotel room booking.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel room booking creation operation.</returns>
        Task<Result<int>> AddHotelRoomBookingAsync(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> UpdateHotelRoomBookingAsync(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> UpdateHotelRoomBookingTotalAmountAsync(HotelRoomBookingRateDetailModel hotelRoomBookingRateDetailRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> RoomCheckInAsync(int hotelRoomBookingID, int hotelRoomID, AuditInfoModel auditInfoModel);
        Task<Result> RoomChangeAsync(RoomChangeModel roomChangeRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> RoomCheckOutAsync(UpdateHotelRoomCleaningAuditModel hotelRoomCleaningAuditRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> RoomCheckOutDateChangeAsync(HotelRoomBookingRateDetailModel hotelRoomBookingRateDetailRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> RoomExtendAsync(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> RoomCancelAsync(int hotelRoomBookingID, string? cancellationReason, AuditInfoModel auditInfoModel);
        Task<Result> RoomRefundAsync(AddPaymentModel bookingPaymentRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> RoomCleaningAsync(UpdateHotelRoomCleaningAuditModel hotelRoomCleaningAuditRequestModel, AuditInfoModel auditInfoModel);
        Task<Result<List<HotelRoomCleaningAuditModel>>> GetPendingRoomCleaningListAsync(int hotelID);
        Task<Result> UpdateHotelRoomBookingStatusAsync(HotelRoomBookingModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> AddEditMiscAmountAsync(AddEditMiscAmountModel addEditMiscAmountRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> AddUpdateBookingPaymentAsync(AddPaymentModel bookingPaymentRequestModel, AuditInfoModel auditInfoModel);
        /// <summary>
        /// Retrieves a list of booked rooms based on the provided booking ID and check-out date.
        /// </summary>
        /// <param name="hotelRoomBookingID">The ID of the hotel room booking to exclude from the search.</param>
        /// <param name="checkOutDate">The <see cref="DateTime"/> representing the check-out date to filter bookings.</param>
        /// <returns>
        /// A <see cref="Result{List{GetBookedRoomDetailsModel}}"/> containing a list of booked rooms, including 
        /// check-in date, check-out date, guest name, room type, and room number.
        /// </returns>
        Task<Result<List<GetBookedRoomDetailsModel>>> GetBookedRoomsByCheckOutDate(int hotelRoomBookingID, DateTime checkOutDate);
        Task<Result> AddUpdateGuestAsync(int hotelRoomBookingID, AddGuestModel guestRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> UpdateGuestRequestAsync(UpdateGuestRequestModel hotelRoomBookingRequestModel, AuditInfoModel auditInfoModel);
        Task<Result> UpdateBookingReportFlagAsync(int hotelRoomBookingID, bool isIncludedInReport, AuditInfoModel auditInfoModel);
        Task<Result<List<AddEditMiscAmountModel>>> GetRoomBookingMiscAmountAsync(int hotelRoomBookingID);
        Task<Result> DeleteMiscAmountAsync(int hotelRoomBookingMiscellaneousID);

    }
}
