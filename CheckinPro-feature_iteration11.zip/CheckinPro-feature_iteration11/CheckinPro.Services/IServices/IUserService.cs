﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.WebApi.Models;

namespace CheckinPro.Services.IServices
{
    public interface IUserService
    {
        /// <summary>
        /// Retrieves list of all users.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetUserModel"/> representing the user data.</returns>
        Task<Result<List<GetUserModel>>> GetUsersAsync(int hotelID);

        /// <summary>
        /// Retrieves details of a specific user by its ID.
        /// </summary>
        /// <param name="userID">The ID of the user to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetUserModel"/> for the specified user Id.</returns>
        Task<Result<GetUserModel>> GetUserByIdAsync(int userID);

        /// <summary>
        /// Adds a new user record based on the provided addUserRequestModel.
        /// </summary>
        /// <param name="addUserRequestModel">The <see cref="AddUserModel"/> containing data for the new user.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the user creation operation.</returns>
        Task<Result> AddUserAsync(AddUserModel addUserRequestModel, string randomPassword, AuditInfoModel auditInfoModel);

        /// <summary>
        /// Updates an existing user record based on the provided userID and updateUserRequestModel.
        /// </summary>
        /// <param name="userID">The ID of the user to be updated.</param>
        /// <param name="updateUserRequestModel">The <see cref="UpdateUserModel"/> containing updated data for the user.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the user update operation.</returns>
        Task<Result> UpdateUserAsync(int userID, UpdateUserModel updateUserRequestModel, AuditInfoModel auditInfoModel);

        /// <summary>
        /// Deletes an user based on the provided userID.
        /// </summary>
        /// <param name="userID">The ID of the user to be deleted.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the delete operation.</returns>
        Task<Result> DeleteUserAsync(int userId, AuditInfoModel auditInfoModel);

        /// <summary>
        /// Blocks an user based on the provided userID.
        /// </summary>
        /// <param name="userID">The ID of the user to be blocked.</param> 
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the block operation.</returns>
        Task<Result> BlockUserAsync(int userId, AuditInfoModel auditInfoModel);

        /// <summary>
        /// Activates the user based on the provided userID.
        /// </summary>
        /// <param name="userID">The ID of the user to be activated.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the profile activation operation.</returns>
        Task<Result> ActivateUserAsync(int userId, AuditInfoModel auditInfoModel);
    }
}
