﻿using Ardalis.Result;
using CheckinPro.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.Services.IServices
{
    public interface IHotelReportService
    {
        Task<Result<byte[]>> PrintBookingReceiptAsync(int hotelRoomBookingID);
        Task<Result<byte[]>> DownloadBookingInvoiceAsync(int hotelRoomBookingID);
        Task<Result<byte[]>> DownloadDailyAuditReportAsync(int hotelId, DateOnly fromDate, DateOnly toDate);
        Task<Result<byte[]>> DownloadRoomTaxCollectedReportAsync(int hotelId, DateOnly fromDate, DateOnly toDate);
        Task<Result<byte[]>> DownloadSummaryIncomeReportAsync(int hotelId, DateOnly fromDate, DateOnly toDate);
        Task<Result<byte[]>> DownloadRoomRevenueReportAsync(int hotelId, DateOnly fromDate, DateOnly toDate);
        Task<Result<byte[]>> DownloadIncomeBreakdownReportAsync(int hotelId, DateOnly fromDate, DateOnly toDate);
        Task<Result<byte[]>> DownloadShiftReportAsync(int hotelId, HotelShiftModel hotelShiftData, DateOnly fromDate, DateOnly toDate);
    }
}
