﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.WebApi.Models;

namespace CheckinPro.Services.IServices
{
    public interface IHotelConfigurationService
    {
        /// <summary>
        /// Retrieves a list of hotel tax rate.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="HotelTaxRateModel"/> representing all hotel tax rate data.</returns>
        Task<Result<List<HotelTaxRateModel>>> GetHotelTaxRateAsync(int hotelID);

        /// <summary> 
        /// Adds a new hotel tax rate record based on the provided hotelTaxRateRequestModel.
        /// </summary>
        /// <param name="hotelTaxRateRequestModel">The <see cref="HotelTaxRateModel"/> containing data for the new hotel tax rate.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel tax rate creation operation.</returns>
        Task<Result> AddEditHotelTaxRateAsync(HotelTaxRateModel hotelTaxRateRequestModel, AuditInfoModel auditInfoModel);

        Task<Result<HotelConfigurationModel>> GetHotelMasterConfigurationAsync(int hotelID);
        Task<Result> AddEditHotelMasterConfigurationAsync(HotelConfigurationModel hotelMasterConfigurationRequestModel, AuditInfoModel auditInfoModel);

        Task<Result<List<HotelDailyRateModel>>> GetHotelDailyRateAsync(int hotelID);
        Task<Result> AddEditHotelDailyRateAsync(HotelDailyRateModel hotelDailyRateRequestModel, AuditInfoModel auditInfoModel);

        Task<Result<List<HotelHourlyRateModel>>> GetHotelHourlyRateAsync(int hotelID);
        Task<Result> AddEditHotelHourlyRateAsync(HotelHourlyRateModel hotelHourlyRateRequestModel, AuditInfoModel auditInfoModel);

        Task<Result<List<HotelRoomTypeModel>>> GetHotelRoomTypeAsync(int hotelID);

        Task<Result<HotelRoomTypeModel>> GetHotelRoomTypeByIdAsync(int hotelRoomTypeID);

        Task<Result> AddEditHotelRoomTypeAsync(HotelRoomTypeModel hotelRoomTypeRequestModel, AuditInfoModel auditInfoModel);


        Task<Result<List<HotelAdditionalRateModel>>> GetHotelAdditionalRateAsync(int hotelID);
        Task<Result> AddEditHotelAdditionalRateAsync(HotelAdditionalRateModel hotelAdditionalRateRequestModel, AuditInfoModel auditInfoModel);

        Task<Result> DeleteHotelDailyRateAsync(int hotelDailyRateID);

    }
}
