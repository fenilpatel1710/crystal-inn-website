﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.WebApi.Models;

namespace CheckinPro.Services.IServices
{
    public interface IRoleService
    {
        /// <summary>
        /// Retrieves a list of roles.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="RoleModel"/> representing the role data.</returns>
        Task<Result<List<RoleModel>>> GetRolesAsync();

        /// <summary>
        /// Retrieves details of a specific role by its ID.
        /// </summary>
        /// <param name="roleID">The ID of the role to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetRoleModel"/> for the specified role Id.</returns>
        Task<Result<RoleModel>> GetRoleByIdAsync(int roleID);

        /// <summary>
        /// Updates an existing role record based on the provided roleID and roleRequestModel.
        /// </summary>
        /// <param name="roleID">The ID of the role to be updated.</param>
        /// <param name="roleRequestModel">The <see cref="RoleModel"/> containing updated data for the role.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the role update operation.</returns>
        Task<Result> UpdateRoleAsync(int roleID, RoleModel roleRequestModel, AuditInfoModel auditInfoModel);
    }
}
