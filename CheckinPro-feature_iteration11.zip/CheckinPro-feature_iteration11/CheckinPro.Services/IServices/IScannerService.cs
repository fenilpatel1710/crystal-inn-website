﻿using Ardalis.Result;
using CheckinPro.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.Services.IServices
{
    public interface IScannerService
    {
        Task<Result<List<AddGuestModel>>> GetGuestScanDetailAsync(int hotelID);

        Task<Result> AddGuestScanDetailAsync(GuestIDScan guestIDScan);

    }
}
