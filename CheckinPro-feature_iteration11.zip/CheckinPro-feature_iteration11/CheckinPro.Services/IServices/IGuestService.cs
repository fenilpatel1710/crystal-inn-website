﻿using Ardalis.Result;
using CheckinPro.WebApi.Models;

namespace CheckinPro.Services.IServices
{
    public interface IGuestService
    {
        /// <summary>
        /// Retrieves  list of all guests.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetGuestModel"/> representing the Guest data.</returns>
        Task<Result<List<GetGuestModel>>> GetGuestByHotelIDAsync(int hotelID);

        /// <summary>
        /// Retrieves details of a specific guest by its ID.
        /// </summary>
        /// <param name="guestID">The ID of the guest to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetGuestModel"/> for the specified guest.</returns>
        Task<Result<List<GetGuestModel>>> GetGuestByIdAsyn(int guestID);

        /// <summary>
        /// Retrieves details of a specific Guest by its ID.
        /// </summary>
        /// <param name="guestId">The ID of the Guest to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetGuestModel"/> for the specified Guest Id.</returns>
        Task<Result<GetGuestModel>> GetGuestByCodeOrIdentityNumberOrMobileAsync(string? guestCode = null, string? identityNumber = null, string? mobileNumber = null);

        /// <summary>
        /// Retrieves details of a specific Guest by its mobileNumber.
        /// </summary>
        /// <param name="mobileNumber">The mobileNumber of the Guest to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetGuestModel"/> for the specified Guest mobileNumber.</returns>
        Task<Result<GetGuestModel>> GetGuestByMobileAsync(string? mobileNumber = null);

        Task<Result<List<GetGuestModel>>> GetGuestByNameAsync(string? firstName = null, string? lastName = null);

        Task<Result<GuestRewardModel>> GetGuestRewardPointAsync(int hotelID, int guestID);

    }
}
