﻿using Ardalis.Result;
using CheckinPro.Common.Models;

namespace CheckinPro.Services.IServices
{
    public interface IDropdownService
    {
        /// <summary>
        /// Retrieves a list of roles for dropdown.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="SelectionItemModel"/> representing the role data.</returns>
        Task<Result<List<SelectionItemModel>>> GetRolesForDropdownAsync();

        /// <summary>
        /// Retrieves a list of countries for dropdown.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="SelectionItemModel"/> representing the country data.</returns>
        Task<Result<List<SelectionItemModel>>> GetCountriesForDropdownAsync();

        /// <summary>
        /// Retrieves a list of states for dropdown.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="SelectionItemModel"/> representing the state data.</returns>
        Task<Result<List<SelectionItemModel>>> GetStatesForDropdownAsync(int countryID);

        /// <summary>
        /// Retrieves a list of hotel room types for dropdown.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="SelectionItemModel"/> representing the hotel room type data.</returns>
        Task<Result<List<SelectionItemModel>>> GetHotelRoomTypesForDropdownAsync(int hotelID);

        /// <summary>
        /// Retrieves a list of room  status for dropdown.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="SelectionItemModel"/> representing the room  status data.</returns>
        Task<Result<List<SelectionItemModel>>> GetRoomStatusesForDropdownAsync();
    }
}
