﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.WebApi.Models;

namespace CheckinPro.Services.IServices
{
    public interface ICountryService
    {
        /// <summary>
        /// Retrieves a list of countries.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="CountryModel"/> representing the country data.</returns>
        Task<Result<List<CountryModel>>> GetCountriesAsync();

        /// <summary>
        /// Retrieves details of a specific country by its ID.
        /// </summary>
        /// <param name="countryID">The ID of the country to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="CountryModel"/> for the specified country.</returns>
        Task<Result<CountryModel>> GetCountryByIdAsync(int countryID);

        /// <summary>
        /// Adds a new country record based on the provided countryRequestModel.
        /// </summary>
        /// <param name="countryRequestModel">The <see cref="CountryModel"/> containing data for the new country.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the country addition operation.</returns>
        Task<Result> AddCountryAsync(CountryModel countryRequestModel, AuditInfoModel auditInfoModel);

        /// <summary>
        /// Updates an existing country record based on the provided countryID and countryRequestModel.
        /// </summary>
        /// <param name="countryID">The ID of the country to be updated.</param>
        /// <param name="countryRequestModel">The <see cref="CountryModel"/> containing updated data for the country.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the country update operation.</returns>
        Task<Result> UpdateCountryAsync(int countryID, CountryModel countryRequestModel, AuditInfoModel auditInfoModel);

        /// <summary>
        /// Deletes a country based on the provided countryID.
        /// </summary>
        /// <param name="countryID">The ID of the country to be deleted.</param>
        /// <param name="countryRequestModel">The <see cref="CountryModel"/> containing updated data for the country.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the delete operation.</returns>
        Task<Result> DeleteCountryAsync(int countryID, CountryModel countryRequestModel, AuditInfoModel auditInfoModel);
    }
}
