﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.Services.IServices
{
    public interface IDashboardService
    {
        /// <summary>
        /// Retrieves the count of various hotel room statuses for a given hotel.
        /// </summary>
        /// <param name="hotelID">The unique identifier of the hotel.</param>
        /// <returns>A <see cref="Result"/> containing a <see cref="GetDashboardModel"/> object with the counts of different room statuses.</returns>
        Task<Result<GetDashboardModel>> GetHotelRoomStatusCountsAsync(int hotelID);

        Task<Result<List<HotelShiftModel>>> GetHotelShiftDetailByDateAsync(int hotelID, DateOnly fromDate, DateOnly toDate);
        
        Task<Result<HotelShiftModel>> GetHotelShiftDetailAsync(int hotelID);

        Task<Result> StartHotelShiftAsync(HotelShiftModel hotelShiftRequestModel, AuditInfoModel auditInfoModel);

        Task<Result> EndHotelShiftAsync(HotelShiftModel hotelShiftRequestModel, AuditInfoModel auditInfoModel);

        Task<Result<List<GetHotelOwnerDashboardModel>>> GetHotelMetricsByDateRangeAsync(int hotelID, DateTime? selectedDate, string metrix);

        Task<Result<List<GetHotelRoomRevenueModel>>> GetHotelRoomRevenueByYearAsync(int hotelID, int year);
    }
}
