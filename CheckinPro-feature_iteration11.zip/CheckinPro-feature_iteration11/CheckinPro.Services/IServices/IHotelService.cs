﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.WebApi.Models;

namespace CheckinPro.Services.IServices
{
    public interface IHotelService
    {
        /// <summary>
        /// Checks if hotel-related records exist.
        /// </summary>
        /// <param name="hotelId">The ID of the hotel to check.</param>
        /// <returns>A <see cref="Result"/> containing a <see cref="HotelRecordsCheckResult"/> with presence status.</returns>
        Task<Result<HotelProfileStatusModel>> GetHotelProfileCompletionStatusAsync(int hotelId);

        /// <summary>
        /// Retrieves a list of Hotels.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelModel"/> representing the hotel data.</returns>
        Task<Result<List<GetHotelModel>>> GetHotelsAsync();

        /// <summary>
        /// Retrieves details of a specific hotel by its ID.
        /// </summary>
        /// <param name="hotelID">The ID of the hotel to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetHotelModel"/> for the specified hotel.</returns>
        Task<Result<GetHotelModel>> GetHotelByIdAsync(int hotelID);

        /// <summary>
        /// Adds a new hotel record based on the provided hotelRequestModel.
        /// </summary>
        /// <param name="hotelRequestModel">The <see cref="AddHotelModel"/> containing data for the new hotel.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel creation operation.</returns>
        Task<Result> AddHotelAsync(AddHotelModel hotelRequestModel, string randomPassword, AuditInfoModel auditInfoModel);

        Task<Result> ActiveInactiveOwnerDashboardAsync(int hotelID, bool isActive, AuditInfoModel auditInfoModel);

        Task<Result> ActiveInactiveHotelAsync(int hotelID, bool isActive, AuditInfoModel auditInfoModel);

        Task<Result> AddHotelExpenseAsync(HotelExpenseModel hotelExpenseRequestModel, AuditInfoModel auditInfoModel);
        
        Task<Result<List<HotelExpenseModel>>> GetHotelExpenseAsync(int hotelID);

        Task<Result> UpdateHotelExpenseAsync(HotelExpenseModel hotelExpenseRequestModel, AuditInfoModel auditInfoModel);

        Task<Result> DeleteHotelExpenseAsync(int hotelExpenseID);

        Task<Result<List<DirectBillingCompanyModel>>> GetDirectBillingCompanyAsync(int hotelID);
        Task<Result> AddUpdateDirectBillingCompanyAsync(DirectBillingCompanyModel directBillingCompanyRequestModel, AuditInfoModel auditInfoModel);
    }
}
