﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.WebApi.Models;
using CheckinPro.WebApi.Models.HotelRoomModels;

namespace CheckinPro.Services.IServices
{
    public interface IHotelRoomService
    {
        /// <summary>
        /// Retrieves a list of hotel rooms.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelRoomModel"/> representing all hotel rooms data.</returns>
        Task<Result<List<HotelRoomModel>>> GetHotelRoomAsync(int hotelID);

        /// <summary>
        /// Retrieves a list of hotel rooms with booking details, including TimeLeftToCheckOut.
        /// </summary>
        /// <param name="hotelID">The ID of the hotel.</param>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="HotelRoomModel"/> with booking details.</returns>
        Task<Result<List<HotelRoomDetailModel>>> GetHotelRoomAllDetailsAsync(int hotelID);

        /// <summary>
        /// Retrieves details of a specific hotel room by its ID.
        /// </summary>
        /// <param name="hotelRoomID">The ID of the hotel room to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetHotelRoomModel"/> for the specified hotel room Id.</returns>
        Task<Result<HotelRoomModel>> GetHotelRoomByIdAsync(int hotelRoomID);

        /// <summary> 
        /// Adds a new hotel room record based on the provided hotelRoomRequestModel.
        /// </summary>
        /// <param name="hotelRoomRequestModel">The <see cref="AddEditHotelRoomModel"/> containing data for the new hotel room.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel room creation operation.</returns>
        Task<Result> AddEditHotelRoomAsync(AddEditHotelRoomModel hotelRoomRequestModel, AuditInfoModel auditInfoModel);

        /// <summary>
        /// Updates an existing hotel room record based on the provided hotelRoomID and hotelRoomRequestModel.
        /// </summary>
        /// <param name="hotelRoomID">The ID of the hotel room to be updated.</param>
        /// <param name="hotelRoomRequestModel">The <see cref="AddEditHotelRoomModel"/> containing updated data for the hotel room.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel room update operation.</returns>
        Task<Result> UpdateHotelRoomStatusAsync(int hotelRoomID, string RoomStatus, AuditInfoModel auditInfoModel);

        /// <summary>
        /// Deletes a hotel room based on the provided hotelRoomID.
        /// </summary>
        /// <param name="hotelRoomID">The ID of the hotel room to be deleted.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the delete operation.</returns>
        Task<Result> DeleteHotelRoomAsync(int hotelRoomID, AuditInfoModel auditInfoModel);
    }
}
