﻿using Ardalis.Result;
using CheckinPro.Repositories;
using CheckinPro.Repositories.IRepository;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.Services
{
    public class HotelReportService : IHotelReportService
    {
        private readonly ILogger _logger;
        private readonly IHotelReportRepository _hotelReportRepository;

        public HotelReportService(ILogger<HotelReportRepository> logger, IHotelReportRepository hotelReportRepository)
        {
            _logger = logger;
            _hotelReportRepository = hotelReportRepository;
        }

        public async Task<Result<byte[]>> PrintBookingReceiptAsync(int hotelRoomBookingID)
        {
            try
            {
                _logger.LogInformation($"Controller: PrintBookingReceiptAsync method initiated.");

                var serviceResult = await _hotelReportRepository.PrintBookingReceipt(hotelRoomBookingID);

                _logger.LogInformation($"Controller: PrintBookingReceiptAsync method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: PrintBookingReceiptAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Print Booking Receipt.");
            }
        }

        public async Task<Result<byte[]>> DownloadBookingInvoiceAsync(int hotelRoomBookingID)
        {
            try
            {
                _logger.LogInformation($"Controller: DownloadBookingInvoiceAsync method initiated.");

                var serviceResult = await _hotelReportRepository.DownloadBookingInvoice(hotelRoomBookingID);

                _logger.LogInformation($"Controller: DownloadBookingInvoiceAsync method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DownloadBookingInvoiceAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Download Booking Invoice.");
            }
        }

        public async Task<Result<byte[]>> DownloadDailyAuditReportAsync(int hotelId, DateOnly fromDate, DateOnly toDate)
        {
            try
            {
                _logger.LogInformation($"Controller: DownloadDailyAuditReportAsync method initiated.");

                var serviceResult = await _hotelReportRepository.DownloadDailyAuditReport(hotelId, fromDate, toDate);

                _logger.LogInformation($"Controller: DownloadDailyAuditReportAsync method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DownloadDailyAuditReportAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Download Daily Audit Report.");
            }
        }

        public async Task<Result<byte[]>> DownloadRoomTaxCollectedReportAsync(int hotelId, DateOnly fromDate, DateOnly toDate)
        {
            try
            {
                _logger.LogInformation($"Controller: DownloadRoomTaxCollectedReportAsync method initiated.");

                var serviceResult = await _hotelReportRepository.DownloadRoomTaxCollectedReport(hotelId, fromDate, toDate);

                _logger.LogInformation($"Controller: DownloadRoomTaxCollectedReportAsync method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DownloadRoomTaxCollectedReportAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while Download Daily Audit Report.");
            }
        }

        public async Task<Result<byte[]>> DownloadSummaryIncomeReportAsync(int hotelId, DateOnly fromDate, DateOnly toDate)
        {
            try
            {
                _logger.LogInformation($"Controller: DownloadSummaryIncomeReportAsync method initiated.");

                var serviceResult = await _hotelReportRepository.DownloadSummaryIncomeReport(hotelId, fromDate, toDate);

                _logger.LogInformation($"Controller: DownloadSummaryIncomeReportAsync method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DownloadSummaryIncomeReportAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while DownloadSummaryIncomeReportAsync.");
            }
        }

        public async Task<Result<byte[]>> DownloadRoomRevenueReportAsync(int hotelId, DateOnly fromDate, DateOnly toDate)
        {
            try
            {
                _logger.LogInformation($"Controller: DownloadRoomRevenueReportAsync method initiated.");

                var serviceResult = await _hotelReportRepository.DownloadRoomRevenueReport(hotelId, fromDate, toDate);

                _logger.LogInformation($"Controller: DownloadRoomRevenueReportAsync method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DownloadRoomRevenueReportAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while DownloadRoomRevenueReportAsync.");
            }
        }

        public async Task<Result<byte[]>> DownloadIncomeBreakdownReportAsync(int hotelId, DateOnly fromDate, DateOnly toDate)
        {
            try
            {
                _logger.LogInformation($"Controller: DownloadIncomeBreakdownReportAsync method initiated.");

                var serviceResult = await _hotelReportRepository.DownloadIncomeBreakdownReport(hotelId, fromDate, toDate);

                _logger.LogInformation($"Controller: DownloadIncomeBreakdownReportAsync method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DownloadIncomeBreakdownReportAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while DownloadIncomeBreakdownReportAsync.");
            }
        }

        public async Task<Result<byte[]>> DownloadShiftReportAsync(int hotelId, HotelShiftModel hotelShiftData, DateOnly fromDate, DateOnly toDate)
        {
            try
            {
                _logger.LogInformation($"Controller: DownloadShiftReportAsync method initiated.");

                var serviceResult = await _hotelReportRepository.DownloadShiftReport(hotelId, hotelShiftData, fromDate, toDate);

                _logger.LogInformation($"Controller: DownloadShiftReportAsync method execution completed.");
                return Result.Success(serviceResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Controller: DownloadShiftReportAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while DownloadShiftReportAsync.");
            }
        }
    }
}
