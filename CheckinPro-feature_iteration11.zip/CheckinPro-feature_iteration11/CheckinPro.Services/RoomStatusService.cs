﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.Repositories.IRepository;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Services
{
    public class RoomStatusService : IRoomStatusService
    {
        private readonly ILogger _logger;
        private readonly IRoomStatusRepository _RoomStatusRepository;
        public RoomStatusService(ILogger<RoomStatusService> logger, IRoomStatusRepository RoomStatusRepository)
        {
            _logger = logger;
            _RoomStatusRepository = RoomStatusRepository;
        }

        /// <summary>
        /// Retrieves a list of Room Cleaning Statuses.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetRoomStatusModel"/> representing the room cleaning status data.</returns>
        public async Task<Result<List<GetRoomStatusModel>>> GetRoomStatusesAsync()
        {
            try
            {
                _logger.LogInformation("Service: GetRoomStatusesAsync method initiated.");

                var result = await _RoomStatusRepository.GetRoomStatuses();

                _logger.LogInformation("Service: GetRoomStatusesAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetRoomStatusesAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching Amenities.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific room cleaning status by its ID.
        /// </summary>
        /// <param name="roomvID">The ID of the room cleaning status to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetRoomStatusModel"/> for the specified room cleaning status.</returns>
        public async Task<Result<GetRoomStatusModel>> GetRoomStatusByIdAsync(int RoomStatusID)
        {
            try
            {
                _logger.LogInformation($"Service: GetRoomStatusByIdAsync method initiated for RoomStatusID: {RoomStatusID}.");
                var result = await _RoomStatusRepository.GetRoomStatusById(RoomStatusID);
                if (result.Status == ResultStatus.NotFound)
                {
                    _logger.LogWarning($"Service: No room cleaning status found with RoomStatusID: {RoomStatusID}.");
                }
                else
                {
                    _logger.LogInformation($"Service: Successfully retrieved room cleaning status for RoomStatusID: {RoomStatusID}.");
                }
                _logger.LogInformation("Service: GetRoomStatusByIdAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetRoomStatusByIdAsync Exception occurred for RoomvID: {RoomStatusID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the room cleaning status.");
            }
        }

        /// <summary>
        /// Adds a new room cleaning status record based on the provided RoomStatusRequestModel.
        /// </summary>
        /// <param name="RoomStatusRequestModel">The <see cref="GetRoomStatusModel"/> containing data for the new room cleaning status.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the room cleaning status addition operation.</returns>
        public async Task<Result> AddRoomStatusAsync(AddEditRoomStatusModel RoomStatusRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: AddRoomStatusAsync method initiated.");

                var result = await _RoomStatusRepository.AddRoomStatus(RoomStatusRequestModel, auditInfoModel);
                _logger.LogInformation("Service: AddRoomStatusAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: AddRoomStatusAsync Exception occurred. Stacktrace: {ex}");
                return Result.Error("An error occurred while adding the room cleaning status.");
            }
        }

        /// <summary>
        /// Updates an existing room cleaning status record based on the provided RoomStatusID and RoomStatusRequestModel.
        /// </summary>
        /// <param name="RoomStatusID">The ID of the room cleaning status to be updated.</param>
        /// <param name="RoomStatusRequestModel">The <see cref="UpdateRoomStatusModel"/> containing updated data for the room cleaning status.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the room v update operation.</returns>
        public async Task<Result> UpdateRoomStatusAsync(int RoomStatusID, UpdateRoomStatusModel RoomStatusRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation($"Service: UpdateRoomStatusAsync method initiated for RoomStatusID: {RoomStatusID}.");

                var result = await _RoomStatusRepository.UpdateRoomStatus(RoomStatusID, RoomStatusRequestModel, auditInfoModel);
                _logger.LogInformation("Service: UpdateRoomStatusAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: UpdateRoomStatusAsync Exception occurred for RoomStatusID: {RoomStatusID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while updating the room cleaning status.");
            }
        }

        /// <summary>
        /// Deletes a room cleaning status based on the provided RoomStatusID.
        /// </summary>
        /// <param name="RoomStatusID">The ID of the room cleaning status to be deleted.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the soft delete operation.</returns>
        public async Task<Result> DeleteRoomStatusAsync(int RoomStatusID, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation($"Service: DeleteRoomStatusAsync method initiated for RoomStatusID: {RoomStatusID}.");

                var result = await _RoomStatusRepository.DeleteRoomStatus(RoomStatusID, auditInfoModel);
                _logger.LogInformation("Service: DeleteRoomStatusAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: DeleteRoomStatusAsync Exception occurred for RoomStatusID: {RoomStatusID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while deleting the room cleaning status.");
            }
        }
    }
}
