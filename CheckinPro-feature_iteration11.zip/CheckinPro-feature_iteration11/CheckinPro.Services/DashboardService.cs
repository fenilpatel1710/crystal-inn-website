﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.Repositories;
using CheckinPro.Repositories.IRepository;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Services
{
    public class DashboardService : IDashboardService
    {
        private readonly ILogger _logger;
        private readonly IDashboardRepository _dashboardRepository;
        public DashboardService(ILogger<DashboardService> logger, IDashboardRepository dashboardRepository)
        {
            _logger = logger;
            _dashboardRepository = dashboardRepository;
        }

        /// <summary>
        /// Retrieves the count of various hotel room statuses for a given hotel.
        /// </summary>
        /// <param name="hotelID">The unique identifier of the hotel.</param>
        /// <returns>A <see cref="Result"/> containing a <see cref="GetDashboardModel"/> object with the counts of different room statuses.</returns>
        public async Task<Result<GetDashboardModel>> GetHotelRoomStatusCountsAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation($"Service: GetHotelRoomStatusCountsAsync method initiated.");
                var result = await _dashboardRepository.GetHotelRoomStatusCounts(hotelID);
                _logger.LogInformation("Service: GetHotelRoomStatusCountsAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Exception occurred in GetHotelRoomStatusCountsAsync Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel room status counts.");
            }
        }

        public async Task<Result<List<HotelShiftModel>>> GetHotelShiftDetailByDateAsync(int hotelID, DateOnly fromDate, DateOnly toDate)
        {
            try
            {
                _logger.LogInformation($"Service: GetHotelShiftDetailByDateAsync method initiated.");
                var result = await _dashboardRepository.GetHotelShiftDetailByDate(hotelID, fromDate, toDate);
                _logger.LogInformation("Service: GetHotelShiftDetailByDateAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Exception occurred in GetHotelShiftDetailByDateAsync Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel shift.");
            }
        }

        public async Task<Result<HotelShiftModel>> GetHotelShiftDetailAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation($"Service: GetHotelShiftDetailAsync method initiated.");
                var result = await _dashboardRepository.GetHotelShiftDetail(hotelID);
                _logger.LogInformation("Service: GetHotelShiftDetailAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Exception occurred in GetHotelShiftDetailAsync Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching hotel shift.");
            }
        }

        public async Task<Result> StartHotelShiftAsync(HotelShiftModel hotelShiftRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation($"Service: StartHotelShiftAsync method initiated.");
                var result = await _dashboardRepository.StartHotelShift(hotelShiftRequestModel, auditInfoModel);
                _logger.LogInformation("Service: StartHotelShiftAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Exception occurred in StartHotelShiftAsync Stacktrace: {ex}");
                return Result.Error("An error occurred while starting hotel shift.");
            }
        }

        public async Task<Result> EndHotelShiftAsync(HotelShiftModel hotelShiftRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation($"Service: GetHotelShiftDetailAsync method initiated.");
                var result = await _dashboardRepository.EndHotelShift(hotelShiftRequestModel, auditInfoModel);
                _logger.LogInformation("Service: GetHotelShiftDetailAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Exception occurred in GetHotelShiftDetailAsync Stacktrace: {ex}");
                return Result.Error("An error occurred while ending hotel shift.");
            }
        }

        public async Task<Result<List<GetHotelOwnerDashboardModel>>> GetHotelMetricsByDateRangeAsync(int hotelID, DateTime? selectedDate, string metrix)
        {
            try
            {
                _logger.LogInformation($"Service: GetHotelMetricsByDateRangeAsync method initiated.");
                var result = await _dashboardRepository.GetHotelMetricsByDateRange(hotelID, selectedDate, metrix);
                _logger.LogInformation("Service: GetHotelMetricsByDateRangeAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Exception occurred in GetHotelMetricsByDateRangeAsync Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel owner dashboard details.");
            }
        }

        public async Task<Result<List<GetHotelRoomRevenueModel>>> GetHotelRoomRevenueByYearAsync(int hotelID, int year)
        {
            try
            {
                _logger.LogInformation($"Service: GetHotelRoomRevenueByYearAsync method initiated.");
                var result = await _dashboardRepository.GetHotelRoomRevenueByYear(hotelID, year);
                _logger.LogInformation("Service: GetHotelRoomRevenueByYearAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Exception occurred in GetHotelRoomRevenueByYearAsync Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the hotel room revenue details.");
            }
        }
    }
}
