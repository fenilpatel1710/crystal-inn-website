﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.Repositories.IRepository;
using CheckinPro.Services.IServices;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Services
{
    public class DropdownService : IDropdownService
    {
        private readonly ILogger _logger;
        private readonly IDropdownRepository _dropdownRepository;
        public DropdownService(ILogger<DropdownService> logger, IDropdownRepository dropdownRepository)
        {
            _logger = logger;
            _dropdownRepository = dropdownRepository;
        }

        /// <summary>
        /// Retrieves a list of roles for dropdown.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="SelectionItemModel"/> representing the role data.</returns>
        public async Task<Result<List<SelectionItemModel>>> GetRolesForDropdownAsync()
        {
            try
            {
                _logger.LogInformation("Service: GetRolesForDropdownAsync method initiated.");

                var result = await _dropdownRepository.GetRolesForDropdown();

                _logger.LogInformation("Service: GetRolesForDropdownAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error fetching active roles: {ex.Message}");
                return Result.Error("An error occurred while fetching active roles.");
            }
        }

        /// <summary>
        /// Retrieves a list of countries for dropdown.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="SelectionItemModel"/> representing the country data.</returns>
        public async Task<Result<List<SelectionItemModel>>> GetCountriesForDropdownAsync()
        {
            try
            {
                _logger.LogInformation("Service: GetCountriesForDropdownAsync method initiated.");

                var result = await _dropdownRepository.GetCountriesForDropdown();

                _logger.LogInformation("Service: GetCountriesForDropdownAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error fetching active countries: {ex.Message}");
                return Result.Error("An error occurred while fetching active countries.");
            }
        }

        /// <summary>
        /// Retrieves a list of states for dropdown.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="SelectionItemModel"/> representing the state data.</returns>
        public async Task<Result<List<SelectionItemModel>>> GetStatesForDropdownAsync(int countryID)
        {
            try
            {
                _logger.LogInformation("Service: GetStatesForDropdownAsync method initiated.");

                var result = await _dropdownRepository.GetStatesForDropdown(countryID);

                _logger.LogInformation("Service: GetStatesForDropdownAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error fetching active states: {ex.Message}");
                return Result.Error("An error occurred while fetching active states.");
            }
        }

        /// <summary>
        /// Retrieves a list of hotel room types for dropdown.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="SelectionItemModel"/> representing the hotel room type data.</returns>
        public async Task<Result<List<SelectionItemModel>>> GetHotelRoomTypesForDropdownAsync(int hotelID)
        {
            try
            {
                _logger.LogInformation("Service: GetHotelRoomTypesForDropdownAsync method initiated.");

                var result = await _dropdownRepository.GetHotelRoomTypesForDropdown(hotelID);

                _logger.LogInformation("Service: GetHotelRoomTypesForDropdownAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error fetching active room type: {ex.Message}");
                return Result.Error("An error occurred while fetching active room type.");
            }
        }

        /// <summary>
        /// Retrieves a list of room  status for dropdown.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="SelectionItemModel"/> representing the room  status data.</returns>
        public async Task<Result<List<SelectionItemModel>>> GetRoomStatusesForDropdownAsync()
        {
            try
            {
                _logger.LogInformation("Service: GetRoomStatusesForDropdownAsync method initiated.");

                var result = await _dropdownRepository.GetRoomStatusesForDropdown();

                _logger.LogInformation("Service: GetRoomStatusesForDropdownAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error fetching active room  status: {ex.Message}");
                return Result.Error("An error occurred while fetching active room  status.");
            }
        }
    }
}
