﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.Repositories.IRepository;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using Microsoft.Extensions.Logging;
public class StateService : IStateService
{
    private readonly ILogger _logger;
    private readonly IStateRepository _stateRepository;
    public StateService(ILogger<StateService> logger, IStateRepository stateRepository)
    {
        _logger = logger;
        _stateRepository = stateRepository;
    }

    /// <summary>
    /// Retrieves a list of states.
    /// </summary>
    /// <returns>A <see cref="Result"/> containing a list of <see cref="StateModel"/> representing the state data.</returns>
    public async Task<Result<List<StateModel>>> GetStatesByCountryIdAsync(int countryId)
    {
        try
        {
            _logger.LogInformation("Service: GetStatesByCountryIdAsync method initiated.");

            var result = await _stateRepository.GetStates(countryId);

            _logger.LogInformation("Service: GetStatesByCountryIdAsync method execution completed.");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Service: Error fetching states: {ex.Message}");
            return Result.Error("An error occurred while fetching states.");
        }
    }

    /// <summary>
    /// Retrieves a list of active states.
    /// </summary>
    /// <returns>A <see cref="Result"/> containing a list of <see cref="StateModel"/> representing the state data.</returns>
    public async Task<Result<List<StateModel>>> GetActiveStatesByCountryIdAsync(int countryId)
    {
        try
        {
            _logger.LogInformation("Service: GetActiveStatesByCountryIdAsync method initiated.");

            var result = await _stateRepository.GetActiveStates(countryId);

            _logger.LogInformation("Service: GetActiveStatesByCountryIdAsync method execution completed.");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Service: Error fetching active states: {ex.Message}");
            return Result.Error("An error occurred while fetching active states.");
        }
    }

    /// <summary>
    /// Retrieves details of a specific state by its ID.
    /// </summary>
    /// <param name="stateID">The ID of the state to retrieve.</param>
    /// <returns>A <see cref="Result"/> containing the <see cref="StateModel"/> for the specified state.</returns>
    public async Task<Result<StateModel>> GetStatesByStateIdAsync(int stateId)
    {
        try
        {
            _logger.LogInformation($"Service: GetStateByIdAsync method initiated for StateID: {stateId}.");
            var result = await _stateRepository.GetStateByStateID(stateId);
            if (result.Status == ResultStatus.NotFound)
            {
                _logger.LogWarning($"Service: No state found with StateID: {stateId}.");
            }
            else
            {
                _logger.LogInformation($"Service: Successfully retrieved state for StateID: {stateId}.");
            }
            _logger.LogInformation("Service: GetStateByIdAsync method execution completed.");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Service: Error fetching state with ID {stateId}: {ex.Message}");
            return Result.Error("An error occurred while fetching the state.");
        }
    }

    /// <summary>
    /// Adds a new state record based on the provided stateRequestModel.
    /// </summary>
    /// <param name="stateRequestModel">The <see cref="StateModel"/> containing data for the new state.</param>
    /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
    /// <returns>A <see cref="Result"/> representing the outcome of the state addition operation.</returns>
    public async Task<Result> AddStateAsync(StateModel stateRequestModel, AuditInfoModel auditInfoModel)
    {
        try
        {
            _logger.LogInformation("Service: AddStateAsync method initiated.");

            var result = await _stateRepository.AddState(stateRequestModel, auditInfoModel);
            _logger.LogInformation("Service: AddStateAsync method execution completed.");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Service: Error adding state: {ex.Message}");
            return Result.Error("An error occurred while adding the state.");
        }
    }

    /// <summary>
    /// Updates an existing state record based on the provided stateID and stateRequestModel.
    /// </summary>
    /// <param name="stateID">The ID of the state to be updated.</param>
    /// <param name="stateRequestModel">The <see cref="StateModel"/> containing updated data for the state.</param>
    /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
    /// <returns>A <see cref="Result"/> representing the outcome of the state update operation.</returns>
    public async Task<Result> UpdateStateAsync(int stateId, StateModel stateRequestModel, AuditInfoModel auditInfoModel)
    {
        try
        {
            _logger.LogInformation($"Service: UpdateStateAsync method initiated for StateID: {stateId}.");

            var result = await _stateRepository.UpdateState(stateId, stateRequestModel, auditInfoModel);
            _logger.LogInformation("Service: UpdateStateAsync method execution completed.");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Service: Error updating state with ID {stateId}: {ex.Message}");
            return Result.Error("An error occurred while updating the state.");
        }
    }

    /// <summary>
    /// Deletes an state record based on the provided stateID and stateRequestModel.
    /// </summary>
    /// <param name="stateID">The ID of the state to be deleted.</param>
    /// <param name="stateRequestModel">The <see cref="StateModel"/> containing updated data for the state.</param>
    /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
    /// <returns>A <see cref="Result"/> representing the outcome of the state delete operation.</returns>
    public async Task<Result> DeleteStateAsync(int stateId, StateModel stateRequestModel, AuditInfoModel auditInfoModel)
    {
        try
        {
            _logger.LogInformation($"Service: DeleteStateAsync method initiated for StateID: {stateId}.");

            var result = await _stateRepository.DeleteState(stateId, stateRequestModel, auditInfoModel);
            _logger.LogInformation("Service: DeleteStateAsync method execution completed.");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Service: Error deleting state with ID {stateId}: {ex.Message}");
            return Result.Error("An error occurred while deleting the state.");
        }
    }
}


