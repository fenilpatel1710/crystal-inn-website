﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.DAL.SQL.CheckinProDBContext;
using CheckinPro.Repositories;
using CheckinPro.Repositories.IRepository;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Services
{
    public class HotelService : IHotelService
    {
        private readonly ILogger _logger;
        private readonly IHotelRepository _hotelRepository;

        public HotelService(ILogger<HotelService> logger, IHotelRepository hotelRepository)
        {
            _logger = logger;
            _hotelRepository = hotelRepository;
        }

        /// <summary>
        /// Checks if hotel-related records exist.
        /// </summary>
        /// <param name="hotelId">The ID of the hotel to check.</param>
        /// <returns>A <see cref="Result"/> containing a <see cref="HotelRecordsCheckResult"/> with presence status.</returns>
        public async Task<Result<HotelProfileStatusModel>> GetHotelProfileCompletionStatusAsync(int hotelId)
        {
            try
            {
                _logger.LogInformation($"Service: GetHotelProfileCompletionStatusAsync method initiated for HotelID {hotelId}.");

                var result = await _hotelRepository.GetHotelProfileCompletionStatus(hotelId);

                _logger.LogInformation($"Service: GetHotelProfileCompletionStatusAsync method execution completed for HotelID {hotelId}.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: GetHotelProfileCompletionStatusAsync method encountered an exception for HotelID {hotelId}. Stacktrace: {ex}");
                return Result.Error("An error occurred while checking hotel records.");
            }
        }


        /// <summary>
        /// Retrieves a list of Hotels.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="GetHotelModel"/> representing the hotel data.</returns>
        public async Task<Result<List<GetHotelModel>>> GetHotelsAsync()
        {
            try
            {
                _logger.LogInformation("Service: GetHotelsAsync method initiated.");

                var result = await _hotelRepository.GetHotels();

                _logger.LogInformation("Service:GetHotelsAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelsAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching Hotels.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific hotel by its ID.
        /// </summary>
        /// <param name="hotelID">The ID of the hotel to retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="GetHotelModel"/> for the specified hotel.</returns>
        public async Task<Result<GetHotelModel>> GetHotelByIdAsync(int hotelID)
        {
            try
            {

                _logger.LogInformation("Service: GetHotelByIdAsync method initiated.");

                var result = await _hotelRepository.GetHotelById(hotelID);

                _logger.LogInformation("Service: GetHotelByIdAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelByIdAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching Hotels.");
            }
        }

        /// <summary>
        /// Adds a new hotel record based on the provided hotelRequestModel.
        /// </summary>
        /// <param name="hotelRequestModel">The <see cref="AddHotelModel"/> containing data for the new hotel.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the hotel creation operation.</returns>
        public async Task<Result> AddHotelAsync(AddHotelModel hotelRequestModel, string randomPassword, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: AddHotelAsync method initiated.");

                var result = await _hotelRepository.AddHotel(hotelRequestModel, randomPassword, auditInfoModel);

                _logger.LogInformation("Service: AddHotelAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error while adding hotel info: {ex.Message}");
                return Result.Error("An error occurred while adding hotel info.");
            }
        }

        public async Task<Result> ActiveInactiveOwnerDashboardAsync(int hotelID, bool isActive, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation($"Service: ActiveInactiveOwnerDashboard method initiated for hotelID: {hotelID}.");

                var result = await _hotelRepository.ActiveInactiveOwnerDashboard(hotelID, isActive, auditInfoModel);
                _logger.LogInformation("Service: ActiveInactiveOwnerDashboardAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error ActiveInactiveOwnerDashboard with ID {hotelID}: {ex.Message}");
                return Result.Error("An error occurred while ActiveInactiveOwnerDashboard.");
            }
        }

        public async Task<Result> ActiveInactiveHotelAsync(int hotelID, bool isActive, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation($"Service: ActiveInactiveHotelAsync method initiated for hotelID: {hotelID}.");

                var result = await _hotelRepository.ActiveInactiveHotel(hotelID, isActive, auditInfoModel);
                _logger.LogInformation("Service: ActiveInactiveHotelAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error ActiveInactiveHotelAsync with ID {hotelID}: {ex.Message}");
                return Result.Error("An error occurred while ActiveInactiveHotelAsync.");
            }
        }

        public async Task<Result> AddHotelExpenseAsync(HotelExpenseModel hotelExpenseRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation("Service: AddHotelExpenseAsync method initiated.");

                var result = await _hotelRepository.AddHotelExpense(hotelExpenseRequestModel, auditInfoModel);

                _logger.LogInformation("Service: AddHotelExpenseAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error while adding hotel expense: {ex.Message}");
                return Result.Error("An error occurred while adding hotel expense.");
            }
        }

        public async Task<Result<List<HotelExpenseModel>>> GetHotelExpenseAsync(int hotelID)
        {
            try
            {

                _logger.LogInformation("Service: GetHotelExpenseAsync method initiated.");

                var result = await _hotelRepository.GetHotelExpense(hotelID);

                _logger.LogInformation("Service: GetHotelExpenseAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetHotelExpenseAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching Hotel Expense.");
            }
        }

        public async Task<Result> UpdateHotelExpenseAsync(HotelExpenseModel hotelExpenseRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation($"Service: UpdateHotelExpenseAsync method initiated.");

                var result = await _hotelRepository.UpdateHotelExpense(hotelExpenseRequestModel, auditInfoModel);
                _logger.LogInformation("Service: UpdateHotelExpenseAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error updating Hotel Expense: {ex.Message}");
                return Result.Error("An error occurred while updating Hotel Expense.");
            }
        }

        public async Task<Result> DeleteHotelExpenseAsync(int hotelExpenseID)
        {
            try
            {
                _logger.LogInformation($"Service: DeleteHotelExpenseAsync method initiated.");

                var result = await _hotelRepository.DeleteHotelExpense(hotelExpenseID);
                _logger.LogInformation("Service: DeleteHotelExpenseAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error deleting Hotel Expense: {ex.Message}");
                return Result.Error("An error occurred while deleting Hotel Expense.");
            }
        }

        public async Task<Result<List<DirectBillingCompanyModel>>> GetDirectBillingCompanyAsync(int hotelID)
        {
            try
            {

                _logger.LogInformation("Service: GetDirectBillingCompanyAsync method initiated.");

                var result = await _hotelRepository.GetDirectBillingCompany(hotelID);

                _logger.LogInformation("Service: GetDirectBillingCompanyAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetDirectBillingCompanyAsync method encountered an exception. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching DirectBillingCompany.");
            }
        }

        public async Task<Result> AddUpdateDirectBillingCompanyAsync(DirectBillingCompanyModel directBillingCompanyRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation($"Service: AddUpdateDirectBillingCompanyAsync method initiated.");

                var result = await _hotelRepository.AddUpdateDirectBillingCompany(directBillingCompanyRequestModel, auditInfoModel);
                _logger.LogInformation("Service: AddUpdateDirectBillingCompanyAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: AddUpdateDirectBillingCompany Exception occurred. Stacktrace: {ex.Message}");
                return Result.Error("An error occurred while AddUpdateDirectBillingCompany.");
            }
        }
    }
}
