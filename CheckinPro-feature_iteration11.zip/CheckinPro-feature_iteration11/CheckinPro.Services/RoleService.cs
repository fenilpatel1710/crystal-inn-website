﻿using Ardalis.Result;
using CheckinPro.Common.Models;
using CheckinPro.Repositories.IRepository;
using CheckinPro.Services.IServices;
using CheckinPro.WebApi.Models;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Services
{
    public class RoleService : IRoleService
    {
        private readonly ILogger _logger;
        private readonly IRoleRepository _roleRepository;
        public RoleService(ILogger<RoleService> logger, IRoleRepository roleRepository)
        {
            _logger = logger;
            _roleRepository = roleRepository;
        }

        /// <summary>
        /// Retrieves a list of roles.
        /// </summary>
        /// <returns>A <see cref="Result"/> containing a list of <see cref="RoleModel"/> representing the role data.</returns>
        public async Task<Result<List<RoleModel>>> GetRolesAsync()
        {
            try
            {
                _logger.LogInformation("Service: GetRolesAsync method initiated.");

                var result = await _roleRepository.GetRoles();

                _logger.LogInformation("Service: GetRolesAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error fetching roles: {ex.Message}");
                return Result.Error("An error occurred while fetching roles.");
            }
        }

        /// <summary>
        /// Retrieves details of a specific role by its ID.
        /// </summary>
        /// <param name="roleID">The ID of the role to be retrieve.</param>
        /// <returns>A <see cref="Result"/> containing the <see cref="RoleModel"/> for the specified room type Id.</returns>
        public async Task<Result<RoleModel>> GetRoleByIdAsync(int roleID)
        {
            try
            {
                _logger.LogInformation($"Service: GetRoleByIdAsync method initiated for RoleID: {roleID}.");
                var result = await _roleRepository.GetRoleById(roleID);
                if (result.Status == ResultStatus.NotFound)
                {
                    _logger.LogWarning($"Service: No room type found with RoleID: {roleID}.");
                }
                else
                {
                    _logger.LogInformation($"Service: Successfully retrieved room type for RoleID: {roleID}.");
                }
                _logger.LogInformation("Service: GetRoleByIdAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Repository: GetRoleByIdAsync Exception occurred for RoleID: {roleID}. Stacktrace: {ex}");
                return Result.Error("An error occurred while fetching the Role.");
            }
        }

        /// <summary>
        /// Updates an existing role record based on the provided roleID and roleRequestModel.
        /// </summary>
        /// <param name="roleID">The ID of the role to be updated.</param>
        /// <param name="roleRequestModel">The <see cref="RoleModel"/> containing updated data for the role.</param>
        /// <param name="auditInfoModel">The <see cref="AuditInfoModel"/> containing audit info of current user.</param>
        /// <returns>A <see cref="Result"/> representing the outcome of the role update operation.</returns>
        public async Task<Result> UpdateRoleAsync(int roleId, RoleModel roleRequestModel, AuditInfoModel auditInfoModel)
        {
            try
            {
                _logger.LogInformation($"Service: UpdateRoleAsync method initiated for RoleID: {roleId}.");

                var result = await _roleRepository.UpdateRole(roleId, roleRequestModel, auditInfoModel);
                _logger.LogInformation("Service: UpdateRoleAsync method execution completed.");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Service: Error updating role with ID {roleId}: {ex.Message}");
                return Result.Error("An error occurred while updating the role.");
            }
        }
    }
}
