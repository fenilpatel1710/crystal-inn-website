﻿namespace CheckinPro.WebApp.Models
{
    public class CountryWebAppModel
    {
        public int CountryID { get; set; }

        public string CountryName { get; set; }

        public string? ISO2 { get; set; }

        public string? ISO3 { get; set; }

        public string? PhoneCode { get; set; }

        public string? Capital { get; set; }

        public string? Currency { get; set; }

        public bool IsCountryActive { get; set; }

        public bool IsCountryDeleted { get; set; }

        public virtual ICollection<StateWebAppModel> States { get; set; } = new List<StateWebAppModel>();
    }
}
