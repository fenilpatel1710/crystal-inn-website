﻿using System.ComponentModel.DataAnnotations;

namespace CheckinPro.WebApp.Models
{
    public class AddEditHotelRoomWebAppModel
    {
        public int HotelRoomID { get; set; }

        public int HotelID { get; set; }

        [Required]
        public int HotelRoomTypeID { get; set; }

        [Required]
        public string? RoomNumber { get; set; }

        [Required]
        public int? Floor { get; set; }

        [Required]
        public int? MaxOccupancy { get; set; }

        [Required]
        public string? RoomStatus { get; set; }

        public string? Description { get; set; }

        public bool IsHotelRoomActive { get; set; } = true;

        public bool IsHotelRoomDeleted { get; set; }

        public virtual HotelRoomTypeWebAppModel HotelRoomType { get; set; } = new HotelRoomTypeWebAppModel();
    }
}
