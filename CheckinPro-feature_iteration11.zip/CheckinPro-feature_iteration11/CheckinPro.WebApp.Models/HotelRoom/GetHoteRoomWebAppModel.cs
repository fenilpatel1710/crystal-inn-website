﻿namespace CheckinPro.WebApp.Models
{
    public class GetHoteRoomWebAppModel
    {
        public int HotelRoomID { get; set; }

        public string? RoomNumber { get; set; }

        public int? Floor { get; set; }

        public int? MaxOccupancy { get; set; }

        public decimal? BestAvailableRate { get; set; }

        public decimal? HourlyRate { get; set; }

        public string? Description { get; set; }

        public string? RoomStatus { get; set; }

        public bool IsHotelRoomActive { get; set; }

        public virtual GetHotelWebAppModel GetHotel { get; set; } = new GetHotelWebAppModel();

        public virtual HotelRoomTypeWebAppModel HotelRoomType { get; set; } = new HotelRoomTypeWebAppModel();

    }
}
