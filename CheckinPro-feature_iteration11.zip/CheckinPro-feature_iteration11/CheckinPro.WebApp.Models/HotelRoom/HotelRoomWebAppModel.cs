﻿namespace CheckinPro.WebApp.Models
{
    public class HotelRoomWebAppModel
    {
        public int HotelRoomID { get; set; }

        public int HotelID { get; set; }

        public int HotelRoomTypeID { get; set; }

        public string? RoomNumber { get; set; }

        public int? Floor { get; set; }

        public int? MaxOccupancy { get; set; }

        public string? RoomStatus { get; set; }

        public string? Description { get; set; }

        public bool IsHotelRoomActive { get; set; }

        public bool IsHotelRoomDeleted { get; set; }

        public virtual GetHotelWebAppModel Hotel { get; set; } = new GetHotelWebAppModel();

        public virtual HotelRoomTypeWebAppModel HotelRoomType { get; set; } = new HotelRoomTypeWebAppModel();

        public virtual ICollection<GetHotelRoomBookingWebAppModel> HotelRoomBookings { get; set; } = new List<GetHotelRoomBookingWebAppModel>();
    }
}
