﻿namespace CheckinPro.WebApp.Models
{
    public class HotelShiftWebAppModel
    {
        public int HotelShiftID { get; set; }

        public int HotelID { get; set; }

        public int? ShiftNo { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public decimal? StartingCash { get; set; }

        public decimal? TotalCashReceived { get; set; }

        public decimal? DropCash { get; set; }

        public decimal? EndingCash { get; set; }

        public decimal? EndingCashDrawer { get; set; }

        public bool IsShiftActive { get; set; }

        public int? CreatedBy { get; set; }

        public string? ShiftOwnerName { get; set; }

        public bool IsBusyShiftReportDownload { get; set; } = false;

    }
}
