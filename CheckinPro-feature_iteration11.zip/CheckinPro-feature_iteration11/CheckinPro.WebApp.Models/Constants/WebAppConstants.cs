﻿namespace CheckinPro.WebApp.Models.Constants
{
    internal class WebAppConstants
    {
    }
}
