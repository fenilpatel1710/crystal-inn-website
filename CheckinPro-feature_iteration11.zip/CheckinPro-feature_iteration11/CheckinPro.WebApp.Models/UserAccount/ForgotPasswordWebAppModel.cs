﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CheckinPro.Common.Models.Constants;

namespace CheckinPro.WebApp.Models
{
    public class ForgotPasswordWebAppModel
    {
        [Required]
        [RegularExpression(CommonConstants.CheckRegularExpression.EmailRegEx, ErrorMessage = CommonConstants.DataAnnotationsErrorMessages.Invalid_Email_Format_Error_Message)]
        public string? Email { get; set; }
    }
}
