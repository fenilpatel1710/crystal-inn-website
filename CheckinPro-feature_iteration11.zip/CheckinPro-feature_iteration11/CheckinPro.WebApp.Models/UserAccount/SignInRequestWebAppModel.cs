﻿using CheckinPro.Common.Models.Constants;
using System.ComponentModel.DataAnnotations;

namespace CheckinPro.WebApp.Models
{
    public partial class SignInRequestWebAppModel
    {
        [Required]
        [RegularExpression(CommonConstants.CheckRegularExpression.EmailRegEx, ErrorMessage = CommonConstants.DataAnnotationsErrorMessages.Invalid_Email_Format_Error_Message)]
        public string? EmailID { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string? Password { get; set; }
    }
}
