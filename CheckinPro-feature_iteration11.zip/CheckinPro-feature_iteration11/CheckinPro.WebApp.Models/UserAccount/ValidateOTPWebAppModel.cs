﻿using CheckinPro.Common.Models.Constants;
using System.ComponentModel.DataAnnotations;

namespace CheckinPro.WebApp.Models
{
    public partial class ValidateOTPWebAppModel
    {
        public string? EmailID { get; set; }

        [Required]
        public string? OTP { get; set; }
    }
}