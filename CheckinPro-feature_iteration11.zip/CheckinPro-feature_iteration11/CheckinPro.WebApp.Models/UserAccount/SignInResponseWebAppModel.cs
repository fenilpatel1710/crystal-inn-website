﻿namespace CheckinPro.WebApp.Models
{
    public partial class SignInResponseWebAppModel
    {
        public int? UserID { get; set; }
        public int? HotelID { get; set; }
        public string? UserName { get; set; }
        public string? RoleName { get; set; }
        public string? EmailID { get; set; }
        public bool IsPasswordChanged { get; set; }
        public bool IsProfileActive { get; set; }
        public bool IsAuthenticated { get; set; }
        public bool IsShiftActive { get; set; }
        public bool IsOwnerDashboardVisible { get; set; }
    }
}
