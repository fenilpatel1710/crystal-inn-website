﻿namespace CheckinPro.WebApp.Models
{
    public class StateWebAppModel
    {
        public int StateID { get; set; }

        public int CountryID { get; set; }

        public string StateName { get; set; }

        public bool IsStateActive { get; set; }

        public bool IsStateDeleted { get; set; }

        public virtual CountryWebAppModel Country { get; set; }

        public virtual ICollection<GetGuestWebAppModel> Guests { get; set; } = new List<GetGuestWebAppModel>();

        public virtual ICollection<GetHotelWebAppModel> Hotels { get; set; } = new List<GetHotelWebAppModel>();

        public virtual ICollection<GetUserWebAppModel> Users { get; set; } = new List<GetUserWebAppModel>();


    }
}
