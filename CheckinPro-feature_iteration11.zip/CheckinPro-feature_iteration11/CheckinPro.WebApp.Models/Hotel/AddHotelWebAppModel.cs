﻿using System.ComponentModel.DataAnnotations;
using CheckinPro.Common.Models.Constants;

namespace CheckinPro.WebApp.Models
{
    public class AddHotelWebAppModel
    {
        [Required]
        public string? BusinessLLCName { get; set; }

        [Required]
        [RegularExpression(CommonConstants.CheckRegularExpression.EmailRegEx, ErrorMessage = CommonConstants.DataAnnotationsErrorMessages.Invalid_Email_Format_Error_Message)]
        public string? Email { get; set; }

        [Required]
        public string? MobileNumber { get; set; }

        [Required]
        public string? Address1 { get; set; }

        public string? Address2 { get; set; }

        public int? StateID { get; set; }

        [Required]
        public string? City { get; set; }

        [Required]
        public string? ZipCode { get; set; }

        public string? Website { get; set; }

        public string? Description { get; set; }

        public bool IsOwnerDashboardVisible { get; set; } = false;

        public UserinfoWebAppModel? Userinfo { get; set; }
    }

    public partial class UserinfoWebAppModel
    {
        [Required]
        public string? FirstName { get; set; }

        [Required]
        public string? LastName { get; set; }

        [Required]
        [RegularExpression(CommonConstants.CheckRegularExpression.EmailRegEx, ErrorMessage = CommonConstants.DataAnnotationsErrorMessages.Invalid_Email_Format_Error_Message)]
        public string? EmailID { get; set; }

        [Required]
        public string? MobileNumber { get; set; }

    }
}
