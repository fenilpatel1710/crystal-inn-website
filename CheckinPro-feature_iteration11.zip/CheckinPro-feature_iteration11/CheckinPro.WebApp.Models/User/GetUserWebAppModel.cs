﻿namespace CheckinPro.WebApp.Models
{
    public partial class GetUserWebAppModel
    {
        public int UserID { get; set; }

        public string RoleName { get; set; }

        public string FullName { get; set; }

        public string EmailID { get; set; }

        public string MobileNumber { get; set; }

        public string? Address { get; set; }

        public string? Address1 { get; set; }

        public string? Address2 { get; set; }

        public int? CountryID { get; set; }

        public int? StateID { get; set; }

        public string? City { get; set; }

        public string? ZipCode { get; set; }

        public string? ProfilePicture { get; set; }

        public DateTime? LastLoginDate { get; set; }

        public bool IsPasswordChanged { get; set; }

        public bool IsProfileActive { get; set; }

        public bool IsProfileBlocked { get; set; }

        public bool IsProfileDeleted { get; set; }
    }
}
