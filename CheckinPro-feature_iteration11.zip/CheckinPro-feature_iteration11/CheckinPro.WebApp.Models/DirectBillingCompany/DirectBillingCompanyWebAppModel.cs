﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.WebApp.Models
{
    public class DirectBillingCompanyWebAppModel
    {
        public int CompanyID { get; set; }

        public int HotelID { get; set; }

        [Required]
        public string? CompanyName { get; set; }

        public string? BillingAddress { get; set; }

        public string? MobileNumber { get; set; }

        public string? Email { get; set; }

        public string? ManagerFirstName { get; set; }

        public string? ManagerLastName { get; set; }

        public string? ManagerAddress { get; set; }

        public string? NameOnCreditCard { get; set; }

        public string? CreditCardNumber { get; set; }

        public DateOnly? ExpirationDate { get; set; }

        public string? SecurityCode { get; set; }

        public string? AccountNumber { get; set; }

        public string? RoutingNumber { get; set; }

        public string? Notes { get; set; }
    }
}
