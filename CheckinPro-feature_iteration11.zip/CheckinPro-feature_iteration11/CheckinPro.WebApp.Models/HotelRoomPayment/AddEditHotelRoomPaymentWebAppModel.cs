﻿
using System.ComponentModel.DataAnnotations;

namespace CheckinPro.WebApp.Models
{
    public class AddEditHotelRoomPaymentWebAppModel
    {
        public Guid PaymentLocalID { get; set; } = Guid.NewGuid();

        public int PaymentID { get; set; }

        public int HotelRoomBookingID { get; set; }

        public DateTime? PaymentDate { get; set; }

        public DateTime? PaymentCompletedOn { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "The value must be greater than 0.")]
        public decimal? Amount { get; set; }

        public decimal? UsedRewardPoint { get; set; }

        [Required]
        public string? PaymentMode { get; set; }


        [Required]
        public string? PaymentType { get; set; }


        [Required]
        public string? PaymentStatus { get; set; }

        public string? PaymentGateway { get; set; }

        public string? TransactionID { get; set; }

        //public string? TransactionType { get; set; }

        public bool IsRefunded { get; set; }

        public bool IsRefund { get; set; }

        public decimal? RefundAmount { get; set; }

        public DateTime? RefundDate { get; set; }

        public string? PaymentNotes { get; set; }

        public string? RefundNotes { get; set; }

        //public virtual HotelRoomBookingWebAppModel HotelRoomBooking { get; set; } = new HotelRoomBookingWebAppModel();
    }
}
