﻿
namespace CheckinPro.WebApp.Models
{
    public class GetDashboardWebAppModel
    {
        public int InHouseCount { get; set; }
        public int DirtyRoomCount { get; set; }
        public int PendingCheckOutCount { get; set; }
        public int CheckedOutCount { get; set; }
        public int ArrivalsCount { get; set; }
        public int Cancelled { get; set; }
        public int TotalRoomsCount { get; set; }
        public int OutOfServiceCount { get; set; }
        public int SoldCount { get; set; }
        public int AvailableRoomsCount { get; set; }
    }
}
