﻿
namespace CheckinPro.WebApp.Models
{
    public class GetHotelOwnerDashboardWebAppModel
    {
        public string Metrictype { get; set; }
        public DateOnly Date { get; set; }
        public int RoomSold { get; set; }
        public decimal Occupancy { get; set; }
        public decimal ADR { get; set; }
        public decimal RevPAR { get; set; }
        public decimal GrossRevenue { get; set; }
        public decimal TotalRevenue { get; set; }
        public decimal Cash { get; set; }
        public decimal Credit { get; set; }
        public decimal TotalPayments { get; set; }
    }
}
