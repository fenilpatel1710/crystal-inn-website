﻿namespace CheckinPro.WebApp.Models
{
    public  class GetHotelRoomRevenueWebAppModel
    {
        public string? MonthName { get; set; }

        public decimal? TotalRevenue { get; set; }
    }
}
