﻿

namespace CheckinPro.WebApp.Models
{
    public class UpdateGuestRequestWebAppModel
    {
        public int HotelRoomBookingID { get; set; }

        public string? GuestSpecialRequests { get; set; }

        public string? GuestNoteType { get; set; }

        public string? GuestNotes { get; set; }

    }
}
