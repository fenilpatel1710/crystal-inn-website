﻿namespace CheckinPro.WebApp.Models
{
    public class HotelRoomBookingTaxRateWebAppModel
    {
        public int HotelRoomBookingTaxRateID { get; set; }

        public int HotelRoomBookingID { get; set; }

        public int? HotelTaxRateID { get; set; }

        public string? BookingTaxRateName { get; set; }

        public decimal? BookingTaxRatePercentage { get; set; }

        public decimal? BookingTaxRate { get; set; }

        public bool IsBookingTaxRateActive { get; set; }

    }
}
