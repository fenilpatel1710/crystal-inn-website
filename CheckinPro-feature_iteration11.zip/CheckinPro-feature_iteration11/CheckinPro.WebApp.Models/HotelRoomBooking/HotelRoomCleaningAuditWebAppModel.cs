﻿namespace CheckinPro.WebApp.Models
{
    public class HotelRoomCleaningAuditWebAppModel
    {
        public int HotelRoomCleaningAuditID { get; set; }

        public int? HotelRoomBookingID { get; set; }

        public int? HotelRoomID { get; set; }

        public string? CheckOutComment { get; set; }

        public bool IsRoomClean { get; set; }

        public DateTime? ActionDateTime { get; set; }

        public string? ActionBy { get; set; }

        public string? ActionComment { get; set; }

        public string? RoomNumber { get; set; }

        public int? Floor { get; set; }

        public int? MaxOccupancy { get; set; }

        public string? RoomStatus { get; set; }

        public string? RoomTypeName { get; set; }
    }
}
