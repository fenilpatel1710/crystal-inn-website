﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.WebApp.Models
{
    public class GetHotelRoomBookingSearchListWebAppModel
    {
        public int HotelRoomBookingID { get; set; }
        public int? HotelRoomTypeID { get; set; }
        public int? HotelRoomID { get; set; }
        public string? BookingCode { get; set; }
        public string? GuestName { get; set; }
        public string? RoomType { get; set; }
        public string? RoomNumber { get; set; }
        public DateTime? ScheduledCheckInDate { get; set; }
        public DateTime? ScheduledCheckOutDate { get; set; }
        public decimal? RoomChargeAmount { get; set; }
        public decimal? Amount { get; set; }
        public decimal? TotalPaid { get; set; }
        public decimal? Balance { get; set; }
        public string? BookingStatus { get; set; }
        public bool IsHourlyBooking { get; set; }

    }
}
