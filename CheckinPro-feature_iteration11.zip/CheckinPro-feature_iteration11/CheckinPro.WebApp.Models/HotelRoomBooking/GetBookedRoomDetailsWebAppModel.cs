﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.WebApp.Models.HotelRoomBooking
{
    public class GetBookedRoomDetailsWebAppModel
    {
        public DateTime? ScheduledCheckInDate { get; set; }

        public DateTime? ScheduledCheckOutDate { get; set; }

        public string? RoomType { get; set; }

        public string? GuestName { get; set; }

        public string? RoomNumber { get; set; }

        public string? Duration { get; set; }

        public bool IsHourlyBooking { get; set; }

        public string? BookingStatus { get; set; }

        public string? PaymentStatus { get; set; }
    }
}
