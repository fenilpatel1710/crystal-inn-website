﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.WebApp.Models
{
    public class FindHotelRoomBookingWebAppModel
    {
        public int? HotelId { get; set; }
        public string? BookingCode { get; set; }
        public string? BookingStatus { get; set; }
        public int? HotelRoomTypeID { get; set; }
        public string? RoomNumber { get; set; }
        public string? GuestCode { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
