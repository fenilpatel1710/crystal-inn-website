﻿
namespace CheckinPro.WebApp.Models
{
    public class UpdateHotelRoomCleaningAuditWebAppModel
    {
        public int HotelRoomCleaningAuditID { get; set; }

        public int? HotelRoomBookingID { get; set; }

        public int? HotelRoomID { get; set; }

        public string? CheckOutComment { get; set; }

        public string? ActionComment { get; set; }

        public string? GuestNoteType { get; set; }

        public string? GuestNotes { get; set; }

        public bool IsRewardPointGiven { get; set; } = true;

        public decimal? EarnedRewardPoint { get; set; }
    }
}
