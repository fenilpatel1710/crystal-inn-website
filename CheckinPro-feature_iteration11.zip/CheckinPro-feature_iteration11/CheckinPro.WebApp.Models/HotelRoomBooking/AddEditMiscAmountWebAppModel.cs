﻿using System.ComponentModel.DataAnnotations;

namespace CheckinPro.WebApp.Models
{
    public class AddEditMiscAmountWebAppModel
    {
        public int HotelRoomBookingMiscellaneousID { get; set; }
        
        public int HotelRoomBookingID { get; set; }
        
        [Required]
        public DateTime? MiscellaneousDate { get; set; }
        
        [Required]
        [Range(0, int.MaxValue, ErrorMessage = "The value must be greater than 0.")]
        public decimal? MiscellaneousAmount { get; set; }
        
        public decimal? FinalAmount { get; set; }
    }
}
