﻿
namespace CheckinPro.WebApp.Models
{
    public class RoomChangeWebAppModel
    {
        public int HotelRoomBookingID { get; set; }

        public int HotelRoomTypeID { get; set; }

        public int? HotelRoomID { get; set; }

        public int? OldHotelRoomID { get; set; }

        public string? RoomNumber { get; set; }
    }
}
