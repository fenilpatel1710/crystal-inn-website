﻿namespace CheckinPro.WebApp.Models
{
    public class BookingListDataGridFlags
    {
        public bool isRoomNumberVisible { get; set; } = true;
        public bool isCheckInButtonVisible { get; set; }
        public bool isCheckOutButtonVisible { get; set; }
        public bool isCancelButtonVisible { get; set; }
    }
}
