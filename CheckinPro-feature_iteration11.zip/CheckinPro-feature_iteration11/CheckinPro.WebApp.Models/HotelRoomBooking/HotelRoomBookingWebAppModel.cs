﻿
using System.ComponentModel.DataAnnotations;

namespace CheckinPro.WebApp.Models
{
    public class HotelRoomBookingWebAppModel
    {
        public int HotelRoomBookingID { get; set; }

        public int HotelRoomTypeID { get; set; }

        public int? HotelRoomID { get; set; }

        public string? BookingCode { get; set; }

        public DateTime? ScheduledCheckInDate { get; set; }

        public DateTime? ScheduledCheckOutDate { get; set; }

        public int? Duration { get; set; }

        public DateTime? ActualCheckInDate { get; set; }

        public DateTime? ActualCheckOutDate { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "The value must be greater than 0.")]
        public int? CheckOutTime { get; set; }

        public int? NumberOfGuests { get; set; } = 2;

        public bool IsHourlyBooking { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "The value must be greater than 0.")]
        public decimal? HourlyRate { get; set; }

        public string? BookingStatus { get; set; }

        public string? GuestSpecialRequests { get; set; }

        public string? GuestNoteType { get; set; }

        public string? GuestNotes { get; set; }

        public bool IsBookingCancelled { get; set; }

        public string? CancellationReason { get; set; }

        public decimal? BestAvailableRate { get; set; }

        public decimal? AdjustmentRate { get; set; }

        public decimal? RoomChargeAmount { get; set; }

        public decimal? TotalAmount { get; set; }

        public bool IsDiscountedRate { get; set; }

        public string? AdditionalRateType { get; set; }

        public decimal? AdditionalRateAmount { get; set; }

        public decimal? DiscountedAmount { get; set; }

        public decimal? MiscellaneousAmount { get; set; }

        public decimal? FinalAmount { get; set; }

        public bool IsIncludedInReport { get; set; } = true;


        public virtual List<AddEditGuestWebAppModel> Guests { get; set; } = new List<AddEditGuestWebAppModel>();

        public virtual HotelRoomTypeWebAppModel HotelRoomType { get; set; } = new HotelRoomTypeWebAppModel();

        public virtual AddEditHotelRoomWebAppModel HotelRoom { get; set; } = new AddEditHotelRoomWebAppModel();

        public virtual ICollection<HotelRoomBookingRateDetailWebAppModel> HotelRoomBookingRateDetails { get; set; } = new List<HotelRoomBookingRateDetailWebAppModel>();

        public virtual ICollection<HotelRoomBookingAuditWebAppModel> HotelRoomBookingAudits { get; set; } = new List<HotelRoomBookingAuditWebAppModel>();

        public virtual ICollection<HotelRoomBookingTaxRateWebAppModel> HotelRoomBookingTaxRates { get; set; } = new List<HotelRoomBookingTaxRateWebAppModel>();

        public virtual ICollection<AddEditHotelRoomPaymentWebAppModel> HotelRoomPayments { get; set; } = new List<AddEditHotelRoomPaymentWebAppModel>();
    }
}
