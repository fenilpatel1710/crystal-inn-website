﻿namespace CheckinPro.WebApp.Models
{
    public class GetHotelRoomBookingWebAppModel
    {
        public int HotelRoomBookingID { get; set; }

        public int HotelRoomTypeID { get; set; }

        public int? HotelRoomID { get; set; }

        public string? BookingCode { get; set; }

        public DateTime? ScheduledCheckInDate { get; set; }

        public DateTime? ScheduledCheckOutDate { get; set; }

        public int? Duration { get; set; }

        public DateTime? ActualCheckInDate { get; set; }

        public DateTime? ActualCheckOutDate { get; set; }

        public int? NumberOfGuests { get; set; }

        public bool IsHourlyBooking { get; set; }      

        public decimal? TotalPaid { get; set; }

        public string? BookingStatus { get; set; }        

        public string? GuestSpecialRequests { get; set; }

        public string? GuestNoteType { get; set; }

        public string? GuestNotes { get; set; }

        public bool IsBookingCancelled { get; set; }

        public string? CancellationReason { get; set; }

        public bool IsIncludedInReport { get; set; }


        public virtual HotelRoomTypeWebAppModel HotelRoomType { get; set; } = new HotelRoomTypeWebAppModel();
        
        public virtual List<GetGuestWebAppModel> GetGuests { get; set; } = new List<GetGuestWebAppModel>();

        public virtual GetHoteRoomWebAppModel GetHotelRoom { get; set; } = new GetHoteRoomWebAppModel();

        public virtual ICollection<GetPaymentWebAppModel> GetPayments { get; set; } = new List<GetPaymentWebAppModel>();

        public virtual ICollection<HotelRoomBookingRateDetailWebAppModel> HotelRoomBookingRateDetails { get; set; } = new List<HotelRoomBookingRateDetailWebAppModel>();
    }
}
