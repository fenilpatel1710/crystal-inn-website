﻿namespace CheckinPro.WebApp.Models
{
    public class RoleWebAppModel
    {
        public int RoleID { get; set; }

        public string RoleName { get; set; }

        public string Description { get; set; }

        public bool IsRoleActive { get; set; }

        public virtual ICollection<GetUserWebAppModel> Users { get; set; } = new List<GetUserWebAppModel>();
    }
}
