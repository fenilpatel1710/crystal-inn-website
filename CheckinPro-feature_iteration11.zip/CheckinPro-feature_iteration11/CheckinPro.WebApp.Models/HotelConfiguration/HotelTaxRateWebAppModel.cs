﻿
using System.ComponentModel.DataAnnotations;

namespace CheckinPro.WebApp.Models
{
    public class HotelTaxRateWebAppModel
    {
        public int HotelTaxRateID { get; set; }

        public int HotelID { get; set; }

        [Required]
        public string? TaxName { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "The value must be greater than 0.")]
        public decimal? TaxRate { get; set; }

        public bool IsTaxRateActive { get; set; } = true;

        public virtual GetHotelWebAppModel Hotel { get; set; } = new GetHotelWebAppModel()!;
    }
}
