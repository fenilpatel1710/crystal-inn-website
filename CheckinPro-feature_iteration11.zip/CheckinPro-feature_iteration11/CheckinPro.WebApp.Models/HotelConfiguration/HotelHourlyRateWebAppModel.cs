﻿using System.ComponentModel.DataAnnotations;

namespace CheckinPro.WebApp.Models
{
    public class HotelHourlyRateWebAppModel
    {
        public int HotelHourlyRateID { get; set; }

        public int HotelID { get; set; }

        [Required]
        [Range(1,24, ErrorMessage = "Hours must be 1 to 24.")]
        public int? Hour { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "The value must be greater than 0.")]
        public decimal? HourlyRate { get; set; }

        public bool IsHotelHourlyRateActive { get; set; } = true;

        public virtual GetHotelWebAppModel Hotel { get; set; } = new GetHotelWebAppModel();
    }
}
