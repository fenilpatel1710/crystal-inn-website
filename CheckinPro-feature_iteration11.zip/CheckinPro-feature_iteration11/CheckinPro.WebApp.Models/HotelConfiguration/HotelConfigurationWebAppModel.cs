﻿using System.ComponentModel.DataAnnotations;

namespace CheckinPro.WebApp.Models
{
    public class HotelConfigurationWebAppModel
    {
        public int HotelMasterConfigurationID { get; set; }

        public int HotelID { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "The value must be greater than 0.")]
        public decimal? BestAvailableRate { get; set; }

        public decimal? CashDrawerAmount { get; set; }

    }
}
