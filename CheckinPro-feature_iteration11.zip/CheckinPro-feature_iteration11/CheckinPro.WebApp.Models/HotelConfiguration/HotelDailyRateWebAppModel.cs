﻿using System.ComponentModel.DataAnnotations;

namespace CheckinPro.WebApp.Models
{
    public class HotelDailyRateWebAppModel
    {
        public int HotelDailyRateID { get; set; }

        public int HotelID { get; set; }

        [Required]
        public DateOnly? DailyRateDate { get; set; }

        [Required]
        public DateOnly? StartDate { get; set; }

        [Required]
        public DateOnly? EndDate { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "The value must be greater than 0.")]
        public decimal? DailyBestAvailableRate { get; set; }

        public bool IsDailyRateActive { get; set; } = true;

        public virtual GetHotelWebAppModel Hotel { get; set; } = new GetHotelWebAppModel();
    }
}
