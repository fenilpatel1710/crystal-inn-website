﻿
using System.ComponentModel.DataAnnotations;

namespace CheckinPro.WebApp.Models
{
    public class HotelAdditionalRateWebAppModel
    {
        public int HotelAdditionalRateID { get; set; }

        public int HotelID { get; set; }

        [Required]
        public string? AdditionalRateName { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "The value must be greater than 0.")]
        public decimal? AdditionalRate { get; set; }

        public bool IsDiscountedRate { get; set; } = true;

        public bool IsAdditionalRateActive { get; set; } = true;

        public virtual GetHotelWebAppModel Hotel { get; set; } = new GetHotelWebAppModel();
    }
}
