﻿using System.ComponentModel.DataAnnotations;

namespace CheckinPro.WebApp.Models
{
    public class HotelRoomTypeWebAppModel
    {
        public int HotelRoomTypeID { get; set; }

        public int HotelID { get; set; }

        [Required]
        public string? RoomTypeName { get; set; }

        public string? Description { get; set; }

        public string? RoomTypeIcon { get; set; }

        public decimal? AdjustmentRate { get; set; }

        public bool IsHotelRoomTypeActive { get; set; } = true;

        public int NumberOfRoomsAvailable { get; set; }

        public int PendingRoomCleaning { get; set; }

        public int BookedRoom { get; set; }

        public virtual GetHotelWebAppModel Hotel { get; set; } = new GetHotelWebAppModel();
    }
}
