﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.WebApp.Models.Guest
{
    public class ScanJSONDocumentWebAppModel
    {
        public Dictionary<string, List<Item>> Data { get; set; }
    }

    public class Item
    {
        public string Item1 { get; set; }  // Column Name
        public string Item2 { get; set; }  // Data 
    }
}
