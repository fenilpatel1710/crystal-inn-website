﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.WebApp.Models
{
    public class GuestRewardWebAppModel
    {
        public int GuestRewardID { get; set; }

        public int? GuestID { get; set; }

        public int? HotelID { get; set; }

        public decimal? TotalRewardPoint { get; set; }
    }
}
