﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.WebApp.Models
{
    public class HotelExpenseWebAppModel
    {
        public int HotelExpenseID { get; set; }

        public int HotelID { get; set; }

        [Required]
        public DateOnly? ExpenseDate { get; set; }

        [Required]
        public string? ExpenseType { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "The value must be greater than 0.")]
        public decimal? ExpenseAmount { get; set; }

        public string? ExpenseDescription { get; set; }

        public byte[]? Attachment { get; set; } = null;
    }
}
