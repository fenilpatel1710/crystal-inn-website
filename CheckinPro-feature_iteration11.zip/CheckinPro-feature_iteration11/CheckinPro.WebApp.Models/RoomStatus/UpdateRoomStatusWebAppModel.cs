﻿namespace CheckinPro.WebApp.Models
{
    public partial class UpdateRoomStatusWebAppModel
    {
        public string? RoomStatusName { get; set; }

        public string? Description { get; set; }

        public string? RoomStatusIcon { get; set; }

        public bool IsActive { get; set; }

        public bool IsDeleted { get; set; }
    }
}