﻿
namespace CheckinPro.WebApp.Models
{
    public partial class GetRoomStatusWebAppModel
    {
        public int RoomStatusID { get; set; }

        public string RoomStatusName { get; set; } = null!;

        public string? Description { get; set; }

        public string? RoomStatusIcon { get; set; }

        public bool IsActive { get; set; }

        public bool IsDeleted { get; set; }
    }
}