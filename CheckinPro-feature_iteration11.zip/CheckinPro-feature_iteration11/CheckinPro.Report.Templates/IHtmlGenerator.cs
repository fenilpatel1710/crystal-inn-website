﻿namespace CheckinPro.Report.Templates
{
    public interface IHtmlGenerator
    {
        Task<string> getBookingReceiptHTML(BookingReceiptHTMLModel bookingReceipt);

        Task<string> getBookingInvoiceHTML(BookingInvoiceHTMLModel bookingInvoice);

        Task<string> getDailyAuditReportHTML(DailyAuditReportHTMLModel dailyAuditReportHTMLModel);

        Task<string> getRoomTaxCollectedReportHTML(RoomTaxCollectedHTMLModel roomTaxCollectedHTMLModel);

        Task<string> getSummaryIncomeReportHTML(SummaryIncomeReportHTMLModel summaryIncomeReportHTMLModel);

        Task<string> getRoomRevenueReportHTML(RoomRevenueReportHTMLModel roomRevenueReportHTMLModel);

        Task<string> getIncomeBreakdownReportHTML(IncomeBreakdownReportHTMLModel incomeBreakdownReportHTMLModel);

        Task<string> getShiftReportHTML(ShiftReportHTMLModel shiftReportHTMLModel);

        Task<string> getStatisticReportHTML(SummaryIncomeReportHTMLModel summaryIncomeReportHTMLModel);
    }
}
