﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.Report.Templates
{
    public class BookingReceiptHTMLModel
    {
        public HotelHTMLModel hotelHTMLModel { get; set; } = new HotelHTMLModel();

        public int? ShiftNo { get; set; }
        public string? RoomNumber { get; set; }
        public string? GuestName { get; set; }
        public string? GuestCode { get; set; }
        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? Country { get; set; }
        public string? State { get; set; }
        public string? City { get; set; }
        public string? ZipCode { get; set; }
        public string? BookingCode { get; set; }
        public DateTime? ScheduledCheckInDate { get; set; }
        public DateTime? ScheduledCheckOutDate { get; set; }
        public int? Duration { get; set; }
        public DateTime? ActualCheckInDate { get; set; }
        public DateTime? ActualCheckOutDate { get; set; }
        public int? CheckOutTime { get; set; }
        public int? NumberOfGuests { get; set; }
        public bool IsHourlyBooking { get; set; }
        public decimal? BestAvailableRate { get; set; }
        public decimal? AdjustmentRate { get; set; }
        public decimal? HourlyRate { get; set; }
        public decimal? SubTotalAmount { get; set; }
        public decimal? TotalAmount { get; set; }
        public string? AdditionalRateType { get; set; }
        public decimal? AdditionalRateAmount { get; set; }
        public decimal? DiscountedAmount { get; set; }
        public decimal? MiscellaneousAmount { get; set; }
        public decimal? FinalAmount { get; set; }
        public decimal? Tax { get; set; }
        public decimal? Total { get; set; }
        public decimal? Cash { get; set; }
        public decimal? Credit { get; set; }
        public decimal? Reward { get; set; }
        public decimal? Payment { get; set; }
        public decimal? Balance { get; set; }
        public decimal? Refund { get; set; }
    }
}
