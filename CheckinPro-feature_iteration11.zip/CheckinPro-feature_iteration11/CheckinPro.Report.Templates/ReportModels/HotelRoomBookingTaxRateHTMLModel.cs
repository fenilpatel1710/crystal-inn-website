﻿namespace CheckinPro.Report.Templates
{
    public class HotelRoomBookingTaxRateHTMLModel
    {
        public string? BookingTaxRateName { get; set; }
        public decimal? BookingTaxRatePercentage { get; set; }
        public decimal? BookingTaxRate { get; set; }
    }
}
