﻿namespace CheckinPro.Report.Templates
{
    public class ShiftReportHTMLModel
    {
        public DateOnly? FromDate { get; set; }
        public DateOnly? ToDate { get; set; }
        public HotelHTMLModel hotelHTMLModel { get; set; } = new HotelHTMLModel();
        public List<ShiftHTMLModel> shiftHTMLModels { get; set; } = new List<ShiftHTMLModel>();
        public ShiftHTMLModel shiftHTMLModel { get; set; } = new ShiftHTMLModel();
    }

    public class ShiftHTMLModel
    {
        public int? ShiftNo { get; set; }
        public DateTime? ShiftStartDate { get; set; }
        public DateTime? ShiftEndDate { get; set; }
        public string? ShiftOwnerName { get; set; }
        public string? BookingCode { get; set; }
        public string? RoomNumber { get; set; }
        public string? GuestName { get; set; }
        public DateTime? ScheduledCheckInDate { get; set; }
        public int? Duration { get; set; }
        public string? PaymentType { get; set; }
        public decimal? Cash { get; set; }
        public decimal? Credit { get; set; }
        public decimal? Reward { get; set; }
        public decimal? RefundAmount { get; set; }
    }
}
