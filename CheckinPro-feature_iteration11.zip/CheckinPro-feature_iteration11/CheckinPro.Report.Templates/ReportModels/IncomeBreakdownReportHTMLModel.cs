﻿using System;
namespace CheckinPro.Report.Templates
{
    public class IncomeBreakdownReportHTMLModel
    {
        public DateOnly? FromDate { get; set; }
        public DateOnly? ToDate { get; set; }
        public HotelHTMLModel hotelHTMLModel { get; set; } = new HotelHTMLModel();
        public List<IncomeBreakdownHTMLModel>? incomeBreakdownHTMLModels { get; set; } = new List<IncomeBreakdownHTMLModel>();
        public IncomeBreakdownHTMLModel? incomeBreakdownHTMLModel { get; set; } = new IncomeBreakdownHTMLModel();
    }

    public class IncomeBreakdownHTMLModel
    {
        public DateOnly? Date { get; set; }
        public decimal? Cash { get; set; }
        public decimal? MiscellaneousAmount { get; set; }
        public decimal? NetCash { get; set; }
        public decimal? Credit { get; set; }
        public decimal? Reward { get; set; }
        public decimal? Total { get; set; }
        public List<HotelRoomBookingTaxRateHTMLModel>? hotelRoomBookingTaxRateHTMLModels { get; set; } = new List<HotelRoomBookingTaxRateHTMLModel>();
    }
}
