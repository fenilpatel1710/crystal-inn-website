﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.Report.Templates
{
    public class BookingInvoiceHTMLModel
    {
        public int? HotelRoomBookingID { get; set; }
        public string? RoomTypeName { get; set; }
        public string? RoomNumber { get; set; }
        public int? Floor { get; set; }
        public DateTime? ScheduledCheckInDate { get; set; }
        public DateTime? ScheduledCheckOutDate { get; set; }
        public DateTime? ActualCheckInDate { get; set; }
        public int? Duration { get; set; }
        public int? NumberOfGuests { get; set; }
        public bool IsHourlyBooking { get; set; }
        public decimal? BestAvailableRate { get; set; }
        public decimal? AdjustmentRate { get; set; }
        public decimal? HourlyRate { get; set; }
        public decimal? SubTotalAmount { get; set; }
        public decimal? TotalAmount { get; set; }
        public string? AdditionalRateType { get; set; }
        public decimal? AdditionalRateAmount { get; set; }
        public decimal? DiscountedAmount { get; set; }
        public decimal? MiscellaneousAmount { get; set; }
        public decimal? FinalAmount { get; set; }
        public string? BookingStatus { get; set; }
        public string? GuestName { get; set; }
        public string? GuestCode { get; set; }
        public HotelHTMLModel hotelHTMLModel { get; set; } = new HotelHTMLModel();
        public List<HotelRoomBookingTaxRateHTMLModel>? hotelRoomBookingTaxRateHTMLModels { get; set; } = new List<HotelRoomBookingTaxRateHTMLModel>();
        public List<BookingPaymentHTMLModel>? bookingPaymentHTMLModels { get; set; } = new List<BookingPaymentHTMLModel>();
    }

    public class BookingPaymentHTMLModel
    {
        public DateTime? PaymentDate { get; set; }

        public decimal? Amount { get; set; }

        public string? PaymentMode { get; set; }

        public string PaymentStatus { get; set; }

        public string? PaymentGateway { get; set; }

        public string? TransactionID { get; set; }

        public string? TransactionType { get; set; }

        public bool IsRefunded { get; set; }

        public decimal? RefundAmount { get; set; }

        public DateTime? RefundDate { get; set; }

        public string? PaymentNotes { get; set; }

        public string? RefundNotes { get; set; }
    }
}
