﻿namespace CheckinPro.Report.Templates
{
    public class DailyAuditReportHTMLModel
    {
        public DateOnly? FromDate { get; set; }
        public DateOnly? ToDate { get; set; }
        public HotelHTMLModel hotelHTMLModel { get; set; } = new HotelHTMLModel();
        public List<DailyAuditReportBookingSummary>? dailyAuditReportBookingSummaries { get; set; } = new List<DailyAuditReportBookingSummary>();
        public DailyAuditReportTotalSummary? dailyAuditReportTotalSummary { get; set; } = new DailyAuditReportTotalSummary();
        public DailyAuditReportSummary? dailyAuditReportSummary { get; set; } = new DailyAuditReportSummary();
        public DailyAuditReportTaxSummary? dailyAuditReportTaxSummary { get; set; } = new DailyAuditReportTaxSummary();
    }

    public class DailyAuditReportBookingSummary
    {
        public DateOnly? BookingDate { get; set; }
        public int Rented { get; set; }
        public int HourlyRented { get; set; }
        public string? BookingCode { get; set; }
        public string? RoomNumber { get; set; }
        public string? GuestName { get; set; }
        public string? GuestCode { get; set; }
        public string? IdentityNumber { get; set; }
        public DateTime? ScheduledCheckInDate { get; set; }
        public DateTime? ScheduledCheckOutDate { get; set; }
        public string? Duration { get; set; }
        public string? PaymentType { get; set; }
        public decimal? RoomChargeAmount { get; set; }
        public decimal? Tax { get; set; }
        public decimal? MiscellaneousAmount { get; set; }
        public decimal? Total { get; set; }
        public decimal? Cash { get; set; }
        public decimal? Credit { get; set; }
        public decimal? Reward { get; set; }
        public decimal? Payment { get; set; }
        public decimal? Balance { get; set; }
        public decimal? TaxableRevenue { get; set; }
        public decimal? NonTaxableRevenue { get; set; }
        public decimal? PartialTaxableRevenue { get; set; }
        public int? TaxStatus { get; set; }
        public bool IsRefunded { get; set; }
        public List<HotelRoomBookingTaxRateHTMLModel>? hotelRoomBookingTaxRateHTMLModels { get; set; } = new List<HotelRoomBookingTaxRateHTMLModel>();
    }

    public class DailyAuditReportTotalSummary
    {
        public int TotalRented { get; set; }
        public int TotalHourlyRented { get; set; }
        public decimal? TotalRoomCharge { get; set; }
        public decimal? TotalTax { get; set; }
        public decimal? TotalMiscellaneous { get; set; }
        public decimal? Total { get; set; }
        public decimal? TotalCash { get; set; }
        public decimal? TotalCreditCards { get; set; }
        public decimal? TotalReward { get; set; }
        public decimal? TotalPayment { get; set; }
        public decimal? TotalBalance { get; set; }
    }

    public class DailyAuditReportSummary
    {
        public decimal? TotalCash { get; set; }
        public decimal? TotalCheck { get; set; }
        public decimal? TotalCreditCards { get; set; }
        public decimal? TotalRefunds { get; set; }
        public decimal? Total { get; set; }
    }

    public class DailyAuditReportTaxSummary
    {
        public decimal? TaxableRevenue { get; set; }
        public decimal? NonTaxableRevenue { get; set; }
        public decimal? PartialTaxableRevenue { get; set; }
        public int? Rented { get; set; }
        public int? HourlyRented { get; set; }
        public decimal? ADR { get; set; }
        public decimal? OCC { get; set; }
        public int? CheckIn { get; set; }
        public int? CheckOut { get; set; }
        public int? StayOvers { get; set; }
        public int? OverStayed { get; set; }
        public int? TotalRoom { get; set; }
        public decimal? ExpenseAmount { get; set; }
        public List<HotelRoomBookingTaxRateHTMLModel>? hotelRoomBookingTaxRateHTMLModels { get; set; } = new List<HotelRoomBookingTaxRateHTMLModel>();
    }
}
