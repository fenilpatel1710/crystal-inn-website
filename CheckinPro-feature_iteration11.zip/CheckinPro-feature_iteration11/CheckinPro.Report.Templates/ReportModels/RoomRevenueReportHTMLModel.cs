﻿
namespace CheckinPro.Report.Templates
{
    public class RoomRevenueReportHTMLModel
    {
        public DateOnly? FromDate { get; set; }
        public DateOnly? ToDate { get; set; }
        public HotelHTMLModel hotelHTMLModel { get; set; } = new HotelHTMLModel();
        public List<RoomRevenueHTMLModel>? roomRevenueHTMLModels { get; set; } = new List<RoomRevenueHTMLModel>();
        public RoomRevenueHTMLModel? roomRevenueHTMLModel { get; set; } = new RoomRevenueHTMLModel();

    }

    public class RoomRevenueHTMLModel
    {
        public DateOnly? Date { get; set; }
        public decimal? GrossRevenue { get; set; }
        public decimal? TaxableRevenue { get; set; }
        public decimal? NonTaxableRevenue { get; set; }
        public decimal? PartialTaxableRevenue { get; set; }
        public decimal? Tax { get; set; }
        public decimal? MiscellaneousAmount { get; set; }
        public decimal? Total { get; set; }
        public int? OCC_Rooms { get; set; }
        public decimal? OCC_Rate { get; set; }
        public decimal? ADR { get; set; }
        public decimal? Rev_Par { get; set; }
        public List<HotelRoomBookingTaxRateHTMLModel>? hotelRoomBookingTaxRateHTMLModels { get; set; } = new List<HotelRoomBookingTaxRateHTMLModel>();
    }
}
