﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.Report.Templates
{
    public class SummaryIncomeReportHTMLModel
    {
        public DateOnly? FromDate { get; set; }
        public DateOnly? ToDate { get; set; }
        public HotelHTMLModel hotelHTMLModel { get; set; } = new HotelHTMLModel();
        public List<SummaryIncomeHTMLModel> summaryIncomeHTMLModels { get; set; } = new List<SummaryIncomeHTMLModel>();

        public SummaryIncomeHTMLModel summaryIncomeHTMLModel = new SummaryIncomeHTMLModel();

        public SummaryIncomeTaxBreakdownSummary summaryIncomeTaxBreakdownSummary = new SummaryIncomeTaxBreakdownSummary();
    }

    public class SummaryIncomeHTMLModel
    {
        public DateOnly? Date { get; set; }
        public int? Rooms { get; set; }
        public decimal? TaxableRevenue { get; set; }
        public decimal? NonTaxableRevenue { get; set; }
        public decimal? PartialTaxableRevenue { get; set; }
        public decimal? Gross { get; set; }
        public decimal? Tax { get; set; }
        public decimal? MiscellaneousAmount { get; set; }
        public decimal? Total { get; set; }
        public decimal? Cash { get; set; }
        public decimal? Credit { get; set; }
        public decimal? Reward { get; set; }
        public decimal? Payment { get; set; }
        public decimal? Balance { get; set; }
    }

    public class SummaryIncomeTaxBreakdownSummary
    {
        public decimal? TaxableRevenue { get; set; }
        public decimal? NonTaxableRevenue { get; set; }
        public decimal? PartialTaxableRevenue { get; set; }
        public int? Rented { get; set; }
        public decimal? ADR { get; set; }
        public decimal? OCC { get; set; }
        public List<HotelRoomBookingTaxRateHTMLModel>? hotelRoomBookingTaxRateHTMLModels { get; set; } = new List<HotelRoomBookingTaxRateHTMLModel>();
    }
}
