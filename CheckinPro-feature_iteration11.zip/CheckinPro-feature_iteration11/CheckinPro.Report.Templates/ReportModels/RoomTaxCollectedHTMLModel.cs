﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckinPro.Report.Templates
{
    public class RoomTaxCollectedHTMLModel
    {
        public DateOnly? FromDate { get; set; }
        public DateOnly? ToDate { get; set; }
        public HotelHTMLModel hotelHTMLModel { get; set; } = new HotelHTMLModel();
        public List<RoomTaxHTMLModel> roomTaxHTMLModels { get; set; } = new List<RoomTaxHTMLModel>();
        public RoomTaxHTMLModel roomTaxTotalHTMLModel { get; set; } = new RoomTaxHTMLModel();
    }

    public class RoomTaxHTMLModel
    {
        public DateOnly? Date { get; set; }
        public int? Rooms { get; set; }
        public decimal? RoomChargeAmount { get; set; }
        public decimal? Total { get; set; }
        public int? TaxStatus { get; set; }
        public List<HotelRoomBookingTaxRateHTMLModel> hotelRoomBookingTaxRateHTMLModels { get; set; } = new List<HotelRoomBookingTaxRateHTMLModel>();
    }
}
