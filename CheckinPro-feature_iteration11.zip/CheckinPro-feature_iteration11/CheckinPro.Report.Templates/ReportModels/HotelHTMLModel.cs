﻿using System;

namespace CheckinPro.Report.Templates
{
    public class HotelHTMLModel
    {
        public string? BusinessLLCName { get; set; }
        public string? HotelCode { get; set; }
        public string? Email { get; set; }
        public string? MobileNumber { get; set; }
        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? Country { get; set; }
        public string? State { get; set; }
        public string? City { get; set; }
        public string? ZipCode { get; set; }
    }
}
