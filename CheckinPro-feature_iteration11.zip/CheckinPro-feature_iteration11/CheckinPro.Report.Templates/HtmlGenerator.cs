﻿using CheckinPro.Report.Templates.HtmlTemplate;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace CheckinPro.Report.Templates
{
    public class HtmlGenerator : IHtmlGenerator
    {
        private readonly IServiceProvider _services;

        public HtmlGenerator(IServiceProvider services)
        {
            _services = services;
        }

        public async Task<string> getBookingReceiptHTML(BookingReceiptHTMLModel bookingReceipt)
        {
            var receiptHTML = await getHTML<BookingReceiptHTMLModel, BookingReceipt>(bookingReceipt);
            return receiptHTML;
        }

        public async Task<string> getBookingInvoiceHTML(BookingInvoiceHTMLModel bookingInvoice)
        {
            var invoiceHTML = await getHTML<BookingInvoiceHTMLModel, BookingInvoice>(bookingInvoice);
            return invoiceHTML;
        }

        public async Task<string> getDailyAuditReportHTML(DailyAuditReportHTMLModel dailyAuditReportHTMLModel)
        {
            var dailyAuditReportHTML = await getHTML<DailyAuditReportHTMLModel, DailyAuditReport>(dailyAuditReportHTMLModel);
            return dailyAuditReportHTML;
        }

        public async Task<string> getRoomTaxCollectedReportHTML(RoomTaxCollectedHTMLModel roomTaxCollectedHTMLModel)
        {
            var roomTaxCollectedReportHTML = await getHTML<RoomTaxCollectedHTMLModel, RoomTaxCollectedReport>(roomTaxCollectedHTMLModel);
            return roomTaxCollectedReportHTML;
        }

        public async Task<string> getSummaryIncomeReportHTML(SummaryIncomeReportHTMLModel summaryIncomeReportHTMLModel)
        {
            var summaryIncomeReportHTML = await getHTML<SummaryIncomeReportHTMLModel, SummaryIncomeReport>(summaryIncomeReportHTMLModel);
            return summaryIncomeReportHTML;
        }

        public async Task<string> getRoomRevenueReportHTML(RoomRevenueReportHTMLModel roomRevenueReportHTMLModel)
        {
            var roomRevenueReportHTML = await getHTML<RoomRevenueReportHTMLModel, RoomRevenueReport>(roomRevenueReportHTMLModel);
            return roomRevenueReportHTML;
        }

        public async Task<string> getIncomeBreakdownReportHTML(IncomeBreakdownReportHTMLModel incomeBreakdownReportHTMLModel)
        {
            var incomeBreakdownReportHTML = await getHTML<IncomeBreakdownReportHTMLModel, IncomeBreakdownReport>(incomeBreakdownReportHTMLModel);
            return incomeBreakdownReportHTML;
        }

        public async Task<string> getShiftReportHTML(ShiftReportHTMLModel shiftReportHTMLModel)
        {
            var shiftReportHTML = await getHTML<ShiftReportHTMLModel, ShiftReport>(shiftReportHTMLModel);
            return shiftReportHTML;
        }

        public async Task<string> getStatisticReportHTML(SummaryIncomeReportHTMLModel summaryIncomeReportHTMLModel)
        {
            var summaryIncomeReportHTML = await getHTML<SummaryIncomeReportHTMLModel, SummaryIncomeReport>(summaryIncomeReportHTMLModel);
            return summaryIncomeReportHTML;
        }

        private async Task<string> getHTML<T, TComponent>(T dto) where TComponent : IComponent
        {
            var loggerFactory = _services.GetRequiredService<ILoggerFactory>(); // Get logger
            await using var htmlRenderer = new HtmlRenderer(_services, loggerFactory); // Use _services for DI
            var html = await htmlRenderer.Dispatcher.InvokeAsync(async () =>
            {
                var dictionary = new Dictionary<string, object?>
                {
                    { "dto", dto }
                };

                var parameters = ParameterView.FromDictionary(dictionary);
                var output = await htmlRenderer.RenderComponentAsync<TComponent>(parameters);
                return output.ToHtmlString();
            });
            return html;
        }
    }
}
