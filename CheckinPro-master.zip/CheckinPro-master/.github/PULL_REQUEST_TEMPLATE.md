# Pull Request Title

<!-- Briefly describe what this pull request does. -->

## Description

<!-- What changes did you make? Why did you make them? -->

## Related Issue

<!-- If this PR addresses an issue, link it here (e.g., #123). -->

## What type of change is this?

Please select one or more:

- [ ] **Bug fix**  
  (Fixes a problem in the code.)

- [ ] **New feature**  
  (Adds a new feature to the application.)

- [ ] **Documentation update**  
  (Updates existing documentation or adds new documentation.)

- [ ] **Code improvement**  
  (Refactors or improves existing code without changing its behavior.)

- [ ] **Other**  
  (Any other changes. Please describe.)

## Checklist

- [ ] I have read the [contributing guidelines](link-to-guidelines).
- [ ] My code follows the project's coding style.
- [ ] I have tested my changes and they work.
- [ ] I have updated any necessary documentation.

## Screenshots (if applicable)

<!-- Add screenshots if your changes include visual updates. -->

## Additional Comments

<!-- Any other information you want to share. -->
